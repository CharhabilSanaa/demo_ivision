<?php
include "lib/auth/config.php";

?>

<!DOCTYPE html>
<html lang="<?php echo $lang['lang'] ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php
    include 'header_star.php';
    ?>

</head>
<?php

if (((isset($_SESSION['user']))&&(verif_user($_SESSION['user'],$_SESSION['mdp'])==true)) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true) || (verif_habilitation($_SESSION['autorisation_projet'],24)==true))):?>

    <body class="c-app flex-row align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 text-center">
                <span class="display-1 d-block">404</span>
                <div class="mb-4 lead"><?php echo $lang['404_erreur'] ?></div>
                <a href="start.php" class="btn btn-link"><?php echo $lang['back_home'] ?></a>
            </div>
        </div>
    </div>
    <!-- CoreUI and necessary plugins-->
    <script src="vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
    <!--[if IE]><!-->
    <script src="vendors/@coreui/icons/js/svgxuse.min.js"></script>
    <!--<![endif]-->


    </body>

<?php
else:
    header("location: index.php");
endif

?>
</html>
