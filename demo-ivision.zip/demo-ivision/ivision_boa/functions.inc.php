<?php

function ColorWhite(float $Alpha = 100)
{
    return new pChart\pColor(0,0,0,$Alpha);
}

function ColorBlack(float $Alpha = 100)
{
    return new pChart\pColor(0,0,0,$Alpha);
}

function Colorgreen(float $Alpha = 100)
{
    return new pChart\pColor(30,40,50,$Alpha);
}
