<?php
include "lib/auth/config.php";

?>
<!DOCTYPE html>
<html lang="<?php echo $lang['lang'];?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php include 'header_star.php'; ?> 

</head>
<?php

if (verif_user($_SESSION['user'],$_SESSION['mdp'])==true): ?>
    <?php if ((verif_user($_SESSION['user'],$_SESSION['mdp'])==true) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true))): ?>

        <?php
        if(empty($_POST['recherche'])){$_POST['recherche']="";}
        if(empty($_GET['page'])){$_GET['page']="";}
        ?>

        <body class="c-app">

        <?php
        include 'sidebar.php';

        $date_month= date("Y-m");
        $date_today= date("Y-m-d", strtotime("-1 day"));
        $date= date("Y-m-d", strtotime("-15 day"));
        setlocale(LC_TIME, 'fr_FR.utf8', 'fra');
        ?>
        <div class="c-wrapper c-fixed-components">
            <?php  include 'navbar_star.php'; ?>
            <div class="c-body">
                <main class="c-main">
                    <div class="container-fluid">
                        <div class="fade-in">
                            <input type="hidden" id="hdnSession" data-value="21"/>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="start.php">I-Vision</a></li>
                                    <li class="breadcrumb-item"><a href="start.php"><?php echo $lang['bank'];?></a></li>
                                    <li class="breadcrumb-item" aria-current="page"><?php echo $lang['incid_ouv'];?></li>
                                </ol>
                            </nav>

                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <form action="" method="post" role="search" >
                                                <div class="row d-flex justify-content-between">
                                                    <div class="col-md-6 search-box">
                                                        <input class="form-control" id="recherche" name="recherche"  value="<?php echo $_POST['recherche'];  ?>" type="text" placeholder="<?php echo $lang['saer_ter_lib'];  ?>" >
                                                    </div>
                                                    <div class="col-md-2 search-box">
                                                        <button class="btn btn-block btn-outline-primary my-2 my-sm-0" type="submit"><?php echo $lang['search'];  ?>
                                                            <svg class="c-icon float-right">
                                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-search"></use>
                                                            </svg>
                                                        </button>
                                                    </div>
                                                    <div></div>
                                                    <div></div>
                                                    <div></div>
                                                    <div class="btn-toolbar d-none d-md-block float-right text-center " role="toolbar" aria-label="Toolbar with buttons" title="<?php echo $lang['dur_rapp'];?>">

                                                        <div class="btn-group btn-group-toggle mx-3" >
                                                            <label class="btn btn-secondary">
                                                                <div class="float-right"><?php echo $lang['infe_a'];?> 2H
                                                                    <span class="badge badge-pill badge-success">- 2H</span>
                                                                </div>
                                                            </label>
                                                            <label class="btn btn-secondary active">
                                                                <div class="float-right"><?php echo $lang['sup_a'];?> 2H
                                                                    <span class="badge badge-pill badge-warning">+ 2H</span>
                                                                </div>
                                                            </label>
                                                            <label class="btn btn-secondary">
                                                                <div class="float-right"><?php echo $lang['sup_a'];?> 4H
                                                                    <span class="badge badge-pill badge-danger">+ 4H</span>
                                                                </div>
                                                            </label>
                                                        </div>

                                                    </div>
                                                    <!--<div class="col-md-4 float-right">
                                                        <div class="float-right">Inf à 2H
                                                            <span class="badge badge-pill badge-success">- 2H</span>
                                                        </div><br>
                                                        <div class="float-right">Sup à 2H
                                                            <span class="badge badge-pill badge-warning">+ 2H</span>
                                                        </div><br>
                                                        <div class="float-right">Sup à 4H
                                                            <span class="badge badge-pill badge-danger">+ 4H</span>
                                                        </div><br>
                                                    </div>-->
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">

                                        <div class="card-header"><i class="fa fa-align-justify"></i> <?php echo $lang['mod_adm_inc_ouv'];?></div>
                                        <div class="card-body">
                                            <?php

                                            if ((verif_habilitation($_SESSION['habilitation_backoffice'],21)==true)):
                                                include("pagination.php");
                                                all_incident_ouvert($_POST['recherche'],$lang);
                                            else:
                                                 echo '<div class="alert alert-danger text-center" role="alert">PAGE UNAUTHORIZED !!</div>';
                                            endif
                                            ?>

                                        </div>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.col-lg-4 (nested) -->

                                <!-- /.col-lg-8 (nested) -->
                            </div>

                        </div>
                    </div>
                </main>
            </div>

        </div>

        <?php

        //header NAV Bar
        include 'footer.php';

        ?>



        </body>

    <?php
    else:
        header("location: start.php");
    endif ?>
<?php
else:
    header("location: index.php");
endif ?>
</html>
