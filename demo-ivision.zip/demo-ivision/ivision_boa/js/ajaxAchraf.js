﻿$(document).ready(function() {
    //get token from localStorage
    token = localStorage.getItem('token');
    var  sessionValue= $("#hdnSession").data('value');

    if (!token)
    {
        //if token is not exists then redirect to index.html
        $('.error-jwt').append('<div class="alert alert-danger text-center" role="alert">PAGE UNAUTHORIZED !!</div>');
        location.href = "logout.php";
    }
    doCheckToken();
    CheckautorisationToken(token,sessionValue);
});


function logout() {
    localStorage.removeItem('token');
}

function doCheckToken() {
    $.ajax({
        type: 'GET',
        headers: {
            'x-access-token': token
        },
        url: 'lib/auth/doValidateToken.php',
        dataType: 'JSON',
        success: function(response) {
            //  alert(response.jwt.token);
            if (response.status) {
                token = response.jwt.token;
                localStorage.setItem('token', token);
            } else {

                localStorage.removeItem('token');
                 location.href = "logout.php";
            }
        }
    });
}
function CheckautorisationToken(token,idhabilitation) {
    $.ajax({
        type: 'GET',

        headers: {
            'x-access-token': token
        },
        data: {
            idhabilitation: idhabilitation
        },
        url: 'lib/auth/CheckautorisationToken.php',
        dataType: 'JSON',
        success: function(response) {
            //   alert(response.message.message);
            if (!response.status) {
                //  location.href = "PAGE_401.php";
                localStorage.removeItem('token');
            }
        }
    });
}

$(document).ready(function() {

    var table = $('#table_id').DataTable( {
            deferRender:    true,
            scrollY:        true,
            scrollX : true,
            fixedColumns: true,
            scrollCollapse: true,
            scroller:       true,
            stateSave:      true,

            "paging": false,
            "info":     false,
            dom: 'Bflr<"table-filter-container">tip',

            initComplete: function(settings){
                var api = new $.fn.dataTable.Api( settings );
                $('.table-filter-container', api.table().container()).append(
                    $('#table-filter').detach().show()
                );

                $('#table-filter select').on('change', function(){
                    table.search(this.value).draw();
                });
            },

            columnDefs: [
                {
                    targets: 0,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                },{
                    targets: 1,
                    className: 'noVis'

                },{
                    targets: 2,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                },{
                    targets: 3,
                    className: 'noVis'
                },{
                    targets: 4,
                    className: 'noVis',

                },{
                    targets: 5,
                    visible: false,
                    searchable: false,
                    orderable:false
                },{
                    targets: 6,
                    visible: false,
                    searchable: false,
                    orderable:false
                },{
                    targets: 7,
                    className: 'noVis',
                    searchable: false
                },{
                    targets: 8,
                    className: 'noVis',
                    searchable: false
                },{
                    targets: 9,
                    className: 'noVis',
                    searchable: false
                },{
                    targets: 10,
                    className: 'noVis',
                    orderable:false,
                    searchable: false,
                },{
                    targets: 11,
                    className: 'noVis',
                    orderable:false,
                    searchable: false,
                },{
                    targets: 12,
                    className: 'noVis',
                    searchable: false,
                    orderable:false

                },{
                    targets: 13,
                    visible: false,
                    className: 'noVis',
                    orderable:false
                }
            ],
            order: [ 3, 'asc' ],
            buttons: [
                {
                    extend: 'colvis',
                    text:      '<i class="fa fa-cog" align="right" title="Visibilité des colonnes"></i>',
                    columns: ':not(.noVis)'
                }
            ],
            language: {
                searchPlaceholder: "Recherche ..."
            },
            oLanguage: {
                sSearch: " ",
            },

            drawCallback: function( settings ) {
                // Reset margin to 0 after datatable render
                var ele = document.querySelector('div.dataTables_scrollBody .text-warning');
                if(ele){
                    ele.style.visibility = "hidden";
                }
            }
        }
    );

    $('a.toggle-vis').on( 'click', function (e) {
        e.preventDefault();

        // Get the column API object
        var column = table.column( $(this).attr('data-column') );

        // Toggle the visibility
        column.visible( ! column.visible() );
    } );
} );


$(document).ready(function() {

    $('#table_id_v2').on('init.dt', function() {

        $('.data-new_workorder')
            .attr('data-toggle', 'modal')
            .attr('data-target', '#detailTrait_Mass')
            .attr('onclick', 'javascript:getTraitMassive()');
    });

    var table = $('#table_id_v2').DataTable( {
            deferRender:    true,
            scrollY:        true,
            scrollX : true,
            fixedColumns: true,
            scrollCollapse: true,
            scroller:       true,
            stateSave:      true,
            orderCellsTop: true,
            fixedHeader: true,

            "paging": false,
            "info":     false,
            dom: 'Bflr<"table-filter-container">tip',

            initComplete: function(settings){
                var api = new $.fn.dataTable.Api( settings );
                $('.table-filter-container', api.table().container()).append(
                    $('#table-filter').detach().show()
                );

                $('#table-filter select').on('change', function(){
                    table.column(14).search(this.value).draw();
                });


                $('.table-filter-container', api.table().container()).append(
                    $('#table-filter1').detach().show()
                );

                $('#table-filter1 select').on('change', function(){
                    var vals = $('option:selected', this).map(function (index, element) {
                        return $.fn.dataTable.util.escapeRegex($(element).val());
                    }).toArray().join('|');
                    //table.column(13).search(this.value).draw();
                    table.column(13).search( vals.length > 0 ? '^('+vals+')$' : '', true, false ).draw();
                    //table.search(this.value).draw();
                });


                $('.table-filter-container', api.table().container()).append(
                    $('#table-filter2').detach().show()
                );

                $('#table-filter2 select').on('change', function(){
                    var vals = $('option:selected', this).map(function (index, element) {
                        return $.fn.dataTable.util.escapeRegex($(element).val());
                    }).toArray().join('|');

                    //table.column(13).search(this.value).draw();
                    table.column(8).search( vals.length > 0 ? '^('+vals+')$' : '', true, false ).draw();
                    //table.search(this.value).draw();
                });
            },

            columnDefs: [
                {
                    targets: 0,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                },{
                    targets: 1,
                    className: 'noVis'

                },{
                    targets: 2,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                },{
                    targets: 3,
                    className: 'noVis'
                },{
                    targets: 4,
                    className: 'noVis',

                },{
                    targets: 5,
                    visible: false,

                    orderable:false
                },{
                    targets: 6,
                    visible: false,

                    orderable:false
                },{
                    targets: 7,
                    className: 'noVis',
                    searchable: false
                },{
                    targets: 8,
                    className: 'noVis',
                    render: function (data, type, row) {
                        data_indexOf=50;
                        if(data.indexOf("-")>1)
                        {
                            data_indexOf=data.indexOf("-")+6;
                        }
                        else if(data.indexOf("<")>1)
                        {
                            data_indexOf=data.indexOf("<")-1;
                        }
                        return type === 'export' ?
                            data.substr(0,data_indexOf) :
                    data;
                }
                },{
                    targets: 9,
                    className: 'noVis',
                    searchable: false
                },{
                    targets: 10,
                    className: 'noVis',
                    orderable:false,
                    searchable: false,
                },{
                    targets: 11,
                    className: 'noVis',
                    orderable:false,
                    searchable: false,
                },{
                    targets: 12,
                    className: 'noVis',
                    searchable: false,
                    orderable:false

                },{
                    targets: 13,
                    className: 'noVis',

                    orderable:false
                },{
                    targets: 14,
                    visible: false,
                    className: 'noVis',
                    orderable:false
                }
				
            ],

            order: [ 3, 'asc' ],
            buttons: [
                {
                    text: ' <i class="glyphicon glyphicon-edit" title="Traitement Massive"></i> ',
                    className: ' data-new_workorder'

                },
                {
                    extend: 'colvis',
                    text:      '<i class="fa fa-cog" align="right" title="Visibilité des colonnes"></i>',
                    columns: ':not(.noVis)'
                },
                //'excelHtml5',
                {
                    title: 'GABs hors services',
                    //messageBottom: 'Télécharger le '+currDay+'-'+currMonth+'-'+currYear+' '+currHours+':'+currMinutes+':'+currSeconds,
                    extend: 'excelHtml5',
                    className: 'excelButton',
                    exportOptions: {
                        columns: [ 1,3,4,5,6,7,8],
                        orthogonal: 'export'
                    },
                    //appendTo:'#card_header',
                    text: '<i class="fa fa-file-excel-o fa-lg" align="right" title="Télécharger Excel" ></i>',
                    //className: 'btn pull-right',
                    customize: function(xlsx) {

                        var sheet = xlsx.xl.worksheets['sheet1.xml'];
                        $('row c', sheet).each(function() {

                            var numero=$(this).parent().index() ;
                            if (numero===1){
                                $(this).attr( 's', '32' );//22 - Bold, blue background
                            }else if (numero===0)
                            {
                                $(this).remove();
                            }else if (numero>1)
                            {
                                $(this).attr('s','25');//25 - Normal text, fine black border
                            }
                        });
                    }
                }
            ],
            language: {
                searchPlaceholder: "Recherche ..."
            },
            oLanguage: {
                sSearch: " ",
            },

            drawCallback: function( settings ) {
                // Reset margin to 0 after datatable render
                var ele = document.querySelector('div.dataTables_scrollBody .text-warning');
                if(ele){
                    ele.style.visibility = "hidden";
                }
            }
        }
    );

    $('a.toggle-vis').on( 'click', function (e) {
        e.preventDefault();

        // Get the column API object
        var column = table.column( $(this).attr('data-column') );

        // Toggle the visibility
        column.visible( ! column.visible() );
    } );



} );
$(document).ready(function() {


    var session = '<%= Session["VALUE"] %>';
    $.fn.dataTable.ext.classes.sPageButton = 'button button-primary';// Change Pagination Button Class
    var table = $('#tbl_d_m_gab').DataTable( {

            "paging": true,
            "info":     false,
            dom: 'T<"clear">frtip',

            columnDefs: [
                {
                    targets: 0,
                    orderable:false,
                    searchable: false
                },{
                    targets: 1

                },{
                    targets: 2
                },{
                    targets: 3,
                    searchable: false
                },{
                    targets: 4,
                    searchable: false
                },{
                    targets: 5,
                    searchable: false
                }
            ],
            order: [ 1, 'asc' ],

            language: {
                searchPlaceholder: "Recherche ..."
            },
            oLanguage: {
                sSearch: " ",
            }
        }
    );

} );


$(document).ready(function() {

    var table = $('#table_gab_deconnecte').DataTable( {
            deferRender:    true,
            scrollY:        true,
            scrollX : true,
            fixedColumns: true,
            scrollCollapse: true,
            scroller:       true,
            stateSave:      true,

            "paging": false,
            "info":     false,
            dom: 'Bflr<"table-filter-container">tip',

            initComplete: function(settings){
                var api = new $.fn.dataTable.Api( settings );
                $('.table-filter-container', api.table().container()).append(
                    $('#table-filter').detach().show()
                );

                $('#table-filter select').on('change', function(){
                    table.search(this.value).draw();
                });
            },

            columnDefs: [
                {
                    targets: 0,
                    className: 'noVis'
                }, {
                    targets: 1,
                    className: 'noVis'
                }, {
                    targets: 2,
                    className: 'noVis'
                }, {
                    targets: 3,
                    visible: false,
                    orderable: false,
                    searchable: false
                }, {
                    targets: 4,
                    visible: false,
                    orderable: false,
                    searchable: false
                }, {
                    targets: 5,
                    className: 'noVis',
                    searchable: false

                }, {
                    targets: 6,
                    className: 'noVis',
                    searchable: false

                },{
                    targets: 7,
                    className: 'noVis',
                    orderable: false,
                    searchable: false
                },{
                    targets: 8,
                    className: 'noVis',
                    orderable: false,
                    searchable: false

                },{
                    targets: 9,
                    className: 'noVis',
                    orderable: false,
                    searchable: false

                }, {
                    targets: 10,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                },{
                    targets: 11,
                    visible: false,
                    className: 'noVis',
                    orderable:false
                }


            ],
            order: [ 6, 'asc' ],
            buttons: [
                //'excelHtml5',
                {
                    extend: 'colvis',
                    text:      '<i class="fa fa-cog" align="right" title="Visibilité des colonnes"></i>',
                    columns: ':not(.noVis)'
                },
                {



                    title: 'GABs Déconnectés',
                    //messageBottom: 'Télécharger le '+currDay+'-'+currMonth+'-'+currYear+' '+currHours+':'+currMinutes+':'+currSeconds,
                    extend: 'excelHtml5',
                    className: 'excelButton',
                    exportOptions: {
                        columns: [ 0, 1, 2, 3, 4, 5 ,6]
                    },
                    //appendTo:'#card_header',
                    text: '<i class="fa fa-file-excel-o fa-lg" align="right" title="Télécharger Excel" ></i>',
                    //className: 'btn pull-right',
                    customize: function(xlsx) {

                        var sheet = xlsx.xl.worksheets['sheet1.xml'];
                        $('row c', sheet).each(function() {

                            var numero=$(this).parent().index() ;
                            if (numero===1){
                                $(this).attr( 's', '32' );//22 - Bold, blue background
                            }else if (numero===0)
                            {
                                $(this).remove();

                            }else if (numero>1)
                            {
                                $(this).attr('s','25');//25 - Normal text, fine black border
                            }
                        });



                    }
                }
            ],
            language: {
                searchPlaceholder: "Recherche ..."
            },
            oLanguage: {
                sSearch: " ",
            },

            drawCallback: function( settings ) {
                // Reset margin to 0 after datatable render
                var ele = document.querySelector('div.dataTables_scrollBody .text-warning');
                if(ele){
                    ele.style.visibility = "hidden";
                }
            }

        }
    );

} );



$(document).ready(function() {

    var table = $('#table_gab_deconnecte_2h').DataTable( {
            deferRender:    true,
            scrollY:        true,
            scrollX : true,
            fixedColumns: true,
            scrollCollapse: true,
            scroller:       true,
            stateSave:      true,

            "paging": false,
            "info":     false,
            dom: 'Bflr<"table-filter-container">tip',

            initComplete: function(settings){
                var api = new $.fn.dataTable.Api( settings );
                $('.table-filter-container', api.table().container()).append(
                    $('#table-filter').detach().show()
                );

                $('#table-filter select').on('change', function(){
                    table.search(this.value).draw();
                });
            },

            columnDefs: [
                {
                    targets: 0,
                    className: 'noVis'
                }, {
                    targets: 1,
                    className: 'noVis'
                }, {
                    targets: 2,
                    className: 'noVis'
                }, {
                    targets: 3,
                    visible: false,
                    orderable: false,
                    searchable: false
                }, {
                    targets: 4,
                    visible: false,
                    orderable: false,
                    searchable: false
                }, {
                    targets: 5,
                    className: 'noVis',
                    searchable: false

                }, {
                    targets: 6,
                    className: 'noVis',
                    searchable: false

                },{
                    targets: 7,
                    className: 'noVis',
                    orderable: false,
                    searchable: false
                },{
                    targets: 8,
                    className: 'noVis',
                    orderable: false,
                    searchable: false

                },{
                    targets: 9,
                    className: 'noVis',
                    orderable: false,
                    searchable: false

                }, {
                    targets: 10,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                },{
                    targets: 11,
                    visible: false,
                    className: 'noVis',
                    orderable:false
                }


            ],
            order: [ 6, 'asc' ],
            buttons: [
                //'excelHtml5',
                {
                    extend: 'colvis',
                    text:      '<i class="fa fa-cog" align="right" title="Visibilité des colonnes"></i>',
                    columns: ':not(.noVis)'
                },
                {



                    title: 'GABs Déconnectés',
                    //messageBottom: 'Télécharger le '+currDay+'-'+currMonth+'-'+currYear+' '+currHours+':'+currMinutes+':'+currSeconds,
                    extend: 'excelHtml5',
                    className: 'excelButton',
                    exportOptions: {
                        columns: [ 0, 1, 2, 3, 4, 5 ,6]
                    },
                    //appendTo:'#card_header',
                    text: '<i class="fa fa-file-excel-o fa-lg" align="right" title="Télécharger Excel" ></i>',
                    //className: 'btn pull-right',
                    customize: function(xlsx) {

                        var sheet = xlsx.xl.worksheets['sheet1.xml'];
                        $('row c', sheet).each(function() {

                            var numero=$(this).parent().index() ;
                            if (numero===1){
                                $(this).attr( 's', '32' );//22 - Bold, blue background
                            }else if (numero===0)
                            {
                                $(this).remove();

                            }else if (numero>1)
                            {
                                $(this).attr('s','25');//25 - Normal text, fine black border
                            }
                        });



                    }
                }
            ],
            language: {
                searchPlaceholder: "Recherche ..."
            },
            oLanguage: {
                sSearch: " ",
            },

            drawCallback: function( settings ) {
                // Reset margin to 0 after datatable render
                var ele = document.querySelector('div.dataTables_scrollBody .text-warning');
                if(ele){
                    ele.style.visibility = "hidden";
                }
            }

        }
    );

} );

$(document).ready(function() {

    var table = $('#table_gab_passive').DataTable( {
            deferRender:    true,
            scrollY:        true,
            scrollX : true,
            fixedColumns: true,
            scrollCollapse: true,
            scroller:       true,
            stateSave:      true,

            "paging": false,
            "info":     false,
            dom: 'Bflr<"table-filter-container">tip',

            initComplete: function(settings){
                var api = new $.fn.dataTable.Api( settings );
                $('.table-filter-container', api.table().container()).append(
                    $('#table-filter').detach().show()
                );

                $('#table-filter select').on('change', function(){
                    table.search(this.value).draw();
                });
            },

            columnDefs: [
                {
                    targets: 0,
                    className: 'noVis'

                }, {
                    targets: 1,
                    className: 'noVis'
                },{
                    targets: 2,
                    className: 'noVis'
                }, {
                    targets: 3,
                    visible: false,
                    orderable:false,
                    searchable: false
                }, {
                    targets: 4,
                    visible: false,
                    orderable:false,
                    searchable: false
                }, {
                    targets: 5,
                    className: 'noVis'
                }, {
                    targets: 6,
                    className: 'noVis'
                },{
                    targets: 7,
                    className: 'noVis'
                },{
                    targets: 8,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                },{
                    targets: 9,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 10,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 11,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                },{
                    targets: 12,
                    visible: false,
                    className: 'noVis',
                    orderable:false
                }
            ],
            order: [ 5, 'asc' ],
            buttons: [
                {
                    extend: 'colvis',
                    text:      '<i class="fa fa-cog" align="right" title="Visibilité des colonnes"></i>',
                    columns: ':not(.noVis)'
                }
            ],
            language: {
                searchPlaceholder: "Recherche ..."
            },
            oLanguage: {
                sSearch: " ",
            },

            drawCallback: function( settings ) {
                // Reset margin to 0 after datatable render
                var ele = document.querySelector('div.dataTables_scrollBody .text-warning');
                if(ele){
                    ele.style.visibility = "hidden";
                }
            }

        }

    );

} );

$(document).ready(function() {
    var table = $('#table_etat_parc_atm').DataTable( {
            deferRender:    true,
            scrollY:        true,
            scrollX : true,
            fixedColumns: true,
            scrollCollapse: true,
            scroller:       true,
            stateSave:      true,

            "paging": false,
            "info":     false,
            dom: 'Bflr<"table-filter-container">tip',

            initComplete: function(settings){
                var api = new $.fn.dataTable.Api( settings );
                $('.table-filter-container', api.table().container()).append(
                    $('#table-filter').detach().show()
                );

                $('#table-filter select').on('change', function(){
                    table.search(this.value).draw();
                });
            },

            columnDefs: [
                {
                    targets: 0,
                    className: 'noVis'
                }, {
                    targets: 1,
                    className: 'noVis'
                }, {
                    targets: 2,
                    className: 'noVis'
                }, {
                    targets: 3,
                    visible: false,
                    orderable: false,
                    searchable: false
                }, {
                    targets: 4,
                    visible: false,
                    orderable: false,
                    searchable: false
                }, {
                    targets: 5,
                    className: 'noVis',
                    orderable: false,
                    searchable: false
                },{
                    targets: 6,
                    className: 'noVis',
                    searchable: false
                },{
                    targets: 7,
                    className: 'noVis',
                    orderable: false,
                    searchable: false
                },{
                    targets: 8,
                    className: 'noVis',
                    orderable: false,
                    searchable: false
                }, {
                    targets: 9,
                    className: 'noVis',
                    orderable: false,
                    searchable: false
                }, {
                    targets: 10,
                    visible: false,
                    className: 'noVis',
                    orderable:false
                }
            ],
            order: [ 6, 'asc' ],
            buttons: [
                {
                    extend: 'colvis',
                    text:      '<i class="fa fa-cog" align="right" title="Visibilité des colonnes"></i>',
                    columns: ':not(.noVis)'
                }
            ],
            language: {
                searchPlaceholder: "Recherche ..."
            },
            oLanguage: {
                sSearch: " ",
            },

            drawCallback: function( settings ) {
                // Reset margin to 0 after datatable render
                var ele = document.querySelector('div.dataTables_scrollBody .text-warning');
                if(ele){
                    ele.style.visibility = "hidden";
                }
            }
        }
    );

} );

$(document).ready(function() {
    var table = $('#table_etat_parc_atm_admin').DataTable( {
            deferRender:    true,
            scrollY:        true,
            scrollX : true,
            fixedColumns: true,
            scrollCollapse: true,
            scroller:       true,
            stateSave:      true,

            "paging": false,
            "info":     false,
            dom: 'Bflr<"table-filter-container">tip',

            initComplete: function(settings){
                var api = new $.fn.dataTable.Api( settings );
                $('.table-filter-container', api.table().container()).append(
                    $('#table-filter').detach().show()
                );

                $('#table-filter select').on('change', function(){
                    table.search(this.value).draw();
                });
            },

            columnDefs: [
                {
                    targets: 0,
                    className: 'noVis'
                }, {
                    targets: 1,
                    className: 'noVis',
                    searchable: false,
                },{
                    targets: 2,
                    className: 'noVis'
                }, {
                    targets: 3,
                    className: 'noVis'
                }, {
                    targets: 4,
                    visible: false,
                    searchable: false,
                    orderable:false
                },{
                    targets: 5,
                    visible: false,
                    searchable: false,
                    orderable:false
                },{
                    targets: 6,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                },{
                    targets: 7,
                    className: 'noVis',
                    searchable: false
                }, {
                    targets: 8,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 9,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 10,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 11,
                    visible: false,
                    className: 'noVis',
                    orderable:false
                }
            ],
            order: [ 7, 'asc' ],
            buttons: [
                {
                    extend: 'colvis',
                    text:      '<i class="fa fa-cog" align="right" title="Visibilité des colonnes"></i>',
                    columns: ':not(.noVis)'
                }
            ],
            language: {
                searchPlaceholder: "Recherche ..."
            },
            oLanguage: {
                sSearch: " ",
            },

            drawCallback: function( settings ) {
                // Reset margin to 0 after datatable render
                var ele = document.querySelector('div.dataTables_scrollBody .text-warning');
                if(ele){
                    ele.style.visibility = "hidden";
                }
            }

        }
    );

} );
$(document).ready(function() {
    var table = $('#table_incidents_ouverts').DataTable( {
            deferRender:    true,
            scrollX : true,
            fixedColumns: true,
            scrollCollapse: true,
            scroller:       true,
            stateSave:      true,
            "ordering": false,

            "paging": false,
            "info":     false,
            dom: 'flr<"table-filter-container">tip',

            initComplete: function(settings){
                var api = new $.fn.dataTable.Api( settings );
                $('.table-filter-container', api.table().container()).append(
                    $('#table-filter').detach().show()
                );

                $('#table-filter select').on('change', function(){
                    table.search(this.value).draw();
                });
            },

            columnDefs: [
                {
                    targets: 0,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 1,
                    className: 'noVis',
                    orderable:false
                }, {
                    targets: 2,
                    className: 'noVis',
                    orderable:false
                }, {
                    targets: 3,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 4,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 5,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 6,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 7,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 8,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 9,
                    visible: false,
                    orderable:false
                }
            ],

            language: {
                searchPlaceholder: "Recherche ..."
            },
            oLanguage: {
                sSearch: " ",
            },

            drawCallback: function( settings ) {
                // Reset margin to 0 after datatable render
                var ele = document.querySelector('div.dataTables_scrollBody .text-warning');
                if(ele){
                    ele.style.visibility = "hidden";
                }
            }

        }
    );

} );
$(document).ready(function() {
    var table = $('#table_liste_rappel').DataTable( {
            deferRender:    true,
            scrollX : true,
            fixedColumns: true,
            scrollCollapse: true,
            scroller:       true,
            stateSave:      true,
            "ordering": false,
            "paging": false,
            "info":     false,
            dom: 'flr<"table-filter-container">tip',

            initComplete: function(settings){
                var api = new $.fn.dataTable.Api( settings );
                $('.table-filter-container', api.table().container()).append(
                    $('#table-filter').detach().show()
                );

                $('#table-filter select').on('change', function(){
                    table.search(this.value).draw();
                });
            },

            columnDefs: [
                {
                    targets: 0,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 1,
                    className: 'noVis',
                    orderable:false
                }, {
                    targets: 2,
                    className: 'noVis',
                    orderable:false
                }, {
                    targets: 3,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 4,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 5,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 6,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 7,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 8,
                    className: 'noVis',
                    searchable: false,
                    orderable:false
                }, {
                    targets: 9,
                    visible: false,
                    orderable:false
                }
            ],

            language: {
                searchPlaceholder: "Recherche ..."
            },
            oLanguage: {
                sSearch: " ",
            },

            drawCallback: function( settings ) {
                // Reset margin to 0 after datatable render
                var ele = document.querySelector('div.dataTables_scrollBody .text-warning');
                if(ele){
                    ele.style.visibility = "hidden";
                }
            }

        }
    );

} );


// this is the id of the form
$("#form_upload_image").submit(function(e) {

    e.preventDefault();
    var formData = new FormData($(this)[0]);
    inputFile = $('#uploadimage');
    console.log(inputFile.files);
    if (parseInt(inputFile.get(0).files.length) > 20)
    {
        var alertBox = '<div class="col-sm-12" ><br><div class="alert alert-danger" align="center"><strong>Nombre d\'images invalide </strong></div>';
        $("#message").html(alertBox);
    }
    else
    {
        formData.append('function', 'uploadpic');

        //formData.append('sessionValue', sessionValue);
        $.ajax({
            type: "POST",
            headers: {
                'x-access-token': token
            },
            url: "ajax/ajaxAchraf.php",
            data: formData,
            cache       : false,
            contentType : false,
            processData : false,
            success: function(data)
            {
                var messageAlert = 'alert-' + data.type;
                var messageText = data.message;
                var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
                if (messageAlert && messageText) {
                    $("#message").html(alertBox);
                }
            },
            error: function (data)
            {
                var messageAlert = 'alert-' + data.type;
                var messageText = data.message;
                var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
                if (messageAlert && messageText) {
                    $("#message").html(alertBox);
                }
            }
        });
    }

});

$("#checkAll").click(function () {
    $('input:checkbox').not(this).prop('checked', this.checked);
});





function show()
{
    //alert("cheked the button - worked");
    if(document.getElementById('type_commande[]').value!=1 && document.getElementById('type_commande[]').value!=52 && document.getElementById('type_commande[]').value!=53 && document.getElementById('type_commande[]').value!=54 )
    {
        document.getElementById('pathconfig').style.display= 'block' ;
        if(document.getElementById('type_commande[]').value==2)
        {
            document.getElementById('pathconfig22').value="C:\\Ivision\\ivision_client.exe";
        }
        if(document.getElementById('type_commande[]').value==3)
        {
            document.getElementById('pathconfig22').value="1";
        }
        if(document.getElementById('type_commande[]').value==4)
        {
            document.getElementById('pathconfig22').value="1";
        }
        if(document.getElementById('type_commande[]').value==5)
        {
            document.getElementById('pathconfig22').value="1";
        }
        if(document.getElementById('type_commande[]').value==6)
        {
            document.getElementById('pathconfig22').value="C:\\Ivision\\ivision_agent.exe";
        }
        if(document.getElementById('type_commande[]').value==7)
        {
            document.getElementById('pathconfig22').value="1";
        }
        if(document.getElementById('type_commande[]').value==8)
        {
            document.getElementById('pathconfig22').value="2";
        }
        if(document.getElementById('type_commande[]').value==10)
        {
            document.getElementById('pathconfig22').value="1";
        }
        if(document.getElementById('type_commande[]').value==11)
        {
            document.getElementById('pathconfig22').value="10";
        }
        if(document.getElementById('type_commande[]').value==12)
        {
            document.getElementById('pathconfig22').value="C:/Ivision/files/";
        }
        if(document.getElementById('type_commande[]').value==13)
        {
            document.getElementById('pathconfig22').value="C:/E_Journal/";
        }
        if(document.getElementById('type_commande[]').value==14)
        {
            document.getElementById('pathconfig22').value="C:/Ivision/journal/";
        }
        if(document.getElementById('type_commande[]').value==15)
        {
            document.getElementById('pathconfig22').value="C:/Ivision/journaltemp/";
        }
        if(document.getElementById('type_commande[]').value==17)
        {
            document.getElementById('pathconfig22').value="C:/Ivision/image/temp/";
        }
        if(document.getElementById('type_commande[]').value==18)
        {
            document.getElementById('pathconfig22').value="C:/Ivision/image/down/";
        }
        if(document.getElementById('type_commande[]').value==19)
        {
            document.getElementById('pathconfig22').value="192.168.0.232";
        }
        if(document.getElementById('type_commande[]').value==20)
        {
            document.getElementById('pathconfig22').value="root";
        }
        if(document.getElementById('type_commande[]').value==21)
        {
            document.getElementById('pathconfig22').value="************";
        }
        if(document.getElementById('type_commande[]').value==22)
        {
            document.getElementById('pathconfig22').value="db_ivision_GAB_CFG";
        }
        if(document.getElementById('type_commande[]').value==23)
        {
            document.getElementById('pathconfig22').value="C:/Ivision/ssl232/ca-cert.pem";
        }
        if(document.getElementById('type_commande[]').value==24)
        {
            document.getElementById('pathconfig22').value="C:/Ivision/ssl232/client-cert.pem";
        }
        if(document.getElementById('type_commande[]').value==25)
        {
            document.getElementById('pathconfig22').value="C:/Ivision/ssl232/client-key.pem";
        }
        if(document.getElementById('type_commande[]').value==27)
        {
            document.getElementById('pathconfig22').value="1";
        }
        if(document.getElementById('type_commande[]').value==28)
        {
            document.getElementById('pathconfig22').value=".DEFAULT\\\\XFS\\\\LOGICAL_SERVICES\\\\";
        }
        if(document.getElementById('type_commande[]').value==29)
        {
            document.getElementById('pathconfig22').value="C:\\Ivision\\files\\";
        }
        if(document.getElementById('type_commande[]').value==30)
        {
            document.getElementById('pathconfig22').value="300";
        }
        if(document.getElementById('type_commande[]').value >= 31 && document.getElementById('type_commande[]').value <= 46)
        {
            document.getElementById('pathconfig22').value="1";
        }
        if(document.getElementById('type_commande[]').value==47)
        {
            document.getElementById('pathconfig22').value="1";
        }
        if(document.getElementById('type_commande[]').value==50)
        {
            document.getElementById('pathconfig22').value="123";
        }
        if(document.getElementById('type_commande[]').value==51)
        {
            document.getElementById('pathconfig22').value="123";
        }
        if(document.getElementById('type_commande[]').value==26)
        {
            document.getElementById('pathconfig22').value="1";
        }
        if(document.getElementById('type_commande[]').value==9)
        {
            document.getElementById('pathconfig22').value="1";
        }
        if(document.getElementById('type_commande[]').value==48)
        {
            document.getElementById('pathconfig22').value="0";
        }
        if(document.getElementById('type_commande[]').value==49)
        {
            document.getElementById('pathconfig22').value="123";
        }
    }
    else
    {
        document.getElementById('pathconfig').style.display= 'none' ;
    }
}

$("#form_upload_image_prof").submit(function(e) {
    token = localStorage.getItem('token');
    e.preventDefault();
    var boolvar=false;
    var formData = new FormData($(this)[0]);
    inputFile = $('#uploadimage');
    console.log(inputFile.files);
    formData.append('function', 'uploadpicprofil');
    var searchIDs = $("#tbl_prof input:checkbox:checked").map(function(){
        return $(this).val();
    }).get();

    for (i = 0; i < inputFile.get(0).files.length; i++)
    {
        if (parseInt(inputFile[0].files[i].size) > 5242880)
        {
            boolvar=true;
            break;
        }
    }
    if (parseInt(inputFile.get(0).files.length) > 20)
    {
        var alertBox = '<div class="col-sm-12" ><br><div class="alert alert-danger" align="center"><strong>Nombre d\'images invalide </strong></div>';
        $("#message").html(alertBox);
    }
    else if(boolvar === true)
    {
        var alertBox = '<div class="col-sm-12" ><br><div class="alert alert-danger" align="center"><strong>Taille image(s) invalide</strong></div>';
        $("#message").html(alertBox);
    }

    else
    {
        formData.append('idatms', searchIDs);
        $.ajax({
            type: "POST",
            headers: {
                'x-access-token': token
            },
            url: "ajax/ajaxAchraf.php",
            data: formData,
            cache       : false,
            contentType : false,
            processData : false,
            success: function(data)
            {

                var messageAlert = 'alert-' + data.type;
                var messageText = data.message;
                var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
                if (messageAlert && messageText) {
                    $("#message").html(alertBox);
                }
            },
            error: function (data)
            {
                var messageAlert = 'alert-' + data.type;
                var messageText = data.message;
                var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
                if (messageAlert && messageText) {
                    $("#message").html(alertBox);
                }
            }

        });
    }

});

$("#form_upload_compagne").submit(function(e) {

    e.preventDefault();
    var boolvar=false;
    var formData = new FormData($(this)[0]);
    inputFile = $('#uploadimage');

    formData.append('function', 'uploadcompagne');
    var searchIDs = $("#tbl_prof input:checkbox:checked").map(function(){
        return $(this).val();
    }).get();
    for (i = 0; i < inputFile.get(0).files.length; i++)
    {
        if (parseInt(inputFile[0].files[i].size) > 5242880)
        {
            boolvar=true;
            break;
        }
    }
    if (parseInt(inputFile.get(0).files.length) > 20)
    {
        var alertBox = '<div class="col-sm-12" ><br><div class="alert alert-danger" align="center"><strong>Invalid number of images </strong></div>';
        $("#step-4").html(alertBox);
    }
    else if(boolvar === true)
    {
        var alertBox = '<div class="col-sm-12" ><br><div class="alert alert-danger" align="center"><strong>Invalid image size (s) </strong></div>';
        $("#step-4").html(alertBox);
    }
    else
    {
        formData.append('idatms', searchIDs);
        $.ajax({
            type: "POST",
            headers: {
                'x-access-token': token
            },
            url: "ajax/ajaxAchraf.php",
            data: formData,
            cache       : false,
            contentType : false,
            processData : false,
            success: function(data)
            {
                var messageAlert = 'alert-' + data.type;
                var messageText = data.message;
                var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + ' align="center"><strong>' + messageText + '</strong></div>';
                if (messageAlert && messageText) {
                    $("#step-4").html(alertBox);
                }
            },
            error: function (data)
            {
                var messageAlert = 'alert-' + data.type;
                var messageText = data.message;
                var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
                if (messageAlert && messageText) {
                    $("#step-4").html(alertBox);
                }
            }
        });
    }

});

$("#form_upload_schedule").submit(function(e) {

    e.preventDefault();

    var formData = new FormData($(this)[0]);


    formData.append('function', 'uploadschedule');
    var searchIDs = $("#tbl_prof input:checkbox:checked").map(function(){
        return $(this).val();
    }).get();

    formData.append('idatms', searchIDs);
    $.ajax({
        type: "POST",
        headers: {
            'x-access-token': token
        },
        url: "ajax/ajaxAchraf.php",
        data: formData,
        cache       : false,
        contentType : false,
        processData : false,
        success: function(data)
        {
            var messageAlert = 'alert-' + data.type;
            var messageText = data.message;
            var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + ' align="center"><strong>' + messageText + '</strong></div>';
            if (messageAlert && messageText) {
                $("#step-4").html(alertBox);
            }
        },
        error: function (data)
        {
            var messageAlert = 'alert-' + data.type;
            var messageText = data.message;
            var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
            if (messageAlert && messageText) {
                $("#step-4").html(alertBox);
            }
        }
    });


});
$("#form_upload_binaire_prof").submit(function(e) {
    token = localStorage.getItem('token');
    e.preventDefault();
    var formData = new FormData($(this)[0]);
    inputFile = $('#uploadbinaire');
    console.log(inputFile.files);
    formData.append('function', 'uploadbinaireprofil');
    var searchIDs = $("#tbl_prof input:checkbox:checked").map(function(){
        return $(this).val();
    }).get();

    if (parseInt(inputFile.get(0).files.length) > 1)
    {
        var alertBox = '<div class="col-sm-12" ><br><div class="alert alert-danger" align="center"><strong>Un seul binaire autorisé </strong></div>';
        $("#message").html(alertBox);
    }
    else if (parseInt(inputFile[0].files[0].size) > 5242880)
    {
        var alertBox = '<div class="col-sm-12" ><br><div class="alert alert-danger" align="center"><strong>Taille Binaire invalide </strong></div>';
        $("#message").html(alertBox);
    }

    else
    {
        formData.append('idatms', searchIDs);
        $.ajax({
            type: "POST",
            headers: {
                'x-access-token': token
            },
            url: "ajax/ajaxAchraf.php",
            data: formData,
            cache       : false,
            contentType : false,
            processData : false,
            success: function(data)
            {
                //alert(data); // show response from the php script.
                var messageAlert = 'alert-' + data.type;
                var messageText = data.message;
                var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
                if (messageAlert && messageText) {
                    $("#message").html(alertBox);
                }
            },
            error: function (data)
            {
                var messageAlert = 'alert-' + data.type;
                var messageText = data.message;
                var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
                if (messageAlert && messageText) {
                    $("#message").html(alertBox);
                }
            }

        });
    }

});

$("#form_historique_deploiement").each(function (e) {

    $("#dated").val(new Date().toJSON().slice(0,11) +"00:00");
    $("#datef").val(new Date().toJSON().slice(0,16));
});

$("#form_historique_deploiement").submit(function (e) {


    token = localStorage.getItem('token');

    e.preventDefault();
    var formData = new FormData($(this)[0]);
    formData.append('function', 'get_hist_deplo');
    $.ajax({
        type: "POST",
        headers: {
            'x-access-token': token
        },
        url: "ajax/ajaxAchraf.php",
        data: formData,
        cache       : false,
        contentType : false,
        processData : false,
        dataType : 'html',
        success : function(code_html){

            $("#tb_get_hist").html(code_html);
        }
    });
});

////////////////////////////////////////////////////////////////////////////////////////////////////



$("#form_Compagnes_pub").each(function (e) {

    var today = new Date();
    var currDay = today.getDate();
    var currMonth = today.getMonth();
    var currYear = today.getFullYear();
    var currHour = today.getHours();
    var currMinute = today.getMinutes();
    var currSecond = today.getSeconds();
    var startDate = new Date(currYear, currMonth,currDay,0,0,0 );
    var startDatefull = new Date(currYear, currMonth,currDay,currHour,currMinute,currSecond );

   /* $(document).ready(function(){
        $('#datetimepicker1').datetimepicker('setDate',startDate);
        $('#datetimepicker2').datetimepicker('setDate',startDatefull);
    });
    $('#datetimepicker1').datetimepicker({
        format: 'yyyy-mm-dd hh:ii:00',
        autoclose: true,
        todayBtn: true,
        endDate : today
    }).on('changeDate', function(ev){
        $('#datetimepicker2').datetimepicker('setStartDate', ev.date);
    });


    $('#datetimepicker2').datetimepicker({
        format: 'yyyy-mm-dd hh:ii:00',
        autoclose: true,
        todayBtn: true,
        endDate : today
    }).on('changeDate', function(ev){
        $('#datetimepicker1').datetimepicker('setEndDate', ev.date);
    });*/
});

$("#form_Compagnes_pub").submit(function (e) {
    token = localStorage.getItem('token');
    e.preventDefault();
    var formData = new FormData($(this)[0]);
    formData.append('function', 'get_Compagnes_pub');
    $.ajax({
        type: "POST",
        headers: {
            'x-access-token': token
        },
        url: "ajax/ajaxAchraf.php",
        data: formData,
        cache       : false,
        contentType : false,
        processData : false,
        dataType : 'html',
        success : function(code_html){
            $('#tb_compagnes_pub').html(code_html).slideDown().fadeIn();
        }
    });
});

////////////////////////////////////////////////////////////////////////////////////////////////////
$("#form_Schedule_pub").submit(function (e) {

    token = localStorage.getItem('token');
    e.preventDefault();
    var formData = new FormData($(this)[0]);
    formData.append('function', 'get_Schedule_pub');
    $.ajax({
        type: "POST",
        headers: {
            'x-access-token': token
        },
        url: "ajax/ajaxAchraf.php",
        data: formData,
        cache       : false,
        contentType : false,
        processData : false,
        dataType : 'html',
        success : function(code_html){
            $('#tb_schedule_pub').html(code_html).slideDown().fadeIn();
        }
    });
});
////////////////////////////////////////////////////////////////////////////////////////////////////

$("#form_historique_dep_binaire").each(function (e) {

    $("#dated").val(new Date().toJSON().slice(0,11) +"00:00");
    $("#datef").val(new Date().toJSON().slice(0,16));

});

$("#form_historique_dep_binaire").submit(function (e) {
    token = localStorage.getItem('token');
    e.preventDefault();
    var formData = new FormData($(this)[0]);
    formData.append('function', 'get_hist_deplo_binaire');
    $.ajax({
        type: "POST",
        headers: {
            'x-access-token': token
        },
        url: "ajax/ajaxAchraf.php",
        data: formData,
        cache       : false,
        contentType : false,
        processData : false,
        dataType : 'html',
        success : function(code_html){
            $("#tb_get_hist").html(code_html);
        }
    });
});

////////////////////////////////////////////////////////////////////////////////////////////
$("#form_historique_redemarrage").each(function (e) {

    var now = new Date();

    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);
    var today = now.getFullYear()+"-"+(month)+"-"+(day) ;
    $(document).ready(function(){
        $('#dated').val(today);
        $('#datef').val(today);
    });

});

$("#form_historique_redemarrage").submit(function (e) {
    token = localStorage.getItem('token');
    e.preventDefault();
    var formData = new FormData($(this)[0]);
    formData.append('function', 'get_hist_redemarrage');
    $.ajax({
        type: "POST",
        headers: {
            'x-access-token': token
        },
        url: "ajax/ajaxAchraf.php",
        data: formData,
        cache       : false,
        contentType : false,
        processData : false,
        dataType : 'html',
        success : function(code_html){
            $("#tb_get_hist").html(code_html);
        }
    });
});


/////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
$("#form_historique_server").each(function (e) {

    $("#dated").val(new Date().toJSON().slice(0,11) +"00:00");
    $("#datef").val(new Date().toJSON().slice(0,16));
});

$("#form_historique_server").submit(function (e) {
    token = localStorage.getItem('token');
    e.preventDefault();
    var formData = new FormData($(this)[0]);
    formData.append('function', 'get_hist_monitor_server');
    $.ajax({
        type: "POST",
        headers: {
            'x-access-token': token
        },
        url: "ajax/ajaxAchraf.php",
        data: formData,
        cache       : false,
        contentType : false,
        processData : false,
        dataType : 'html',
        success : function(code_html){
            $("#content_historique_server").html(code_html);
        }
    });
});


/////////////////////////////////////////////////////////////////////////////////////////////
function getTraitMassive()
{
    token = localStorage.getItem('token');

    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("divModalTrait_Mass").innerHTML = "<div class='modal-dialog modal-lg' style='width:60%'><div class='modal-content' ><div class='modal-header' style='background-color: #e7722c;color:#2b3449;'><h4 class='modal-title'>Traitement Massive</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";
        }
        if(xhr.readyState == 4 && xhr.status == 200){

            document.getElementById("divModalTrait_Mass").innerHTML=xhr.responseText;

        }
    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);
    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=getTraitMassive");

}
/////////////////////////////////////////////////////////////////////////////////////////////

function getjournalATM(id_atm,terminalID, page)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("divModaljournalATM").innerHTML = "<div class='modal-dialog modal-xl' style='max-width: 1700px;'><div class='modal-content' style='background-color:#e9ecef;color:#2b3449;'><div class='modal-header'><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img style='display: block;margin-left: auto; margin-right: auto;' src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";
        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("divModaljournalATM").innerHTML=xhr.responseText;
            $("#dated").val(new Date().toJSON().slice(0,11) +"00:00");
            $("#datef").val(new Date().toJSON().slice(0,16));
        }
    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);
    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


    xhr.send("function=getjournalATM&id_atm="+id_atm+
        '&terminalID='+terminalID);

}



function getjournalATMdate(id_atm,terminalID,dated,datef,idev,idev2,idev3,page)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("btn_detailjournalATM").innerHTML = " <i class='fa fa-spinner fa-spin' aria-hidden='true'></i>";

        }
        if(xhr.readyState == 4 && xhr.status == 200){

            document.getElementById("btn_detailjournalATM").innerHTML = " <i ></i>";
            document.getElementById("divModaljournalATM").innerHTML=xhr.responseText;


        }
    }
    dated=document.getElementById("dated").value;
    datef=document.getElementById("datef").value;


    var idev = $('#eventid').find(":selected").val();
    var idev2 = $('#type_transaction_id').find(":selected").val();
    var idev3 = $('#type_authentification_id').find(":selected").val();

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php?page="+page,true);
    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


    xhr.send("function=getjournalATMdate&id_atm="+id_atm+
        "&terminalID="+terminalID+
        "&dated="+dated+
        "&datef="+datef+
        "&idev="+idev+
        "&idev2="+idev2+
        "&idev3="+idev3);



}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getconfigevrnt(aldiv)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200){

            document.getElementById("div_event_jrn").innerHTML=xhr.responseText;

        }
    }

    var checkboxes1=document.getElementById("eventid1[]");


    var idev1="";
    for (var i=0, n=checkboxes1.length;i<n;i++)
    {
        if (checkboxes1[i].selected && idev1.length>0)
        {
            idev1 += "(5,"+checkboxes1[i].value+"),";

        }
        else if (checkboxes1[i].selected )
        {
            idev1 += ",(5,"+checkboxes1[i].value+"),";
        }


    }
    if (idev1) idev1 = idev1.substring(1);

    ///////////////////////////////////////////////////////////////////////////
    var checkboxes2=document.getElementById("eventid2[]");

    var idev2="";
    for (var i=0, n=checkboxes2.length;i<n;i++)
    {
        if (checkboxes2[i].selected && idev2.length>0)
        {
            idev2 += "(6,"+checkboxes2[i].value+"),";

        }
        else if (checkboxes2[i].selected )
        {
            idev2 += ",(6,"+checkboxes2[i].value+"),";
        }

    }
    if (idev2) idev2 = idev2.substring(1);

    ///////////////////////////////////////////////////////////////////////////
    var checkboxes3=document.getElementById("eventid3[]");

    var idev3="";
    for (var i=0, n=checkboxes3.length;i<n;i++)
    {
        if (checkboxes3[i].selected && idev3.length>0)
        {
            idev3 += "(7,"+checkboxes3[i].value+"),";

        }
        else if (checkboxes3[i].selected)
        {
            idev3 += ",(7,"+checkboxes3[i].value+"),";
        }

    }
    if (idev3) idev3 = idev3.substring(1);

    ///////////////////////////////////////////////////////////////////////////
    var checkboxes4=document.getElementById("eventid4[]");

    var idev4="";
    for (var i=0, n=checkboxes4.length;i<n;i++)
    {
        if (checkboxes4[i].selected && idev4.length>0)
        {
            idev4 += "(8,"+checkboxes4[i].value+"),";

        }
        else if (checkboxes4[i].selected)
        {
            idev4 += ",(8,"+checkboxes4[i].value+"),";
        }

    }
    if (idev4) idev4 = idev4.substring(1);

    ///////////////////////////////////////////////////////////////////////////
    var checkboxes5=document.getElementById("eventid5[]");

    var idev5="";
    for (var i=0, n=checkboxes5.length;i<n;i++)
    {
        if (checkboxes5[i].selected && idev5.length>0)
        {
            idev5 += "(9,"+checkboxes5[i].value+"),";

        }
        else if (checkboxes5[i].selected)
        {
            idev5 += ",(9,"+checkboxes5[i].value+"),";
        }

    }
    if (idev5) idev5 = idev5.substring(1);

    ///////////////////////////////////////////////////////////////////////////
    var checkboxes6=document.getElementById("eventid6[]");

    var idev6="";
    for (var i=0, n=checkboxes6.length;i<n;i++)
    {
        if (checkboxes6[i].selected && idev6.length>0)
        {
            idev6 += "(10,"+checkboxes6[i].value+"),";

        }
        else if (checkboxes6[i].selected)
        {
            idev6 += ",(10,"+checkboxes6[i].value+"),";
        }

    }
    if (idev6) idev6 = idev6.substring(1);

    var aldiv = idev1  + idev2 + idev3 + idev4 +  idev5  +idev6;

    if (aldiv) aldiv = aldiv.substring(0,aldiv.length-1);
    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);
    // ne pas oublier ça pour le post
    var r = confirm("You want to continue !");
    if (r == true && aldiv.length>0)
    {
        xhr.setRequestHeader('x-access-token',token);
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        xhr.send("function=getconfigevrnt&aldiv="+aldiv);
        reloadDiv();
    }
    else{
        alert("No updates have been made !!!");
    }
    reloadDiv();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function deletconfigevent(d_name_event)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function()
    {
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";
        }
        if(xhr.readyState == 4 && xhr.status == 200){
            document.getElementById("div_info_parametrage").innerHTML=xhr.responseText;

        }
    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    var r = confirm("Vous Voulez Supprimer l'evenement !!");
    if (r == true) {
        xhr.setRequestHeader('x-access-token',token);
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        xhr.send("function=deletconfigevent&d_name_event="+d_name_event);
    }
    else
    {
        alert("Aucune mise à jour n'a été effectuée !!!");
    }
}

function reloadDiv()
{
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("div_info_parametrage").innerHTML=xhr.responseText;
        }
    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post

    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=getallcongjrn");
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function reloadDiv_commande_ATM(id_atm,idprivilege)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("btn_reload_cmd_ATM").innerHTML = " <i class='fa fa-spinner fa-spin' aria-hidden='true'></i>";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("btn_reload_cmd_ATM").innerHTML = " <i class='fa fa-refresh' aria-hidden='true'></i>";
            document.getElementById("div_commande_ATM").innerHTML=xhr.responseText;
        }
    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=getallcommandATM&id_atm="+id_atm+
        "&idprivilege="+idprivilege);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function reloadDiv_capture_incid(id_atm)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("btn_reload_cmd_ATM").innerHTML = " <i class='fa fa-spinner fa-spin' aria-hidden='true'></i>";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("btn_reload_cmd_ATM").innerHTML = " <i class='fa fa-refresh' aria-hidden='true'></i>";
            document.getElementById("div_scren_incident").innerHTML=xhr.responseText;
        }
    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=get_all_scren_incident&id_atm="+id_atm);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_atm_profil(profil)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("tbl_prof_tbody").innerHTML=xhr.responseText;

        }

    }
    profil=document.getElementById("profil[]");


    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=get_atm_profil&profil="+profil.value);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_atm_new_comp(profil)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("tbl_prof_tbody").innerHTML=xhr.responseText;

        }

    }
    profil=document.getElementById("profil[]");


    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=get_atm_new_comp&profil="+profil.value);

}/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_bianire_profil_for_commande(profil)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("tbl_prof").innerHTML=xhr.responseText;

        }

    }
    profil=document.getElementById("profil[]");


    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=get_bianire_profil_for_commande&profil="+profil.value);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function comm_atm_profil(profil)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("tbl_prof_tbody").innerHTML=xhr.responseText;

        }

    }
    profil=document.getElementById("profil[]");


    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=comm_atm_profil&profil="+profil.value);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_bianire_profil(profil)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("tbl_prof_tbody").innerHTML=xhr.responseText;

        }

    }
    profil=document.getElementById("profil[]");


    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=get_bianire_profil&profil="+profil.value);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_bianire_profil_echoues(profil)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("tbl_prof_tbody").innerHTML=xhr.responseText;

        }

    }
    profil=document.getElementById("profil[]");


    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=get_bianire_profil_echoues&profil="+profil.value);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_bianire_profil_for_mode_execution(profil)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("tbl_prof_tbody").innerHTML=xhr.responseText;

        }

    }
    profil=document.getElementById("profil[]");


    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=get_bianire_profil_for_mode_execution&profil="+profil.value);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getSendCommand()
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    var nomDiv="form_upload_image_prof";
    var checkboxes = document.getElementsByName('chekedTreminal[]');
    var optionCommande= document.getElementById("type_commande[]");
    var pathconfig= document.getElementById("pathconfig22");

    var valeurCommande=optionCommande.value;
    var pathconfigFinal=pathconfig.value;

    xhr.onreadystatechange = function()
    {

        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById(nomDiv).innerHTML=xhr.responseText;
            document.getElementById('form_upload_image_prof_2').remove();
        }
    }
    var vals = "";
    for (var i=0, n=checkboxes.length;i<n;i++)
    {
        if (checkboxes[i].checked)
        {
            vals += ","+checkboxes[i].value;
        }
    }
    if (vals) vals = vals.substring(1);
    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);
    // ne pas oublier ça pour le post
    var r = confirm("Vous Voulez Envoyer la Commande!!");


    if (r == true)
    {
        xhr.setRequestHeader('x-access-token',token);
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        // ancien_password = document.getElementById('input_ancien_password').value;
        xhr.send("function=getSendCommand&gabSelected="+vals+"&valeurCommande="+valeurCommande+"&pathconfigFinal="+pathconfigFinal);
    }
    else
    {
        alert("Aucune Commande n'a été effectuée !!!");
    }

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_modal_button(lang)
{
    var capture_selec='Capture selected';
    var capture_not_selec='Capture not selected';

    if (lang==='fr')
    {
         capture_selec='Capture sélectionnée';
         capture_not_selec='Capture non sélectionnée';
    }
   // var value = $('input:radio:checked').next().text();
    var value = $('input[name="cheked_cmd"]:checked').val();

    if (value === undefined)
    {
        value=0;
    }
    if (value != 0)
    {
        $('#p_ret').text(capture_selec);
        $('#p_ret').css('color', 'green');

        $('#i_ret').removeClass('fa fa-times').addClass('fa fa-check');
        $('#i_ret').css('color', 'green');

    }
    else if(value == 0)
    {
        $('#p_ret').text(capture_not_selec);
        $('#p_ret').css('color', 'red');

        $('#i_ret').addClass('fa fa-times');
        $('#i_ret').css('color', 'red');

    }
    $('#purpose_input').val(value);

   
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function getSendModeExecution()
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse
    var nomDiv="form_upload_image_prof";
    var checkboxes = document.getElementsByName('chekedTreminal[]');
    var optionCommande= document.getElementById("type_commande[]");
    var optionVersion= document.getElementById("version[]");

    var valeurCommande=optionCommande.value;
    var valeurVersion=optionVersion.value;


    xhr.onreadystatechange = function()
    {

        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById(nomDiv).innerHTML=xhr.responseText;
            $('#form_upload_image_prof_2').hide();
        }

    }



    var vals = "";
    for (var i=0, n=checkboxes.length;i<n;i++)
    {
        // document.getElementsByName('allTraiter[]').checked = true;
        if (checkboxes[i].checked)
        {
            vals += ","+checkboxes[i].value;
        }
    }
    if (vals) vals = vals.substring(1);

    /* alert(vals);
     alert(valeurCommande);
     alert(valeurVersion);*/
    // document.getElementById(nomDiv).innerHTML = "You ordered a coffee with: " + vals +"DIV"+nomDiv;

    // Ici on va voir comment faire du post


    xhr.open("POST","ajax/ajaxAchraf.php",true);
    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

    // ancien_password = document.getElementById('input_ancien_password').value;

    xhr.send("function=getSendModeExecution&gabSelected="+vals+"&valeurCommande="+valeurCommande+"&valeurVersion="+valeurVersion);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function(){

    $('.search-box input[type="search"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.get("lib/backend-search.php", {term: inputVal}).done(function(data){

                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });

    // Set search input value on click of result item
    $(document).on("click", ".result li", function(){

        $(this).parents(".search-box").find('input[type="search"]').val($(this).val());

        $(this).parent(".dropdown-menu").removeClass( "show" ).addClass( " " );
        $(this).parent(".dropdown-menu").empty();

    });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function search_atm()
{

    var formData = new FormData();
    formData.append('function', 'search_atm');
    search_input=$('#search_input').val();
    
    url = "declarer.php?terminal="+search_input+"&dateArret=&dateArret=&id_motif=&id_arret=";
    window.open(url);
   // $(location).prop('href', url);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$("#frm_intervention").submit(function(e)
{
    token = localStorage.getItem('token');
    e.preventDefault();
    var formData = new FormData($(this)[0]);

    formData.append('function', 'ajouterintervention');
    console.log(formData);
    $.ajax({
        type: "POST",
        headers: {
            'x-access-token': token
        },
        url: "ajax/ajaxAchraf.php",
        data: formData,
        cache       : false,
        contentType : false,
        processData : false,
        success: function(data)
        {
            var messageAlert = 'alert-' + data.type;
            var messageText = data.message;
            var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
            if (messageAlert && messageText) {
                $("#div_frm_intervention").html(alertBox);
            }
        }
    });
});

function update_mail_auto(auto_mail,id_intevention)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse



    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    var r = confirm("Vous Voulez Modifier l'evenement !!");
    if (r == true) {
        xhr.setRequestHeader('x-access-token',token);
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        xhr.send("function=update_mail_auto&auto_mail="+auto_mail+"&id_intevention="+id_intevention);
        $( "#" +id_intevention+ "1" ).load(window.location.href + " #" +id_intevention+ "1" );
    }
    else
    {
        alert("Aucune mise à jour n'a été effectuée !!!");
    }
    $( "#" +id_intevention+ "1" ).load(window.location.href + " #" +id_intevention+ "1" );
}
function update_retrait_argent(retrait_argent,id_intevention)
{
    token = localStorage.getItem('token');

    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse



    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    var r = confirm("Vous Voulez Modifier l'evenement !!");
    if (r == true) {
        xhr.setRequestHeader('x-access-token',token);
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        xhr.send("function=update_retrait_argent&retrait_argent="+retrait_argent+"&id_intevention="+id_intevention);
        $( "#" +id_intevention+ "2" ).load(window.location.href + " #" +id_intevention+ "2" );
    }
    else
    {
        alert("Aucune mise à jour n'a été effectuée !!!");
    }
    $( "#"+id_intevention+ "2" ).load(window.location.href + " #" +id_intevention+ "2" );
}


function update_depot_argent(depot_argent,id_intevention)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse



    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    var r = confirm("Vous Voulez Modifier l'evenement !!");
    if (r == true) {
        xhr.setRequestHeader('x-access-token',token);
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        xhr.send("function=update_depot_argent&depot_argent="+depot_argent+"&id_intevention="+id_intevention);
        $( "#" +id_intevention+ "3" ).load(window.location.href + " #" +id_intevention+ "3" );
    }
    else
    {
        alert("Aucune mise à jour n'a été effectuée !!!");
    }
    $( "#"+id_intevention+ "3" ).load(window.location.href + " #" +id_intevention+ "3" );
}
function update_depot_cheque(depot_cheque,id_intevention)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse



    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    var r = confirm("Vous Voulez Modifier l'evenement !!");
    if (r == true) {
        xhr.setRequestHeader('x-access-token',token);
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        xhr.send("function=update_depot_cheque&depot_cheque="+depot_cheque+"&id_intevention="+id_intevention);
        $( "#" +id_intevention+ "4" ).load(window.location.href + " #" +id_intevention+ "4" );
    }
    else
    {
        alert("Aucune mise à jour n'a été effectuée !!!");
    }
    $( "#"+id_intevention+ "4" ).load(window.location.href + " #" +id_intevention+ "4" );
}

function update_autre_transactions(autre_transactions,id_intevention)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse



    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    var r = confirm("Vous Voulez Modifier l'evenement !!");
    if (r == true) {
        xhr.setRequestHeader('x-access-token',token);
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        xhr.send("function=update_autre_transactions&autre_transactions="+autre_transactions+"&id_intevention="+id_intevention);
        $( "#" +id_intevention+ "5" ).load(window.location.href + " #" +id_intevention+ "5" );
    }
    else
    {
        alert("Aucune mise à jour n'a été effectuée !!!");
    }
    $( "#"+id_intevention+ "5" ).load(window.location.href + " #" +id_intevention+ "5" );
}
function update_categorie_intervention(sel,id_intevention)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse



    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    var r = confirm("Vous Voulez Modifier Categorie d'ntervention !!");
    if (r == true) {
        xhr.setRequestHeader('x-access-token',token);
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        xhr.send("function=update_categorie_intervention&sel="+sel.value+"&id_intevention="+id_intevention);
    }
    else
    {
        alert("Aucune mise à jour n'a été effectuée !!!");
    }
}
function delete_intervention(id_intevention)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function()
    {

        if(xhr.readyState == 4 && xhr.status == 200){
            document.getElementById("tbl_arret").innerHTML=xhr.responseText;
        }
    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    var r = confirm("Vous Voulez Supprimer l'ntervention !!");
    if (r == true) {
        xhr.setRequestHeader('x-access-token',token);
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        xhr.send("function=delete_intervention&&id_intevention="+id_intevention);
        $( "#tbl_arret" ).load(window.location.href + " #tbl_arret" );
    }
    else
    {
        alert("Aucune mise à jour n'a été effectuée !!!");
    }
    $( "#tbl_arret" ).load(window.location.href + " #tbl_arret" );

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$(document).on("click",".apage", function(){
    var currentPage = $(this).attr('data-page');
    var idAtm = $(this).attr('data-id_atm');
    var terminalID = $(this).attr('data-terminalID');
    var dated = $(this).attr('data-dated');
    var datef = $(this).attr('data-datef');
    var idev = $(this).attr('data-idev');
    var idev2 = $(this).attr('data-idev2');
    var idev3 = $(this).attr('data-idev3');

    getjournalATMdate(idAtm,terminalID,dated,datef,idev,idev2,idev3,currentPage);
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$(document).on("click",".cmdpage", function(){
    var currentPage = $(this).attr('data-page');
    var idAtm = $(this).attr('data-id_atm');
    var terminalID = $(this).attr('data-terminalID');
    var idprivilege = $(this).attr('data-privilege');
    var dated = $(this).attr('data-dated');
    var datef = $(this).attr('data-datef');
    var idev = $(this).attr('data-idev');

    getcommandeATMdate(idAtm,terminalID,idprivilege,dated,datef,idev,currentPage);
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$(document).on("click",".modalpage", function(){
    var id_compaign = $(this).attr('data-id_compaign');
    var id_image = $(this).attr('data-id_image');
    var name_compaign = $(this).attr('data-name_compaign');
    var currentPage = $(this).attr('data-page');


    Show_All_Image_Comp(id_compaign,id_image,name_compaign,currentPage);
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$(document).on("click",".modalpage_screen", function(){
    var ATM = $(this).attr('data-ATM');
    var value_cmd = $(this).attr('data-value_cmd');
    var currentPage = $(this).attr('data-page');

    ShowScreenshotATM(ATM,value_cmd,currentPage);

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function Show_All_Image_Comp(id_compaign,id_image,name_compaign,page)
{
    token = localStorage.getItem('token');

    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse
    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("divModal_ALL_Show_Image").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("divModal_ALL_Show_Image").innerHTML=xhr.responseText;
        }
    }
    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php?page="+page,true);
    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

    xhr.send("function=Show_All_Image_Comp&id_compaign="+id_compaign+
        "&id_image="+id_image+
        "&name_compaign="+name_compaign);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function ShowScreenshotATM(ATM,value_cmd,page)
{
    
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse
    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("divModalshowScreenshotATM").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Capture écran GAB</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";
        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("divModalshowScreenshotATM").innerHTML=xhr.responseText;
        }
    }
    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php?page="+page,true);
    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

    xhr.send("function=ShowScreenshotATM&ATM="+ATM+
        "&value_cmd="+value_cmd);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDetail_Compagnes_success(id_compaign,name_compaign)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse
    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            $(document).ready(function() {

                $.fn.dataTable.ext.classes.sPageButton = 'button button-primary';// Change Pagination Button Class


                var table = $('table.display.success').DataTable( {

                        deferRender:    true,
                        scrollY:        true,
                        scrollX : true,
                        fixedColumns: true,
                        scrollCollapse: true,
                        scroller:       true,
                        stateSave:      true,
                        info:     true,
                        paging: true,
                        pageLength: 5,

                        dom: 'T<"clear">lfrtip',

                        columnDefs: [
                            {
                                targets: 0,
                                className: 'noVis'

                            }, {
                                targets: 1,
                                className: 'noVis'

                            }, {
                                targets: 2,
                                className: 'noVis'

                            },{
                                targets:3,
                                className: 'noVis'
                            },{
                                targets: 4,
                                orderable:false,
                                className: 'noVis'
                            },{
                                targets: 5,
                                orderable:false,
                                className: 'noVis',
                                searchable: false
                            }
                        ],
                        order: [ 1, 'asc' ],
                        language: {
                            searchPlaceholder: "Recherche ...",
                            lengthMenu: "Afficher _MENU_ enregistrements"
                        },
                        oLanguage: {
                            sSearch: " ",
                        },
                        lengthMenu: [5, 10, 15, 20],
                        drawCallback: function( settings ) {
                            // Reset margin to 0 after datatable render
                            var ele = document.querySelector('div.dataTables_scrollBody .text-warning');
                            if(ele){
                                ele.style.visibility = "hidden";
                            }
                        }

                    }
                );

            } );
            document.getElementById("divModal_Comp_success").innerHTML=xhr.responseText;
        }
    }
    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

    xhr.send("function=getDetail_Compagnes_success&id_compaign="+id_compaign+
        "&name_compaign="+name_compaign);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDetail_Compagnes_not_yet(id_compaign,name_compaign)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse
    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            $(document).ready(function() {

                $.fn.dataTable.ext.classes.sPageButton = 'button button-primary';// Change Pagination Button Class


                var table = $('table.display.not_yet').DataTable( {

                        deferRender:    true,
                        scrollY:        true,
                        scrollX : true,
                        fixedColumns: true,
                        scrollCollapse: true,
                        scroller:       true,
                        stateSave:      true,
                        info:     true,
                        paging: true,
                        pageLength: 5,

                        dom: 'T<"clear">lfrtip',

                        columnDefs: [
                            {
                                targets: 0,
                                className: 'noVis'

                            }, {
                                targets: 1,
                                className: 'noVis'

                            }, {
                                targets: 2,
                                className: 'noVis'

                            },{
                                targets:3,
                                className: 'noVis'
                            },{
                                targets: 4,
                                orderable:false,
                                className: 'noVis'
                            },{
                                targets: 5,
                                orderable:false,
                                className: 'noVis',
                                searchable: false
                            }
                        ],
                        order: [ 1, 'asc' ],
                        language: {
                            searchPlaceholder: "Recherche ...",
                            lengthMenu: "Afficher _MENU_ enregistrements"
                        },
                        oLanguage: {
                            sSearch: " ",
                        },
                        lengthMenu: [5, 10, 15, 20],
                        drawCallback: function( settings ) {
                            // Reset margin to 0 after datatable render
                            var ele = document.querySelector('div.dataTables_scrollBody .text-warning');
                            if(ele){
                                ele.style.visibility = "hidden";
                            }
                        }

                    }
                );

            } );
            document.getElementById("divModal_Comp_not_yet").innerHTML=xhr.responseText;
        }
    }
    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

    xhr.send("function=getDetail_Compagnes_not_yet&id_compaign="+id_compaign+
        "&name_compaign="+name_compaign);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDetail_Compagnes_non_déployée(id_compaign,name_compaign)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse
    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            $(document).ready(function() {

                $.fn.dataTable.ext.classes.sPageButton = 'button button-primary';// Change Pagination Button Class


                var table = $('table.display.non_deployee').DataTable( {

                        deferRender:    true,
                        scrollY:       true,
                        scrollX : true,
                        fixedColumns: true,
                        scrollCollapse: true,
                        scroller:       true,
                        stateSave:      true,
                        info:     true,
                        paging: true,
                        pageLength: 5,

                        dom: 'T<"clear">lfrtip',

                        columnDefs: [
                            {
                                targets: 0,
                                className: 'noVis'

                            }, {
                                targets: 1,
                                className: 'noVis'

                            }, {
                                targets: 2,
                                className: 'noVis'

                            },{
                                targets:3,
                                className: 'noVis'
                            },{
                                targets: 4,
                                orderable:false,
                                className: 'noVis'
                            },{
                                targets: 5,
                                orderable:false,
                                className: 'noVis',
                                searchable: false
                            }
                        ],
                        order: [ 1, 'asc' ],
                        language: {
                            searchPlaceholder: "Recherche ...",
                            lengthMenu: "Afficher _MENU_ enregistrements"
                        },
                        oLanguage: {
                            sSearch: " ",
                        },
                        lengthMenu: [5, 10, 15, 20],
                        drawCallback: function( settings ) {
                            // Reset margin to 0 after datatable render
                            var ele = document.querySelector('div.dataTables_scrollBody .text-warning');
                            if(ele){
                                ele.style.visibility = "hidden";
                            }
                        }

                    }
                );

            } );
            document.getElementById("divModal_Comp_non_déployée").innerHTML=xhr.responseText;
        }
    }
    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

    xhr.send("function=getDetail_Compagnes_non_déployée&id_compaign="+id_compaign+
        "&name_compaign="+name_compaign);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDetail_Compagnes_Time_out(id_compaign,name_compaign)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse
    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            $(document).ready(function() {

                $.fn.dataTable.ext.classes.sPageButton = 'button button-primary';// Change Pagination Button Class


                var table = $('table.display.time_out').DataTable( {

                        deferRender:    true,
                        scrollY:        true,
                        scrollX : true,
                        fixedColumns: true,
                        scrollCollapse: true,
                        scroller:       true,
                        stateSave:      true,
                        info:     true,
                        paging: true,
                        pageLength: 5,

                        dom: 'T<"clear">lfrtip',

                        columnDefs: [
                            {
                                targets: 0,
                                className: 'noVis'

                            }, {
                                targets: 1,
                                className: 'noVis'

                            }, {
                                targets: 2,
                                className: 'noVis'

                            },{
                                targets:3,
                                className: 'noVis'
                            },{
                                targets: 4,
                                orderable:false,
                                className: 'noVis'
                            },{
                                targets: 5,
                                orderable:false,
                                className: 'noVis',
                                searchable: false
                            }
                        ],
                        order: [ 1, 'asc' ],
                        language: {
                            searchPlaceholder: "Recherche ...",
                            lengthMenu: "Afficher _MENU_ enregistrements"
                        },
                        oLanguage: {
                            sSearch: " ",
                        },
                        lengthMenu: [5, 10, 15, 20],
                        drawCallback: function( settings ) {
                            // Reset margin to 0 after datatable render
                            var ele = document.querySelector('div.dataTables_scrollBody .text-warning');
                            if(ele){
                                ele.style.visibility = "hidden";
                            }
                        }

                    }
                );

            } );
            document.getElementById("divModal_Comp_Time_out").innerHTML=xhr.responseText;
        }
    }
    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

    xhr.send("function=getDetail_Compagnes_Time_out&id_compaign="+id_compaign+
        "&name_compaign="+name_compaign);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function Show_MyModal_Image(id_compaign,id_image)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse
    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("divModal_Show_Image").innerHTML=xhr.responseText;
        }
    }
    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

    xhr.send("function=Show_MyModal_Image&id_compaign="+id_compaign+
        "&id_image="+id_image);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_supprimer_incident(id_atm)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function() {
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok

        if (xhr.readyState == 4 && xhr.status == 200) {


            document.getElementById("divModalSuprimerGAB").innerHTML = xhr.responseText;
        }
    }
    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);
    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


    xhr.send("function=get_supprimer_incident&id_atm="+id_atm);
}
//////////////////////////////////////////////////////////////////////////////
function getcommandeATM(id_atm,terminalID,idprivilege)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("divModalcommandeATM").innerHTML = "<div class='modal-dialog modal-xl' style='max-width: 1700px;'><div class='modal-content' style='background-color:#e9ecef;color:#2b3449;' ><div class='modal-header' ><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img style='display: block;margin-left: auto; margin-right: auto;' src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";
        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("divModalcommandeATM").innerHTML=xhr.responseText;
        }

    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);
    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


    xhr.send("function=getcommandeATM&id_atm="+id_atm+
        '&terminalID='+terminalID+
        '&idprivilege='+idprivilege);

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_scren_incident(id_atm,terminalID)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function()
    {
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("divModalscreenincident").innerHTML = "<div class='modal-dialog modal-xl'><div class='modal-content' ><div class='modal-header' ><h4 class='modal-title'>Historique Capture écran GAB</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img style='display: block;margin-left: auto; margin-right: auto;' src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";
        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("divModalscreenincident").innerHTML=xhr.responseText;
        }
    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);
    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


    xhr.send("function=get_scren_incident&id_atm="+id_atm+
        '&terminalID='+terminalID);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_modal_AjouterPost()
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse
    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("divModal_ajouter_Post").innerHTML=xhr.responseText;
        }
    }
    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

    xhr.send("function=get_modal_AjouterPost");
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function ajouterPost()
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse
    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";
        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("divDeclarer").innerHTML=xhr.responseText;
        }
    }
    var post = document.getElementById('post').value;
    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


    xhr.send("function=ajouterPost&region="+post);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function suppimer_work_post(id_post)
{
    token = localStorage.getItem('token');
    if (confirm("Voulez-vous supprimer ce post ?"))
    {
        var xhr = getXhr();
        // On défini ce qu'on va faire quand on aura la réponse
        xhr.onreadystatechange = function(){
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if(xhr.readyState == 1)
            {

            }
            if(xhr.readyState == 4 && xhr.status == 200){
                document.getElementById("divDeclarer").innerHTML=xhr.responseText;

            }
        }
        // Ici on va voir comment faire du post
        xhr.open("POST","ajax/ajaxAchraf.php",true);

        // ne pas oublier ça pour le post
        xhr.setRequestHeader('x-access-token',token);
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

        xhr.send("function=suppimer_work_post&id_post="+id_post);
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_modal_modifier_work_post(id_post)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse
    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("divModal_Modifier_Post").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Modifier Post</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("divModal_Modifier_Post").innerHTML=xhr.responseText;
            $('select').selectpicker();
        }
    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

    xhr.send("function=get_modal_modifier_work_post&id_post="+id_post);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifierPost(id_post)
{
    token = localStorage.getItem('token');
    if (confirm("Voulez-vous Modifier ce post ?"))
    {
        var xhr = getXhr();
        // On défini ce qu'on va faire quand on aura la réponse
        xhr.onreadystatechange = function(){
            // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
            if(xhr.readyState == 1)
            {

            }
            if(xhr.readyState == 4 && xhr.status == 200){
                document.getElementById("divDeclarer").innerHTML=xhr.responseText;

            }
        }
        var name_poste = document.getElementById('post').value;
        var checkboxes = document.getElementById('regionid[]');

        var id_filiale="";
        for (var i=0, n=checkboxes.length;i<n;i++)
        {
            if (checkboxes[i].selected)
            {
                id_filiale += ","+checkboxes[i].value+"";
            }
        }
        // Ici on va voir comment faire du post
        xhr.open("POST","ajax/ajaxAchraf.php",true);

        // ne pas oublier ça pour le post
        xhr.setRequestHeader('x-access-token',token);
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

        xhr.send("function=modifierPost&id_post="+id_post+
            "&name_poste="+name_poste+
            "&id_filiale="+id_filiale);
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDashboardATM(id_atm)
{
    token = localStorage.getItem('token');
    // alert(logical_name);
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("divModalDashboardATM").innerHTML = "<div class='modal-dialog modal-xl' style='max-width: 1700px;'><div class='modal-content' style='background-color:#e9ecef;color:#2b3449;'><div class='modal-header'><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row'><img style='display: block;margin-left: auto; margin-right: auto;' src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

        }
        if(xhr.readyState == 4 && xhr.status == 200){
            $(document).ready(function () {

                Chart.pluginService.register({
                    beforeDraw: function (chart) {
                        if (chart.config.options.elements.center) {
                            //Get ctx from string
                            var ctx = chart.chart.ctx;

                            //Get options from the center object in options
                            var centerConfig = chart.config.options.elements.center;
                            var fontStyle = centerConfig.fontStyle || 'Arial';
                            var txt = centerConfig.text;
                            var color = centerConfig.color || '#000';
                            var sidePadding = centerConfig.sidePadding || 20;
                            var sidePaddingCalculated = (sidePadding/100) * (chart.innerRadius * 2)
                            //Start with a base font of 30px
                            ctx.font = "30px " + fontStyle;

                            //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
                            var stringWidth = ctx.measureText(txt).width;
                            var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;

                            // Find out how much the font can grow in width.
                            var widthRatio = elementWidth / stringWidth;
                            var newFontSize = Math.floor(30 * widthRatio);
                            var elementHeight = (chart.innerRadius * 2);

                            // Pick a new font size so it will not be larger than the height of label.
                            var fontSizeToUse = Math.min(newFontSize, elementHeight);

                            //Set font settings to draw it correctly.
                            ctx.textAlign = 'center';
                            ctx.textBaseline = 'middle';
                            var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
                            var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
                            ctx.font = fontSizeToUse+"px " + fontStyle;
                            ctx.fillStyle = color;

                            //Draw text in center
                            ctx.fillText(txt, centerX, centerY);
                        }
                    }
                });

                showGraph1(id_atm);
                showGraph2(id_atm);
                showGraph3(id_atm);
            });

            document.getElementById("divModalDashboardATM").innerHTML=xhr.responseText;

        }

    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);
    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


    xhr.send("function=getDashboardATM&id_atm="+id_atm);

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function reloadDiv_Dashboard_ATM(id_atm)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("btn_reload_Dashboard_ATM").innerHTML = " <i class='fa fa-spinner fa-spin' aria-hidden='true'></i>";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {

            $(document).ready(function () {

                Chart.pluginService.register({
                    beforeDraw: function (chart) {
                        if (chart.config.options.elements.center) {
                            //Get ctx from string
                            var ctx = chart.chart.ctx;

                            //Get options from the center object in options
                            var centerConfig = chart.config.options.elements.center;
                            var fontStyle = centerConfig.fontStyle || 'Arial';
                            var txt = centerConfig.text;
                            var color = centerConfig.color || '#000';
                            var sidePadding = centerConfig.sidePadding || 20;
                            var sidePaddingCalculated = (sidePadding/100) * (chart.innerRadius * 2)
                            //Start with a base font of 30px
                            ctx.font = "30px " + fontStyle;

                            //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
                            var stringWidth = ctx.measureText(txt).width;
                            var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;

                            // Find out how much the font can grow in width.
                            var widthRatio = elementWidth / stringWidth;
                            var newFontSize = Math.floor(30 * widthRatio);
                            var elementHeight = (chart.innerRadius * 2);

                            // Pick a new font size so it will not be larger than the height of label.
                            var fontSizeToUse = Math.min(newFontSize, elementHeight);

                            //Set font settings to draw it correctly.
                            ctx.textAlign = 'center';
                            ctx.textBaseline = 'middle';
                            var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
                            var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
                            ctx.font = fontSizeToUse+"px " + fontStyle;
                            ctx.fillStyle = color;

                            //Draw text in center
                            ctx.fillText(txt, centerX, centerY);
                        }
                    }
                });

                showGraph1(id_atm);
                showGraph2(id_atm);
                showGraph3(id_atm);
            });
            document.getElementById("divModalDashboardATM").innerHTML=xhr.responseText;
        }
    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=getDashboardATM&id_atm="+id_atm);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function showGraph1(param) {
    {
        $.post("lib/datachart/ram_load.php?id_atm="+param,
            function (data)
            {
                //console.log(data);

                var ram_load = [];


                for (var i in data) {
                    ram_load.push(data[i].memory_load);
                }

                var chartdata = {
                    labels: ['RAM USED %','RAM NOT USED %'],
                    datasets: [
                        {
                            backgroundColor: [
                                'rgb(118,41,47)',
                                'rgb(219,225,235)',

                            ],
                            borderColor: [
                                'rgb(118,41,47)',
                                'rgb(219,225,235)',

                            ],

                            borderWidth: 1,
                            showInLegend: "true",
                            legendText: ram_load+ " %",
                            indexLabelFontSize: 16,
                            indexLabel: ram_load+ " %",
                            data: [ram_load,(100-ram_load)]
                        }
                    ],
                };

                var myChart = $("#myChart1");

                var doughnutGraph = new Chart(myChart, {
                    type: 'doughnut',
                    data: chartdata,
                    options: {
                        cutoutPercentage: 80,
                        responsive: false,
                        elements: {
                            center: {
                                text: Number(ram_load[0]).toFixed(2)+ " %",
                                color: '#595959', // Default is #000000
                                fontStyle: 'Calibri Light', // Default is Arial
                                sidePadding: 50 // Defualt is 20 (as a percentage)
                            }
                        },
                        legend: {
                            display: false
                        },
                        tooltips: {
                            enabled: true,
                            mode: 'label',
                            callbacks: {
                                title: function(tooltipItems, data) {
                                    var idx = tooltipItems[0].index;
                                    return  data.labels[idx]; //do something with title
                                },
                                label: function(tooltipItem, data) {
                                    // get the data label and data value to display
                                    var value =  data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index].toLocaleString()+' %';
                                    // return the text to display on the tooltip
                                    return value;
                                }
                            }
                        },
                        title: {
                            display: false,
                            text: ' ',
                            fontSize: 20,
                            fontFamily: 'Calibri'
                        },
                        animation: {
                            animateScale: true,
                            animateRotate: true
                        }
                    }
                });
            });
    }
}

function showGraph2(param) {

    $.post("lib/datachart/cpu_load.php?id_atm="+param,
        function (data)
        {
            //console.log(data);

            var cpu_load = [];




            for (var i in data) {
                cpu_load.push(data[i].cpu_load);
            }

            var chartdata = {
                labels: ['CPU USED %','CPU NOT USED %'],
                datasets: [
                    {
                        backgroundColor: [
                            'rgb(118,41,47)',
                            'rgb(219,225,235)',

                        ],
                        borderColor: [
                            'rgb(118,41,47)',
                            'rgb(219,225,235)',

                        ],

                        borderWidth: 1,
                        showInLegend: "true",
                        legendText: cpu_load+ " %",
                        indexLabelFontSize: 16,
                        indexLabel: cpu_load+ " %",
                        data: [cpu_load,(100-cpu_load)]
                    }
                ],
            };

            var myChart = $("#myChart2");

            var doughnutGraph = new Chart(myChart, {
                type: 'doughnut',
                data: chartdata,
                options: {
                    cutoutPercentage: 80,
                    responsive: false,
                    elements: {
                        center: {
                            text: Number(cpu_load[0]).toFixed(2)+ " %",
                            color: '#595959', // Default is #000000
                            fontStyle: 'Calibri Light', // Default is Arial
                            sidePadding: 50 // Defualt is 20 (as a percentage)
                        }
                    },
                    legend: {
                        display: false
                    },
                    tooltips: {
                        enabled: true,
                        mode: 'label',
                        callbacks: {
                            title: function(tooltipItems, data) {
                                var idx = tooltipItems[0].index;
                                return  data.labels[idx]; //do something with title
                            },
                            label: function(tooltipItem, data) {
                                // get the data label and data value to display
                                var value =  data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index].toLocaleString()+' %';
                                // return the text to display on the tooltip
                                return value;
                            }
                        }
                    },
                    title: {
                        display: false,
                        text: ' ',
                        fontSize: 20,
                        fontFamily: 'Calibri'
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    }
                }
            });
        });
}
function showGraph3(param) {

    $.post("lib/datachart/disk_used.php?id_atm="+param,
        function (data)
        {
            //console.log(data);

            var disk_useds = [];
            var taux_disk = [];


            for (var i in data) {
                disk_useds.push(data[i].disk_useds);
                taux_disk.push(data[i].taux_disk);
            }

            var chartdata = {
                labels: ['HARD DISK USED %','HARD DISK NOT USED %'],
                datasets: [
                    {
                        backgroundColor: [
                            'rgb(118,41,47)',
                            'rgb(219,225,235)',

                        ],
                        borderColor: [
                            'rgb(118,41,47)',
                            'rgb(219,225,235)',

                        ],

                        borderWidth: 1,
                        showInLegend: "true",
                        legendText: taux_disk+ " %",
                        indexLabelFontSize: 16,
                        indexLabel: taux_disk+ " %",
                        data: [taux_disk,(100-taux_disk)]
                    }
                ],
            };

            var myChart = $("#myChart3");

            var doughnutGraph = new Chart(myChart, {
                type: 'doughnut',
                data: chartdata,
                options: {
                    cutoutPercentage: 80,
                    responsive: false,
                    elements: {
                        center: {
                            text: Number(disk_useds[0]).toFixed(2)+ " GO",
                            color: '#595959', // Default is #000000
                            fontStyle: 'Calibri Light', // Default is Arial
                            sidePadding: 50 // Defualt is 20 (as a percentage)
                        }
                    },
                    legend: {
                        display: false
                    },
                    tooltips: {
                        enabled: true,
                        mode: 'label',
                        callbacks: {
                            title: function(tooltipItems, data) {
                                var idx = tooltipItems[0].index;
                                return  data.labels[idx]; //do something with title
                            },
                            label: function(tooltipItem, data) {
                                // get the data label and data value to display
                                var value =  Number(data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index]).toFixed(2).toLocaleString()+' %';
                                // return the text to display on the tooltip

                                return value;
                            }
                        }
                    },
                    title: {
                        display: false,
                        text: ' ',
                        fontSize: 20,
                        fontFamily: 'Calibri'
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    }
                }
            });
        });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$("#form_historique_forcasting").each(function (e) {

    var today = new Date();
    var currDay = today.getDate();
    var currMonth = today.getMonth();
    var currYear = today.getFullYear();

    var startDate = new Date(currYear, currMonth,currDay);
    var startDatefull = new Date(currYear, currMonth,currDay-1);

    $(document).ready(function(){
        $('#datetimepicker1').datetimepicker('setDate',startDate);
        $('#datetimepicker2').datetimepicker('setDate',startDatefull);
    });
    $('#datetimepicker1').datetimepicker({

        format: 'yyyy-mm-dd',
        autoclose: true,
        todayBtn: true,
        endDate : today
    }).on('changeDate', function(ev){
        $('#datetimepicker2').datetimepicker('setStartDate', ev.date);
    });


    $('#datetimepicker2').datetimepicker({

        format: 'yyyy-mm-dd',
        autoclose: true,
        todayBtn: true,
        endDate : today
    }).on('changeDate', function(ev){
        $('#datetimepicker1').datetimepicker('setEndDate', ev.date);
    });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function reloadDiv_upload_execution(id_atm,idprivilege)
{

    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("btn_reload_cmd_ATM").innerHTML = " <i class='fa fa-spinner fa-spin' aria-hidden='true'></i>";
        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("btn_reload_cmd_ATM").innerHTML = " <i class='fa fa-refresh' aria-hidden='true'></i>";
            document.getElementById("div_pload_content").innerHTML=xhr.responseText;
        }
    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=getall_upload_content&id_atm="+id_atm+
        "&idprivilege="+idprivilege);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function DownloadFileATM(id_atm,id_content)
{


    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse
    var searchIDs = $("#tbl_cnt_file input:checkbox:checked").map(function(){
        return $(this).val();
    }).get();
    if (searchIDs.length == 0)
    {
        searchIDs=id_content;
    }
    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            //document.getElementById("listedepeche").className="invisible";
            //document.getElementById("message").className="tumevois";

        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("tbl_cnt_file").innerHTML=xhr.responseText;
        }
    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);

    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("function=DownloadFileATM&id_atm="+id_atm+
        "&id_content="+id_content+
        "&searchIDs="+searchIDs);
   reloadDiv_upload_execution(id_atm,1);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$("div[id^='myModalCompg']").on('hidden.bs.modal', function () {

    window.location.reload();
});
$("#myModal777").on('hidden.bs.modal', function () {
    window.location.reload();
});
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function chackallcheckbox()
{
    var select_all = document.getElementById("checkAllcheckbox"); //select all checkbox
    var checkboxes = document.getElementsByClassName("checkbox"); //checkbox items

//select all checkboxes
    select_all.addEventListener("change", function(e){
        for (i = 0; i < checkboxes.length; i++)
        {
            checkboxes[i].checked = select_all.checked;
        }
    });


    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].addEventListener('change', function(e){ //".checkbox" change
            //uncheck "select all", if one of the listed checkbox item is unchecked
            if(this.checked == false){
                select_all.checked = false;

            }
            //check "select all" if all checkbox items are checked
            if(document.querySelectorAll('.checkbox:checked').length == checkboxes.length){
                select_all.checked = true;
            }
        });
    }

}
/////////////////////////////////////////////////////////////////////////////////////////////
function TraitMassive()
{
    token = localStorage.getItem('token');
    var formData = new FormData();
    formData.append('function', 'TraitMassive');
    var searchIDs = $("#tbl_trait_massive input:checkbox:checked").map(function(){
        return $(this).val();
    }).get();


    formData.append('idincid', searchIDs);

    $.ajax({
        type: "POST",
        headers: {
            'x-access-token': token
        },
        url: "ajax/ajaxAchraf.php",
        data: formData,
        cache       : false,
        contentType : false,
        processData : false,
        success: function(data)
        {

            var messageAlert = 'alert-' + data.type;
            var messageText = data.message;
            var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
            if (messageAlert && messageText) {
                $("#form_trait_massive").html(alertBox);
            }
            searchIDs.forEach((number, index)=>{
                if (number > 0)
                {
                    var row = document.getElementById("div_list_gab_hors_serv"+number);
                    row.parentNode.removeChild(row);
                }

            });
        },
        error: function (data)
        {
            var messageAlert = 'alert-' + data.type;
            var messageText = data.message;
            var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
            if (messageAlert && messageText) {
                $("#form_trait_massive").html(alertBox);
            }
        }
    });

}

/////////////////////////////////////////////////////////////////////////////////////////////
function sup_inci(searchIDs)
{
    searchIDs.forEach((number, index)=>{
        if (number > 0)
        {
            alert("div_list_gab_hors_serv"+number);
            var row = document.getElementById("div_list_gab_hors_serv"+number);
            row.parentNode.removeChild(row);
        }

    });
   /* foreach ($array as $item)
    {
        if($item != 0)
        {
            $list_id_atm[]=$item;
            if(isset($list_id_atm)){$listFinalMotifatm = implode(',',$list_id_atm); } else { $listFinalMotifatm=""; }
        }
    }
    var row = document.getElementById("div_list_gab_hors_serv"+searchIDs);
    row.parentNode.removeChild(row);*/
}
/////////////////////////////////////////////////////////////////////////////////////////////

function getdeconATM(id_atm)
{
    token = localStorage.getItem('token');
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("divModaldeconATM").innerHTML = "<div class='modal-dialog modal-lg' ><div class='modal-content' style='background-color:#e9ecef;color:#2b3449;' ><div class='modal-header' ><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";
        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            document.getElementById("divModaldeconATM").innerHTML=xhr.responseText;
        }

    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);
    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


    xhr.send("function=getdeconATM&id_atm="+id_atm);

}
///////////////////////////////////////////////////////////////////////////////////////////////
function Affect_Incid(id_atm,id_insert)
{
    token = localStorage.getItem('token');

    var formData = new FormData();
    var idMotifTraiter = 0;
    var ele = document.getElementsByName('motifAffectIncid'+id_atm);
    for(i = 0; i < ele.length; i++)
    {
        if(ele[i].checked)
            idMotifTraiter=ele[i].value;
    }

    var btn = document.getElementById("btn_affec");
    if (idMotifTraiter == 0)
    {
        var alertBox = '<div class="col-sm-12" ><br><div class="alert alert-danger" align="center"><strong>Aucune modification effectuée </strong></div>';
        $("#div_Affect_Incid").html(alertBox);
        btn.parentNode.removeChild(btn);
    }
    else
        {
            formData.append('function', 'Affect_Incid');
            formData.append('id_insert', id_insert);
            formData.append('idMotifTraiter', idMotifTraiter);
            
            $.ajax({
                type: "POST",
                headers: {
                    'x-access-token': token
                },
                url: "ajax/ajaxAchraf.php",
                data: formData,
                cache       : false,
                contentType : false,
                processData : false,
                success: function(data)
                {
					alert(data);
                    var messageAlert = 'alert-' + data.type;
                    var messageText = data.message;
                    var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
                    if (messageAlert && messageText) {
                        $("#div_Affect_Incid").html(alertBox);
                        btn.parentNode.removeChild(btn);
                        var row = document.getElementById("div_list_gab_hors_serv"+id_insert);
                        row.parentNode.removeChild(row);
                    }
                }
            });
        }

}
///////////////////////////////////////////////////////////////////////////////////////////////
function getAffectIncid_gab_ouv(terminal,id_insert,id_atm)
{

// alert(logical_name);
    var xhr = getXhr();
    // On défini ce qu'on va faire quand on aura la réponse

    xhr.onreadystatechange = function(){
        // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
        if(xhr.readyState == 1)
        {
            document.getElementById("divModalAffectIncid_gab_ouv").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Affecter Incident GAB</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";
        }
        if(xhr.readyState == 4 && xhr.status == 200)
        {

            document.getElementById("divModalAffectIncid_gab_ouv").innerHTML=xhr.responseText;

        }

    }

    // Ici on va voir comment faire du post
    xhr.open("POST","ajax/ajaxAchraf.php",true);
    // ne pas oublier ça pour le post
    xhr.setRequestHeader('x-access-token',token);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


    xhr.send("function=getAffectIncid_gab_ouv&terminal="+terminal+"&id_insert="+id_insert+"&id_atm="+id_atm);

}