﻿function getXhr()
{
	var xhr = null;
	if(window.XMLHttpRequest) // Firefox et autres
	xhr = new XMLHttpRequest();
	else if(window.ActiveXObject)
	{ // Internet Explorer
	try
	{
		xhr = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch (e)
	{
	xhr = new ActiveXObject("Microsoft.XMLHTTP");
	}
	}
	else
	{ // XMLHttpRequest non supporté par le navigateur
	alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest...");
	xhr = false;
	}
	return xhr;
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function confirmServiceATM(idatm,paramettre,idprivilege,date_debut,date_fin,historique_vacation)
{
	token = localStorage.getItem('token');
	var xhr = getXhr();
	var valServices = "";
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
	// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
	if(xhr.readyState == 1)
	{
	//document.getElementById("listedepeche").className="invisible";
	//document.getElementById("message").className="tumevois";

	}
	if(xhr.readyState == 4 && xhr.status == 200){

	document.getElementById("div_etat_parc").innerHTML=xhr.responseText;

	}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	var checkboxeServices = document.getElementsByName('allserviceATM[]');
	for (var i=0, j=checkboxeServices.length;i<j;i++)
	{
		if (checkboxeServices[i].checked)
		{
			valServices +=checkboxeServices[i].value+",";
		}
	}

	xhr.send("function=confirmServiceATM&idatm="+idatm+"&serviceCheckbox="+valServices+
									"&paramettre="+paramettre+
									"&idprivilege="+idprivilege+
									"&date_debut="+date_debut+
									"&date_fin="+date_fin+
									"&historique_vacation="+historique_vacation);

}

/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function ajouter_intrevention_consigne(id_mail)
{
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok

		if(xhr.readyState == 4 && xhr.status == 200)
		{

			document.getElementById("liste_mail_consigne").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	var e = document.getElementById("id_intrevention");
	id_intrevention = e.options[e.selectedIndex].value;

	xhr.send("function=ajouter_intrevention_consigne&id_intrevention="+id_intrevention+"&id_mail="+id_mail);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function get_ajouter_rappel_detail_3(terminal,id_incident,id_intervention,id_degre,opt)
{
	// alert('okkkkkkkkkkkkkkkkk');
	token = localStorage.getItem('token');
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse
	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("Lightbox_modifier_rappel_detail_prestataire").innerHTML = "<div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div>";


		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("Lightbox_modifier_rappel_detail_prestataire").innerHTML=xhr.responseText;
		}
					
	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
					//alert(id_incident);
	xhr.send("function=get_ajouter_rappel_detail&terminal="+terminal+
											"&id_incident="+id_incident+
											"&id_intervention="+id_intervention+
											"&id_degre="+id_degre+
											"&option="+opt);
}
/**
	* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function ajouter_nouvelle_appel2(incident){
	token = localStorage.getItem('token');
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("Lightbox_nouveau_appel_gab").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	txtnumaffectation = document.getElementById('txtnumaffectation').value;
	date_prise = document.getElementById('date_prise').value;
	id_affectation = document.getElementById('id_affectation').value;
	id_etat = document.getElementById('id_etat').value;
	id_rappel = document.getElementById('id_rappel').value;
	degre_declaration = document.getElementById('degre_declaration').value;
	id_motif_arret = document.getElementById('id_motif_arret').value;
	// alert('llllllllllllll');
	xhr.send("function=ajouter_nouvelle_appel2&txtnumaffectation="+txtnumaffectation+
											 "&id_motif_arret="+id_motif_arret+
											 "&id_rappel="+id_rappel+
											 "&id_affectation="+id_affectation+
											 "&id_etat="+id_etat+
											 "&date_prise="+date_prise+
											 "&degre_declaration="+degre_declaration+
											 "&id_incident="+incident);
}
 /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function modifier_date_prise_charge_iprc(id)
{
	token = localStorage.getItem('token');
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_charge"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	date_prise_charge_iprc = document.getElementById('date_prise_charge_iprc'+id).value;
	xhr.send("function=modifier_date_prise_charge_iprc&id_incident="+id+"&date_prise_charge_iprc="+date_prise_charge_iprc);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_date_prise_charge_iprc2(id,date_pr_charge)
{

	token = localStorage.getItem('token');
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_charge"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_date_prise_charge_iprc2&id="+id+"&date_prise_en_charge="+date_pr_charge);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_date_prise_charge(id,date_pr_charge)
{

	token = localStorage.getItem('token');
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_charge"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_date_prise_charge&id="+id+"&date_prise_en_charge="+date_pr_charge);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function modifier_date_arrete2(id)
{
	token = localStorage.getItem('token');

			var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_arrete"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	date_arrete = document.getElementById('date_arrete'+id).value;


	xhr.send("function=modifier_date_arrete2&date_arrete="+date_arrete+"&id="+id);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_date_arrete2(id,date_arrete)
{

	token = localStorage.getItem('token');
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_arrete"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_date_arrete2&id="+id+"&date_arrete="+date_arrete);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_date_arrete(id,date_arrete)
{

	token = localStorage.getItem('token');
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_arrete"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_date_arrete&id="+id+"&date_arrete="+date_arrete);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_degre_appel2(id,degre_appel)
{

	token = localStorage.getItem('token');
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_nbr_appel"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_degre_appel2&id="+id+"&degre_appel="+degre_appel);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_nbr_escalade2(id,nbr_escalade)
{
	token = localStorage.getItem('token');

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_nbr_escalade"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_nbr_escalade2&id="+id+"&nbr_escalade="+nbr_escalade);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_etat_contact2(id,etat_contact)
{
	token = localStorage.getItem('token');

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("id_etat_contact"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_etat_contact2&id="+id+"&etat_contact="+etat_contact);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_id_affectation2(id,id_affectation)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("id_affectation"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_id_affectation2&id="+id+"&id_affectation="+id_affectation);

}

/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function update_personne_avisee(id)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("personne_avisee"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	personne_avisee = document.getElementById('personneavisee'+id).value;
	xhr.send("function=update_personne_avisee&id="+id+"&personne_avisee="+personne_avisee);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_rappel2(id,date_rappel2)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_rappel2"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=get_annuler_update_rappel2&id="+id+"&date_rappel2="+date_rappel2);

}


  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_personne_avisee2(id,nbr_escalade)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("personne_avisee"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_personne_avisee2&id="+id+"&nbr_escalade="+nbr_escalade);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_personne_avisee(id,personne_avisee)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("personne_avisee"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_personne_avisee&id="+id+"&personne_avisee="+personne_avisee);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_date_derniere_rappel2(id,date_rappel)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_rappel"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_date_derniere_rappel2&id="+id+"&date_rappel="+date_rappel);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function modifier_dernier_rappel(id)
{
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_rappel"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	dernier_dtrappel = document.getElementById('dernier_dtrappel'+id).value;

	xhr.send("function=modifier_dernier_rappel&dernier_dtrappel="+dernier_dtrappel+"&id_incident="+id);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_date_derniere_rappel(id,date_rappel)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_rappel"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_date_derniere_rappel&id="+id+"&date_rappel="+date_rappel);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_date_prise_en_charge2(id,date_pr_charge2)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_charge2"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=get_annuler_update_date_prise_en_charge2&id="+id+"&date_prise_en_charge2="+date_pr_charge2);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_action_intervention2(id,idaction_intervention)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_id_action_intervention"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_action_intervention2&id="+id+"&idaction_intervention="+idaction_intervention);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function update_nbr_degre_appel(id)
{
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_nbr_appel"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	degre_appel = document.getElementById('degreappel'+id).value;
	xhr.send("function=update_nbr_degre_appel&id="+id+"&degre_appel="+degre_appel);

}

  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_nbr_degre_appel(id,degre_appel)
{
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_nbr_appel"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_nbr_degre_appel&id="+id+"&degre_appel="+degre_appel);

}
 /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function update_nbr_escalade(id)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_nbr_escalade"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	nbrescalade = document.getElementById('nbrescalade'+id).value;
	xhr.send("function=update_nbr_escalade&id="+id+"&nbr_escalade="+nbrescalade);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_nbr_escalade(id,nbr_escalade)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_nbr_escalade"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_nbr_escalade&id="+id+"&nbr_escalade="+nbr_escalade);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function update_id_etat_contact(id)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("id_etat_contact"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	etatcontact = document.getElementById('etatcontact'+id).value;
	xhr.send("function=update_id_etat_contact&id="+id+"&etat_contact="+etatcontact);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_id__etat_contact(id,etat_contact)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("id_etat_contact"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_id__etat_contact&id="+id+"&etat_contact="+etat_contact);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function update_id_affectation(id)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("id_affectation"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	idaffectation = document.getElementById('idaffectation'+id).value;
	xhr.send("function=update_id_affectation&id="+id+"&id_affectation="+idaffectation);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_id_affectation(id,id_affectation)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("id_affectation"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_id_affectation&id="+id+"&id_affectation="+id_affectation);

}
 /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function modifier_date_rappel2(id)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_rappel2"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	date_rappel2 = document.getElementById('daterappel2'+id).value;
	xhr.send("function=modifier_date_rappel2&id_action="+id+"&date_rappel2="+date_rappel2);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function suppimerRegion(id_sup)
	{
		if (confirm("Voulez-vous supprimer cet région ?"))
		{
			var xhr = getXhr();
			// On défini ce qu'on va faire quand on aura la réponse
			xhr.onreadystatechange = function()
			{
				// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
				if(xhr.readyState == 1)
				{
				//document.getElementById("listedepeche").className="invisible";
				//document.getElementById("message").className="tumevois";
				}
				if(xhr.readyState == 4 && xhr.status == 200){
						document.getElementById("divDeclarer").innerHTML=xhr.responseText;

				}
			}
			// Ici on va voir comment faire du post
			xhr.open("POST","ajax/ajax.php",true);
			// ne pas oublier ça pour le post
			xhr.setRequestHeader('x-access-token',token);
			xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
			xhr.send("function=suppimerRegion&id_sup="+id_sup);
		}
}

/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function suppimerProfil(id_profil)
	{
		if (confirm("Voulez-vous supprimer ce profil ?"))
		{
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse
	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";
		}
		if(xhr.readyState == 4 && xhr.status == 200){
				document.getElementById("divDeclarer").innerHTML=xhr.responseText;

		}
	}
	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
			xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xhr.send("function=suppimerProfil&id_profil="+id_profil);
		}
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function ajouterRegion()
	{
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse
	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";
		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divDeclarer").innerHTML=xhr.responseText;
		}
	}
	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
		xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	region = document.getElementById('region').value;
	xhr.send("function=ajouterRegion&region="+region);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getAjouterRegion(){

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse
	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";
		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("Lightbox_Label_ajouter_Region").innerHTML=xhr.responseText;

		}
	}
	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xhr.send("function=getAjouterRegion");
}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getAjouterProfil(){

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse
	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";
		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("Lightbox_Label_ajouter_Profil").innerHTML=xhr.responseText;

		}
	}
	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xhr.send("function=getAjouterProfil");
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function ajouterProfil()
	{
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse
	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";
		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divDeclarer").innerHTML=xhr.responseText;
		}
	}
	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
		xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	profil = document.getElementById('profil').value;
	xhr.send("function=ajouterProfil&profil="+profil);
}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function get_update_rappel2(id,date_rappel2)
{
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_rappel2"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=get_update_rappel2&id="+id+"&date_rappel2="+date_rappel2);

}
 /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function modifier_date_prise_charge_iprc2(id)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_charge2"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	date_prise_charge_iprc2 = document.getElementById('date_prise_charge_iprc2'+id).value;
	xhr.send("function=modifier_date_prise_charge_iprc2&id_action="+id+"&date_prise_charge_iprc2="+date_prise_charge_iprc2);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_date_prise_charge2(id,date_pr_charge2)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_date_charge2"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=get_update_date_prise_charge2&id="+id+"&date_prise_en_charge2="+date_pr_charge2);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function update_id_action_intervention(id)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_id_action_intervention"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	idaction_intervention = document.getElementById('idaction_intervention'+id).value;
	xhr.send("function=update_id_action_intervention&id="+id+"&idaction_intervention="+idaction_intervention);

}

/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_action_intervention(id,idaction_intervention)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_id_action_intervention"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_action_intervention&id="+id+"&idaction_intervention="+idaction_intervention);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function get_nouveau_appel_gab(id_incident){
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("Lightbox_nouveau_appel_gab").innerHTML = "<div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div>";


		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("Lightbox_nouveau_appel_gab").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
// alert('ggggggggg');
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xhr.send("function=get_nouveau_appel_gab&id_incident="+id_incident);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function cloturer_detail_6(option){
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("liste_disponibilite_gab").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	id_terminal_6 = document.getElementById('id_terminal_6').value;
	date_rappel_6 = document.getElementById('date_rappel_6').value;
	id_action_interv_6 = document.getElementById('id_action_interv_6').value;
	id_remarque_6 = document.getElementById('id_remarque_6').value;
	id_note_6 = document.getElementById('id_note_6').value;
	id_degre_6 = document.getElementById('id_degre_6').value;
	id_incident_6 = document.getElementById('id_incident_6').value;
	id_cloturer_6 = document.getElementById('id_cloturer_6').value;
	motif_cloturer_6 = document.getElementById('motif_cloturer_6').value;
	xhr.send("function=ajouter_rappel_detail&id_terminal_6="+id_terminal_6+
											"&date_rappel_6="+date_rappel_6+
											"&motif_cloturer_6="+motif_cloturer_6+
											"&id_action_interv_6="+id_action_interv_6+
											"&id_remarque_6="+id_remarque_6+
											"&id_note_6="+id_note_6+
											"&id_degre_6="+id_degre_6+
											"&id_incident_6="+id_incident_6+
											"&date_cloturer_6="+id_cloturer_6+
											"&option="+option);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_cloturer_detail_6(terminal,id_incident,id_intervention,id_degre,option){
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("Lightbox_Label_cloturer_detail_6").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xhr.send("function=get_ajouter_rappel_detail&terminal="+terminal+
											"&id_incident="+id_incident+
											"&id_intervention="+id_intervention+
											"&id_degre="+id_degre+
											"&option="+option);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function modifier_detail_5(option){
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("liste_disponibilite_gab").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post

	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	id_terminal_5 = document.getElementById('id_terminal_5').value;
	id_intervention_5 = document.getElementById('id_intervention_5').value;
	date_rappel_5 = document.getElementById('date_rappel_5').value;
	date_arret_5 = document.getElementById('date_arret_5').value;
	id_incident_5 = document.getElementById('id_incident_5').value;
	date_remis_5 = document.getElementById('date_remis_5').value;
	etat_incident_5 = document.getElementById('etat_incident_5').value;

	xhr.send("function=ajouter_rappel_detail&id_terminal_5="+id_terminal_5+
											"&id_intervention_5="+id_intervention_5+
											"&date_rappel_5="+date_rappel_5+
											"&date_arret_5="+date_arret_5+
											"&id_incident_5="+id_incident_5+
											"&date_remis_5="+date_remis_5+
											"&etat_incident_5="+etat_incident_5+
											"&option="+option);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function get_modifier_detail_5(terminal,id_incident,id_intervention,id_degre,option){
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("Lightbox_Label_modifier_detail_5").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xhr.send("function=get_ajouter_rappel_detail&terminal="+terminal+
											"&id_incident="+id_incident+
											"&id_intervention="+id_intervention+
											"&id_degre="+id_degre+
											"&option="+option);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function supprimer_intervention_incident_6(terminal,id_incident,id_intervention,id_degre,option){
	//alert('okkkkkkkkkkkkkkkkk');
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("liste_disponibilite_gab").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xhr.send("function=ajouter_rappel_detail&terminal="+terminal+
											"&id_incident="+id_incident+
											"&id_intervention="+id_intervention+
											"&id_degre="+id_degre+
											"&option="+option);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function ajouter_rappel_detail_3(opt){
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("liste_disponibilite_gab").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	id_terminal_3 = document.getElementById('id_terminal_3').value;
	date_rappel_3 = document.getElementById('date_rappel_3').value;
	id_action_interv_3 = document.getElementById('id_action_interv_3').value;
	id_remarque_3 = document.getElementById('id_remarque_3').value;
	id_note_3 = document.getElementById('id_note_3').value;
	id_degre_3 = document.getElementById('id_degre_3').value;
	id_appel_3 = document.getElementById('id_appel_3').value;
	id_incident_3 = document.getElementById('id_incident_3').value;
	id_cloturer_3 = document.getElementById('id_cloturer_3').value;
	id_affecter_3 = document.getElementById('id_affecter_3').value;
	id_etat_3 = document.getElementById('id_etat_3').value;
	persone_avise = "";

	xhr.send("function=ajouter_rappel_detail&id_terminal_3="+id_terminal_3+
											"&date_rappel_3="+date_rappel_3+
											"&id_action_interv_3="+id_action_interv_3+
											"&id_remarque_3="+id_remarque_3+
											"&id_note_3="+id_note_3+
											"&id_degre_3="+id_degre_3+
											"&id_appel_3="+id_appel_3+
											"&id_incident_3="+id_incident_3+
											"&id_cloturer_3="+id_cloturer_3+
											"&id_affecter_3="+id_affecter_3+
											"&id_etat_3="+id_etat_3+
											"&persone_avise="+persone_avise+
											"&option="+opt);
}

/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_nom_gab(id,nom_gab)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_nom_gab"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_nom_gab&id="+id+"&nom_gab="+nom_gab);

}

/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function confirmLogicalNamesServiceATM(idatm,idservice,paramettre,idprivilege,date_debut,date_fin,historique_vacation)
{


	var xhr = getXhr();
	var valLogicalnames = "";
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_etat_parc").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	var LogicalnamesATM = document.getElementsByName('allLogicalnamesATM'+idservice+'[]');
		for (var i=0, j=LogicalnamesATM.length;i<j;i++)
		{
			if (LogicalnamesATM[i].checked)
			{

				valLogicalnames +=LogicalnamesATM[i].value+",";
			}
		}

	xhr.send("function=confirmLogicalNamesServiceATM&idatm="+idatm+"&idservice="+idservice+"&valLogicalname="+valLogicalnames+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&date_debut="+date_debut+
												"&date_fin="+date_fin+
												"&historique_vacation="+historique_vacation);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function confirmSLogicalNamesServiceATM(idatm,idservice,id_logical_name,nameTable,paramettre,idprivilege,date_debut,date_fin,historique_vacation)
{


	var xhr = getXhr();
	var valSLogicalnames = "";
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_etat_parc").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	var SLogicalnamesATM = document.getElementsByName('allSLogicalnamesATM'+idservice+''+id_logical_name+'[]');
		for (var i=0, j=SLogicalnamesATM.length;i<j;i++)
		{
			if (SLogicalnamesATM[i].checked)
			{

				valSLogicalnames +=SLogicalnamesATM[i].value+",";
			}
		}

	xhr.send("function=confirmSLogicalNamesServiceATM&idatm="+idatm+"&idservice="+idservice+"&valSLogicalname="+valSLogicalnames+"&nameTable="+nameTable+
												"&paramettre="+paramettre+
												"&id_logical_name="+id_logical_name+
												"&idprivilege="+idprivilege+
												"&date_debut="+date_debut+
												"&date_fin="+date_fin+
												"&historique_vacation="+historique_vacation);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function declarer_incident_gab(idGVacation,idVacation,tableVacation,xfsErreur,xfsStatus,nameVacation,histDateVacation,histNameFile,category,code_error,logical_name,paramAffichage)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModalDetailPeripheralStatus").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	id_ATM = document.getElementById('id_ATM').value;
	name_ATM = document.getElementById('name_ATM').value;
	Vacation = document.getElementById('Vacation').value;
	Erreur = document.getElementById('Erreur').value;
	statusXFS = document.getElementById('statusXFS').value;
	categoryXFS = document.getElementById('categoryXFS').value;
	codeError = document.getElementById('codeError').value;
	dateVacation = document.getElementById('dateVacation').value;

	xhr.send("function=declarer_incident_gab&idGVacation="+idGVacation+
												"&idVacation="+idVacation+
												"&tableVacation="+tableVacation+
												"&xfsErreur="+xfsErreur+
												"&xfsStatus="+xfsStatus+
												"&histDateVacation="+histDateVacation+
												"&histNameFile="+histNameFile+
												"&category="+category+
												"&code_error="+code_error+
												"&logical_name="+logical_name+
												"&nameVacation="+nameVacation+
												"&id_ATM="+id_ATM+
												"&name_ATM="+name_ATM+
												"&Vacation="+Vacation+
												"&Erreur="+Erreur+
												"&statusXFS="+statusXFS+
												"&categoryXFS="+categoryXFS+
												"&codeError="+codeError+
												"&paramAffichage="+paramAffichage+
												"&dateVacation="+dateVacation);

}

/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function updateXFSErrors(paramettre,idprivilege,id_atm,idVacation,tableVacation,xfsErreur,xfsStatus,nameVacation,histDateVacation,histNameFile,category,code_error,logical_name,paramAffichage,id_service,id_error,etatVal)
{
		if (confirm("Voulez-vous désactiver cette etat XFS erreur ?"))
		{
// alert(logical_name);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModalDetailPeripheralStatus").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
			xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=updateXFSErrors&id_atm="+id_atm+
												"&idVacation="+idVacation+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&tableVacation="+tableVacation+
												"&xfsErreur="+xfsErreur+
												"&xfsStatus="+xfsStatus+
												"&histDateVacation="+histDateVacation+
												"&histNameFile="+histNameFile+
												"&category="+category+
												"&code_error="+code_error+
												"&logical_name="+logical_name+
												"&paramAffichage="+paramAffichage+
												"&id_service="+id_service+
												"&id_error="+id_error+
												"&etatVal="+etatVal+
												"&nameVacation="+nameVacation);
}
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getDetailPeripheralStatusSpinner()
{

// alert(logical_name);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		 // document.getElementById("divModalDetailPeripheralStatus").innerHTML = "<img src='img/spinnerIPRC.gif' />";
		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModalDetailPeripheralStatus").innerHTML=xhr.responseText;
				 // document.getElementById("divModalDetailPeripheralStatus").innerHTML = "<img src='img/spinnerIPRC.gif'/>"; ;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getDetailPeripheralStatusSpinner");
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getDetailPeripheralStatus(paramettre,idprivilege,id_atm,idVacation,tableVacation,xfsErreur,xfsStatus,nameVacation,histDateVacation,histNameFile,category,code_error,logical_name,paramAffichage)
{

 	//alert(id_atm);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function()
	{
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalDetailPeripheralStatus").innerHTML = "<div class='modal-dialog modal-xl'><div class='modal-content' ><div class='modal-header'><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img style='display: block;margin-left: auto; margin-right: auto;' src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";
		}
		if(xhr.readyState == 4 && xhr.status == 200)
		{
			document.getElementById("divModalDetailPeripheralStatus").innerHTML=xhr.responseText;
			// document.getElementById("divModalDetailPeripheralStatus").innerHTML = "<img src='img/spinnerIPRC.gif'/>"; ;
		}
	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getDetailPeripheralStatus&id_atm="+id_atm+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&idVacation="+idVacation+
												"&tableVacation="+tableVacation+
												"&xfsErreur="+xfsErreur+
												"&xfsStatus="+xfsStatus+
												"&histDateVacation="+histDateVacation+
												"&histNameFile="+histNameFile+
												"&category="+category+
												"&code_error="+code_error+
												"&logical_name="+logical_name+
												"&paramAffichage="+paramAffichage+
												"&nameVacation="+nameVacation);

}

/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getDetailVacationPeripheralStatus(paramettre,idprivilege,id_atm,idVacation,tableVacation,xfsErreur,xfsStatus,nameVacation,histDateVacation,histNameFile,category,code_error,logical_name,paramAffichage)
{

// alert(logical_name);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("detail_historique_vacation").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getDetailVacationPeripheralStatus&id_atm="+id_atm+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&idVacation="+idVacation+
												"&tableVacation="+tableVacation+
												"&xfsErreur="+xfsErreur+
												"&xfsStatus="+xfsStatus+
												"&histDateVacation="+histDateVacation+
												"&histNameFile="+histNameFile+
												"&category="+category+
												"&code_error="+code_error+
												"&logical_name="+logical_name+
												"&paramAffichage="+paramAffichage+
												"&nameVacation="+nameVacation);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/


function cloturer_incident_fonctionnelle2(id_incident,id,option)
{ //alert('hhhh');
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("liste_gab_sgma").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	date_cloture = document.getElementById('cloture_fonction'+id).value;
	//alert(date_cloture);
	xhr.send("function=cloturer_incident_fonctionnelle2&date_cloture="+date_cloture+"&id_incident="+id_incident+"&option="+option);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getDetailHistotiquePeripheralStatus(paramettre,idprivilege,id_atm,id_vacation,service,tableVacation,xfsErreur,xfsStatus,nameVacation,histDateVacation,histNameFile,category,code_error,logical_name,id_logical_name,paramAffichage)
{

	// alert(logical_name);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModalVacationATM").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getDetailHistotiquePeripheralStatus&id_atm="+id_atm+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&tableVacation="+tableVacation+
												"&id_vacation="+id_vacation+
												"&id_service="+service+
												"&xfsErreur="+xfsErreur+
												"&xfsStatus="+xfsStatus+
												"&histDateVacation="+histDateVacation+
												"&histNameFile="+histNameFile+
												"&category="+category+
												"&code_error="+code_error+
												"&logical_name="+logical_name+
												"&id_logical_name="+id_logical_name+
												"&paramAffichage="+paramAffichage+
												"&nameVacation="+nameVacation);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getConfigServiceATM(id_atm,paramettre,idprivilege,date_debut,date_fin,historique_vacation)
{

// alert(logical_name);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalConfigServiceATM").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Service</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModalConfigServiceATM").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getConfigServiceATM&id_atm="+id_atm+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&date_debut="+date_debut+
												"&date_fin="+date_fin+
												"&historique_vacation="+historique_vacation);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getConfigLogicalNameService(id_atm,paramettre,idprivilege,date_debut,date_fin,historique_vacation)
{

// alert(logical_name);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalConfigLogicalNameServiceATM").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Logical Name par Service</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModalConfigLogicalNameServiceATM").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getConfigLogicalNameService&id_atm="+id_atm+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&date_debut="+date_debut+
												"&date_fin="+date_fin+
												"&historique_vacation="+historique_vacation);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getConfigStatusLogicalName(id_atm,paramettre,idprivilege,date_debut,date_fin,historique_vacation)
{

// alert(logical_name);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalConfigStatusLogicalNameATM").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Status Errors xsf - Logical Name</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModalConfigStatusLogicalNameATM").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getConfigStatusLogicalName&id_atm="+id_atm+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&date_debut="+date_debut+
												"&date_fin="+date_fin+
												"&historique_vacation="+historique_vacation);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getConfigStatusXFSName(id_atm,paramettre,idprivilege,date_debut,date_fin,historique_vacation)
{

// alert(logical_name);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalConfigStatusXFSNameATM").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Activer toutes les status XFS Errors</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModalConfigStatusXFSNameATM").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getConfigStatusXFSName&id_atm="+id_atm+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&date_debut="+date_debut+
												"&date_fin="+date_fin+
												"&historique_vacation="+historique_vacation);

}

/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getRedemarrerATM(id_atm,paramettre,idprivilege,date_debut,date_fin,historique_vacation)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalRedemarrerATM").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img style='display: block;margin-left: auto; margin-right: auto;' src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

		}
		if(xhr.readyState == 4 && xhr.status == 200)
		{
			document.getElementById("divModalRedemarrerATM").innerHTML=xhr.responseText;
		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getRedemarrerATM&id_atm="+id_atm+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&date_debut="+date_debut+
												"&date_fin="+date_fin+
												"&historique_vacation="+historique_vacation);

}



/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function getPingATM(paramettre,idprivilege,id_atm,terminal,ip_adress)
{

	// alert(logical_name);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalPingATM").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";
		}
		if(xhr.readyState == 4 && xhr.status == 200){

			document.getElementById("divModalPingATM").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getPingATM&paramettre="+paramettre+
		"&idprivilege="+idprivilege+
		"&id_atm="+id_atm+
		"&terminal="+terminal+
		"&ip_adress="+ip_adress);
}



/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getScreenshotATM(id_atm)
{

// alert(logical_name);
var xhr = getXhr();
// On défini ce qu'on va faire quand on aura la réponse

xhr.onreadystatechange = function(){
// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
if(xhr.readyState == 1)
{
	document.getElementById("divModalScreenshotATM").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img style='display: block;margin-left: auto; margin-right: auto;' src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";
}
if(xhr.readyState == 4 && xhr.status == 200){

	document.getElementById("divModalScreenshotATM").innerHTML=xhr.responseText;

}

}

// Ici on va voir comment faire du post
xhr.open("POST","ajax/ajax.php",true);
// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


xhr.send("function=getScreenshotATM&id_atm="+id_atm);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function ShowScreenshotATM(id_atm,value_cmd)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function()
	{
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalshowScreenshotATM").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Capture écran GAB</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";
		}
		if(xhr.readyState == 4 && xhr.status == 200)
		{
			document.getElementById("divModalshowScreenshotATM").innerHTML=xhr.responseText;
		}
	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
		xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=ShowScreenshotATM&id_atm="+id_atm+
	"&value_cmd="+value_cmd);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function activerRedemarrerATM(id_atm,paramettre,idprivilege,date_debut,date_fin,historique_vacation)
{
token = localStorage.getItem('token');
var xhr = getXhr();
// On défini ce qu'on va faire quand on aura la réponse

xhr.onreadystatechange = function(){
// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
if(xhr.readyState == 1)
{


}
if(xhr.readyState == 4 && xhr.status == 200){

	// document.getElementById("div_etat_parc").innerHTML=xhr.responseText;
}

}

// Ici on va voir comment faire du post
xhr.open("POST","ajax/ajax.php",true);
// ne pas oublier ça pour le post
xhr.setRequestHeader('x-access-token',token);
xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

code_redemarage = document.getElementById('code_redemarage'+id_atm).value;

xhr.send("function=activerRedemarrerATM&id_atm="+id_atm+"&paramettre="+paramettre+"&idprivilege="+idprivilege+"&code_redemarage="+code_redemarage+
									"&date_debut="+date_debut+"&date_fin="+date_fin+"&historique_vacation="+historique_vacation);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function redemarrerATM(id_atm,paramettre,idprivilege)
{
token = localStorage.getItem('token');

var xhr = getXhr();


xhr.onreadystatechange = function(){
// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
if(xhr.readyState == 1)
{
//document.getElementById("listedepeche").className="invisible";
//document.getElementById("message").className="tumevois";
}
if(xhr.readyState == 4 && xhr.status == 200)
{
	document.getElementById("div_etat_parc").innerHTML=xhr.responseText;
}
}
// Ici on va voir comment faire du post
xhr.open("POST","ajax/ajax.php",true);
// ne pas oublier ça pour le post
xhr.setRequestHeader('x-access-token',token);
xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');



xhr.send("function=redemarrerATM&id_atm="+id_atm+"&paramettre="+paramettre+"&idprivilege="+idprivilege);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function activerScreenshotATM(id_atm)
{
token = localStorage.getItem('token');
var xhr = getXhr();
// On défini ce qu'on va faire quand on aura la réponse

xhr.onreadystatechange = function(){
// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
if(xhr.readyState == 1)
{
	//document.getElementById("listedepeche").className="invisible";
	//document.getElementById("message").className="tumevois";

}
if(xhr.readyState == 4 && xhr.status == 200){

	// document.getElementById("div_etat_parc").innerHTML=xhr.responseText;

}

}

// Ici on va voir comment faire du post
xhr.open("POST","ajax/ajax.php",true);
// ne pas oublier ça pour le post
xhr.setRequestHeader('x-access-token',token);
xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

var code_redemarage = document.getElementById('code_Screenshot'+id_atm).value;

xhr.send("function=activerScreenshotATM&id_atm="+id_atm+"&code_redemarage="+code_redemarage);

}
/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function suppimer_gab_suivi(id_incident)
{
	if (confirm("Voulez-vous supprimer cet incident ?"))
	{
		var xhr = getXhr();
		// On défini ce qu'on va faire quand on aura la réponse

		xhr.onreadystatechange = function(){
			// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
			if(xhr.readyState == 1)
			{
				//document.getElementById("listedepeche").className="invisible";
				//document.getElementById("message").className="tumevois";

			}
			if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_declarer").innerHTML=xhr.responseText;

			}

		}

		// Ici on va voir comment faire du post
		xhr.open("POST","ajax/ajax.php",true);
		// ne pas oublier ça pour le post
		xhr.setRequestHeader('x-access-token',token);
		xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


		xhr.send("function=suppimer_gab_suivi&id_incident="+id_incident);
	}

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function confirmeDeclarerNouveauGAB(id_atm,paramettre,idprivilege,date_debut,date_fin,historique_vacation)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function()
	{
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			//document.getElementById("listedepeche").className="invisible";
			//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200)
		{
			document.getElementById("div_etat_parc").innerHTML=xhr.responseText;
		}
	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	send_statut = $("#radioDiv1 input[type='radio']:checked").val();
	parse_journal = $("#radioDiv2 input[type='radio']:checked").val();
	exec_command = $("#radioDiv3 input[type='radio']:checked").val();
	depl_image = $("#radioDiv4 input[type='radio']:checked").val();
	depl_binaire = $("#radioDiv5 input[type='radio']:checked").val();
	upload_command = $("#radioDiv6 input[type='radio']:checked").val();
	cd_ATM = document.getElementById('cd_ATM'+id_atm).value;
	name_ATM = document.getElementById('name_ATM'+id_atm).value;
	constucteur = document.getElementById('constucteur'+id_atm).value;
	profil = document.getElementById('profil'+id_atm).value;
	cd_agance = document.getElementById('cd_agance'+id_atm).value;
	ville = document.getElementById('ville'+id_atm).value;
	region = document.getElementById('region'+id_atm).value;
	code_region = document.getElementById('code_region'+id_atm).value;
	pays = document.getElementById('pays'+id_atm).value;
	ip_adresse_gab = document.getElementById('ip_adresse_gab'+id_atm).value;
	name_agence = document.getElementById('name_agence'+id_atm).value;


	xhr.send("function=confirmeDeclarerNouveauGAB&id_atm="+id_atm+
			"&name_ATM="+name_ATM+
			"&constucteur="+constucteur+
			"&profil="+profil+
			"&cd_agance="+cd_agance+
			"&ville="+ville+
			"&region="+region+
			"&code_region="+code_region+
			"&cd_ATM="+cd_ATM+
			"&pays="+pays+
			"&ip_adresse_gab="+ip_adresse_gab+
			"&name_agence="+name_agence+
			"&send_statut="+send_statut+
			"&parse_journal="+parse_journal+
			"&exec_command="+exec_command+
			"&depl_image="+depl_image+
			"&depl_binaire="+depl_binaire+
			"&upload_command="+upload_command+
			"&paramettre="+paramettre+
			"&idprivilege="+idprivilege+
			"&date_debut="+date_debut+
			"&date_fin="+date_fin+
			"&historique_vacation="+historique_vacation);
	$( "#tr" +id_atm).load(window.location.href + " #tr" +id_atm);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function modifierATMConfirmed(id_atm)
{
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function()
	{
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			//document.getElementById("listedepeche").className="invisible";
			//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200)
		{
			document.getElementById("div_etat_parc").innerHTML=xhr.responseText;
		}
	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	idATM = document.getElementById('id_ATM'+id_atm).value;
	cd_ATM_old = document.getElementById('cd_terminal'+id_atm).value;
	cd_agence = document.getElementById('cd_agence'+id_atm).value;
	cd_ATM = document.getElementById('id_ATM2').value;
	name_ATM = document.getElementById('name_ATM'+id_atm).value;
	profil=document.getElementById('profil'+id_atm).value;
	constucteur = document.getElementById('constucteur'+id_atm).value;
	nbr_jr_file = document.getElementById('nbr_jr_file'+id_atm).value;
	state=$("#radioDiv1 input[type='radio']:checked").val();
	send_statut = $("#radioDiv2 input[type='radio']:checked").val();
	parse_journal = $("#radioDiv3 input[type='radio']:checked").val();
	exec_command = $("#radioDiv4 input[type='radio']:checked").val();
	depl_image = $("#radioDiv5 input[type='radio']:checked").val();
	depl_binaire = $("#radioDiv6 input[type='radio']:checked").val();
	sleep_command = $("#radioDiv7 input[type='radio']:checked").val();
	state_depot_argent = $("#radioDiv8 input[type='radio']:checked").val();
	state_depot_cheque = $("#radioDiv9 input[type='radio']:checked").val();
	state_uplaod_cmd = $("#radioDiv10 input[type='radio']:checked").val();
	time_sleeping = document.getElementById('time_sleeping'+id_atm).value;



	var r = confirm("Vous Voulez Modifier l'ATM !!");
	if (r === true)
	{


		xhr.send("function=modifierATMConfirmed&id_atm="+idATM+
			"&cd_ATM="+cd_ATM+
			"&cd_ATM_old="+cd_ATM_old+
			"&name_ATM="+name_ATM+
			"&profil="+profil+
			"&constucteur="+constucteur+
			"&nbr_jr_file="+nbr_jr_file+
			"&state="+state+
			"&send_statut="+send_statut+
			"&parse_journal="+parse_journal+
			"&exec_command="+exec_command+
			"&depl_image="+depl_image+
			"&depl_binaire="+depl_binaire+
			"&sleep_command="+sleep_command+
			"&state_depot_argent="+state_depot_argent+
			"&state_depot_cheque="+state_depot_cheque+
			"&time_sleeping="+time_sleeping+
			"&cd_agence="+cd_agence+
			"&state_uplaod_cmd="+state_uplaod_cmd);

		$( "#tr" +id_atm).load(window.location.href + " #tr" +id_atm);

		//$( "#tr_" +idATM).load(window.location.href + " #tr_" +idATM);
	}
	else
	{
		alert("Aucune mise à jour n'a été effectuée !!!");
	}
	$( "#tr" +id_atm).load(window.location.href + " #tr" +id_atm);

	//$( "#tr_" +idATM).load(window.location.href + " #tr_" +idATM);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function change_state(id_atm)
{                                                                                                                                                                                                                                                                                                                                                                                                                                 


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
	// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
	if(xhr.readyState == 1)
	{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

	}
	if(xhr.readyState == 4 && xhr.status == 200){

		//document.getElementById("tbl_suivi").innerHTML=xhr.responseText;

	}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post

	var r = confirm("You want to activate the ATM !!");
	if (r == true) {
		xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xhr.send("function=change_state&id_atm="+id_atm);
	$( "#div" +id_atm).load(window.location.href + " #div" +id_atm);
	$( "#div1" +id_atm).load(window.location.href + " #div1" +id_atm);

	}
	else
	{
		alert("No updates have been made !!!");
	}
	$( "#div" +id_atm).load(window.location.href + " #div" +id_atm);
	$( "#div1" +id_atm).load(window.location.href + " #div1" +id_atm);


}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function modifierGAB(id_atm)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_declarer").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	cd_terminal = document.getElementById('cd_terminal'+id_atm).value;
	name_ATM = document.getElementById('name_ATM'+id_atm).value;
	constucteur = document.getElementById('constucteur'+id_atm).value;
	cd_agance = document.getElementById('cd_agance'+id_atm).value;
	ville = document.getElementById('ville'+id_atm).value;
	region = document.getElementById('region'+id_atm).value;

	xhr.send("function=modifierGAB&id_atm="+id_atm+
												"&name_ATM="+name_ATM+
												"&constucteur="+constucteur+
												"&cd_agance="+cd_agance+
												"&ville="+ville+
												"&region="+region+
												"&cd_terminal="+cd_terminal);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function activerToutesStatusXFSErrors(id_atm,paramettre,idprivilege,date_debut,date_fin,historique_vacation)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200)
		{
			document.getElementById("div_etat_parc").innerHTML=xhr.responseText;
		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=activerToutesStatusXFSErrors&id_atm="+id_atm+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&date_debut="+date_debut+
												"&date_fin="+date_fin+
												"&historique_vacation="+historique_vacation);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function declarerNouveauGAB(id_atm,paramettre,idprivilege,date_debut,date_fin,historique_vacation)
{

// alert(logical_name);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModaldeclarerNouveauGAB").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Nouveau GAB</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModaldeclarerNouveauGAB").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=declarerNouveauGAB&id_atm="+id_atm+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&date_debut="+date_debut+
												"&date_fin="+date_fin+
												"&historique_vacation="+historique_vacation);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getModifierGAB(id_atm)
{

// alert(logical_name);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalModifierGAB").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Modifier GAB</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModalModifierGAB").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getModifierGAB&id_atm="+id_atm);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getModifierATMConfirmed(id_atm)
{

// alert(logical_name);
var xhr = getXhr();
// On défini ce qu'on va faire quand on aura la réponse

xhr.onreadystatechange = function(){
// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
if(xhr.readyState == 1)
{
	document.getElementById("divModalModifierATMConfirmed").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Modifier ATM Confirmed</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

}
if(xhr.readyState == 4 && xhr.status == 200){

	document.getElementById("divModalModifierATMConfirmed").innerHTML=xhr.responseText;

}

}

// Ici on va voir comment faire du post
xhr.open("POST","ajax/ajax.php",true);
// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


xhr.send("function=getModifierATMConfirmed&id_atm="+id_atm);

}

/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getDownloadFileGAB(id_atm,terminalID,idprivilege)
{

	// alert(logical_name);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function()
	{
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalDownloadFileGAB").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Download files</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

		}
		if(xhr.readyState == 4 && xhr.status == 200)
		{
			document.getElementById("divModalDownloadFileGAB").innerHTML=xhr.responseText;
		}
	}

// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getDownloadFileGAB&id_atm="+id_atm+
		'&terminalID='+terminalID+
		'&idprivilege='+idprivilege);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function modifierAgence(code_agence)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_declarer").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');



	name_agence = document.getElementById('name_agence'+code_agence).value;
	name_region = document.getElementById('name_region'+code_agence).value;
	name_ville = document.getElementById('name_ville'+code_agence).value;


	xhr.send("function=modifierAgence&code_agence="+code_agence+
												"&name_agence="+name_agence+
												"&name_region="+name_region+
												"&name_ville="+name_ville);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_remarque2(id,remarque)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_remarque"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_remarque2&id="+id+"&remarque="+remarque);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function modifier_remarque2(id)
{


			var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_remarque"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	remarque = document.getElementById('remarque'+id).value;


	xhr.send("function=modifier_remarque2&remarque="+remarque+"&id_incident="+id);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_remarque_incident(id,remarque)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_remarque"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_remarque_incident&id="+id+"&remarque="+remarque);

}

/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_numSerie(id,numSerie)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_adresse_serie"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_numSerie&id="+id+"&numSerie="+numSerie);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function modifiernumSerie(id)
{


			var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_adresse_serie"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	numSerie = document.getElementById('numSerie'+id).value;


	xhr.send("function=modifiernumSerie&numSerie="+numSerie+"&id="+id);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getupdateNumSerie(id,Numserie)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_adresse_serie"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getupdateNumSerie&id="+id+"&Numserie="+Numserie);

}
	/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_num_affectation2(id,num_affectation)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_num_affectation"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_num_affectation2&id="+id+"&num_affectation="+num_affectation);

}

		  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function modifier_num_tiket_bcp(id)
{


			var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_num_affectation"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	num_tiket_abi = document.getElementById('num_tiket_abi'+id).value;


	xhr.send("function=modifier_num_tiket_bcp&num_tiket_abi="+num_tiket_abi+"&id_incident="+id);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_num_affectation(id,num_affectation)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_num_affectation"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_num_affectation&id="+id+"&num_affectation="+num_affectation);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function modifier_nom_gab2(id)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_nom_gab"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xhr.setRequestHeader('x-access-token',token);
	nom_gab = document.getElementById('nom_gab'+id).value;


	xhr.send("function=modifier_nom_gab2&nom_gab="+nom_gab+"&id="+id);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_adresse_ip2(id,adresse_ip)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_adresse_ip"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_adresse_ip2&id="+id+"&adresse_ip="+adresse_ip);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function modifier_adresse_ip2(id)
{


			var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_adresse_ip"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	adresse_ip = document.getElementById('adresse_ip'+id).value;


	xhr.send("function=modifier_adresse_ip2&adresse_ip="+adresse_ip+"&id="+id);

}
  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_adresse_ip(id,adresse_ip)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_adresse_ip"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_adresse_ip&id="+id+"&adresse_ip="+adresse_ip);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_annuler_update_nom_gab2(id,nom_gab)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_nom_gab"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_annuler_update_nom_gab2&id="+id+"&nom_gab="+nom_gab);

}

  /**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_update_etat_auto_clo(id,auto_clo,id_gab)
{


	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_activ_auto_clo"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_etat_auto_clo&id="+id+"&auto_clo="+auto_clo+"&id_gab="+id_gab);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getModifierAgence(code_agence)
{

// alert(logical_name);
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalModifierAgence").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Modifier Agence</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModalModifierAgence").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getModifierAgence&code_agence="+code_agence);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function suppimerTerminal(id_atm)
{
	if (confirm("Do you want to delete this ATM?"))
	{
		// alert('ok1');
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_declarer").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
			xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xhr.send("function=suppimerTerminal&id_atm="+id_atm);
		}
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function suppimerAgence(code_agence)
	{
		if (confirm("Voulez-vous supprimer cet agence ?"))
		{
		// alert('ok1');
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_declarer").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
			xhr.setRequestHeader('x-access-token',token);
			xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xhr.send("function=suppimerAgence&code_agence="+code_agence);
		}
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function getDeclarerPeripheralStatus(id_atm,idVacation,tableVacation,xfsErreur,xfsStatus,nameVacation,histDateVacation,histNameFile,category,code_error,logical_name,paramAffichage)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModalDetailPeripheralStatus").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getDeclarerPeripheralStatus&id_atm="+id_atm+
												"&idVacation="+idVacation+
												"&tableVacation="+tableVacation+
												"&xfsErreur="+xfsErreur+
												"&xfsStatus="+xfsStatus+
												"&histDateVacation="+histDateVacation+
												"&histNameFile="+histNameFile+
												"&category="+category+
												"&code_error="+code_error+
												"&logical_name="+logical_name+
												"&paramAffichage="+paramAffichage+
												"&nameVacation="+nameVacation);

}

function getVacationATM(id_atm,paramettre,idprivilege,date_debut,date_fin,vacation_date)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
	if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModalVacationATM").innerHTML=xhr.responseText;

				var today = new Date();
				$('#datetimepicker6').datetimepicker({
					format: 'yyyy-mm-dd hh:ii:00',
					autoclose: true,
					todayBtn: true,
					endDate : today
				}).on('changeDate', function(ev){
					$('#datetimepicker7').datetimepicker('setStartDate', ev.date);
				});

				$('#datetimepicker7').datetimepicker({
					format: 'yyyy-mm-dd hh:ii:00',
					autoclose: true,
					todayBtn: true,
					endDate : today
				}).on('changeDate', function(ev){
					$('#datetimepicker6').datetimepicker('setEndDate', ev.date);
				});
				$('select').selectpicker();

			}

	}
	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=getVacationATM&id_atm="+id_atm+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&date_debut="+date_debut+
												"&date_fin="+date_fin+
												"&vacation_date="+vacation_date);

}

function getVacationATM2(id_atm,paramettre,idprivilege,vacation_date)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
	if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("divModalVacationATM").innerHTML=xhr.responseText;

				var today = new Date();
				$('#datetimepicker6').datetimepicker({
					format: 'yyyy-mm-dd hh:ii:00',
					autoclose: true,
					todayBtn: true,
					endDate : today
				}).on('changeDate', function(ev){
					$('#datetimepicker7').datetimepicker('setStartDate', ev.date);
				});

				$('#datetimepicker7').datetimepicker({
					format: 'yyyy-mm-dd hh:ii:00',
					autoclose: true,
					todayBtn: true,
					endDate : today
				}).on('changeDate', function(ev){
					$('#datetimepicker6').datetimepicker('setEndDate', ev.date);
				});
				$('select').selectpicker();

			}


	}
	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	date_debut = document.getElementById('datedebut'+id_atm).value;
	date_fin = document.getElementById('datefin'+id_atm).value;
	xhr.send("function=getVacationATM&id_atm="+id_atm+
												"&paramettre="+paramettre+
												"&idprivilege="+idprivilege+
												"&date_debut="+date_debut+
												"&date_fin="+date_fin+
												"&vacation_date="+vacation_date);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function afficher_nom_gab(id_gab){
	var xhr = getXhr();

	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("get_nom_gab").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=afficher_nom_gab&id_gab="+id_gab);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function afficher_affectation_gab(id_gab){
	var xhr = getXhr();

	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_affecter").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=afficher_affectation_gab&id_gab="+id_gab);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function afficher_information_gab(id_gab)
{
	var xhr = getXhr();

	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_information_gab").innerHTML=xhr.responseText;
		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=afficher_information_gab&id_gab="+id_gab);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function verif_declaration_gab(id_gab){
	var xhr = getXhr();

	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_verif_gab").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=verif_declaration_gab&id_gab="+id_gab);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function vider_verif_declaration_gab(){
	var xhr = getXhr();

	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_verif_gab").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=vider_verif_declaration_gab");
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function actueliser_date_rappel(){

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_inputrappel").innerHTML=xhr.responseText;
		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xhr.send("function=actueliser_date_rappel");
}

/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function afficher_btn_ajouter(id_gab){
	var xhr = getXhr();

	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_btn_ajouter").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=afficher_btn_ajouter&id_gab="+id_gab);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function afficher_information_historique_gab(id_gab){
	var xhr = getXhr();

	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_historique_gab").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=afficher_information_historique_gab&id_gab="+id_gab);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function afficher_ping(id_gab){
	var xhr = getXhr();
// alert();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("testerPing").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=afficher_ping&id_gab="+id_gab);
}
function getdeatil_per(id_gab)
{
	var xhr = getXhr();
// alert();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("testerpériph").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=getdeatil_per&id_gab="+id_gab);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_motif_arret(motif,idmotif,terminal)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_cause_arret").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_motif_arret&motif="+motif+"&idmotif="+idmotif+"&terminal="+terminal);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_generer_mail(motif){
	//alert(motif);

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_generer_mail").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

		inputarret = document.getElementById('inputarret').value;
	terminal = document.getElementById('input_terminal').value;
	var e = document.getElementById("id_affecter_sel");
	var id_affecter = e.value;
	xhr.send("function=get_generer_mail&inputarret="+inputarret+
														"&motif="+motif+
														"&terminal="+terminal+
														"&id_affecter="+id_affecter
														);

}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
function get_mail_prestataire_declarer(terminal,motif,hour,intervention)
{
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("Lightbox_mail_prestataire_declarer").innerHTML = "<div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div>";


		}
		if(xhr.readyState == 4 && xhr.status == 200){

			document.getElementById("Lightbox_mail_prestataire_declarer").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=get_mail_prestataire_declarer&terminal="+terminal+"&motif="+motif+"&hour="+hour+"&intervention="+intervention);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function afficher_loupe(id_gab){
	var xhr = getXhr();

	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_loupe").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=afficher_loupe&id_gab="+id_gab);
}
/**
* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

function actueliser_date_arret(){

	var xhr = getXhr();

	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
		//document.getElementById("listedepeche").className="invisible";
		//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

				document.getElementById("div_inputarret").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);

	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=actueliser_date_arret");
}

/**
 * ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 */


function insert_upload_execution(id_atm)
{
	token = localStorage.getItem('token');
	var formData = new FormData();
	formData.append('function', 'insert_form_upload_execution');


	var path_upload = $("#chemin_file").map(function(){
		return $(this).val();
	}).get();

	formData.append('id_atm', id_atm);
	formData.append('path_upload', path_upload);
	$.ajax({
		type: "POST",
		headers: {
			'x-access-token': token
		},
		url: "ajax/ajax.php",
		data: formData,
		cache       : false,
		contentType : false,
		processData : false,
		success: function(data)
		{
			var messageAlert = 'alert-' + data.type;
			var messageText = data.message;
			var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
			if (messageAlert && messageText) {
				$("#form_insert_upload_execution").html(alertBox);
				reloadDiv_upload_execution(id_atm,1);

			}},
		error: function (data)
		{
			var messageAlert = 'alert-' + data.type;
			var messageText = data.message;
			var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
			if (messageAlert && messageText) {
				$("#form_insert_upload_execution").html(alertBox);
				reloadDiv_upload_execution(id_atm,1);
			}
		}
	});
}
/**
 * ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 */
function ShowFileUploadATM(id_atm,code_upload_content,state_upload)
{

// alert(code_upload_content);
	var xhr = getXhr();
// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function()
	{
// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalshowFileUpload").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Détail fichier GAB</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

		}
		if(xhr.readyState == 4 && xhr.status == 200)
		{
			document.getElementById("divModalshowFileUpload").innerHTML=xhr.responseText;
		}
	}

// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=ShowFileUploadATM&id_atm="+id_atm+
		"&code_upload_content="+code_upload_content+
		"&state_upload="+state_upload);

}
/**
 * ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 */
function get_remarque_incident_pres(id_incident){
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalremarque_incident").innerHTML = "<div class='modal-dialog'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Remarque Prestataire</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";
		}
		if(xhr.readyState == 4 && xhr.status == 200){

			document.getElementById("divModalremarque_incident").innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xhr.send("function=get_remarque_incident_pres&id_incident="+id_incident);
}
/**

 * ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 */
function detailler_email_consigne(id_mail)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function()
	{
		if(xhr.readyState == 1)
		{
			document.getElementById("Lightbox_detailler_email").innerHTML = "<div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div>";
		}

		if(xhr.readyState == 4 && xhr.status == 200)
		{
			document.getElementById("Lightbox_detailler_email").innerHTML=xhr.responseText;
		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xhr.send("function=detailler_email_consigne&id_mail="+id_mail);
}
/**

 * ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 */
function suppimer_mail_consigne(id_maile,idintrevention)
{
	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			//document.getElementById("listedepeche").className="invisible";
			//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200)
		{
			document.getElementById("liste_mail_consigne").innerHTML=xhr.responseText;
		}

	}
	xhr.open("POST","ajax/ajax.php",true);

	var r = confirm("Vous Voulez suppimer mail Consigne !!");
	if (r == true)
	{
		// Ici on va voir comment faire du post
		// ne pas oublier ça pour le post
		xhr.setRequestHeader('x-access-token',token);
		xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xhr.send("function=suppimer_mail_consigne&id_intrevention="+idintrevention+"&id_mail="+id_maile);
	}
	else
	{
		alert("Aucune mise à jour n'a été effectuée !!!");
	}

}
/**

 * ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 */
function DownFileUploadATM(id_atm,code_upload_content,state_upload)
{

// alert(code_upload_content);
	var xhr = getXhr();
// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function()
	{
// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			document.getElementById("divModalshowFileUpload").innerHTML = "<div class='modal-dialog modal-lg'><div class='modal-content' ><div class='modal-header'><h4 class='modal-title'>Détail fichier GAB</h4><button type='button' class='close' data-dismiss='modal'>&times;</button></div><div class='modal-body'><form class='form-horizontal' role='form'><div class='row' style='text-align:center;'><img src='img/spinnerIPRC.gif' /></div></form></div><div class='modal-footer'><button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button></div></div></div>";

		}
		if(xhr.readyState == 4 && xhr.status == 200)
		{
			document.getElementById("divModalshowFileUpload").innerHTML=xhr.responseText;
		}
	}

// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=DownFileUploadATM&id_atm="+id_atm+
		"&code_upload_content="+code_upload_content+
		"&state_upload="+state_upload);

}
//////////////////////////////////////////////////////////////////////////////////////////
function get_update_id_facturation(id,id_facturation)
{

	var xhr = getXhr();
	// On défini ce qu'on va faire quand on aura la réponse

	xhr.onreadystatechange = function(){
		// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
		if(xhr.readyState == 1)
		{
			//document.getElementById("listedepeche").className="invisible";
			//document.getElementById("message").className="tumevois";

		}
		if(xhr.readyState == 4 && xhr.status == 200){

			document.getElementById("div_id_facturation"+id).innerHTML=xhr.responseText;

		}

	}

	// Ici on va voir comment faire du post
	xhr.open("POST","ajax/ajax.php",true);
	// ne pas oublier ça pour le post
	xhr.setRequestHeader('x-access-token',token);
	xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


	xhr.send("function=get_update_id_facturation&id="+id+"&id_facturation="+id_facturation);

}
//////////////////////////////////////////////////////////////////////////////////////////
function traiter_arret(terminal333,ifTraiter333,id_arret){
				var xhr = getXhr();
					// alert('hhhhhhhhh');	
				// On défini ce qu'on va faire quand on aura la réponse
				
				xhr.onreadystatechange = function(){
					// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
					if(xhr.readyState == 1)
					{
					//document.getElementById("listedepeche").className="invisible";
					//document.getElementById("message").className="tumevois";
					
					}
					if(xhr.readyState == 4 && xhr.status == 200){
					
							document.getElementById(id_arret).innerHTML=xhr.responseText;
							
					}
					
				}

					var ele = document.getElementsByName('motifTraiterInput'+id_arret);
						for(i = 0; i < ele.length; i++) { 
						if(ele[i].checked) 
								idMotifTraiter=ele[i].value;
						} 
				if(idMotifTraiter==2)
				{
					//alert('DELETE ROW: div_list_gab_hors_serv'+id_arret);	
					//document.getElementById("div_list_gab_hors_serv"+id_arret).deleteRow(0);
					
					var row = document.getElementById("div_list_gab_hors_serv"+id_arret);
					row.parentNode.removeChild(row);
					
				}
	
				// alert(idMotifTraiter2);	
				// Ici on va voir comment faire du post
			xhr.open("POST","ajax/ajax.php",true);
			// ne pas oublier ça pour le post
			xhr.setRequestHeader('x-access-token',token);
			xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
					// alert('idMotifTraiter: '+idMotifTraiter);		
				xhr.send("function=traiter_arret&terminal333="+terminal333+"&ifTraiter333="+ifTraiter333+"&idMotifTraiter111="+idMotifTraiter+"&id_arret="+id_arret);
			}
//////////////////////////////////////////////////////////////////////////////////////////
function Select_code(containerid) {
	if (document.selection) { // IE
		var range = document.body.createTextRange();
		range.moveToElementText(document.getElementById(containerid));
		range.select();
	} else if (window.getSelection) {
		var range = document.createRange();
		range.selectNode(document.getElementById(containerid));
		window.getSelection().removeAllRanges();
		window.getSelection().addRange(range);
	}
	document.execCommand('copy');
}