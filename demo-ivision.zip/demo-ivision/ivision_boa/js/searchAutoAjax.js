﻿

function autocomplet() {
	var min_length = 3; // min caracters to display the autocomplete
	var keyword = $('#inputcauseaction').val();
	var iterminal2 = $('#terminal2').val();
	if (keyword.length >= min_length) {
		$.ajax({
			url: 'list_motif.php',
			type: 'POST',
			data: {keyword:keyword},
			success:function(data){
				$('#terminal_list_id').show();
				$('#terminal_list_id').html(data);
			}
		});
	} else {
		$('#terminal_list_id').hide();
	}
}
 
			// set_item : this function will be executed when we select an item
			function set_item(item) {
				// change input value
				$('#inputcauseaction').val(item);
				// hide proposition list
				// $('#terminal_list_id').hide();
			}
			
			function hide_motif_arret(id_incident)
				{				
					$('#terminal_list_id').hide();	
				}


