﻿
			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/	
			function pingGab(ipGab,$terminal){
				token = localStorage.getItem('token');
				var xhr = getXhr();
					// alert('hhhhhhhhh');	
				// On défini ce qu'on va faire quand on aura la réponse
				
				xhr.onreadystatechange = function(){
					// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
					if(xhr.readyState == 1)
					{
						document.getElementById("testerPing").innerHTML='<button type="button" class="btn btn-primary btn-link" disabled> Ping <i class="fa fa-spinner fa-spin" aria-hidden="true"></i></button>';

					
					}
					if(xhr.readyState == 4 && xhr.status == 200){
					
							document.getElementById("testerPing").innerHTML=xhr.responseText;
					}
					
				}

				// Ici on va voir comment faire du post
				xhr.open("POST","ajax/ajaxKamar.php",true);
				// ne pas oublier ça pour le post
				
				// terminalPing=document.getElementById("input_terminal").innerHTML=xhr.responseText;
				xhr.setRequestHeader('x-access-token',token);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
			
				
				// alert(idMotifTraiter2);	
				xhr.send("function=pingGab&ipGab="+ipGab+
											"&terminal="+$terminal);
			}
			
			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/	
			function suprimerGabHorsService(idAtm,user){

				token = localStorage.getItem('token');
				var xhr = getXhr();
					// alert('hhhhhhhhh');	
				// On défini ce qu'on va faire quand on aura la réponse
				
				xhr.onreadystatechange = function(){
					// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
					if(xhr.readyState == 1)
					{
					//document.getElementById("listedepeche").className="invisible";
					//document.getElementById("message").className="tumevois";
					
					}
					if(xhr.readyState == 4 && xhr.status == 200){
					
							  document.getElementById("div_list_gab_hors_serv"+idAtm).innerHTML=xhr.responseText;  
					}
					
				}

				// Ici on va voir comment faire du post
				xhr.open("POST","ajax/ajaxKamar.php",true);
				// ne pas oublier ça pour le post
				
				// terminalPing=document.getElementById("input_terminal").innerHTML=xhr.responseText;
				xhr.setRequestHeader('x-access-token',token);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
			
				
				// alert(idMotifTraiter2);	
				xhr.send("function=suprimerGabHorsService&idAtm="+idAtm+
											"&user="+user);
			}
			
			
			
			
			
			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/	
			function validerConfigIncident(idService,nomService)
			{
				token = localStorage.getItem('token');
				// alert(ipGab);
				var xhr = getXhr();
					// alert('hhhhhhhhh');	
				// On défini ce qu'on va faire quand on aura la réponse
				
				xhr.onreadystatechange = function(){
					// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
					
					if(xhr.readyState == 4 && xhr.status == 200){
					
							document.getElementById("bodyConfig_"+idService).innerHTML=xhr.responseText;
							
					}
					
				}
				
					/***CheckBoxes***/
							var allCheckedStatus = document.getElementsByName('allCheckedStatus[]');
							var valsCheckedStatus = "";
							for (var i=0, n=allCheckedStatus.length;i<n;i++) 
							{
								// document.getElementsByName('allTraiter[]').checked = true;
								// alert();
								if (allCheckedStatus[i].checked) 
								{
									
									valsCheckedStatus += allCheckedStatus[i].value+",";
								}
							}
					/***Inputs***/	
					var atm_all= document.getElementById("atm_all_"+nomService).value; 					
					var logicalName= document.getElementById("logical_name_"+nomService).value; 					
							

				// Ici on va voir comment faire du post
				xhr.open("POST","ajax/ajaxKamar.php",true);
				// ne pas oublier ça pour le post
				
				// terminalPing=document.getElementById("input_terminal").innerHTML=xhr.responseText;
				xhr.setRequestHeader('x-access-token',token);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
			
				
				// alert(idMotifTraiter2);	
				xhr.send("function=validerConfigIncident&valsCheckedStatus="+valsCheckedStatus+
															"&atm_all="+atm_all+
															"&logicalName="+logicalName+
															"&idService="+idService+
															"&nomService="+nomService);
			}
			
			/**
						* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/

			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/	
			function validerConfigLogicalNames(idService,nomService){
				// alert(ipGab);
				token = localStorage.getItem('token');
				var xhr = getXhr();
					// alert('hhhhhhhhh');	
				// On défini ce qu'on va faire quand on aura la réponse
				
				xhr.onreadystatechange = function(){
					// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
					
					if(xhr.readyState == 4 && xhr.status == 200){
					
							document.getElementById("bodyConfig_logical_"+idService).innerHTML=xhr.responseText;
							
					}
					
				}
				
					
					/***Inputs***/	
					var atm_all= document.getElementById("atm_all_"+nomService).value; 					
					var logicalName= document.getElementById("logical_name_"+nomService).value; 					
							

				// Ici on va voir comment faire du post
				xhr.open("POST","ajax/ajaxKamar.php",true);
				// ne pas oublier ça pour le post
				
				// terminalPing=document.getElementById("input_terminal").innerHTML=xhr.responseText;
				xhr.setRequestHeader('x-access-token',token);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
			
				
				// alert(idMotifTraiter2);	
				xhr.send("function=validerConfigLogicalName&atm_all="+atm_all+
															"&logicalName="+logicalName+
															"&idService="+idService+
															"&nomService="+nomService);
			}
			
			/**
						* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/

			
			
			
			
			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/
			function validerConfigPassiveProfil()
			{
				token = localStorage.getItem('token');
				var xhr = getXhr();
				// On défini ce qu'on va faire quand on aura la réponse
				
				xhr.onreadystatechange = function(){
					// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
					if(xhr.readyState == 1)
					{
					//document.getElementById("listedepeche").className="invisible";
					//document.getElementById("message").className="tumevois";
					
					}
					if(xhr.readyState == 4 && xhr.status == 200){
					
							document.getElementById("div_val_passive_profile").innerHTML=xhr.responseText;
							
					}
					
				}
		
				// Ici on va voir comment faire du post
				xhr.open("POST","ajax/ajaxKamar.php",true);
				// ne pas oublier ça pour le post
				xhr.setRequestHeader('x-access-token',token);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');							


				id_profile = document.getElementById('profile').value;		
				service = document.getElementById('service_profile').value;		
				
				valuePassive = document.getElementById('passive_value_profil').value;		
				valuePassiveOut = document.getElementById('passive_value_profil_out').value;		
				
				startDayPassive = document.getElementById('start_passive_profil').value;		
				endDayPassive = document.getElementById('end_passive_profil').value;		
					
				//alert(startDayPassive);
				xhr.send("function=validerConfigPassiveProfil&id_profile="+id_profile+
															"&service="+service+
															"&startDayPassive="+startDayPassive+
															"&endDayPassive="+endDayPassive+
															"&valuePassiveOut="+valuePassiveOut+
															"&valuePassive="+valuePassive);		

			}			
			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/	


			function validerConfigPassiveGab()
			{
				token = localStorage.getItem('token');
				var xhr = getXhr();
				// On défini ce qu'on va faire quand on aura la réponse
				
				xhr.onreadystatechange = function(){
					// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
					if(xhr.readyState == 1)
					{
					//document.getElementById("listedepeche").className="invisible";
					//document.getElementById("message").className="tumevois";
					
					}
					if(xhr.readyState == 4 && xhr.status == 200){
					
							document.getElementById("div_val_passive_gab").innerHTML=xhr.responseText;
							
					}
					
				}
		
				// Ici on va voir comment faire du post
				xhr.open("POST","ajax/ajaxKamar.php",true);
				// ne pas oublier ça pour le post
				xhr.setRequestHeader('x-access-token',token);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');							


				gab = document.getElementById('passive_gab').value;		
				service = document.getElementById('service_gab').value;		
				valuePassive = document.getElementById('passive_value_gab').value;	
				valuePassiveOut = document.getElementById('passive_value_gab_out').value;	
				
				startPassiveGab = document.getElementById('start_passive_gab').value;		
				endPassiveGab = document.getElementById('end_passive_gab').value;		
					
				
				xhr.send("function=validerConfigPassiveGab&gab="+gab+
															"&service="+service+
															"&startPassiveGab="+startPassiveGab+
															"&endPassiveGab="+endPassiveGab+
															"&valuePassiveOut="+valuePassiveOut+
															"&valuePassive="+valuePassive);		

			}			
			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/	
function validerConfigMontantProfil()
			{
				token = localStorage.getItem('token');
				var xhr = getXhr();
				// On défini ce qu'on va faire quand on aura la réponse
				
				xhr.onreadystatechange = function(){
					// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
					if(xhr.readyState == 1)
					{
					//document.getElementById("listedepeche").className="invisible";
					//document.getElementById("message").className="tumevois";
					
					}
					if(xhr.readyState == 4 && xhr.status == 200){
					
							document.getElementById("div_val_montant_profile").innerHTML=xhr.responseText;
							
					}
					
				}
		
				// Ici on va voir comment faire du post
				xhr.open("POST","ajax/ajaxKamar.php",true);
				// ne pas oublier ça pour le post
				xhr.setRequestHeader('x-access-token',token);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');							


				profilMontant = document.getElementById('profile_montant').value;		
			
				valueMontant = document.getElementById('montant_value_profil').value;		
					
				//alert(profilMontant);
				xhr.send("function=validerConfigMontantProfil&profilMontant="+profilMontant+
															"&valueMontant="+valueMontant);		

			}			
			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/	

			function validerConfigMontantGab()
			{
				token = localStorage.getItem('token');
				var xhr = getXhr();
				// On défini ce qu'on va faire quand on aura la réponse
				
				xhr.onreadystatechange = function(){
					// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
					if(xhr.readyState == 1)
					{
					//document.getElementById("listedepeche").className="invisible";
					//document.getElementById("message").className="tumevois";
					
					}
					if(xhr.readyState == 4 && xhr.status == 200){
					
							document.getElementById("div_val_montant_gab").innerHTML=xhr.responseText;
							
					}
					
				}
		
				// Ici on va voir comment faire du post
				xhr.open("POST","ajax/ajaxKamar.php",true);
				// ne pas oublier ça pour le post
				xhr.setRequestHeader('x-access-token',token);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');							


				gab = document.getElementById('montant_gab').value;		
			
				valueMontant = document.getElementById('montant_value_gab').value;		
					
				
				xhr.send("function=validerConfigMontantGab&gab="+gab+
															"&valueMontant="+valueMontant);		

			}			
			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/	


			function validerConfigModeSuperviseurProfil()
			{
				token = localStorage.getItem('token');
				var xhr = getXhr();
				// On défini ce qu'on va faire quand on aura la réponse
				
				xhr.onreadystatechange = function(){
					// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
					if(xhr.readyState == 1)
					{
					//document.getElementById("listedepeche").className="invisible";
					//document.getElementById("message").className="tumevois";
					
					}
					if(xhr.readyState == 4 && xhr.status == 200){
					
							document.getElementById("div_val_superviseur_profile").innerHTML=xhr.responseText;
							
					}
					
				}
		
				// Ici on va voir comment faire du post
				xhr.open("POST","ajax/ajaxKamar.php",true);
				// ne pas oublier ça pour le post
				xhr.setRequestHeader('x-access-token',token);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');							


				profilSuperviseur = document.getElementById('profile_superviseur').value;		
			
				valueSuperviseur = document.getElementById('superviseur_value_profil').value;		
					
				//alert(profilMontant);
				xhr.send("function=validerConfigModeSuperviseurProfil&profilSuperviseur="+profilSuperviseur+
															"&valueSuperviseur="+valueSuperviseur);		

			}			
			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/	

			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/	

			function validerConfigModeSuperviseurGab()
			{
				token = localStorage.getItem('token');
				var xhr = getXhr();
				// On défini ce qu'on va faire quand on aura la réponse
				
				xhr.onreadystatechange = function(){
					// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
					if(xhr.readyState == 1)
					{
					//document.getElementById("listedepeche").className="invisible";
					//document.getElementById("message").className="tumevois";
					
					}
					if(xhr.readyState == 4 && xhr.status == 200){
					
							document.getElementById("div_val_superviseur_gab").innerHTML=xhr.responseText;
							
					}
					
				}
		
				// Ici on va voir comment faire du post
				xhr.open("POST","ajax/ajaxKamar.php",true);
				// ne pas oublier ça pour le post
				xhr.setRequestHeader('x-access-token',token);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');							


				gab = document.getElementById('superviseur_gab').value;		
			
				valueSuperviseurGab = document.getElementById('superviseur_value_gab').value;		
					
				
				xhr.send("function=validerConfigModeSuperviseurGab&gab="+gab+
															"&valueSuperviseurGab="+valueSuperviseurGab);		

			}			
			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/	

			function validerConfigTimeoutCommand()
			{
				token = localStorage.getItem('token');
				var xhr = getXhr();
				// On défini ce qu'on va faire quand on aura la réponse
				
				xhr.onreadystatechange = function()
				{
					// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
					if(xhr.readyState == 1)
					{
						//document.getElementById("listedepeche").className="invisible";
						//document.getElementById("message").className="tumevois";
					}
					if(xhr.readyState == 4 && xhr.status == 200)
					{
							document.getElementById("div_val_timeout_command").innerHTML=xhr.responseText;
					}
				}
		
				// Ici on va voir comment faire du post
				xhr.open("POST","ajax/ajaxKamar.php",true);
				// ne pas oublier ça pour le post
				xhr.setRequestHeader('x-access-token',token);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');							


				id_command = document.getElementById('id_command').value;		
			
				parm_timeout_cmd = document.getElementById('parm_timeout_cmd').value;		
					
				
				xhr.send("function=validerConfigTimeoutCommand&id_command="+id_command+
															"&parm_timeout_cmd="+parm_timeout_cmd);		

			}			
			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/	

			
			function validerConfigTimeoutCompagn()
			{
				token = localStorage.getItem('token');
				var xhr = getXhr();
				// On défini ce qu'on va faire quand on aura la réponse
				
				xhr.onreadystatechange = function(){
					// On ne fait quelque chose que si on a tout reçu et que le serveur est ok
					if(xhr.readyState == 1)
					{
					//document.getElementById("listedepeche").className="invisible";
					//document.getElementById("message").className="tumevois";
					
					}
					if(xhr.readyState == 4 && xhr.status == 200)
					{
						document.getElementById("div_val_timeout_compagn").innerHTML=xhr.responseText;
					}
					
				}
		
				// Ici on va voir comment faire du post
				xhr.open("POST","ajax/ajaxKamar.php",true);
				// ne pas oublier ça pour le post
				xhr.setRequestHeader('x-access-token',token);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');


					
			
				parm_timeout_compagn = document.getElementById('parm_timeout_compagn').value;		
					
				
				xhr.send("function=validerConfigTimeoutCompagn&parm_timeout_compagn="+parm_timeout_compagn);		

			}			
			/**
			* ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			*/	

			