
$(document).ready(function() {
    getTokenindex()

});
$("#form_login").submit(function(e)
{
    var idtoken = $("#hdnJWT").val();
    //e.preventDefault();
    CheckTokenindex(idtoken);

    $("#formMessage").addClass('').html("");
    var formData = new FormData($(this)[0]);
    // alert(formData.get('user'));
    $.ajax({
        type: "POST",
        url: "lib/auth/doGetToken.php",
        dataType: "JSON",
        data: formData,
        cache       : false,
        contentType : false,
        processData : false,

        success: function(response)
        {
            if (response.status)
            {

                localStorage.setItem('token', response.jwt.token);
                //location.href = "start.php";
            }
            else
            {
                $("#formMessage").addClass('alert alert-danger').html(response.payload.message);
                alert(response.payload.message);
                return false;
            }
        }
    });

});

function CheckTokenindex(idtoken) {

    $.ajax({
        type: 'GET',
        headers: {
            'x-access-token': idtoken
        },
        url: 'lib/auth/ValidateTokenIndex.php',
        dataType: 'JSON',
        success: function(response) {
            if (response.status) {
                //token = response.jwt.token;
                localStorage.setItem('token', idtoken);
            } else {
                localStorage.removeItem('token');
                location.href = "index.php";

            }
        }
    });
}
function getTokenindex() {
    $.ajax({
        type: 'GET',

        url: 'lib/auth/GetTokenIndex.php',
        dataType: 'JSON',
        success: function(response) {

            if (response.status) {
                token = response.jwt.token;
                $("#hdnJWT").val(token);
                //  localStorage.setItem('token', token);
            }
        }
    });
}
