<?php
use pChart\pColor;
use pChart\pDraw;
use pChart\pPie;
use pChart\pCharts;

//////////////////////////////////////////////////////////////////////////////////
function getDureeGloblalMotif($date_debut,$date_fin,$motif_inclus,$list_gab,$categorie)
{
    // $duree_globlal=$nb_gab*$nb_jour*1440;
    $sql = "SELECT round(SUM(`duree_arret_reel`/60),0) AS nb_minute
		FROM  `taux_dispo_sla_global` 
		WHERE `dossier`<>0 AND `categorie_action` <> 0 ";
    if(($motif_inclus<>'')&&($motif_inclus<>'%')){$sql = $sql." AND `id_action` IN(".implode(',',$motif_inclus).")";}
    if(($categorie<>'')&&($categorie<>'%')){$sql = $sql." AND `categorie_action`  IN(".$categorie.") ";}
    if(($list_gab<>'')&&($list_gab<>'%')){$sql = $sql." AND `gab` IN('".implode("','",$list_gab)."')";}
    $sql = $sql." AND  DATE_FORMAT(`date_courant` , '%Y-%m-%d') BETWEEN  '".$date_debut."' AND '".$date_fin."'";
    // $sql = $sql." GROUP BY  `categorie_action`";
    // $sql = $sql." ORDER BY SUM(duree_arret_reel) DESC";
    $link = ma_db_connexion();
    $result = mysqli_query($link,$sql);
    if (mysqli_num_rows($result)>0)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
            mysqli_close($link);
            return $row["nb_minute"];
        }
    }
    else
    {
        mysqli_close($link);
        return  0;
    }

}
//////////////////////////////////////////////////////////////////////////////////
function getLibelleCategorieDuree($date_debut,$date_fin,$motif_inclus,$list_gab,$categorie,$nb_gab,$nb_jour)
{
    // $duree_globlal=$nb_gab*$nb_jour*1440;
    $nombre_array = array();
    $sql = "SELECT `categorie_action`,round(SUM(`duree_arret_reel`/60),0) AS nb_minute
		FROM  `taux_dispo_sla_global` 
		WHERE `dossier`<>0  AND `categorie_action` <> 0 ";
    if(($motif_inclus<>'')&&($motif_inclus<>'%')){$sql = $sql." AND `id_action` IN(".implode(',',$motif_inclus).")";}
    if(($list_gab<>'')&&($list_gab<>'%')){$sql = $sql." AND `gab` IN('".implode("','",$list_gab)."')";}
    if(($categorie<>'')&&($categorie<>'%')){$sql = $sql." AND  `categorie_action`  IN(".$categorie.")";}
    $sql = $sql." AND  DATE_FORMAT(`date_courant` , '%Y-%m-%d') BETWEEN  '".$date_debut."' AND '".$date_fin."'";
    $sql = $sql." GROUP BY  `categorie_action`";
    $sql = $sql." ORDER BY SUM(duree_arret_reel) DESC";
// echo "<br>".$sql."<br>";

    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql);
    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            // $nombre_array[$j]=($row["categorie_action"]);
            $nombre_array[$j]=get_libelle_categorie_intervention($row["categorie_action"]);
            $j++;
        }
    }
    else
    {
        $nombre_array[0]='Not defined';
    }
    mysqli_close($link);
    return $nombre_array;



}
//////////////////////////////////////////////////////////////////////////////////

function getDureeCategorie($date_debut,$date_fin,$motif_inclus,$list_gab,$categorie,$nb_gab,$nb_jour,$region)
{
    // $duree_globlal=$nb_gab*$nb_jour*1440;
    $nombre_array = array();
    $sql = "SELECT round(SUM(`duree_arret_reel`/60),0) AS nb_minute
		FROM  `taux_dispo_sla_global` 
		WHERE `dossier`<>0 AND `categorie_action` <> 0 ";
    if(($motif_inclus<>'')&&($motif_inclus<>'%')){$sql = $sql." AND `id_action` IN(".implode(',',$motif_inclus).")";}
    if(($categorie<>'')&&($categorie<>'%')){$sql = $sql." AND `categorie_action`  IN(".$categorie.") ";}
    if(($region<>'')&&($region<>'%')){$sql = $sql." AND `region`  IN(".$region.") ";}
    if(($list_gab<>'')&&($list_gab<>'%')){$sql = $sql." AND `gab` IN('".implode("','",$list_gab)."')";}
    $sql = $sql." AND  DATE_FORMAT(`date_courant` , '%Y-%m-%d') BETWEEN  '".$date_debut."' AND '".$date_fin."'";
    // if($region=='')
    {$sql = $sql." GROUP BY  `categorie_action`";}
    $sql = $sql." ORDER BY SUM(duree_arret_reel) DESC";
    // if($region<>'')
    {
        // echo "<br>".$sql."<br>";
    }

    // "	WHERE `dossier`<>0 ";
    // if(($categorie<>'')&&($categorie<>'%')) {$sql = $sql." AND `categorie_action`   IN(".$categorie.")";}
    // if(($id_filiales<>'')&&($id_filiales<>'%')){$sql = $sql." AND `region`   IN(".$id_filiales.")";}
    // if(($motif_inclus<>'')&&($motif_inclus<>'%')){$sql = $sql." AND `id_action` IN(".implode(',',$motif_inclus).")";}
    // if(($list_gab<>'')&&($list_gab<>'%')){$sql = $sql." AND `gab` IN(".implode(',',$list_gab).")";}
    // $sql = $sql." AND  DATE_FORMAT(`date_courant` , '%Y-%m-%d')  BETWEEN '".$date_courant."' AND '".$date_fin."'";
    // $sql = $sql." ORDER BY SUM(duree_arret_reel) DESC";


    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql);
    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            // echo "<br>".$row["nb_minute"]."<br>";
            $nombre_array[$j]=$row["nb_minute"];
            $j++;
        }
    }
    else
    {
        $nombre_array[0]=0;
    }
    mysqli_close($link);
    return $nombre_array;



}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function nbr_jour_duree($date1, $date2)
{
    return abs((strtotime($date1)-strtotime($date2))/(3600*24));
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_categorie($categorie)
{
    if($categorie==""){$categorie="%";}
    $connexion = ma_db_connexion();

    $sql = "SELECT `id_categorie`, `libelle` FROM `new_categorie_intervention`";
    if($categorie<>"%"){$sql = $sql." WHERE `id_categorie` IN(".mysqli_real_escape_string($connexion,$categorie).")"; }
    $sql = $sql." GROUP BY `libelle`";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 032 : ".mysqli_error($connexion));
        die('ERREUR QUERY 032 !');
    }


    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["id_categorie"].'">'.$row["libelle"].'</option>';
            }
        }
    }

    mysqli_free_result($result);
    mysqli_close($connexion);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_gestionnaire($gestionnaire)
{
    if($gestionnaire==""){$gestionnaire="%";}
    $connexion = ma_db_connexion();


    $sql = "SELECT `id_type`, `libelle2` FROM `new_libelle_type_contact`";
    if($gestionnaire<>"%"){$sql = $sql." WHERE `id_type` IN(".mysqli_real_escape_string($connexion,$gestionnaire).")"; }
    $sql = $sql." GROUP BY `libelle2`";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 021 : ".mysqli_error($connexion));
        die('ERREUR QUERY 021 !');
    }


    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["id_type"].'">'.$row["libelle2"].'</option>';
            }
        }
    }

    mysqli_free_result($result);
    mysqli_close($connexion);

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getTauxDisponibiliteTotal($dateCourant,$gestionnaire,$region,$typeTaux,$table)
{

    $taux='';
    $link=ma_db_connexion();
    $sql="SELECT 	code_filiale, AVG(taux_dispo_reel) AS tauDispo	FROM `".$table."` 
		WHERE `type_dispo` = '".$typeTaux."'
		AND DATE_FORMAT( `date_courant` , '%Y-%m-%d' )=  '".$dateCourant."'";
    if (($region<>"")&&($region<>"%")){$sql= $sql." AND  code_filiale IN(".$region.")  ";}
    // echo $sql."<br>";
    if ($result=mysqli_query($link,$sql) or die('Erreur   getTauxDisponibilite !<br>'.$sql.'<br>'.mysqli_error($link)))
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                // $taux=$row["tauDispo"];
                $taux=str_replace(",", ".", $row["tauDispo"]);
            }
        }

        mysqli_close($link);
        return round($taux,2);
        mysqli_free_result($result);
    }


}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_categorie_intervention($id)
{

    $sql = "SELECT `libelle` FROM  `new_categorie_intervention`    WHERE   `new_categorie_intervention`.`id_categorie` =  '".$id."' ";
    $link = ma_db_connexion();
    if ($result=mysqli_query($link,$sql) or die('Erreur   get_libelle_categorie_intervention !<br>'.$sql.'<br>'.mysqli_error($link)))
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                mysqli_close($link);
                return ucfirst(strtolower($row["libelle"]));
            }
        }
        else
        {
            mysqli_close($link);
            return "";
        }
        mysqli_free_result($result);
    }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_type_gab($type_gab)
{
    if($type_gab==""){$type_gab="%";}
    $connexion = ma_db_connexion();

    $sql = "SELECT `id_fournisseur`, `nom_fournisseur` FROM `new_list_fournisseur` ";
    if($type_gab<>"%"){$sql = $sql." WHERE `id_fournisseur` IN(".mysqli_real_escape_string($connexion,$type_gab).")"; }
    $sql = $sql." GROUP BY `nom_fournisseur`";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 021 : ".mysqli_error($connexion));
        die('ERREUR QUERY 021 !');
    }


    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["id_fournisseur"].'">'.$row["nom_fournisseur"].'</option>';
            }
        }
    }

    mysqli_free_result($result);
    mysqli_close($connexion);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_filiale($idfiliale)
{
    if($idfiliale==""){$idfiliale="%";}
    $connexion = ma_db_connexion();

    $sql = "SELECT `id_filiale2`, `nom_filiale` FROM `new_filiale` ";
    if($idfiliale<>"%"){$sql = $sql." WHERE `id_filiale2` IN(".mysqli_real_escape_string($connexion,$idfiliale).")"; }
    $sql = $sql." GROUP BY `nom_filiale`";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 019 : ".mysqli_error($connexion));
        die('ERREUR QUERY 019 !');
    }


    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["id_filiale2"].'">'.$row["nom_filiale"].'</option>';
            }
        }
    }

    mysqli_free_result($result);
    mysqli_close($connexion);

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_array_id_responsable($type_gestionnaire)
{
    $link = ma_db_connexion();
    $array_id = array();
    $sql = "SELECT  `id_type`,`libelle`  FROM `new_libelle_type_contact`";
    if(($type_gestionnaire<>"")&&($type_gestionnaire<>"%")){$sql = $sql." WHERE `id_type` IN(".mysqli_real_escape_string($link,$type_gestionnaire).")"; }
    $sql = $sql." ORDER BY `libelle` ASC";
    // echo  $sql;
    $link = ma_db_connexion();
    $result = mysqli_query($link,$sql) or die('Erreur sql get_id_responsablee !<br>'.$sql.'<br>'.mysqli_error($link));
    if(mysqli_num_rows($result)>0)
    { 	$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            $array_id[$j]=$row["id_type"];
            $j++;
        }

    }
    else
    {
        $array_id[0]='';
    }
    mysqli_close($link);
    return $array_id;

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_compte_nb_incident_ouvert_responsable($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$affectation)
{

    $table_incident = array();
    $sql = "SELECT  count(`id_action_interv`) as nbr_incident  FROM `new_intevention_incident`
			WHERE   `id_action_interv` IN (".implode(',',get_array_max_nbr_intervention_ouvert($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$affectation)).") AND `id_affectation` IN(".$affectation.")";

    // echo "<br>".$sql."<br>";
    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql) or die('Erreur   get_compte_nb_incident_responsable !<br>'.$sql.'<br>'.mysqli_error($link));
    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            mysqli_close($link);
            return $row["nbr_incident"];
            $j++;
        }
    }
    else
    {
        mysqli_close($link);
        return 0;
    }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_compte_nb_incident_responsable($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$affectation)
{

    $table_incident = array();
    $sql = "SELECT  count(`id_action_interv`) as nbr_incident  FROM `new_intevention_incident`
			WHERE   `id_action_interv` IN (".implode(',',get_array_max_nbr_intervention($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$affectation)).") AND `id_affectation` IN(".$affectation.")";
    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql) or die('Erreur   get_compte_nb_incident_responsable !<br>'.$sql.'<br>'.mysqli_error($link));
    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            mysqli_close($link);
            return $row["nbr_incident"];
            $j++;
        }
    }
    else
    {
        mysqli_close($link);
        return 0;
    }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_array_max_nbr_intervention_ouvert($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$affectation)
{


    $table_incident = array();
    $sql = "SELECT  MAX(`id_action_interv`) as nbrmax  FROM `new_intevention_incident`
			WHERE   `id_incident` IN (".implode(',',get_array_intervention_incident_ouvert($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$affectation)).")
			GROUP BY  `id_incident` ";
    // echo "<br>".$sql."<br>";
    // echo $sql
    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql) or die('Erreur   get_array_max_nbr_intervention_ouvert !<br>'.$sql.'<br>'.mysqli_error($link));
    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            $table_incident[$j]=$row["nbrmax"];
            $j++;
        }
    }
    else
    {
        $table_incident[0]=0;
    }
    mysqli_close($link);
    return $table_incident;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_array_max_nbr_intervention($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$affectation)
{


    $table_incident = array();
    $sql = "SELECT  MAX(`id_action_interv`) as nbrmax  FROM `new_intevention_incident`
			WHERE   `id_incident` IN (".implode(',',get_array_incident_ouvert($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$affectation)).")
			GROUP BY  `id_incident` ";
    // echo "<br>".$sql."<br>";
    // echo $sql
    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql) or die('Erreur   get_array_max_nbr_intervention !<br>'.$sql.'<br>'.mysqli_error($link));
    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            $table_incident[$j]=$row["nbrmax"];
            $j++;
        }
    }
    else
    {
        $table_incident[0]=0;
    }
    mysqli_close($link);
    return $table_incident;
}
//////////////////////////////////////////////////////////////////////////////////
function get_nbr_incident_inpact_service($id_impact_service,$categorie,$motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque,$list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)
{
    // $nombreAlerte = array();
    $sql = "SELECT  count(distinct(`id_incident`)) as nbr_incident
							FROM  `new_incident_gab` ,`new_action_intervention`
							WHERE	`new_incident_gab`.`id_action_fonctionelle`= `new_action_intervention`.`id_intevention` 
							AND  `new_incident_gab`.`etat_stat` = 0	  
							AND  `new_incident_gab`.`id_activation` = 1					
							AND   `etat_incident` = 0 ";
    if($id_impact_service==0){$sql = $sql." AND `retrait_argent` = 0 AND `depot_argent` = 0 AND `depot_cheque` = 0  ";}
    if($id_impact_service==1){$sql = $sql." AND ((`retrait_argent` = 0 AND `depot_argent` = 0 AND `depot_cheque` = 1)
															OR	(`retrait_argent` = 0 AND `depot_argent` = 1 AND `depot_cheque` = 0)
															OR	(`retrait_argent` = 1 AND `depot_argent` = 0 AND `depot_cheque` = 0))";}
    if($id_impact_service==2){$sql = $sql." AND ((`retrait_argent` = 0 AND `depot_argent` = 1 AND `depot_cheque` = 1)
															OR	(`retrait_argent` = 1 AND `depot_argent` = 1 AND `depot_cheque` = 0)
															OR	(`retrait_argent` = 1 AND `depot_argent` = 0 AND `depot_cheque` = 1))";}
    if($id_impact_service==3){$sql = $sql." AND `retrait_argent` = 1 AND `depot_argent` = 1 AND `depot_cheque` = 1 ";}

    // echo "<br>".$sql."<br>";

    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql) or die('Erreur   get_nbr_incident_inpact_service !<br>'.$sql.'<br>'.mysqli_error($link));

    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            mysqli_close($link);
            return $row["nbr_incident"];
            $j++;
        }
    }
    else
    {
        mysqli_close($link);
        return 0;
    }


}
//////////////////////////////////////////////////////////////////////////////////
function get_array_intervention_incident_ouvert($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$affectation)
{


    $table_incident = array();


    $sql = "SELECT `id_incident`
					FROM  `new_incident_gab` ,`new_list_gab`
					WHERE	`new_incident_gab`.`id_gab`= `new_list_gab`.`terminal` 
					AND  `new_incident_gab`.`etat_stat` = 0	  
					AND  `new_list_gab`.`id_activation` = 1					
					AND   `etat_incident` = 0";

    if(($list_gab<>'')&&($list_gab<>'%')){$sql = $sql." AND `new_incident_gab`.`id_gab` IN(".implode(',',$list_gab).")";}
    if(($motif_inclus<>'')&&($motif_inclus<>'%')){$sql = $sql." AND `new_incident_gab`.`id_action_fonctionelle` IN(".implode(',',$motif_inclus).")";}
    if(($id_filiales<>'')&&($id_filiales<>'%')){$sql = $sql." AND `new_incident_gab`.`cd_filiale` IN(".$id_filiales.")";}
    if(($type_gab<>'')&&($type_gab<>'%')){$sql = $sql." AND `new_list_gab`.`type_gab` IN(".$type_gab.")";}
    if(($categorie<>'')&&($categorie<>'%')){$sql = $sql." AND `new_incident_gab`.`id_categories_fonctionnelle` IN(".$categorie.")";}


    // $sql = "SELECT `id_incident` FROM  `new_incident_gab` ,`new_list_gab`
    // WHERE	`new_incident_gab`.`id_gab`= `new_list_gab`.`terminal`
    // AND  `new_incident_gab`.`etat_stat` = 0
    // AND  `new_incident_gab`.`id_activation` = 1
    // AND `new_incident_gab`.`id_action_fonctionelle` NOT IN(402,407,408,409,410,374,424,425,426,427,442)";

    // if(($motif_inclus<>'')&&($motif_inclus<>'%')){$sql = $sql." AND `new_incident_gab`.`id_action_fonctionelle` IN(".implode(',',$motif_inclus).")";}
    // if(($id_filiales<>'')&&($id_filiales<>'%')){$sql = $sql." AND `new_incident_gab`.`cd_filiale` IN(".$id_filiales.")";}
    // if(($type_gab<>'')&&($type_gab<>'%')){$sql = $sql." AND `new_list_gab`.`type_gab` IN(".$type_gab.")";}
    // if(($categorie<>'')&&($categorie<>'%')){$sql = $sql." AND `new_incident_gab`.`id_categories_fonctionnelle` IN(".$categorie.")";}

    // $sql = $sql ." AND ((TIMESTAMPDIFF(MINUTE,`date_arrete`, `date_remise`)>30 	AND `etat_incident`=1
    // AND (DATE_FORMAT(`date_arrete` , '%Y-%m-%d')  BETWEEN '".$date_debut."' AND '".$date_fin."'
    // OR DATE_FORMAT(`date_remise` , '%Y-%m-%d')  BETWEEN '".$date_debut."' AND '".$date_fin."'
    // OR ( DATE_FORMAT(`date_arrete`, '%Y-%m-%d') <= '".$date_debut."' AND '".$date_fin."' <=  DATE_FORMAT(`date_remise`, '%Y-%m-%d'))))
    // OR ( DATE_FORMAT(`date_arrete`, '%Y-%m-%d') <= '".$date_fin."' AND `etat_incident`=0))	";
    // $sql = $sql." ORDER BY `id_incident` DESC";
    // echo "<br>".$sql."<br>";
    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql) or die('Erreur   get_array_intervention_incident_ouvert !<br>'.$sql.'<br>'.mysqli_error($link));
    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            // echo "<br>".$row["id_incident"]."<br>";
            $table_incident[$j]=$row["id_incident"];
            $j++;
        }
    }
    else
    {
        $table_incident[0]=0;
    }
    mysqli_close($link);
    return $table_incident;
}
//////////////////////////////////////////////////////////////////////////////////
function get_array_incident_ouvert($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$affectation)
{


    $table_incident = array();
    $sql = "SELECT `id_incident` FROM  `new_incident_gab` ,`new_list_gab`
							WHERE	`new_incident_gab`.`id_gab`= `new_list_gab`.`terminal` 
							AND  `new_incident_gab`.`etat_stat` = 0	  
							AND  `new_incident_gab`.`id_activation` = 1
							AND `new_incident_gab`.`id_action_fonctionelle` NOT IN(402,407,408,409,410,374,424,425,426,427,442)";

    if(($motif_inclus<>'')&&($motif_inclus<>'%')){$sql = $sql." AND `new_incident_gab`.`id_action_fonctionelle` IN(".implode(',',$motif_inclus).")";}
    if(($id_filiales<>'')&&($id_filiales<>'%')){$sql = $sql." AND `new_incident_gab`.`cd_filiale` IN(".$id_filiales.")";}
    if(($type_gab<>'')&&($type_gab<>'%')){$sql = $sql." AND `new_list_gab`.`type_gab` IN(".$type_gab.")";}
    if(($categorie<>'')&&($categorie<>'%')){$sql = $sql." AND `new_incident_gab`.`id_categories_fonctionnelle` IN(".$categorie.")";}

    $sql = $sql ." AND ((TIMESTAMPDIFF(MINUTE,`date_arrete`, `date_remise`)>30 	AND `etat_incident`=1 
							AND (DATE_FORMAT(`date_arrete` , '%Y-%m-%d')  BETWEEN '".$date_debut."' AND '".$date_fin."'			
							OR DATE_FORMAT(`date_remise` , '%Y-%m-%d')  BETWEEN '".$date_debut."' AND '".$date_fin."'
							OR ( DATE_FORMAT(`date_arrete`, '%Y-%m-%d') <= '".$date_debut."' AND '".$date_fin."' <=  DATE_FORMAT(`date_remise`, '%Y-%m-%d'))))
							OR ( DATE_FORMAT(`date_arrete`, '%Y-%m-%d') <= '".$date_fin."' AND `etat_incident`=0))	";
    $sql = $sql." ORDER BY `id_incident` DESC";
    // echo "<br>".$sql."<br>";
    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql) or die('Erreur   get_array_incident_ouvert !<br>'.$sql.'<br>'.mysqli_error($link));
    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            $table_incident[$j]=$row["id_incident"];
            $j++;
        }
    }
    else
    {
        $table_incident[0]=0;
    }
    mysqli_close($link);
    return $table_incident;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_responsable($id)
{
    $sql = "SELECT `libelle` FROM  `new_libelle_type_contact` WHERE `new_libelle_type_contact`.id_type = '".$id."'";
    $link = ma_db_connexion();
    if ($result=mysqli_query($link,$sql) or die('Erreur   get_lebelle_type_contact_affecter !<br>'.$sql.'<br>'.mysqli_error($link)))
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                mysqli_close($link);
                return ucfirst(($row["libelle"]));
            }
        }
        else
        {
            mysqli_close($link);
            return  'not defined';
        }
        mysqli_free_result($result);
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function calculeDureeArretGABSup($date_courant,$duree1,$duree,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)
{
//$durue en minute.

    $sql = "SELECT `id_incident`, count(`id_incident`) as nbr_alerte
            FROM  `new_incident_gab` ,`new_list_gab`
			WHERE	`new_incident_gab`.`id_gab`= `new_list_gab`.`terminal` 
			AND  `new_incident_gab`.`etat_stat` = 0	  
			AND  `new_list_gab`.`id_activation` = 1					
		    AND   `etat_incident` = 0
			AND 	round (TIME_TO_SEC(TIMEDIFF('".$date_courant."',`date_arrete`))/60)  > '$duree1'";

    if(($list_gab<>'')&&($list_gab<>'%')){$sql = $sql." AND `new_incident_gab`.`id_gab` IN(".implode(',',$list_gab).")";}
    if(($motif_inclus<>'')&&($motif_inclus<>'%')){$sql = $sql." AND `new_incident_gab`.`id_action_fonctionelle` IN(".implode(',',$motif_inclus).")";}
    if(($id_filiales<>'')&&($id_filiales<>'%')){$sql = $sql." AND `new_incident_gab`.`cd_filiale` IN(".$id_filiales.")";}
    if(($type_gab<>'')&&($type_gab<>'%')){$sql = $sql." AND `new_list_gab`.`type_gab` IN(".$type_gab.")";}
    if(($categorie<>'')&&($categorie<>'%')){$sql = $sql." AND `new_incident_gab`.`id_categories_fonctionnelle` IN(".$categorie.")";}

    $link = ma_db_connexion();
    if ($result=mysqli_query($link,$sql) or die('Erreur   calculeDureeArretGABSup !<br>'.$sql.'<br>'.mysqli_error($link)))
    {
        if(mysqli_num_rows($result)>0)
        {$j=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                mysqli_close($link);
                return $row["nbr_alerte"];
            }
        }
        else
        {
            mysqli_close($link);
            return 0;
        }

        mysqli_free_result($result);
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)
{
//$durue en minute.

    $sql = "SELECT `id_incident`, count(`id_incident`) as nbr_alerte	
            FROM  `new_incident_gab` ,`new_list_gab`
			WHERE	`new_incident_gab`.`id_gab`= `new_list_gab`.`terminal` 
			AND  `new_incident_gab`.`etat_stat` = 0	  
			AND  `new_list_gab`.`id_activation` = 1					
		    AND   `etat_incident` = 0";

    if(($list_gab<>'')&&($list_gab<>'%')){$sql = $sql." AND `new_incident_gab`.`id_gab` IN(".implode(',',$list_gab).")";}
    if(($motif_inclus<>'')&&($motif_inclus<>'%')){$sql = $sql." AND `new_incident_gab`.`id_action_fonctionelle` IN(".implode(',',$motif_inclus).")";}
    if(($id_filiales<>'')&&($id_filiales<>'%')){$sql = $sql." AND `new_incident_gab`.`cd_filiale` IN(".$id_filiales.")";}
    if(($type_gab<>'')&&($type_gab<>'%')){$sql = $sql." AND `new_list_gab`.`type_gab` IN(".$type_gab.")";}
    if(($categorie<>'')&&($categorie<>'%')){$sql = $sql." AND `new_incident_gab`.`id_categories_fonctionnelle` IN(".$categorie.")";}

    // echo "<br>".$sql."<br>";
    $link = ma_db_connexion();
    if ($result=mysqli_query($link,$sql) or die('Erreur   calculeDureeArretGAB !<br>'.$sql.'<br>'.mysqli_error($link)))
    {
        if(mysqli_num_rows($result)>0)
        {$j=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                mysqli_close($link);
                return $row["nbr_alerte"];
            }
        }
        else
        {
            mysqli_close($link);
            return 0;
        }

        mysqli_free_result($result);
    }


}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function calculeDureeArretGAB($date_courant,$duree1,$duree,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)
{
//$durue en minute.

    $sql = "SELECT `id_incident`, count(`id_incident`) as nbr_alerte	
            FROM  `new_incident_gab` ,`new_list_gab`
			WHERE	`new_incident_gab`.`id_gab`= `new_list_gab`.`terminal` 
			AND  `new_incident_gab`.`etat_stat` = 0	  
			AND  `new_list_gab`.`id_activation` = 1					
		    AND   `etat_incident` = 0
			AND 	round (TIME_TO_SEC(TIMEDIFF('".$date_courant."',`date_arrete`))/60)  > '$duree1'
			AND 	round (TIME_TO_SEC(TIMEDIFF('".$date_courant."',`date_arrete`))/60)  <= '$duree'";

    if(($list_gab<>'')&&($list_gab<>'%')){$sql = $sql." AND `new_incident_gab`.`id_gab` IN(".implode(',',$list_gab).")";}
    if(($motif_inclus<>'')&&($motif_inclus<>'%')){$sql = $sql." AND `new_incident_gab`.`id_action_fonctionelle` IN(".implode(',',$motif_inclus).")";}
    if(($id_filiales<>'')&&($id_filiales<>'%')){$sql = $sql." AND `new_incident_gab`.`cd_filiale` IN(".$id_filiales.")";}
    if(($type_gab<>'')&&($type_gab<>'%')){$sql = $sql." AND `new_list_gab`.`type_gab` IN(".$type_gab.")";}
    if(($categorie<>'')&&($categorie<>'%')){$sql = $sql." AND `new_incident_gab`.`id_categories_fonctionnelle` IN(".$categorie.")";}

    // echo "<br>".$sql."<br>";
    $link = ma_db_connexion();
    if ($result=mysqli_query($link,$sql) or die('Erreur   calculeDureeArretGAB !<br>'.$sql.'<br>'.mysqli_error($link)))
    {
        if(mysqli_num_rows($result)>0)
        {$j=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                mysqli_close($link);
                return $row["nbr_alerte"];
            }
        }
        else
        {
            mysqli_close($link);
            return 0;
        }

        mysqli_free_result($result);
    }


}
////////////////////////////////////////////////////////////////////////////////
function calculeDureeArretGABInferieur($date_courant,$duree1,$duree2,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)
{
//$durue en minute.

    $sql = "SELECT `id_incident`, count(`id_incident`) as nbr_alerte
            FROM  `new_incident_gab` ,`new_list_gab`
			WHERE	`new_incident_gab`.`id_gab`= `new_list_gab`.`terminal` 
			AND  `new_incident_gab`.`etat_stat` = 0	  
			AND  `new_list_gab`.`id_activation` = 1					
		    AND   `etat_incident` = 0
			AND `new_incident_gab`.`id_action_fonctionelle` NOT IN(402,407,408,409,410,374,424,425,426,427,442)
			AND 	round (TIME_TO_SEC(TIMEDIFF('".$date_courant."',`date_arrete`))/60)  <= '$duree1'";

    if(($list_gab<>'')&&($list_gab<>'%')){$sql = $sql." AND `new_incident_gab`.`id_gab` IN(".implode(',',$list_gab).")";}
    if(($motif_inclus<>'')&&($motif_inclus<>'%')){$sql = $sql." AND `new_incident_gab`.`id_action_fonctionelle` IN(".implode(',',$motif_inclus).")";}
    if(($id_filiales<>'')&&($id_filiales<>'%')){$sql = $sql." AND `new_incident_gab`.`cd_filiale` IN(".$id_filiales.")";}
    if(($type_gab<>'')&&($type_gab<>'%')){$sql = $sql." AND `new_list_gab`.`type_gab` IN(".$type_gab.")";}
    if(($categorie<>'')&&($categorie<>'%')){$sql = $sql." AND `new_incident_gab`.`id_categories_fonctionnelle` IN(".$categorie.")";}

    // echo "<br>".$sql."<br>";
    $link = ma_db_connexion();
    if ($result=mysqli_query($link,$sql) or die('Erreur   calculeDureeArretGABInferieur !<br>'.$sql.'<br>'.mysqli_error($link)))
    {
        if(mysqli_num_rows($result)>0)
        {$j=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                mysqli_close($link);
                return $row["nbr_alerte"];
            }
        }
        else
        {
            mysqli_close($link);
            return 0;
        }

        mysqli_free_result($result);
    }
}
//////////////////////////////////////////////////////////////////////////////////
function get_nbr_incident_categorie($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)
{

    $sql = "SELECT  count(distinct(`id_incident`)) as nbr_incident
							FROM  `new_incident_gab` ,`new_list_gab`
							WHERE	`new_incident_gab`.`id_gab`= `new_list_gab`.`terminal` 
							AND  `new_incident_gab`.`etat_stat` = 0	  
							AND  `new_incident_gab`.`id_activation` = 1	";
    $sql = $sql ."AND `new_incident_gab`.`id_action_fonctionelle` NOT IN(402,407,408,409,410,374,424,425,426,427,442)";
    // if($list_gab<>''){$sql = $sql." AND `new_incident_gab`.`id_gab` IN(".$list_gab.")";}
    if($list_gab<>''){$sql = $sql." AND `new_incident_gab`.`id_gab` IN(".implode(',',$list_gab).")";}
    if(($motif_inclus<>'')&&($motif_inclus<>'%')){$sql = $sql." AND `new_incident_gab`.`id_action_fonctionelle` IN(".implode(',',$motif_inclus).")";}
    if(($id_filiales<>'')&&($id_filiales<>'%')){$sql = $sql." AND `new_incident_gab`.`cd_filiale` IN(".$id_filiales.")";}
    if(($type_gab<>'')&&($type_gab<>'%')){$sql = $sql." AND `new_list_gab`.`type_gab` IN(".$type_gab.")";}
    if(($categorie<>'')&&($categorie<>'%')){$sql = $sql." AND `new_incident_gab`.`id_categories_fonctionnelle` IN(".$categorie.")";}
    $sql = $sql ." AND ((TIMESTAMPDIFF(MINUTE,`date_arrete`, `date_remise`)>30 	AND `etat_incident`=1 
							AND (DATE_FORMAT(`date_arrete` , '%Y-%m-%d')  BETWEEN '".$date_debut."' AND '".$date_fin."'				
							OR DATE_FORMAT(`date_remise` , '%Y-%m-%d')  BETWEEN '".$date_debut."' AND '".$date_fin."'
							OR ( DATE_FORMAT(`date_arrete`, '%Y-%m-%d') <= '".$date_debut."' AND '".$date_fin."' <=  DATE_FORMAT(`date_remise`, '%Y-%m-%d'))))
							OR ( DATE_FORMAT(`date_arrete`, '%Y-%m-%d') <= '".$date_fin."' AND `etat_incident`=0))	";

    // if($list_gab<>''){echo "<br>".$sql."<br>";}
    // echo "<br>".$sql."<br>";
    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql);

    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            mysqli_close($link);
            return $row["nbr_incident"];
            $j++;
        }
    }
    else
    {
        mysqli_close($link);
        return 0;
    }


}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nb_gab_service($id_filiale,$champs_service)
{
    // ma_db_connexion()
    $sql = "SELECT  count(`terminal`) as nbr_gab FROM `new_list_gab` WHERE ";
    if (($id_filiale<>"")&&($id_filiale<>"%")) {$sql =$sql." `code_bank`  IN  (".$id_filiale.") AND ";}
    if (($champs_service<>"")) {$sql = $sql." `".$champs_service."`  = 1 AND ";}
    $sql =$sql." `id_activation` = 1  AND id_terminal_xfs IS NOT NULL";
    $link = ma_db_connexion();
    if ($result=mysqli_query($link,$sql) or die('Erreur   get_list_service_atm !<br>'.$sql.'<br>'.mysqli_error($link)))
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                mysqli_close($link);
                return $row["nbr_gab"];
            }
        }
        else
        {
            mysqli_close($link);
            return  0;
        }
        mysqli_free_result($result);
    }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_duree_minute_sla($id)
{
    $sql = "SELECT `duree_minute` FROM  `new_libelle_type_contact` WHERE `new_libelle_type_contact`.id_type = '".$id."'";

    $link = ma_db_connexion();
    if ($result=mysqli_query($link,$sql) or die('Erreur   get_lebelle_type_contact_affecter !<br>'.$sql.'<br>'.mysqli_error($link)))
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {

                // echo $row["duree_minute"]." ------> ".$sql."<br>";
                mysqli_close($link);
                return $row["duree_minute"];
            }
        }
        else
        {
            mysqli_close($link);
            return  0;
        }
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function transforme($time)
{
    if ($time>=86400)
        /* 86400 = 3600*24 c'est à dire le nombre de secondes dans un seul jour ! donc là on vérifie si le nombre de secondes donné contient des jours ou pas */
    {
// Si c'est le cas on commence nos calculs en incluant les jours

// on divise le nombre de seconde par 86400 (=3600*24)
// puis on utilise la fonction floor() pour arrondir au plus petit
        $jour = floor($time/86400);
// On extrait le nombre de jours
        $reste = $time%86400;

        $heure = floor($reste/3600);
// puis le nombre d'heures
        $reste = $reste%3600;

        $minute = floor($reste/60);
// puis les minutes

        $seconde = $reste%60;
// et le reste en secondes

// on rassemble les résultats en forme de date
        $result = $jour.'j '.$heure.'h '.$minute.'min ';
    }
    elseif ($time < 86400 AND $time>=3600)
// si le nombre de secondes ne contient pas de jours mais contient des heures
    {
// on refait la même opération sans calculer les jours
        $heure = floor($time/3600);
        $reste = $time%3600;

        $minute = floor($reste/60);

        $seconde = $reste%60;

        $result = $heure.'h '.$minute.'min ';
    }
    elseif ($time<3600 AND $time>=60)
    {
// si le nombre de secondes ne contient pas d'heures mais contient des minutes
        $minute = floor($time/60);
        $seconde = $time%60;
        $result = $minute.'min ';
    }
    elseif ($time < 60)
// si le nombre de secondes ne contient aucune minutes
    {
        $result = $time.'s';
    }
    return $result;
}
function getNBRIntervention($mois_courant,$date_fin,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab,$motif)
{


    $sql="SELECT `date_courant`, `dossier`, `date_arret`, `date_remise`, `gab`, `gestionnaire_gab`, `region`, `id_categorie`, `id_action`, `libelle_categorie`, MIN(`date_action_reel`) as dt_action_reel,
								MIN(`date_action_cont`) as dt_action_cont, MAX(`date_remise_reel`) as dt_remise_reel, MAX(`date_remise_cont`) as dt_remise_cont, `type_jour`, `id_gestionnaire`, SUM(`duree_arret_reel`) AS duree_arr_reel, `type_gab`,
								SUM(`duree_arret_cont`) AS duree_arr_cont, `duree_sla`, SUM(`delta_sla_reel`) as delta_reel, SUM(`delta_sla_cont`) as delta_cont
								FROM  `taux_dispo_sla`
								WHERE  `dossier` IN(".implode(',',get_liste_dossier_sla($mois_courant,$date_fin,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$motif,$list_gab)).")";

    // $sql=$sql." AND  `new_list_gab`.`id_activation` = 1";
    $sql=$sql." GROUP  BY `dossier`, `id_gestionnaire`";
    $sql=$sql." ORDER BY `dossier`";


    // echo "===== >".$sql."<br>";
    $connexion = ma_db_connexion();
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 035: ".mysqli_error($connexion));
        die('ERREUR QUERY 035 !');
    }


    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $total_incident=0;
            $total_deppassent_reel=0;
            $total_deppassent_cont=0;

            $total_deppassent_agence_reel=0;
            $total_deppassent_agence_cont=0;

            $total_deppassent_G4S_reel=0;
            $total_deppassent_G4S_cont=0;

            $total_deppassent_Logistique_reel=0;
            $total_deppassent_Logistique_cont=0;

            $total_deppassent_NCR_reel=0;
            $total_deppassent_NCR_cont=0;

            $total_deppassent_TELECOM_reel=0;
            $total_deppassent_TELECOM_cont=0;

            $total_deppassent_Monetique_reel=0;
            $total_deppassent_Monetique_cont=0;

            $total_deppassent_S2M_reel=0;
            $total_deppassent_S2M_cont=0;

            $total_duree_reel=0;
            $total_duree_cont=0;

            $total_duree_deppassement_reel=0;
            $total_duree_deppassement_cont=0;



            $duree_deppassent_G4S_reel=0;
            $duree_deppassent_G4S_cont=0;

            $duree_deppassent_Logistique_reel=0;
            $duree_deppassent_Logistique_cont=0;

            $duree_deppassent_NCR_reel=0;
            $duree_deppassent_NCR_cont=0;

            $duree_deppassent_TELECOM_reel=0;
            $duree_deppassent_TELECOM_cont=0;

            $duree_deppassent_Monetique_reel=0;
            $duree_deppassent_Monetique_cont=0;

            $duree_deppassent_S2M_reel=0;
            $duree_deppassent_S2M_cont=0;



            $total_agence=0;
            $total_G4S=0;
            $total_Logistique=0;
            $total_NCR=0;
            $total_TELECOM=0;
            $total_Monetique=0;
            $total_S2M=0;

            $duree_G4S_reel=0;
            $duree_Logistique_reel=0;
            $duree_NCR_reel=0;
            $duree_TELECOM_reel=0;
            $duree_Monetique_reel=0;
            $duree_S2M_reel=0;


            $duree_G4S=0;
            $duree_Logistique=0;
            $duree_NCR=0;
            $duree_TELECOM=0;
            $duree_Monetique=0;
            $duree_S2M=0;


            $moy_deppassent_G4S_reel = 0;
            $moy_deppassent_Logistique_reel  = 0;
            $moy_deppassent_NCR_reel  = 0;
            $moy_deppassent_TELECOM_reel  = 0;
            $moy_deppassent_Monetique_reel = 0;
            $moy_deppassent_S2M_reel = 0;



            while ($row = mysqli_fetch_assoc($result))
            {
                $delta_reel=$row["duree_arr_reel"]-$row["duree_sla"];
                $delta_cont=$row["duree_arr_cont"]-$row["duree_sla"];

                $total_duree_reel=$row["duree_arr_reel"]+$total_duree_reel;
                $total_duree_cont=$row["duree_arr_cont"]+$total_duree_cont;

                if($delta_reel>0){ $total_deppassent_reel++; $total_duree_deppassement_reel=$row["duree_arr_reel"]+$total_duree_deppassement_reel; }
                if($delta_cont>0){ $total_deppassent_cont++; $total_duree_deppassement_cont=$row["duree_arr_cont"]+$total_duree_deppassement_cont; }



                if(($delta_reel>0) && ($row["id_gestionnaire"]==1)){$total_deppassent_agence_reel++;}
                if(($row["id_gestionnaire"]==2)){$total_deppassent_G4S_reel++;$duree_deppassent_G4S_reel=$row["duree_arr_cont"]+$duree_deppassent_G4S_reel;}
                if(($row["id_gestionnaire"]==3)){$total_deppassent_Logistique_reel++;$duree_deppassent_Logistique_reel=$row["duree_arr_cont"]+$duree_deppassent_Logistique_reel;}
                if(($row["id_gestionnaire"]==6)){$total_deppassent_NCR_reel++;$duree_deppassent_NCR_reel=$row["duree_arr_cont"]+$duree_deppassent_NCR_reel;}
                if(($row["id_gestionnaire"]==8)){$total_deppassent_TELECOM_reel++;$duree_deppassent_TELECOM_reel=$row["duree_arr_cont"]+$duree_deppassent_TELECOM_reel;}
                if(($row["id_gestionnaire"]==9)){$total_deppassent_Monetique_reel++;$duree_deppassent_Monetique_reel=$row["duree_arr_cont"]+$duree_deppassent_Monetique_reel;}
                if(($row["id_gestionnaire"]==10)){$total_deppassent_S2M_reel++;$duree_deppassent_S2M_reel=$row["duree_arr_cont"]+$duree_deppassent_S2M_reel;}

                if(($delta_cont>0) && ($row["id_gestionnaire"]==1)){$total_deppassent_agence_cont++; }
                if(($delta_cont>0) && ($row["id_gestionnaire"]==2)){$total_deppassent_G4S_cont++; $duree_deppassent_G4S_cont=$row["duree_arr_cont"]+$duree_deppassent_G4S_cont;}
                if(($delta_cont>0) && ($row["id_gestionnaire"]==3)){$total_deppassent_Logistique_cont++; $duree_deppassent_Logistique_cont=$row["duree_arr_cont"]+$duree_deppassent_Logistique_cont;}
                if(($delta_cont>0) && ($row["id_gestionnaire"]==6)){$total_deppassent_NCR_cont++; $duree_deppassent_NCR_cont=$row["duree_arr_cont"]+$duree_deppassent_NCR_cont;}
                if(($delta_cont>0) && ($row["id_gestionnaire"]==8)){$total_deppassent_TELECOM_cont++; $duree_deppassent_TELECOM_cont=$row["duree_arr_cont"]+$duree_deppassent_TELECOM_cont;}
                if(($delta_cont>0) && ($row["id_gestionnaire"]==9)){$total_deppassent_Monetique_cont++; $duree_deppassent_Monetique_cont=$row["duree_arr_cont"]+$duree_deppassent_Monetique_cont;}
                if(($delta_cont>0) && ($row["id_gestionnaire"]==10)){$total_deppassent_S2M_cont++; $duree_deppassent_S2M_cont=$row["duree_arr_cont"]+$duree_deppassent_S2M_cont;}

                if(($row["id_gestionnaire"]==1)){$total_agence++;}
                if(($row["id_gestionnaire"]==2)){$total_G4S++;$duree_G4S_reel=$row["duree_arr_cont"]+$duree_G4S;}
                if(($row["id_gestionnaire"]==3)){$total_Logistique++;$duree_Logistique=$row["duree_arr_cont"]+$duree_Logistique;}
                if(($row["id_gestionnaire"]==6)){$total_NCR++;$duree_NCR=$row["duree_arr_cont"]+$duree_NCR;}
                if(($row["id_gestionnaire"]==8)){$total_TELECOM++;$duree_TELECOM=$row["duree_arr_cont"]+$duree_TELECOM;}
                if(($row["id_gestionnaire"]==9)){$total_Monetique++;$duree_Monetique=$row["duree_arr_cont"]+$duree_Monetique;}
                if(($row["id_gestionnaire"]==10)){$total_S2M++;$duree_S2M=$row["duree_arr_cont"]+$duree_S2M;}


                $total_incident++;
            }



            // echo '<table>
            // <tr><td>agence : '.$total_deppassent_agence_cont.'</td></tr>
            // <tr><td>G4S : '.$total_deppassent_G4S_cont.'</td></tr>
            // <tr><td>Logistique : '.$total_deppassent_Logistique_cont.'</td></tr>
            // <tr><td>NCR : '.$total_deppassent_NCR_cont.'</td></tr>
            // <tr><td>TELECOM : '.$total_deppassent_TELECOM_cont.'</td></tr>
            // <tr><td>Monétique : '.$total_deppassent_Monetique_cont.'</td></tr>
            // <tr><td>S2M : '.$total_deppassent_S2M_cont.'</td></tr>
            // <tr><td>Total contractuel : '.$total_deppassent_cont.'</td></tr>
            // <tr><td>Total intervention : '.$total_incident.'</td></tr>
            // </table>';


        }

    }

    mysqli_free_result($result);
    mysqli_close($connexion);
    return array($total_incident,$total_deppassent_reel,$total_deppassent_cont,$total_deppassent_agence_reel,$total_deppassent_G4S_reel,$total_deppassent_Logistique_reel,$total_deppassent_NCR_reel,
        $total_deppassent_TELECOM_reel,$total_deppassent_Monetique_reel,$total_deppassent_S2M_reel,$total_deppassent_agence_cont,$total_deppassent_G4S_cont,
        $total_deppassent_Logistique_cont,$total_deppassent_NCR_cont,$total_deppassent_TELECOM_cont,$total_deppassent_Monetique_cont,$total_deppassent_S2M_cont,
        $total_duree_deppassement_reel,$total_duree_deppassement_cont,
        $duree_deppassent_G4S_reel,$duree_deppassent_Logistique_reel,$duree_deppassent_NCR_reel,$duree_deppassent_TELECOM_reel,$duree_deppassent_Monetique_reel,$duree_deppassent_S2M_reel,
        $duree_deppassent_G4S_cont,$duree_deppassent_Logistique_cont,$duree_deppassent_NCR_cont,$duree_deppassent_TELECOM_cont,$duree_deppassent_Monetique_cont,$duree_deppassent_S2M_cont,
        $total_G4S,$total_Logistique,$total_NCR,$total_TELECOM,$total_Monetique,
        $total_S2M,$duree_G4S_reel,$duree_Logistique,$duree_NCR,$duree_TELECOM,$duree_Monetique,$duree_S2M,$total_agence);


// 17 total_duree_deppassement_reel
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getMoyIntervention($mois_courant,$date_fin,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab,$motif,$type)
{


    $sql="SELECT `id_gestionnaire`, AVG(`duree_arret_reel`) AS duree_arr_reel, `type_gab`, `duree_arret_cont` , `duree_sla` ,
								AVG(`duree_arret_cont`) AS duree_arr_cont, SUM(`delta_sla_reel`) as delta_reel, SUM(`delta_sla_cont`) as delta_cont
								FROM  `taux_dispo_sla`
								WHERE  `dossier` IN(".implode(',',get_liste_dossier_sla($mois_courant,$date_fin,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$motif,$list_gab)).")";

    if($type==1){$sql=$sql." AND `duree_arret_cont` >   `duree_sla`";}
    $sql=$sql." GROUP  BY  `id_gestionnaire`";
    // $sql=$sql." HAVING `duree_arret_cont` >   `duree_sla`";
    // $sql=$sql." ORDER BY `dossier`";


    // echo "===== >".$sql."<br>";
    $connexion = ma_db_connexion();
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 035: ".mysqli_error($connexion));
        die('ERREUR QUERY 035 !');
    }


    if ($result)
    {

        $moy_deppassent_G4S_reel=0;
        $moy_deppassent_Logistique_reel=0;
        $moy_deppassent_NCR_reel=0;
        $moy_deppassent_TELECOM_reel=0;
        $moy_deppassent_Monetique_reel=0;
        $moy_deppassent_S2M_reel=0;

        $moy_deppassent_G4S_cont=0;
        $moy_deppassent_Logistique_cont=0;
        $moy_deppassent_NCR_cont=0;
        $moy_deppassent_TELECOM_cont=0;
        $moy_deppassent_Monetique_cont=0;
        $moy_deppassent_S2M_cont=0;

        if(mysqli_num_rows($result)>0)
        {




            while ($row = mysqli_fetch_assoc($result))
            {

                if(($row["id_gestionnaire"]==2)){$moy_deppassent_G4S_reel=$row["duree_arr_reel"];}
                if(($row["id_gestionnaire"]==3)){$moy_deppassent_Logistique_reel=$row["duree_arr_reel"];}
                if(($row["id_gestionnaire"]==6)){$moy_deppassent_NCR_reel=$row["duree_arr_reel"];}
                if(($row["id_gestionnaire"]==8)){$moy_deppassent_TELECOM_reel=$row["duree_arr_reel"];}
                if(($row["id_gestionnaire"]==9)){$moy_deppassent_Monetique_reel=$row["duree_arr_reel"];}
                if(($row["id_gestionnaire"]==10)){$moy_deppassent_S2M_reel=$row["duree_arr_reel"];}


                if(($row["id_gestionnaire"]==2)){$moy_deppassent_G4S_cont=$row["duree_arr_cont"];}
                if(($row["id_gestionnaire"]==3)){$moy_deppassent_Logistique_cont=$row["duree_arr_cont"];}
                if(($row["id_gestionnaire"]==6)){$moy_deppassent_NCR_cont=$row["duree_arr_cont"];}
                if(($row["id_gestionnaire"]==8)){$moy_deppassent_TELECOM_cont=$row["duree_arr_cont"];}
                if(($row["id_gestionnaire"]==9)){$moy_deppassent_Monetique_cont=$row["duree_arr_cont"];}
                if(($row["id_gestionnaire"]==10)){$moy_deppassent_S2M_cont=$row["duree_arr_cont"];}

            }
        }
        // echo "<br>MORSLI : ".$moy_deppassent_G4S_reel;
        mysqli_free_result($result);
        mysqli_close($connexion);
        return array($moy_deppassent_G4S_reel,$moy_deppassent_Logistique_reel,$moy_deppassent_NCR_reel,$moy_deppassent_TELECOM_reel,$moy_deppassent_Monetique_reel,$moy_deppassent_S2M_reel,
            $moy_deppassent_G4S_cont,$moy_deppassent_Logistique_cont,$moy_deppassent_NCR_cont,$moy_deppassent_TELECOM_cont,$moy_deppassent_Monetique_cont,$moy_deppassent_S2M_cont);
    }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_duree_sla_format($id)
{
    $sql = "SELECT `duree_sla` FROM  `new_libelle_type_contact` WHERE `new_libelle_type_contact`.id_type = '".$id."'";
    $link = ma_db_connexion();
    if ($result=mysqli_query($link,$sql) or die('Erreur   get_lebelle_type_contact_affecter !<br>'.$sql.'<br>'.mysqli_error($link)))
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                mysqli_close($link);
                return ucfirst(($row["duree_sla"]));
            }
        }
        else
        {
            mysqli_close($link);
            return  '';
        }
        mysqli_free_result($result);
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_liste_dossier_sla($date_courant,$date_fin,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$motif_inclus,$list_gab)
{

    $connexion = ma_db_connexion();
    $table_incident = array();
    $sql5="SELECT  `dossier` FROM  `taux_dispo_sla`	WHERE  `dossier` <> 0 ";
    $sql5 = $sql5."  AND  DATE_FORMAT(`date_courant` , '%Y-%m-%d')  BETWEEN '".$date_courant."' AND '".$date_fin."'";
    if(($list_gab<>"")&&($list_gab<>'%')){$sql5=$sql5." AND  `gab` IN(".implode(',',$list_gab).")";}
    if(($categorie<>"")&&($categorie<>'%')){$sql5=$sql5." AND  `id_categorie` IN(".$categorie.")";}
    if(($id_filiales<>"")&&($id_filiales<>'%')){$sql5=$sql5." AND  `region` IN(".$id_filiales.")";}
    if(($type_gestionnaire<>"")&&($type_gestionnaire<>'%')){$sql5=$sql5." AND  `id_gestionnaire` IN(".$type_gestionnaire.")";}
    if(($type_gab<>"")&&($type_gab<>'%')){$sql5=$sql5." AND  `type_gab` IN(".$type_gab.")";}
    if(($motif_inclus<>"")&&($motif_inclus<>'%')){$sql5=$sql5." AND `id_action` IN(".implode(',',$motif_inclus).")";}
    $sql5=$sql5." GROUP BY `dossier` ";
    // echo $sql5."<br>";
    $result5=mysqli_query($connexion,$sql5);
    if (!$result5)
    {
        error_log("Erreur sql 040: ".mysqli_error($connexion));
        die('ERREUR QUERY 040 !');
    }


    if ($result5)
    {
        if(mysqli_num_rows($result5)>0)
        {
            $j=0;
            while ($row = mysqli_fetch_assoc($result5))
            {
                $table_incident[$j]=$row["dossier"];
                $j++;
            }
        }
        else
        {
            $table_incident[0]=0;
        }
    }
    mysqli_close($connexion);
    return $table_incident;

}
//////////////////////////////////////////////////////////////////////////////////
function get_nbr_incident_categorie_service($date_debut,$date_fin,$categorie,$champ_service)
{


    $sql = "SELECT  count(distinct(`id_incident`)) as nbr_incident
							FROM  `new_incident_gab` ,`new_action_intervention`
							WHERE	`new_incident_gab`.`id_categories_fonctionnelle`= `new_action_intervention`.`id_categories` 
							AND `new_action_intervention`.`id_intevention` = `new_incident_gab`.`id_action_fonctionelle` 
							AND  `new_incident_gab`.`etat_stat` = 0	  
							AND  `new_incident_gab`.`id_activation` = 1					
							AND  `new_incident_gab`.`id_categories_fonctionnelle`  IN  (".$categorie.")						
							AND  `".$champ_service."` = 1";
    $sql = $sql ." AND ((TIMESTAMPDIFF(MINUTE,`date_arrete`, `date_remise`)>30 	AND `etat_incident`=1 
							AND (DATE_FORMAT(`date_arrete`, '%Y-%m')  BETWEEN '".$date_debut."' AND '".$date_fin."'		
							OR DATE_FORMAT(`date_remise`, '%Y-%m') BETWEEN '".$date_debut."' AND '".$date_fin."'	
							OR ( DATE_FORMAT(`date_arrete`, '%Y-%m') <= '".$date_debut."' AND '".$date_fin."' <=  DATE_FORMAT(`date_remise`, '%Y-%m'))))
							OR ( DATE_FORMAT(`date_arrete`, '%Y-%m') <= '".$date_fin."' AND `etat_incident`=0))	";





    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql) or die('Erreur   get_nbr_incident_categorie_service !<br>'.$sql.'<br>'.mysqli_error($link));

    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            mysqli_close($link);
            return $row["nbr_incident"];
            $j++;
        }
    }
    else
    {
        mysqli_close($link);
        return 0;
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_liste_gab_ville_inclus_taux($id_filiale,$libelle_champ)
{

    $list_gab = array();
    $sql = "SELECT  `terminal` FROM `new_list_gab`	WHERE ";
    // $sql = $sql." `id_activation` = 1 ";
    // $sql = $sql." AND id_terminal_xfs IS NOT NULL ";
    if (($id_filiale<>"")&&($id_filiale<>"%")) {$sql =$sql." `code_bank`  IN  (".$id_filiale.")";}
    if ($libelle_champ<>"") {$sql = $sql." AND `".$libelle_champ."` = 1 ";}	else { $sql = $sql." AND `id_activation` = 1 "; }

    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql);
    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            $list_gab[$j]=$row["terminal"];
            $j++;
        }
    }
    else
    {
        $list_gab[0]=0;
    }
    mysqli_close($link);
    return $list_gab;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getverifTaux1($duree_motif,$duree_globlal)
{
    if (($duree_globlal==0)||($duree_globlal==""))return $duree_globlal;
    else return round((($duree_motif)/$duree_globlal*100),2,PHP_ROUND_HALF_DOWN);

    // if (($duree_globlal==0)||($duree_globlal==""))return $duree_globlal;
    // else return $duree_motif/$duree_globlal;

    // return $duree_motif/$duree_globlal;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getTauxIndispoMotif2($date_courant,$date_fin,$motif_inclus,$list_gab,$categorie,$id_filiales,$type_gab,$type_gestionnaire)
{

    // $duree_globlal=round((affichageDetailDuree($dates1,$dates2,$etatMotif)/60),0);
    // $duree_globlal=round((affichageDetailDureeTotal()/60),0);
    $duree=0;
    $sql = "SELECT round(SUM(`duree_arret_reel`/60),0) AS nb_minute
		FROM  `taux_dispo_sla_global` 
		WHERE `dossier`<>0 AND `categorie_action` <> 0 ";
    if(($categorie<>'')&&($categorie<>'%')) {$sql = $sql." AND `categorie_action`   IN(".$categorie.")";}
    if(($id_filiales<>'')&&($id_filiales<>'%')){$sql = $sql." AND `region`   IN(".$id_filiales.")";}
    if(($motif_inclus<>'')&&($motif_inclus<>'%')){$sql = $sql." AND `id_action` IN(".implode(',',$motif_inclus).")";}
    if(($list_gab<>'')&&($list_gab<>'%')){$sql = $sql." AND `gab` IN(".implode(',',$list_gab).")";}
    $sql = $sql." AND  DATE_FORMAT(`date_courant` , '%Y-%m-%d')  BETWEEN '".$date_courant."' AND '".$date_fin."'";
    $sql = $sql." ORDER BY SUM(duree_arret_reel) DESC";
// echo "<br>".$sql."<br>";
    $link = ma_db_connexion();
    $result = mysqli_query($link,$sql);


    if(mysqli_num_rows($result)>0)
    {


        while ($row = mysqli_fetch_assoc($result))
        {

            // echo "<br> DREE : ".$row["nb_minute"]."<br>";
            $duree=$row["nb_minute"];
        }

    }
    else
    {
        $duree=0;
    }

    mysqli_close($link);
    return $duree;

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_nb_gab($id,$libelle_champ)
{
    // ma_db_connexion()
    $sql = "SELECT  count(`terminal`) as nbr_gab FROM `new_list_gab` WHERE ";
    if (($id<>"")&&($id<>"%")) {$sql =$sql."`new_list_gab`.`code_bank`  IN  (".$id.") AND ";}
    $sql =$sql."  `new_list_gab`.`id_activation` = 1  AND  `".$libelle_champ."` = 1 
		AND id_terminal_xfs IS NOT NULL";
    $link = ma_db_connexion();
    if ($result=mysqli_query($link,$sql) or die('Erreur   get_list_service_atm !<br>'.$sql.'<br>'.mysqli_error($link)))
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                mysqli_close($link);
                return $row["nbr_gab"];
            }
        }
        else
        {
            mysqli_close($link);
            return  0;
        }
        mysqli_free_result($result);
    }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_liste_motif_inclus_taux($libelle_champ)
{

    $list_intevention = array();
    $sql = "SELECT  `id_intevention` FROM `new_action_intervention`	WHERE   `".$libelle_champ."` = 1";
    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql);
    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            $list_intevention[$j]=$row["id_intevention"];
            $j++;
        }
    }
    else
    {
        $list_intevention[0]=0;
    }
    mysqli_close($link);
    return $list_intevention;

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_liste_gab_inclus_taux($libelle_champ)
{

    $list_gab = array();
    $sql = "SELECT  `terminal` FROM `new_list_gab`	WHERE   `".$libelle_champ."` = 1";
    $link = ma_db_connexion();
    $result=mysqli_query($link,$sql);
    if(mysqli_num_rows($result)>0)
    {$j=0;
        while ($row = mysqli_fetch_assoc($result))
        {
            $list_gab[$j]=$row["terminal"];
            $j++;
        }
    }
    else
    {
        $list_gab[0]=0;
    }
    mysqli_close($link);
    return $list_gab;

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_table_nbr_alerte_incidents_service_categorie($mois_courant,$date_fin,$list_gab_retrait_argent,$motif_retrait_argent,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$lang)
{
    echo '<table class="table table-responsive-sm table-hover table-outline mb-0">';
    echo '<thead class="thead-light">';
    echo '<tr>';
    echo '<th>'.$lang['th_table_21'].'</th>';
    echo '<th>'.$lang['th_table_20'].'</th>';
    echo '</tr>';
    echo '</thead>';

    $connexion = ma_db_connexion();

    $sql = "SELECT `id_categorie`, `libelle` FROM `new_categorie_intervention`";
    if(($categorie<>"")&&($categorie<>"%")){$sql = $sql." WHERE `id_categorie` IN(".mysqli_real_escape_string($connexion,$categorie).")"; }
    $sql = $sql." GROUP BY `libelle`";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 032 : ".mysqli_error($connexion));
        die('ERREUR QUERY 032 !');
    }


    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {


                echo '<tr>';
                echo '<td>'.$row["libelle"].'</td><td>'.get_nbr_incident_categorie($mois_courant,$date_fin,$row["id_categorie"],$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire).'</td>';
                echo '</tr>';
            }
        }
    }

    mysqli_free_result($result);
    mysqli_close($connexion);

    echo '</table>';
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_table_nbr_alerte_incidents_responsable($mois_courant,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire,$lang)
{

    echo '<table class="table table-responsive-sm table-hover table-outline mb-0">';
    echo '<thead class="thead-light">';
    echo '<tr>';
    echo '<th>'.$lang['th_table_19'].'</th>';
    echo '<th>'.$lang['th_table_20'].'</th>';
    echo '</tr>';
    echo '</thead>';
    foreach (get_array_id_responsable($type_gestionnaire) AS $id_responsable)
    {
        echo '<tr>';
        echo '<td>';
        echo get_libelle_responsable($id_responsable);
        echo '</td>';
        echo '<td>';
        echo get_compte_nb_incident_responsable($mois_courant,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$id_responsable);
        echo '</td>';
        echo '</tr>';

    }
    echo '</table>';
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_table_nbr_alerte_incidents_categorie($mois_courant,$date_fin,$list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque,$motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$lang)
{


    foreach ($motif_retrait_argent AS $id_gab)
    {
        // echo "<br>List gab retrait argent : ".$id_gab;
    }
    echo '<table class="table table-responsive-sm table-hover table-outline mb-0">';
    echo '<thead class="thead-light">';
    echo '<tr>';
    echo '<th>'.$lang['th_table_21'].'</th>';
    echo '<th>'.$lang['th_table_22'].'</th>';
    echo '<th>'.$lang['th_table_23'].'</th>';
    echo '<th>'.$lang['th_table_24'].'</th>';
    echo '</tr>';
    echo '</thead>';

    if($categorie==""){$categorie="%";}
    $connexion = ma_db_connexion();

    $sql = "SELECT `id_categorie`, `libelle` FROM `new_categorie_intervention`";
    if($categorie<>"%"){$sql = $sql." WHERE `id_categorie` IN(".mysqli_real_escape_string($connexion,$categorie).")"; }
    $sql = $sql." GROUP BY `libelle`";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 032 : ".mysqli_error($connexion));
        die('ERREUR QUERY 032 !');
    }


    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {

                echo '<tr>';
                echo '<td>'.$row["libelle"].'</td>
					<td>'.get_nbr_incident_categorie($mois_courant,$date_fin,$row["id_categorie"],$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire).'</td>
					<td>'.get_nbr_incident_categorie($mois_courant,$date_fin,$row["id_categorie"],$list_gab_depot_argent,$motif_depot_argent,$id_filiales,$type_gab,$type_gestionnaire).'</td>
					<td>'.get_nbr_incident_categorie($mois_courant,$date_fin,$row["id_categorie"],$list_gab_depot_cheque,$motif_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire).'</td>
					</tr>';
            }
        }
    }

    mysqli_free_result($result);
    mysqli_close($connexion);


    echo '</table>';
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function affichageDureeInformationIntervenantVille($date_courant,$date_fin,$motif_inclus,$list_gab,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$nb_gab,$nb_jour_mois,$titre,$champs_service,$lang)
{
    $duree_globlal=$nb_gab*$nb_jour_mois*1440;
    $duree=getTauxIndispoMotif2($date_courant,$date_fin,$motif_inclus,$list_gab,$categorie,$id_filiales,$type_gab,$type_gestionnaire);
    $taux_indispo_dispo=getverifTaux1($duree,$duree_globlal);
    $dispo=round(100-$taux_indispo_dispo,2,PHP_ROUND_HALF_DOWN);
    foreach ($list_gab AS $id_gab)
    {
        // if($champs_service=="id_activ_depot_argent"){echo $id_gab."<br>";}
    }
    // echo "<br>=====><br>";




    echo '<table class="table table-responsive-sm table-hover table-outline mb-0">';
    echo '
								<thead class="thead-light">
								<tr >
									<th colspan = 5 class="text-center">'.$titre.'</th>
								</tr><tr >
									<th>'.$lang['th_table_14'].'</th>
									<th>'.$lang['th_table_18'].'</th>
									<th>'.$lang['th_table_15'].'</th>
									<th>'.$lang['th_table_16'].'</th>
									<th>'.$lang['th_table_17'].'</th>
								</tr>
								<tr>
									<td>'.$lang['th_table_35'].'</td>
									<td>'.$nb_gab.'</td>
									<td>'.$duree_globlal.'</td>
									<td>'.$duree.'</td>
									<td>'.round($dispo,2).' %</td>
								</tr>
								</thead>	';




    ////////////////////// par ville
    $sql = "SELECT  `id_filiale`, `nom_filiale` FROM `new_filiale` ORDER BY `new_filiale`.`nom_filiale` ASC";
    $link = ma_db_connexion();
    if ($result=mysqli_query($link,$sql))
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $nb_gab_ville=get_nb_gab_service($row["id_filiale"],$champs_service);
                $list_gab_ville=get_liste_gab_ville_inclus_taux($row["id_filiale"],$champs_service);
                foreach ($list_gab_ville AS $id_gab)
                {
                    // if($champs_service=="id_activ_depot_argent"){echo $row["id_filiale"]." - ".$id_gab."<br>";}
                }

                $duree_globlal_ville=$nb_gab_ville*$nb_jour_mois*1440;
                $duree_ville=getTauxIndispoMotif2($date_courant,$date_fin,$motif_inclus,$list_gab_ville,$categorie,$id_filiales,$type_gab,$type_gestionnaire);
                $taux_indispo_dispo_ville=getverifTaux1($duree_ville,$duree_globlal_ville);
                $dispo_ville=round(100-$taux_indispo_dispo_ville,2,PHP_ROUND_HALF_DOWN);


                echo '<tr>
									<td>'.$row["nom_filiale"].'</td>
									<td>'.$nb_gab_ville.'</td>
									<td>'.$duree_globlal_ville.'</td>
									<td>'.$duree_ville.'</td>
									<td>'.round($dispo_ville,2).' %</td>
								</tr>';

            }
        }
    }

    mysqli_free_result($result);
    mysqli_close($link);





    echo '</table>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function affichageInformationDeppasementSLA4($date_courant,$date_fin,$nb_gab,$nb_jour_mois,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab,$motif,$libelle,$lang)
{



    $duree_total=$nb_gab*$nb_jour_mois*1440;
    $nbr_intervention=getNBRIntervention($date_courant,$date_fin,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab,$motif);
    $moy_intervention=getMoyIntervention($date_courant,$date_fin,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab,$motif,1);
    // $moy_delai_intervention=getMoyIntervention($date_courant,$date_fin,$list_gab,$motif,'');
    echo '<table class="table table-responsive-sm table-hover table-outline mb-0">
												<thead class="thead-light">
													<tr>					
													<th colspan=11 class="text-center">'.$lang['th_table_36'].' '.$libelle.'</th>	
													</tr>													
												<tr>
													<th rowspan=2>#</th>							
													<th colspan=10></th>									
												</tr>
												<tr>
													<th>'.$lang['th_table_26'].'</th>
													<th>'.$lang['th_table_27'].'</th>
													<th>'.$lang['th_table_28'].'</th>
													<th>'.$lang['th_table_29'].'</th>
													<th>'.$lang['th_table_30'].'</th>													
													
													<th>'.$lang['th_table_31'].'</th>
													
													<th>'.$lang['th_table_32'].'</th>
												</tr>
												</thead>';

    // total_duree_moyenne_sla_G4S
    // echo "<br>MORSLI : ".get_duree_minute_sla(2).'---'.$nbr_intervention[11]."<br>";
    if($nbr_intervention[11]<>0)
    {
        $total_duree_moyenne_sla_G4S=get_duree_minute_sla(2)*$nbr_intervention[11];
        $total_duree_arret_contactuelle_G4S=round(($nbr_intervention[25]/60),0);
        $duree_moyenne_déppassement_G4S=round((($total_duree_arret_contactuelle_G4S-$total_duree_moyenne_sla_G4S)/$total_duree_moyenne_sla_G4S)*100,0);
        $delai_moyenne_déppassement_G4S=$duree_moyenne_déppassement_G4S+$total_duree_moyenne_sla_G4S;
        $taux_nn_deppass_G4S=round(((($nbr_intervention[31]-$nbr_intervention[11])/$nbr_intervention[31])*100),2);
        $taux_deppass_G4S=round((($nbr_intervention[11]/$nbr_intervention[31])*100),2);

        $moy_moyenne_deppassement_G4S=round((($nbr_intervention[25]/$nbr_intervention[11])/60),0);
        $moy_moyenne_intevention_deppassement_G4S=round((($nbr_intervention[19]/$nbr_intervention[11])/60),0);

        echo '<tr><td>G4S  </td>
													<td>'.$nbr_intervention[31].'</td>
													<td>'.$nbr_intervention[11].'</td>
													<td>'.$taux_nn_deppass_G4S.'%</td>
													<td>'.$taux_deppass_G4S.'%</td>
													';
        // echo '<td>'.round($moy_intervention[6]/60,0).' / '.$duree_moyenne_déppassement_G4S.' </td><td>'.transforme($duree_moyenne_déppassement_G4S).' </td>';
        echo '<td>'.transforme($moy_moyenne_deppassement_G4S*60).' </td>';
        echo '
													
													<td>'.transforme($total_duree_arret_contactuelle_G4S*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_G4S/$duree_total*100),2).'%</td></tr>';
    }


    if($nbr_intervention[12]<>0)
    {
        $total_duree_moyenne_sla_Logistique=get_duree_minute_sla(3)*$nbr_intervention[12];
        $total_duree_arret_contactuelle_Logistique=round(($nbr_intervention[26]/60),0);
        $duree_moyenne_déppassement_Logistique=round((($total_duree_arret_contactuelle_Logistique-$total_duree_moyenne_sla_Logistique)/$total_duree_moyenne_sla_Logistique)*100,0);
        $delai_moyenne_déppassement_Logistique=$duree_moyenne_déppassement_Logistique+$total_duree_moyenne_sla_Logistique;
        $taux_nn_deppass_Logistique=round(((($nbr_intervention[32]-$nbr_intervention[12])/$nbr_intervention[32])*100),2);
        $taux_deppass_Logistique=round((($nbr_intervention[12]/$nbr_intervention[32])*100),2);

        $moy_moyenne_deppassement_Logistique=round((($nbr_intervention[26]/$nbr_intervention[12])/60),0);
        $moy_moyenne_intevention_deppassement_Logistique=round((($nbr_intervention[20]/$nbr_intervention[12])/60),0);

        echo '<tr><td>Logistique  </td>
													<td>'.$nbr_intervention[32].' </td>
													<td>'.$nbr_intervention[12].' </td>
													<td>'.$taux_nn_deppass_Logistique.'%</td>
													<td>'.$taux_deppass_Logistique.'%</td>
													
													<td>'.transforme($moy_moyenne_deppassement_Logistique*60).' </td>
													
													<td>'.transforme($total_duree_arret_contactuelle_Logistique*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_Logistique/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[13]<>0)
    {

        $total_duree_moyenne_sla_NCR=get_duree_minute_sla(6)*$nbr_intervention[13];
        $total_duree_arret_contactuelle_NCR=round(($nbr_intervention[27]/60),0);
        $duree_moyenne_déppassement_NCR=round((($total_duree_arret_contactuelle_NCR-$total_duree_moyenne_sla_NCR)/$total_duree_moyenne_sla_NCR)*100,0);
        $delai_moyenne_déppassement_NCR=$duree_moyenne_déppassement_NCR+$total_duree_moyenne_sla_NCR;
        $taux_nn_deppass_NCR=round(((($nbr_intervention[33]-$nbr_intervention[13])/$nbr_intervention[33])*100),2);
        $taux_deppass_NCR=round((($nbr_intervention[13]/$nbr_intervention[33])*100),2);

        $moy_moyenne_deppassement_NCR=round((($nbr_intervention[27]/$nbr_intervention[13])/60),0);
        $moy_moyenne_intevention_deppassement_NCR=round((($nbr_intervention[21]/$nbr_intervention[13])/60),0);

        echo '<tr><td>NCR  </td><td>'.$nbr_intervention[33].' </td><td>'.$nbr_intervention[13].' </td><td>'.$taux_nn_deppass_NCR.'%</td><td>'.$taux_deppass_NCR.'%</td>
													
													<td>'.transforme($moy_moyenne_deppassement_NCR*60).' </td>
													
													<td>'.transforme($total_duree_arret_contactuelle_NCR*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_NCR/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[14]<>0)
    {
        $total_duree_moyenne_sla_TELECOM=get_duree_minute_sla(8)*$nbr_intervention[14];
        $total_duree_arret_contactuelle_TELECOM=round(($nbr_intervention[28]/60),0);
        $duree_moyenne_déppassement_TELECOM=round((($total_duree_arret_contactuelle_TELECOM-$total_duree_moyenne_sla_TELECOM)/$total_duree_moyenne_sla_TELECOM)*100,0);
        $delai_moyenne_déppassement_TELECOM=$duree_moyenne_déppassement_TELECOM+$total_duree_moyenne_sla_TELECOM;
        $taux_nn_deppass_TELECOM=round(((($nbr_intervention[34]-$nbr_intervention[14])/$nbr_intervention[34])*100),2);
        $taux_deppass_TELECOM=round((($nbr_intervention[14]/$nbr_intervention[34])*100),2);

        $moy_moyenne_deppassement_TELECOM=round((($nbr_intervention[28]/$nbr_intervention[14])/60),0);
        $moy_moyenne_intevention_deppassement_TELECOM=round((($nbr_intervention[22]/$nbr_intervention[14])/60),0);

        echo '<tr><td>TELECOM  </td><td>'.$nbr_intervention[34].' </td><td>'.$nbr_intervention[14].' </td><td>'.$taux_nn_deppass_TELECOM.'%</td><td>'.$taux_deppass_TELECOM.'%</td>													
													
													<td>'.transforme($moy_moyenne_deppassement_TELECOM*60).' </td>
													
													<td>'.transforme($total_duree_arret_contactuelle_TELECOM*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_TELECOM/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[15]<>0)
    {
        $total_duree_moyenne_sla_Monetique=get_duree_minute_sla(9)*$nbr_intervention[15];
        $total_duree_arret_contactuelle_Monetique=round(($nbr_intervention[29]/60),0);
        $duree_moyenne_déppassement_Monetique=round((($total_duree_arret_contactuelle_Monetique-$total_duree_moyenne_sla_Monetique)/$total_duree_moyenne_sla_Monetique)*100,0);
        $delai_moyenne_déppassement_Monetique=$duree_moyenne_déppassement_Monetique+$total_duree_moyenne_sla_Monetique;
        $taux_nn_deppass_Monetique=round(((($nbr_intervention[35]-$nbr_intervention[15])/$nbr_intervention[35])*100),2);
        $taux_deppass_Monetique=round((($nbr_intervention[15]/$nbr_intervention[35])*100),2);

        $moy_moyenne_deppassement_Monetique=round((($nbr_intervention[29]/$nbr_intervention[15])/60),0);
        $moy_moyenne_intevention_deppassement_Monetique=round((($nbr_intervention[23]/$nbr_intervention[15])/60),0);

        echo '<tr><td>Monétique  </td><td>'.$nbr_intervention[35].' </td><td>'.$nbr_intervention[15].' </td><td>'.$taux_nn_deppass_Monetique.'%</td><td>'.$taux_deppass_Monetique.'%</td>
													
													
													<td>'.transforme($moy_moyenne_deppassement_Monetique*60).' </td>
													
													<td>'.transforme($total_duree_arret_contactuelle_Monetique*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_Monetique/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[16]<>0)
    {
        $total_duree_moyenne_sla_S2M=get_duree_minute_sla(10)*$nbr_intervention[16];
        $total_duree_arret_contactuelle_S2M=round(($nbr_intervention[30]/60),0);
        $duree_moyenne_déppassement_S2M=round((($total_duree_arret_contactuelle_S2M-$total_duree_moyenne_sla_S2M)/$total_duree_moyenne_sla_S2M)*100,0);
        $delai_moyenne_déppassement_S2M=$duree_moyenne_déppassement_S2M+$total_duree_moyenne_sla_S2M;
        $taux_nn_deppass_S2M=round(((($nbr_intervention[36]-$nbr_intervention[16])/$nbr_intervention[36])*100),2);
        $taux_deppass_S2M=round((($nbr_intervention[16]/$nbr_intervention[36])*100),2);

        $moy_moyenne_deppassement_S2M=round((($nbr_intervention[30]/$nbr_intervention[16])/60),0);
        $moy_moyenne_intevention_deppassement_S2M=round((($nbr_intervention[24]/$nbr_intervention[16])/60),0);

        echo '<tr><td>S2M  </td><td>'.$nbr_intervention[36].' </td><td>'.$nbr_intervention[16].' </td><td>'.$taux_nn_deppass_S2M.'%</td><td>'.$taux_deppass_S2M.'%</td>
													
													
													<td>'.transforme($moy_moyenne_deppassement_S2M*60).' </td>
													
													<td>'.transforme($total_duree_arret_contactuelle_S2M*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_S2M/$duree_total*100),2).'%</td></tr>';
    }

    // echo '<tr><td>Total  </td><td>'.$nbr_intervention[31].'</td><td>'.$nbr_intervention[2].' </td><td></td><td></td><td></td><td></td><td></td><td></td><td>'.round($nbr_intervention[18]/60,0).' </td><td></td><td>'.$duree_total.' </td><td> </td><td> </td><td>'.round((round($nbr_intervention[18]/60,0)/$duree_total*100),2).'%</td></tr>';

    echo '</table>';

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function affichageInformationDeppasementSLA3($date_courant,$date_fin,$nb_gab,$nb_jour_mois,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab,$motif,$libelle)
{



    $duree_total=$nb_gab*$nb_jour_mois*1440;
    $nbr_intervention=getNBRIntervention($date_courant,$date_fin,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab,$motif);
    $moy_intervention=getMoyIntervention($date_courant,$date_fin,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab,$motif,1);
    // $moy_delai_intervention=getMoyIntervention($date_courant,$date_fin,$list_gab,$motif,'');
    echo '<table class="table table-responsive-sm table-hover table-outline mb-0">
												<thead class="thead-light">
													<tr>					
													<th colspan=15 class="text-center">Dépassement SLA '.$libelle.'</th>	
													</tr>													
												<tr>
													<th rowspan=2>#</th>							
													<th colspan=14></th>									
												</tr>
												<tr>
													<th>NBR d\'intrevention total</th>
													<th>NBR d\'intrevention de déppassement</th>
													<th>Taux d\'intrevention non déppassement</th>
													<th>Taux d\'intrevention de déppassement</th>
													<th>Durée SLA</th>
													<th>Durée SLA (Format)</th>
													<th>Durée moyenne de déppassement</th>
													<th>Durée moyenne de déppassement (Format)</th>	
													
													<th>Durée d\'intevention de déppassement </th>
													<th>Durée d\'intevention de déppassement (Format)</th>
													<th>Durée total</th>
													<th>Taux d\'indisponibilité</th>
												</tr>
												
												
												
												</thead>';

    // total_duree_moyenne_sla_G4S
    // echo "<br>MORSLI : ".get_duree_minute_sla(2).'---'.$nbr_intervention[11]."<br>";
    if($nbr_intervention[11]<>0)
    {
        $total_duree_moyenne_sla_G4S=get_duree_minute_sla(2)*$nbr_intervention[11];
        $total_duree_arret_contactuelle_G4S=round(($nbr_intervention[25]/60),0);
        $duree_moyenne_déppassement_G4S=round((($total_duree_arret_contactuelle_G4S-$total_duree_moyenne_sla_G4S)/$total_duree_moyenne_sla_G4S)*100,0);
        $delai_moyenne_déppassement_G4S=$duree_moyenne_déppassement_G4S+$total_duree_moyenne_sla_G4S;
        $taux_nn_deppass_G4S=round(((($nbr_intervention[31]-$nbr_intervention[11])/$nbr_intervention[31])*100),2);
        $taux_deppass_G4S=round((($nbr_intervention[11]/$nbr_intervention[31])*100),2);

        $moy_moyenne_deppassement_G4S=round((($nbr_intervention[25]/$nbr_intervention[11])/60),0);
        $moy_moyenne_intevention_deppassement_G4S=round((($nbr_intervention[19]/$nbr_intervention[11])/60),0);

        echo '<tr><td>G4S  </td><td>'.$nbr_intervention[31].'</td><td>'.$nbr_intervention[11].'</td><td>'.$taux_nn_deppass_G4S.'%</td><td>'.$taux_deppass_G4S.'%</td>
													<td>'.get_duree_minute_sla(2).'</td><td>'.get_duree_sla_format(2).'</td>';
        // echo '<td>'.round($moy_intervention[6]/60,0).' / '.$duree_moyenne_déppassement_G4S.' </td><td>'.transforme($duree_moyenne_déppassement_G4S).' </td>';
        echo '<td>'.$moy_moyenne_deppassement_G4S.'</td><td>'.transforme($moy_moyenne_deppassement_G4S*60).' </td>';
        echo '
													<td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_G4S.' </td><td>'.transforme($total_duree_arret_contactuelle_G4S*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_G4S/$duree_total*100),2).'%</td></tr>';
    }


    if($nbr_intervention[12]<>0)
    {
        $total_duree_moyenne_sla_Logistique=get_duree_minute_sla(3)*$nbr_intervention[12];
        $total_duree_arret_contactuelle_Logistique=round(($nbr_intervention[26]/60),0);
        $duree_moyenne_déppassement_Logistique=round((($total_duree_arret_contactuelle_Logistique-$total_duree_moyenne_sla_Logistique)/$total_duree_moyenne_sla_Logistique)*100,0);
        $delai_moyenne_déppassement_Logistique=$duree_moyenne_déppassement_Logistique+$total_duree_moyenne_sla_Logistique;
        $taux_nn_deppass_Logistique=round(((($nbr_intervention[32]-$nbr_intervention[12])/$nbr_intervention[32])*100),2);
        $taux_deppass_Logistique=round((($nbr_intervention[12]/$nbr_intervention[32])*100),2);

        $moy_moyenne_deppassement_Logistique=round((($nbr_intervention[26]/$nbr_intervention[12])/60),0);
        $moy_moyenne_intevention_deppassement_Logistique=round((($nbr_intervention[20]/$nbr_intervention[12])/60),0);

        echo '<tr><td>Logistique  </td>
													<td>'.$nbr_intervention[32].' </td>
													<td>'.$nbr_intervention[12].' </td>
													<td>'.$taux_nn_deppass_Logistique.'%</td>
													<td>'.$taux_deppass_Logistique.'%</td>
													<td>'.get_duree_minute_sla(3).'</td>
													<td>'.get_duree_sla_format(3).'</td>
													<td>'.$moy_moyenne_deppassement_Logistique.' </td>
													<td>'.transforme($moy_moyenne_deppassement_Logistique*60).' </td>
													<td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_Logistique.' </td><td>'.transforme($total_duree_arret_contactuelle_Logistique*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_Logistique/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[13]<>0)
    {

        $total_duree_moyenne_sla_NCR=get_duree_minute_sla(6)*$nbr_intervention[13];
        $total_duree_arret_contactuelle_NCR=round(($nbr_intervention[27]/60),0);
        $duree_moyenne_déppassement_NCR=round((($total_duree_arret_contactuelle_NCR-$total_duree_moyenne_sla_NCR)/$total_duree_moyenne_sla_NCR)*100,0);
        $delai_moyenne_déppassement_NCR=$duree_moyenne_déppassement_NCR+$total_duree_moyenne_sla_NCR;
        $taux_nn_deppass_NCR=round(((($nbr_intervention[33]-$nbr_intervention[13])/$nbr_intervention[33])*100),2);
        $taux_deppass_NCR=round((($nbr_intervention[13]/$nbr_intervention[33])*100),2);

        $moy_moyenne_deppassement_NCR=round((($nbr_intervention[27]/$nbr_intervention[13])/60),0);
        $moy_moyenne_intevention_deppassement_NCR=round((($nbr_intervention[21]/$nbr_intervention[13])/60),0);

        echo '<tr><td>NCR  </td><td>'.$nbr_intervention[33].' </td><td>'.$nbr_intervention[13].' </td><td>'.$taux_nn_deppass_NCR.'%</td><td>'.$taux_deppass_NCR.'%</td>
													<td>'.get_duree_minute_sla(6).'</td><td>'.get_duree_sla_format(6).'</td>
													<td>'.$moy_moyenne_deppassement_NCR.' </td><td>'.transforme($moy_moyenne_deppassement_NCR*60).' </td>
													<td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_NCR.' </td><td>'.transforme($total_duree_arret_contactuelle_NCR*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_NCR/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[14]<>0)
    {
        $total_duree_moyenne_sla_TELECOM=get_duree_minute_sla(8)*$nbr_intervention[14];
        $total_duree_arret_contactuelle_TELECOM=round(($nbr_intervention[28]/60),0);
        $duree_moyenne_déppassement_TELECOM=round((($total_duree_arret_contactuelle_TELECOM-$total_duree_moyenne_sla_TELECOM)/$total_duree_moyenne_sla_TELECOM)*100,0);
        $delai_moyenne_déppassement_TELECOM=$duree_moyenne_déppassement_TELECOM+$total_duree_moyenne_sla_TELECOM;
        $taux_nn_deppass_TELECOM=round(((($nbr_intervention[34]-$nbr_intervention[14])/$nbr_intervention[34])*100),2);
        $taux_deppass_TELECOM=round((($nbr_intervention[14]/$nbr_intervention[34])*100),2);

        $moy_moyenne_deppassement_TELECOM=round((($nbr_intervention[28]/$nbr_intervention[14])/60),0);
        $moy_moyenne_intevention_deppassement_TELECOM=round((($nbr_intervention[22]/$nbr_intervention[14])/60),0);

        echo '<tr><td>TELECOM  </td><td>'.$nbr_intervention[34].' </td><td>'.$nbr_intervention[14].' </td><td>'.$taux_nn_deppass_TELECOM.'%</td><td>'.$taux_deppass_TELECOM.'%</td>													
													<td>'.get_duree_minute_sla(8).'</td><td>'.get_duree_sla_format(8).'</td>
													<td>'.$moy_moyenne_deppassement_TELECOM.' </td><td>'.transforme($moy_moyenne_deppassement_TELECOM*60).' </td>
													<td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_TELECOM.' </td><td>'.transforme($total_duree_arret_contactuelle_TELECOM*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_TELECOM/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[15]<>0)
    {
        $total_duree_moyenne_sla_Monetique=get_duree_minute_sla(9)*$nbr_intervention[15];
        $total_duree_arret_contactuelle_Monetique=round(($nbr_intervention[29]/60),0);
        $duree_moyenne_déppassement_Monetique=round((($total_duree_arret_contactuelle_Monetique-$total_duree_moyenne_sla_Monetique)/$total_duree_moyenne_sla_Monetique)*100,0);
        $delai_moyenne_déppassement_Monetique=$duree_moyenne_déppassement_Monetique+$total_duree_moyenne_sla_Monetique;
        $taux_nn_deppass_Monetique=round(((($nbr_intervention[35]-$nbr_intervention[15])/$nbr_intervention[35])*100),2);
        $taux_deppass_Monetique=round((($nbr_intervention[15]/$nbr_intervention[35])*100),2);

        $moy_moyenne_deppassement_Monetique=round((($nbr_intervention[29]/$nbr_intervention[15])/60),0);
        $moy_moyenne_intevention_deppassement_Monetique=round((($nbr_intervention[23]/$nbr_intervention[15])/60),0);

        echo '<tr><td>Monétique  </td><td>'.$nbr_intervention[35].' </td><td>'.$nbr_intervention[15].' </td><td>'.$taux_nn_deppass_Monetique.'%</td><td>'.$taux_deppass_Monetique.'%</td>
													<td>'.get_duree_minute_sla(9).'</td><td>'.get_duree_sla_format(9).'</td>
													<td>'.$moy_moyenne_deppassement_Monetique.' </td>
													<td>'.transforme($moy_moyenne_deppassement_Monetique*60).' </td>
													<td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_Monetique.' </td><td>'.transforme($total_duree_arret_contactuelle_Monetique*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_Monetique/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[16]<>0)
    {
        $total_duree_moyenne_sla_S2M=get_duree_minute_sla(10)*$nbr_intervention[16];
        $total_duree_arret_contactuelle_S2M=round(($nbr_intervention[30]/60),0);
        $duree_moyenne_déppassement_S2M=round((($total_duree_arret_contactuelle_S2M-$total_duree_moyenne_sla_S2M)/$total_duree_moyenne_sla_S2M)*100,0);
        $delai_moyenne_déppassement_S2M=$duree_moyenne_déppassement_S2M+$total_duree_moyenne_sla_S2M;
        $taux_nn_deppass_S2M=round(((($nbr_intervention[36]-$nbr_intervention[16])/$nbr_intervention[36])*100),2);
        $taux_deppass_S2M=round((($nbr_intervention[16]/$nbr_intervention[36])*100),2);

        $moy_moyenne_deppassement_S2M=round((($nbr_intervention[30]/$nbr_intervention[16])/60),0);
        $moy_moyenne_intevention_deppassement_S2M=round((($nbr_intervention[24]/$nbr_intervention[16])/60),0);

        echo '<tr><td>S2M  </td><td>'.$nbr_intervention[36].' </td><td>'.$nbr_intervention[16].' </td><td>'.$taux_nn_deppass_S2M.'%</td><td>'.$taux_deppass_S2M.'%</td>
													<td>'.get_duree_minute_sla(10).'</td><td>'.get_duree_sla_format(10).'</td>
													<td>'.$moy_moyenne_deppassement_S2M.' </td>
													<td>'.transforme($moy_moyenne_deppassement_S2M*60).' </td>
													<td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_S2M.' </td><td>'.transforme($total_duree_arret_contactuelle_S2M*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_S2M/$duree_total*100),2).'%</td></tr>';
    }

    // echo '<tr><td>Total  </td><td>'.$nbr_intervention[31].'</td><td>'.$nbr_intervention[2].' </td><td></td><td></td><td></td><td></td><td></td><td></td><td>'.round($nbr_intervention[18]/60,0).' </td><td></td><td>'.$duree_total.' </td><td> </td><td> </td><td>'.round((round($nbr_intervention[18]/60,0)/$duree_total*100),2).'%</td></tr>';

    echo '</table>';

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function affichageInformationDeppasementSLA($date_courant,$date_fin,$nb_gab,$nb_jour_mois,$list_gab,$motif,$libelle)
{

    // $total_duree_deppassement_reel17,$total_duree_deppassement_cont,
    // $duree_deppassent_G4S_reel,$duree_deppassent_Logistique_reel,$duree_deppassent_NCR_reel,$duree_deppassent_TELECOM_reel,$duree_deppassent_Monetique_reel,$duree_deppassent_S2M_reel,
    // $duree_deppassent_G4S_cont,$duree_deppassent_Logistique_cont,$duree_deppassent_NCR_cont,$duree_deppassent_TELECOM_cont,$duree_deppassent_Monetique_cont,$duree_deppassent_S2M_cont);


    // </thead>
    // <tr><td>G4S  </td><td>'.$nbr_intervention[4].' </td><td>'.round((round($nbr_intervention[19]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[11].' </td><td>'.round((round($nbr_intervention[25]/60,0)/$duree_total*100),2).'%</td></tr>
    // <tr><td>Logistique  </td><td>'.$nbr_intervention[5].' </td><td>'.round((round($nbr_intervention[20]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[12].' </td><td>'.round((round($nbr_intervention[26]/60,0)/$duree_total*100),2).'%</td></tr>
    // <tr><td>NCR  </td><td>'.$nbr_intervention[6].' </td><td>'.round((round($nbr_intervention[21]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[13].' </td><td>'.round((round($nbr_intervention[27]/60,0)/$duree_total*100),2).'%</td></tr>
    // <tr><td>TELECOM  </td><td>'.$nbr_intervention[7].' </td><td>'.round((round($nbr_intervention[22]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[14].' </td><td>'.round((round($nbr_intervention[28]/60,0)/$duree_total*100),2).'%</td></tr>
    // <tr><td>Monétique  </td><td>'.$nbr_intervention[8].' </td><td>'.round((round($nbr_intervention[23]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[15].' </td><td>'.round((round($nbr_intervention[29]/60,0)/$duree_total*100),2).'%</td></tr>
    // <tr><td>S2M  </td><td>'.$nbr_intervention[9].' </td><td>'.round((round($nbr_intervention[24]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[16].' </td><td>'.round((round($nbr_intervention[30]/60,0)/$duree_total*100),2).'%</td></tr>
    // <tr><td>Total  </td><td>'.$nbr_intervention[1].' </td><td>'.round((round($nbr_intervention[17]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[2].' </td><td>'.round((round($nbr_intervention[18]/60,0)/$duree_total*100),2).'%</td></tr>
    // </table>




    $duree_total=$nb_gab*$nb_jour_mois*1440;
    $nbr_intervention=getNBRIntervention($date_courant,$date_fin,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab,$motif);
    $moy_intervention=getMoyIntervention($date_courant,$date_fin,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab,$motif,1);
    // $moy_delai_intervention=getMoyIntervention($date_courant,$date_fin,$list_gab,$motif,'');
    echo '<table class="table table-responsive-sm table-hover table-outline mb-0">
												<thead class="thead-light">
													<tr>					
													<th colspan=15 class="text-center">Dépassement SLA '.$libelle.'</th>	
													</tr>													
												<tr>
													<th rowspan=2>#</th>							
													<th colspan=14></th>									
												</tr>
												<tr>
													<th>NBR d\'intrevention total</th>
													<th>NBR d\'intrevention de déppassement</th>
													<th>Taux d\'intrevention non déppassement</th>
													<th>Taux d\'intrevention de déppassement</th>
													<th>Durée SLA</th>
													<th>Durée SLA (Format)</th>
													<th>Durée moyenne de déppassement</th>
													<th>Durée moyenne de déppassement (Format)</th>													
													<th>Délai moyenne d\'intevention de déppassement</th>
													<th>Délai moyenne d\'intevention de déppassement (Format)</th>
													<th>Durée d\'intevention de déppassement </th>
													<th>Durée d\'intevention de déppassement (Format)</th>
													<th>Durée total</th>
													<th>Taux d\'indisponibilité</th>
												</tr>
												</thead>';
    // total_duree_moyenne_sla_G4S
    // echo "<br>MORSLI : ".get_duree_minute_sla(2).'---'.$nbr_intervention[11]."<br>";
    if($nbr_intervention[11]<>0)
    {
        $total_duree_moyenne_sla_G4S=get_duree_minute_sla(2)*$nbr_intervention[11];

        if($total_duree_moyenne_sla_G4S<>0){$div_duree_moyenne_G4S=(($total_duree_arret_contactuelle_G4S-$total_duree_moyenne_sla_G4S)/$total_duree_moyenne_sla_G4S);}
        else{$div_duree_moyenne_G4S=0;}

        if($nbr_intervention[11]<>0){
            $taux_non_deppass_G4S=(($nbr_intervention[31]-$nbr_intervention[11])/$nbr_intervention[31]);
            $my_moyenne_deppassement_G4S=($nbr_intervention[25]/$nbr_intervention[11]);
            $my_moyenne_intevention_deppassement_G4S=($nbr_intervention[19]/$nbr_intervention[11]);

        }
        else{$taux_non_deppass_G4S=0;$my_moyenne_deppassement_G4S=0;$my_moyenne_intevention_deppassement_G4S=0;}

        if($nbr_intervention[31]<>0){$tx_deppass_G4S=($nbr_intervention[11]/$nbr_intervention[31]);}
        else{$tx_deppass_G4S=0;}

        $total_duree_arret_contactuelle_G4S=round(($nbr_intervention[25]/60),0);
        $duree_moyenne_déppassement_G4S=round($div_duree_moyenne_G4S*100,0);
        $delai_moyenne_déppassement_G4S=$duree_moyenne_déppassement_G4S+$total_duree_moyenne_sla_G4S;
        $taux_nn_deppass_G4S=round($taux_non_deppass_G4S,2);
        $taux_deppass_G4S=round(($tx_deppass_G4S*100),2);

        $moy_moyenne_deppassement_G4S=round(($my_moyenne_deppassement_G4S/60),0);
        $moy_moyenne_intevention_deppassement_G4S=round(($my_moyenne_intevention_deppassement_G4S/60),0);

        echo '<tr><td>G4S  </td><td>'.$nbr_intervention[31].'</td><td>'.$nbr_intervention[11].'</td><td>'.$taux_nn_deppass_G4S.'%</td><td>'.$taux_deppass_G4S.'%</td>
													<td>'.get_duree_minute_sla(2).'</td><td>'.get_duree_sla_format(2).'</td>';
        // echo '<td>'.round($moy_intervention[6]/60,0).' / '.$duree_moyenne_déppassement_G4S.' </td><td>'.transforme($duree_moyenne_déppassement_G4S).' </td>';
        echo '<td>'.$moy_moyenne_deppassement_G4S.'</td><td>'.transforme($moy_moyenne_deppassement_G4S*60).' </td>';
        echo '<td>'.$moy_moyenne_intevention_deppassement_G4S.' </td><td>'.transforme($moy_moyenne_intevention_deppassement_G4S*60).'</td><td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_G4S.' </td><td>'.transforme($total_duree_arret_contactuelle_G4S*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_G4S/$duree_total*100),2).'%</td></tr>';
    }


    if($nbr_intervention[12]<>0)
    {
        $total_duree_moyenne_sla_Logistique=get_duree_minute_sla(3)*$nbr_intervention[12];
        $total_duree_arret_contactuelle_Logistique=round(($nbr_intervention[26]/60),0);
        $duree_moyenne_déppassement_Logistique=round((($total_duree_arret_contactuelle_Logistique-$total_duree_moyenne_sla_Logistique)/$total_duree_moyenne_sla_Logistique)*100,0);
        $delai_moyenne_déppassement_Logistique=$duree_moyenne_déppassement_Logistique+$total_duree_moyenne_sla_Logistique;
        $taux_nn_deppass_Logistique=round(((($nbr_intervention[32]-$nbr_intervention[12])/$nbr_intervention[32])*100),2);
        $taux_deppass_Logistique=round((($nbr_intervention[12]/$nbr_intervention[32])*100),2);

        $moy_moyenne_deppassement_Logistique=round((($nbr_intervention[26]/$nbr_intervention[12])/60),0);
        $moy_moyenne_intevention_deppassement_Logistique=round((($nbr_intervention[20]/$nbr_intervention[12])/60),0);

        echo '<tr><td>Logistique  </td><td>'.$nbr_intervention[32].' </td><td>'.$nbr_intervention[12].' </td><td>'.$taux_nn_deppass_Logistique.'%</td><td>'.$taux_deppass_Logistique.'%</td>
													<td>'.get_duree_minute_sla(3).'</td><td>'.get_duree_sla_format(3).'</td>
													<td>'.$moy_moyenne_deppassement_Logistique.' </td><td>'.transforme($moy_moyenne_deppassement_Logistique*60).' </td>
													<td>'.$moy_moyenne_intevention_deppassement_Logistique.' </td><td>'.transforme($moy_moyenne_intevention_deppassement_Logistique*60).'</td><td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_Logistique.' </td><td>'.transforme($total_duree_arret_contactuelle_Logistique*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_Logistique/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[13]<>0)
    {

        $total_duree_moyenne_sla_NCR=get_duree_minute_sla(6)*$nbr_intervention[13];
        $total_duree_arret_contactuelle_NCR=round(($nbr_intervention[27]/60),0);
        $duree_moyenne_déppassement_NCR=round((($total_duree_arret_contactuelle_NCR-$total_duree_moyenne_sla_NCR)/$total_duree_moyenne_sla_NCR)*100,0);
        $delai_moyenne_déppassement_NCR=$duree_moyenne_déppassement_NCR+$total_duree_moyenne_sla_NCR;
        $taux_nn_deppass_NCR=round(((($nbr_intervention[33]-$nbr_intervention[13])/$nbr_intervention[33])*100),2);
        $taux_deppass_NCR=round((($nbr_intervention[13]/$nbr_intervention[33])*100),2);

        $moy_moyenne_deppassement_NCR=round((($nbr_intervention[27]/$nbr_intervention[13])/60),0);
        $moy_moyenne_intevention_deppassement_NCR=round((($nbr_intervention[21]/$nbr_intervention[13])/60),0);

        echo '<tr><td>NCR  </td><td>'.$nbr_intervention[33].' </td><td>'.$nbr_intervention[13].' </td><td>'.$taux_nn_deppass_NCR.'%</td><td>'.$taux_deppass_NCR.'%</td>
													<td>'.get_duree_minute_sla(6).'</td><td>'.get_duree_sla_format(6).'</td>
													<td>'.$moy_moyenne_deppassement_NCR.' </td><td>'.transforme($moy_moyenne_deppassement_NCR*60).' </td>
													<td>'.$moy_moyenne_intevention_deppassement_NCR.' </td><td>'.transforme($moy_moyenne_intevention_deppassement_NCR*60).'</td><td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_NCR.' </td><td>'.transforme($total_duree_arret_contactuelle_NCR*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_NCR/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[14]<>0)
    {
        $total_duree_moyenne_sla_TELECOM=get_duree_minute_sla(8)*$nbr_intervention[14];
        $total_duree_arret_contactuelle_TELECOM=round(($nbr_intervention[28]/60),0);
        $duree_moyenne_déppassement_TELECOM=round((($total_duree_arret_contactuelle_TELECOM-$total_duree_moyenne_sla_TELECOM)/$total_duree_moyenne_sla_TELECOM)*100,0);
        $delai_moyenne_déppassement_TELECOM=$duree_moyenne_déppassement_TELECOM+$total_duree_moyenne_sla_TELECOM;
        $taux_nn_deppass_TELECOM=round(((($nbr_intervention[34]-$nbr_intervention[14])/$nbr_intervention[34])*100),2);
        $taux_deppass_TELECOM=round((($nbr_intervention[14]/$nbr_intervention[34])*100),2);

        $moy_moyenne_deppassement_TELECOM=round((($nbr_intervention[28]/$nbr_intervention[14])/60),0);
        $moy_moyenne_intevention_deppassement_TELECOM=round((($nbr_intervention[22]/$nbr_intervention[14])/60),0);

        echo '<tr><td>TELECOM  </td><td>'.$nbr_intervention[34].' </td><td>'.$nbr_intervention[14].' </td><td>'.$taux_nn_deppass_TELECOM.'%</td><td>'.$taux_deppass_TELECOM.'%</td>													
													<td>'.get_duree_minute_sla(8).'</td><td>'.get_duree_sla_format(8).'</td>
													<td>'.$moy_moyenne_deppassement_TELECOM.' </td><td>'.transforme($moy_moyenne_deppassement_TELECOM*60).' </td>
													<td>'.$moy_moyenne_intevention_deppassement_TELECOM.' </td><td>'.transforme($moy_moyenne_intevention_deppassement_TELECOM).'</td><td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_TELECOM.' </td><td>'.transforme($total_duree_arret_contactuelle_TELECOM*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_TELECOM/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[15]<>0)
    {
        $total_duree_moyenne_sla_Monetique=get_duree_minute_sla(9)*$nbr_intervention[15];
        $total_duree_arret_contactuelle_Monetique=round(($nbr_intervention[29]/60),0);
        $duree_moyenne_déppassement_Monetique=round((($total_duree_arret_contactuelle_Monetique-$total_duree_moyenne_sla_Monetique)/$total_duree_moyenne_sla_Monetique)*100,0);
        $delai_moyenne_déppassement_Monetique=$duree_moyenne_déppassement_Monetique+$total_duree_moyenne_sla_Monetique;
        $taux_nn_deppass_Monetique=round(((($nbr_intervention[35]-$nbr_intervention[15])/$nbr_intervention[35])*100),2);
        $taux_deppass_Monetique=round((($nbr_intervention[15]/$nbr_intervention[35])*100),2);

        $moy_moyenne_deppassement_Monetique=round((($nbr_intervention[29]/$nbr_intervention[15])/60),0);
        $moy_moyenne_intevention_deppassement_Monetique=round((($nbr_intervention[23]/$nbr_intervention[15])/60),0);

        echo '<tr><td>Monétique  </td><td>'.$nbr_intervention[35].' </td><td>'.$nbr_intervention[15].' </td><td>'.$taux_nn_deppass_Monetique.'%</td><td>'.$taux_deppass_Monetique.'%</td>
													<td>'.get_duree_minute_sla(9).'</td><td>'.get_duree_sla_format(9).'</td>
													<td>'.$moy_moyenne_deppassement_Monetique.' </td><td>'.transforme($moy_moyenne_deppassement_Monetique*60).' </td>
													<td>'.$moy_moyenne_intevention_deppassement_Monetique.' </td><td>'.transforme($moy_moyenne_intevention_deppassement_Monetique*60).'</td><td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_Monetique.' </td><td>'.transforme($total_duree_arret_contactuelle_Monetique*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_Monetique/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[16]<>0)
    {
        $total_duree_moyenne_sla_S2M=get_duree_minute_sla(10)*$nbr_intervention[16];
        $total_duree_arret_contactuelle_S2M=round(($nbr_intervention[30]/60),0);
        $duree_moyenne_déppassement_S2M=round((($total_duree_arret_contactuelle_S2M-$total_duree_moyenne_sla_S2M)/$total_duree_moyenne_sla_S2M)*100,0);
        $delai_moyenne_déppassement_S2M=$duree_moyenne_déppassement_S2M+$total_duree_moyenne_sla_S2M;
        $taux_nn_deppass_S2M=round(((($nbr_intervention[36]-$nbr_intervention[16])/$nbr_intervention[36])*100),2);
        $taux_deppass_S2M=round((($nbr_intervention[16]/$nbr_intervention[36])*100),2);

        $moy_moyenne_deppassement_S2M=round((($nbr_intervention[30]/$nbr_intervention[16])/60),0);
        $moy_moyenne_intevention_deppassement_S2M=round((($nbr_intervention[24]/$nbr_intervention[16])/60),0);

        echo '<tr><td>S2M  </td><td>'.$nbr_intervention[36].' </td><td>'.$nbr_intervention[16].' </td><td>'.$taux_nn_deppass_S2M.'%</td><td>'.$taux_deppass_S2M.'%</td>
													<td>'.get_duree_minute_sla(10).'</td><td>'.get_duree_sla_format(10).'</td>
													<td>'.$moy_moyenne_deppassement_S2M.' </td><td>'.transforme($moy_moyenne_deppassement_S2M*60).' </td>
													<td>'.$moy_moyenne_intevention_deppassement_S2M.' </td><td>'.transforme($moy_moyenne_intevention_deppassement_S2M*60).'</td><td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_S2M.' </td><td>'.transforme($total_duree_arret_contactuelle_S2M*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_S2M/$duree_total*100),2).'%</td></tr>';
    }

    // echo '<tr><td>Total  </td><td>'.$nbr_intervention[31].'</td><td>'.$nbr_intervention[2].' </td><td></td><td></td><td></td><td></td><td></td><td></td><td>'.round($nbr_intervention[18]/60,0).' </td><td></td><td>'.$duree_total.' </td><td> </td><td> </td><td>'.round((round($nbr_intervention[18]/60,0)/$duree_total*100),2).'%</td></tr>';

    echo '</table>';

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function affichageInformationDeppasementSLA2($date_courant,$date_fin,$nb_gab,$nb_jour_mois,$list_gab,$motif,$libelle)
{

    // $total_duree_deppassement_reel17,$total_duree_deppassement_cont,
    // $duree_deppassent_G4S_reel,$duree_deppassent_Logistique_reel,$duree_deppassent_NCR_reel,$duree_deppassent_TELECOM_reel,$duree_deppassent_Monetique_reel,$duree_deppassent_S2M_reel,
    // $duree_deppassent_G4S_cont,$duree_deppassent_Logistique_cont,$duree_deppassent_NCR_cont,$duree_deppassent_TELECOM_cont,$duree_deppassent_Monetique_cont,$duree_deppassent_S2M_cont);


    // </thead>
    // <tr><td>G4S  </td><td>'.$nbr_intervention[4].' </td><td>'.round((round($nbr_intervention[19]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[11].' </td><td>'.round((round($nbr_intervention[25]/60,0)/$duree_total*100),2).'%</td></tr>
    // <tr><td>Logistique  </td><td>'.$nbr_intervention[5].' </td><td>'.round((round($nbr_intervention[20]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[12].' </td><td>'.round((round($nbr_intervention[26]/60,0)/$duree_total*100),2).'%</td></tr>
    // <tr><td>NCR  </td><td>'.$nbr_intervention[6].' </td><td>'.round((round($nbr_intervention[21]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[13].' </td><td>'.round((round($nbr_intervention[27]/60,0)/$duree_total*100),2).'%</td></tr>
    // <tr><td>TELECOM  </td><td>'.$nbr_intervention[7].' </td><td>'.round((round($nbr_intervention[22]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[14].' </td><td>'.round((round($nbr_intervention[28]/60,0)/$duree_total*100),2).'%</td></tr>
    // <tr><td>Monétique  </td><td>'.$nbr_intervention[8].' </td><td>'.round((round($nbr_intervention[23]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[15].' </td><td>'.round((round($nbr_intervention[29]/60,0)/$duree_total*100),2).'%</td></tr>
    // <tr><td>S2M  </td><td>'.$nbr_intervention[9].' </td><td>'.round((round($nbr_intervention[24]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[16].' </td><td>'.round((round($nbr_intervention[30]/60,0)/$duree_total*100),2).'%</td></tr>
    // <tr><td>Total  </td><td>'.$nbr_intervention[1].' </td><td>'.round((round($nbr_intervention[17]/60,0)/$duree_total*100),2).'%</td><td>'.$nbr_intervention[2].' </td><td>'.round((round($nbr_intervention[18]/60,0)/$duree_total*100),2).'%</td></tr>
    // </table>


    $duree_total=$nb_gab*$nb_jour_mois*1440;
    $nbr_intervention=getNBRIntervention($date_courant,$date_fin,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab,$motif);
    echo '<table class="table table-responsive-sm table-hover table-outline mb-0">
												<thead class="thead-light">
													<tr>					
													<th colspan=11 class="text-center">Dépassement SLA '.$libelle.'</th>												
												</tr>													

												<tr>
													<th></th>
													<th>Durée SLA</th>
													<th>Durée SLA (Format)</th>
													<th>Durée moyenne de déppassement</th>
													<th>Durée moyenne de déppassement (Format)</th>													
													<th>Délai moyenne d\'intevention de déppassement</th>
													<th>Délai moyenne d\'intevention de déppassement (Format)</th>
													<th>Durée d\'intevention de déppassement </th>
													<th>Durée d\'intevention de déppassement (Format)</th>
													<th>Durée total</th>
													<th>Taux d\'indisponibilité</th>
												</tr>
												</thead>';


    if($nbr_intervention[11]<>0)
    {
        $total_duree_moyenne_sla_G4S=get_duree_minute_sla(2)*$nbr_intervention[11];
        $total_duree_arret_contactuelle_G4S=round(($nbr_intervention[25]/60),0);
        $duree_moyenne_déppassement_G4S=round((($total_duree_arret_contactuelle_G4S-$total_duree_moyenne_sla_G4S)/$total_duree_moyenne_sla_G4S)*100,0);
        $delai_moyenne_déppassement_G4S=$duree_moyenne_déppassement_G4S+$total_duree_moyenne_sla_G4S;
        echo '<tr><td>G4S  </td><td>'.$nbr_intervention[11].' </td><td>'.get_duree_minute_sla(2).'</td><td>'.get_duree_sla_format(2).'</td>
													<td>'.$duree_moyenne_déppassement_G4S.' </td><td>'.transforme($duree_moyenne_déppassement_G4S).' </td>
													<td>'.$delai_moyenne_déppassement_G4S.' </td><td>'.transforme($delai_moyenne_déppassement_G4S).'</td><td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_G4S.' </td><td>'.transforme($total_duree_arret_contactuelle_G4S*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_G4S/$duree_total*100),2).'%</td></tr>';

    }

    if($nbr_intervention[12]<>0)
    {
        $total_duree_moyenne_sla_Logistique=get_duree_minute_sla(2)*$nbr_intervention[12];
        $total_duree_arret_contactuelle_Logistique=round(($nbr_intervention[26]/60),0);
        $duree_moyenne_déppassement_Logistique=round((($total_duree_arret_contactuelle_Logistique-$total_duree_moyenne_sla_Logistique)/$total_duree_moyenne_sla_Logistique)*100,0);
        $delai_moyenne_déppassement_Logistique=$duree_moyenne_déppassement_Logistique+$total_duree_moyenne_sla_Logistique;
        echo '<tr><td>Logistique  </td><td>'.$nbr_intervention[12].' </td><td>'.get_duree_minute_sla(2).'</td><td>'.get_duree_sla_format(2).'</td>
													<td>'.$duree_moyenne_déppassement_Logistique.' </td><td>'.transforme($duree_moyenne_déppassement_Logistique).' </td>
													<td>'.$delai_moyenne_déppassement_Logistique.' </td><td>'.transforme($delai_moyenne_déppassement_Logistique).'</td><td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_Logistique.' </td><td>'.transforme($total_duree_arret_contactuelle_Logistique*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_Logistique/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[13]<>0)
    {
        $total_duree_moyenne_sla_NCR=get_duree_minute_sla(2)*$nbr_intervention[13];
        $total_duree_arret_contactuelle_NCR=round(($nbr_intervention[27]/60),0);
        $duree_moyenne_déppassement_NCR=round((($total_duree_arret_contactuelle_NCR-$total_duree_moyenne_sla_NCR)/$total_duree_moyenne_sla_NCR)*100,0);
        $delai_moyenne_déppassement_NCR=$duree_moyenne_déppassement_NCR+$total_duree_moyenne_sla_NCR;
        echo '<tr><td>NCR  </td><td>'.$nbr_intervention[13].' </td><td>'.get_duree_minute_sla(2).'</td><td>'.get_duree_sla_format(2).'</td>
													<td>'.$duree_moyenne_déppassement_NCR.' </td><td>'.transforme($duree_moyenne_déppassement_NCR).' </td>
													<td>'.$delai_moyenne_déppassement_NCR.' </td><td>'.transforme($delai_moyenne_déppassement_NCR).'</td><td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_NCR.' </td><td>'.transforme($total_duree_arret_contactuelle_NCR*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_NCR/$duree_total*100),2).'%</td></tr>';
    }

    if($nbr_intervention[14]<>0)
    {
        $total_duree_moyenne_sla_TELECOM=get_duree_minute_sla(2)*$nbr_intervention[14];
        $total_duree_arret_contactuelle_TELECOM=round(($nbr_intervention[28]/60),0);
        $duree_moyenne_déppassement_TELECOM=round((($total_duree_arret_contactuelle_TELECOM-$total_duree_moyenne_sla_TELECOM)/$total_duree_moyenne_sla_TELECOM)*100,0);
        $delai_moyenne_déppassement_TELECOM=$duree_moyenne_déppassement_TELECOM+$total_duree_moyenne_sla_TELECOM;
        echo '<tr><td>TELECOM  </td><td>'.$nbr_intervention[14].' </td><td>'.get_duree_minute_sla(2).'</td><td>'.get_duree_sla_format(2).'</td>
													<td>'.$duree_moyenne_déppassement_TELECOM.' </td><td>'.transforme($duree_moyenne_déppassement_TELECOM).' </td>
													<td>'.$delai_moyenne_déppassement_TELECOM.' </td><td>'.transforme($delai_moyenne_déppassement_TELECOM).'</td><td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_TELECOM.' </td><td>'.transforme($total_duree_arret_contactuelle_TELECOM*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_TELECOM/$duree_total*100),2).'%</td></tr>';

    }

    if($nbr_intervention[15]<>0)
    {														$total_duree_moyenne_sla_Monetique=get_duree_minute_sla(2)*$nbr_intervention[15];
        $total_duree_arret_contactuelle_Monetique=round(($nbr_intervention[29]/60),0);
        $duree_moyenne_déppassement_Monetique=round((($total_duree_arret_contactuelle_Monetique-$total_duree_moyenne_sla_Monetique)/$total_duree_moyenne_sla_Monetique)*100,0);
        $delai_moyenne_déppassement_Monetique=$duree_moyenne_déppassement_Monetique+$total_duree_moyenne_sla_Monetique;
        echo '<tr><td>Monétique  </td><td>'.$nbr_intervention[15].' </td><td>'.get_duree_minute_sla(2).'</td><td>'.get_duree_sla_format(2).'</td>
													<td>'.$duree_moyenne_déppassement_Monetique.' </td><td>'.transforme($duree_moyenne_déppassement_Monetique).' </td>
													<td>'.$delai_moyenne_déppassement_Monetique.' </td><td>'.transforme($delai_moyenne_déppassement_Monetique).'</td><td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_Monetique.' </td><td>'.transforme($total_duree_arret_contactuelle_Monetique*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_Monetique/$duree_total*100),2).'%</td></tr>';

    }

    if($nbr_intervention[16]<>0)
    {														$total_duree_moyenne_sla_S2M=get_duree_minute_sla(2)*$nbr_intervention[16];
        $total_duree_arret_contactuelle_S2M=round(($nbr_intervention[30]/60),0);
        $duree_moyenne_déppassement_S2M=round((($total_duree_arret_contactuelle_S2M-$total_duree_moyenne_sla_S2M)/$total_duree_moyenne_sla_S2M)*100,0);
        $delai_moyenne_déppassement_S2M=$duree_moyenne_déppassement_S2M+$total_duree_moyenne_sla_S2M;
        echo '<tr><td>S2M  </td><td>'.$nbr_intervention[16].' </td><td>'.get_duree_minute_sla(2).'</td><td>'.get_duree_sla_format(2).'</td>
													<td>'.$duree_moyenne_déppassement_S2M.' </td><td>'.transforme($duree_moyenne_déppassement_S2M).' </td>
													<td>'.$delai_moyenne_déppassement_S2M.' </td><td>'.transforme($delai_moyenne_déppassement_S2M).'</td><td>'.$duree_total.' </td>
													<td>'.$total_duree_arret_contactuelle_S2M.' </td><td>'.transforme($total_duree_arret_contactuelle_S2M*60).'</td>
													<td>'.round(($total_duree_arret_contactuelle_S2M/$duree_total*100),2).'%</td></tr>';

    }

    if($duree_total<>0)
    {

        echo '<tr><td>Total  </td><td>'.$nbr_intervention[2].' </td><td></td><td></td><td></td><td>'.round($nbr_intervention[18]/60,0).' </td><td></td><td>'.$duree_total.' </td><td> </td><td> </td><td>'.round((round($nbr_intervention[18]/60,0)/$duree_total*100),2).'%</td></tr>';
    }
    echo '</table>';

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function affichageDureeInformationIntervenantCategorieMotif($date_courant,$date_fin,$motif_inclus,$list_gab,$categorie,$nb_gab,$nb_jour_mois,$id_filiales,$type_gab,$type_gestionnaire,$titre,$lang)
{

    $duree_globlal=$nb_gab*$nb_jour_mois*1440;

    $duree=getTauxIndispoMotif2($date_courant,$date_fin,$motif_inclus,$list_gab,$categorie,$id_filiales,$type_gab,$type_gestionnaire);
    $taux_indispo_dispo=getverifTaux1($duree,$duree_globlal);
    $dispo=round(100-$taux_indispo_dispo,2,PHP_ROUND_HALF_DOWN);
    $duree_indispo=$duree_globlal-$duree;
    echo '<table class="table table-responsive-sm table-hover table-outline mb-0">';
    echo '
							<thead class="thead-light">
							<tr>							
									<th colspan = 4 class="text-center">'.$titre.'</th>
								</tr><tr >
									<th>'.$lang['th_table_14'].'</th><th>'.$lang['th_table_15'].'</th><th>'.$lang['th_table_16'].'</th><th>'.$lang['th_table_17'].'</th>
								</tr>
								<tr>
									<td>'.$lang['th_table_35'].'</td><td>'.$duree_globlal.'</td><td>'.$duree.'</td><td>'.round($dispo,2).' %</td>
								</tr>								
								<tr>
									<td>'.$lang['th_table_37'].'</td><td>'.$duree_globlal.'</td><td>'.$duree_indispo.'</td><td>'.round($taux_indispo_dispo,2).' %</td>
								</tr>	
								</thead>';

    if($categorie==""){$categorie="%";}
    $connexion = ma_db_connexion();

    $sql = "SELECT `id_categorie`, `libelle` FROM `new_categorie_intervention`";
    if($categorie<>"%"){$sql = $sql." WHERE `id_categorie` IN(".mysqli_real_escape_string($connexion,$categorie).")"; }
    $sql = $sql." GROUP BY `libelle`";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 032 : ".mysqli_error($connexion));
        die('ERREUR QUERY 032 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {

                echo '
							<tr>									
									<td>'.STRTOUPPER($row["libelle"]).'</td><td>'; $duree_3=getTauxIndispoMotif2($date_courant,$date_fin,$motif_inclus,$list_gab,$row["id_categorie"],$id_filiales,$type_gab,$type_gestionnaire);echo $duree_globlal.'</td><td>'.$duree_3.'</td><td>';
                echo getverifTaux1($duree_3,$duree_globlal);
                echo ' %</td></tr>';

            }
        }
    }

    mysqli_free_result($result);
    mysqli_close($connexion);


    echo '</table>';

}
///////////////////////////////////////////////////////////////////////////////////////////
function genere_img_incident_par_responsable($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)
{

    $myPicture = new pDraw(700,280);

    $palette_light = [[255,255,255,100],[40,69,119,100]];
    $myPicture->myData->loadPalette($palette_light, $overwrite=TRUE);

    $k=1;
    $j=0;
    $array_id = array();
    foreach (get_array_id_responsable($type_gestionnaire) AS $id_responsable)
    {

        if($k==1)
        {
            $myPicture->myData->addPoints(array("0"),"1");
            $myPicture->myData->addPoints(array(get_compte_nb_incident_responsable($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$id_responsable)),"2");
            $myPicture->myData->addPoints(array(get_libelle_responsable($id_responsable)),"Labels");

        }
        else
        {
            $myPicture->myData->addPoints(array(get_compte_nb_incident_responsable($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,implode(',',$array_id))),"1");
            $myPicture->myData->addPoints(array(get_compte_nb_incident_responsable($date_debut,$date_fin,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$id_responsable)),"2");
            $myPicture->myData->addPoints(array(get_libelle_responsable($id_responsable)),"Labels");
        }

        $array_id[$j]=$id_responsable;
        $k++;
        $j++;
    }

    $myPicture->myData->setSerieDescription("Labels","Indispo");
    $myPicture->myData->setAbscissa("Labels");

    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>14));
    $TextSettings = array("Align"=>TEXT_ALIGN_MIDDLEMIDDLE, "R"=>0, "G"=>0, "B"=>0);
// $myPicture->drawText(370,25,"Répartition des incidents GAB par centre d'imputation ",$TextSettings);

    $myPicture->setGraphArea(50,50,695,250);
    $myPicture->setFontProperties(array("R"=>0,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>9));
    $scaleSettings =array("DrawSubTicks"=>TRUE,"Mode"=>SCALE_MODE_ADDALL_START0);
    $myPicture->drawScale($scaleSettings);

    $myPicture->setShadow(FALSE);

    $pCharts = new pCharts($myPicture);
    $pCharts->drawStackedBarChart(["DisplayValues"=>TRUE,"DisplayType"=>DISPLAY_AUTO,"Rounded"=>TRUE,"Surrounding"=>60]);

    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/img_incident_ouvert_par_responsable_".date("d-m-Y",strtotime($date_debut)).'_'.date("d-m-Y",strtotime($date_fin)).".png");

}

///////////////////////////////////////////////////////////////////////////////////////////
function genere_img_incident_par_categorie_service($date_debut,$date_fin,$list_gab_retrait_argent,$motif_retrait_argent,$categorie,$id_filiales,$type_gab,$type_gestionnaire)
{

    $myPicture = new pDraw(700,300);
    $palette_light = [[255,255,255,100],[40,69,119,100]];

    $myPicture->myData->loadPalette($palette_light, $overwrite=TRUE);

    if(($categorie<>"")&&($categorie<>"%"))
    {
        $connexion = ma_db_connexion();

        $sql = "SELECT `id_categorie`, `libelle` FROM `new_categorie_intervention`";
        if(($categorie<>"")&&($categorie<>"%")){$sql = $sql." WHERE `id_categorie` IN(".mysqli_real_escape_string($connexion,$categorie).")"; }
        $sql = $sql." GROUP BY `libelle`";

        $result=mysqli_query($connexion,$sql);
        if (!$result)
        {
            error_log("Erreur sql 032 : ".mysqli_error($connexion));
            die('ERREUR QUERY 032 !');
        }


        if ($result)
        {
            if(mysqli_num_rows($result)>0)
            {
                while ($row = mysqli_fetch_assoc($result))
                {
                    $myPicture->myData->addPoints(array("0"),"1");
                    $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,$row["id_categorie"],$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
                    $myPicture->myData->addPoints(array($row["libelle"]),"Labels");
                }
            }
        }

        mysqli_free_result($result);
        mysqli_close($connexion);
    }

    if(($categorie=="")||($categorie=="%"))
    {

        $myPicture->myData->addPoints(array("0"),"1");
        $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,1,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
        $myPicture->myData->addPoints(array("Hardware"),"Labels");

        $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,1,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"1");
        $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,5,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
        $myPicture->myData->addPoints(array(" Fonds"),"Labels");


        $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,'1,5',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"1");
        $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,4,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
        $myPicture->myData->addPoints(array("Consommable"),"Labels");


        $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,'1,5,4',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"1");
        $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,2,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
        $myPicture->myData->addPoints(array("Télécom"),"Labels");


        $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,'1,5,4,2',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"1");
        $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,6,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
        $myPicture->myData->addPoints(array("Electricité"),"Labels");

        $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,'1,5,4,2,6',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"1");
        $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,3,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
        $myPicture->myData->addPoints(array("       Connexion\nserveur monétique"),"Labels");

        $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,'1,5,4,2,3,6',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"1");
        $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,7,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
        $myPicture->myData->addPoints(array("Autres *"),"Labels");

    }






    $myPicture->myData->setSerieDescription("Labels","Indispo");
    $myPicture->myData->setAbscissa("Labels");

    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>14));
    $TextSettings = array("Align"=>TEXT_ALIGN_MIDDLEMIDDLE, "R"=>0, "G"=>0, "B"=>0);
// $myPicture->drawText(370,25,"Répartition des incidents GAB par catégorie ",$TextSettings);
    $myPicture->setGraphArea(50,50,695,250);
    $myPicture->setFontProperties(array("R"=>250,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>9));

    $scaleSettings =array("DrawSubTicks"=>TRUE,"Mode"=>SCALE_MODE_ADDALL_START0);
    $myPicture->drawScale($scaleSettings);
    $myPicture->setShadow(FALSE);

// $settings = array("Gradient"=>TRUE, "DisplayPos"=>LABEL_POS_INSIDE, "DisplayValues"=>TRUE, "DisplayR"=>255, "DisplayG"=>255, "DisplayB"=>255, "DisplayShadow"=>TRUE, "Surrounding"=>30);

// (new pCharts($myPicture))->drawStackedBarChart(array("InnerSurrounding"=>0,"DisplayPos"=>LABEL_POS_INSIDE,"DisplayValues"=>TRUE));
    $pCharts = new pCharts($myPicture);
    $pCharts->drawStackedBarChart(["DisplayValues"=>TRUE, "DisplayShadow"=>TRUE,"DisplayType"=>DISPLAY_AUTO,"Rounded"=>TRUE,"Surrounding"=>60]);

    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/img_incident_ouvert_par_categorie_".date("d-m-Y",strtotime($date_debut)).'_'.date("d-m-Y",strtotime($date_fin)).".png");

}
function getGenereImg4($date_debut,$date_fin,$jours,$tx_dispo_final_retrait_argent,$tx_dispo_final_depot_argent,$tx_dispo_final_depot_cheque)
{
    $myPicture = new pDraw(700,320);

    $palette_light = [[40,69,119,100],[235,124,57,100],[165,165,165,100]];

    $myPicture->myData->loadPalette($palette_light, $overwrite=TRUE);

    $myPicture->myData->addPoints($tx_dispo_final_retrait_argent,"Service retrait");
    $myPicture->myData->addPoints($tx_dispo_final_depot_argent,"Service dépôt d’argent");
    $myPicture->myData->addPoints($tx_dispo_final_depot_cheque,"Service dépôt de chèque");
    $myPicture->myData->addPoints($jours,"Absissa");
    $myPicture->myData->setAbscissa("Absissa");



    $myPicture->setFontProperties(["FontName"=>"fonts/calibri.ttf","FontSize"=>8,"Color"=>new pColor(0)]);
// $myPicture->drawText(130,40,"Historique du taux de disponibilité sur les 7 derniers jours",["FontSize"=>14,"Align"=>TEXT_ALIGN_BOTTOMLEFT]);
// $myPicture->setFontProperties(["FontName"=>"fonts/calibri.ttf","FontSize"=>8,"Color"=>new pColor(0)]);
// $myPicture->drawText(100,40,"Historique du taux de disponibilité par service sur des 7 derniers jours",["FontSize"=>14,"Align"=>TEXT_ALIGN_BOTTOMLEFT]);

    $myPicture->setFontProperties(["FontSize"=>7,"Color"=>new pColor(0)]);
    $myPicture->setGraphArea(50,50,685,250);
// $myPicture->drawScale(["XMargin"=>0,"YMargin"=>0,"Floating"=>TRUE,"GridColor"=>new pColor(200),
    // "DrawSubTicks"=>TRUE,
    // "Mode"=>SCALE_MODE_MANUAL, "ManualScale"=>$AxisBoundaries,
    // "Pos"=>SCALE_POS_LEFTRIGHT]);

    $myPicture->drawScale(["XMargin"=>0,"YMargin"=>0,"Floating"=>TRUE,"GridColor"=>new pColor(200),
        "DrawSubTicks"=>TRUE,
        // "CycleBackground"=>TRUE,
        "Mode"=>SCALE_MODE_FLOATING,
        "Pos"=>SCALE_POS_LEFTRIGHT]);
    $myPicture->setAntialias(TRUE);
    // "CycleBackground"=>TRUE,"LabelSkip"=>3,"DrawSubTicks"=>TRUE
    $pCharts = new pCharts($myPicture);

    $pCharts->drawLineChart();
    $pCharts->drawPlotChart(["PlotBorder"=>TRUE,"BorderSize"=>2,"Surrounding"=>-60,"BorderColor"=>new pColor(0,0,0,80),"BorderAlpha"=>80]);
    $myPicture->setFontProperties(array("R"=>0,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>12));
    /* Write the data bounds */
    $myPicture->setShadow(FALSE);
    $myPicture->setFontProperties(array("R"=>0,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>12));
    $myPicture->drawLegend(130,280,array("Style"=>LEGEND_NOBORDER,"Mode"=>LEGEND_HORIZONTAL));
    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/img_dispo_par_service_".date("d-m-Y", strtotime($date_debut))."__".date("d-m-Y", strtotime($date_fin)).".png");

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function image_incident_ouvert_par_categorie_service($date_debut,$date_fin,$non_utilisee,$list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque,$motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$lang)
{

    $myPicture = new pDraw(700,290);
    if($categorie==""){$categorie="%";}
    $connexion = ma_db_connexion();

    $sql = "SELECT `id_categorie`, `libelle` FROM `new_categorie_intervention`";
    if($categorie<>"%"){$sql = $sql." WHERE `id_categorie` IN(".mysqli_real_escape_string($connexion,$categorie).")"; }
    $sql = $sql." GROUP BY `libelle`";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 032 : ".mysqli_error($connexion));
        die('ERREUR QUERY 032 !');
    }


    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,$row["id_categorie"],$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),ucfirst(strtolower($row["libelle"])));
            }
        }
    }
    $myPicture->myData->addPoints(array($lang['th_table_5']),"Labels");



    $sql = "SELECT `id_categorie`, `libelle` FROM `new_categorie_intervention`";
    if($categorie<>"%"){$sql = $sql." WHERE `id_categorie` IN(".mysqli_real_escape_string($connexion,$categorie).")"; }
    $sql = $sql." GROUP BY `libelle`";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 032 : ".mysqli_error($connexion));
        die('ERREUR QUERY 032 !');
    }


    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,$row["id_categorie"],$list_gab_depot_argent,$motif_depot_argent,$id_filiales,$type_gab,$type_gestionnaire)),ucfirst(strtolower($row["libelle"])));
            }
        }
    }
    $myPicture->myData->addPoints(array($lang['th_table_6']),"Labels");

    $sql = "SELECT `id_categorie`, `libelle` FROM `new_categorie_intervention`";
    if($categorie<>"%"){$sql = $sql." WHERE `id_categorie` IN(".mysqli_real_escape_string($connexion,$categorie).")"; }
    $sql = $sql." GROUP BY `libelle`";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 032 : ".mysqli_error($connexion));
        die('ERREUR QUERY 032 !');
    }


    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $myPicture->myData->addPoints(array(get_nbr_incident_categorie($date_debut,$date_fin,$row["id_categorie"],$list_gab_depot_cheque,$motif_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)),ucfirst(strtolower($row["libelle"])));
            }
        }
    }
    $myPicture->myData->addPoints(array($lang['th_table_7']),"Labels");


    $myPicture->myData->setSerieDescription("Labels","Indispo");
    $myPicture->myData->setAbscissa("Labels");


    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>14));
    $TextSettings = array("Align"=>TEXT_ALIGN_MIDDLEMIDDLE, "R"=>0, "G"=>0, "B"=>0);
    // $myPicture->drawText(410,25,"Répartition des incidents par service et par catégorie ",$TextSettings);

    $myPicture->setGraphArea(50,50,695,250);
    $myPicture->setFontProperties(array("R"=>0,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>9));
    $scaleSettings =array("DrawSubTicks"=>TRUE,"Mode"=>SCALE_MODE_ADDALL_START0);
    $myPicture->drawScale($scaleSettings);

    $myPicture->setShadow(FALSE);

    $pCharts = new pCharts($myPicture);
    $pCharts->drawStackedBarChart(["DisplayValues"=>TRUE,"DisplayType"=>DISPLAY_AUTO,"Rounded"=>TRUE,"Surrounding"=>60]);

    $myPicture->setFontProperties(array("R"=>0,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>9));
    $myPicture->drawLegend(120,277,array("Style"=>LEGEND_NOBORDER,"Mode"=>LEGEND_HORIZONTAL));

    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/img_incident_ouvert_par_categorie_service_".date("d-m-Y",strtotime($date_debut)).'_'.date("d-m-Y",strtotime($date_fin)).".png");


}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function image_alerte_vs_regle($LibelleRegle,$AlerteRegle,$date_courant)
{

    $myPicture = new pDraw(700,350);

    $palette_light = [[252, 93, 93,100],
        [165,165,165,100],
        [169, 234, 254,100],
        [0, 0, 255,100],
        [91,155,213,100],
        [112,173,71,100],
        [15, 5, 107,100],
        [255,192,0,100],
        [68,114,196,100],
        [91,155,213,100],
        [112,173,71,100],
        [237,125,49,100],
        [165,165,165,100],
        [255,192,0,100],
        [68,114,196,100],
        [91,155,213,100],
        [112,173,71,100]];

    $myPicture->myData->loadPalette($palette_light, $overwrite=TRUE);
    $myPicture->myData->addPoints($AlerteRegle,"Serie1");
    $myPicture->myData->setSerieDescription("Serie1","Code régles");
    $myPicture->myData->setSerieOnAxis("Serie1",0);

    $myPicture->myData->addPoints($LibelleRegle,"Absissa");
    $myPicture->myData->setAbscissa("Absissa");

    // $myPicture->myData->setAxisPosition(0,AXIS_POSITION_LEFT);
    // $myPicture->myData->setAxisName(0,"");
    // $myPicture->myData->setAxisUnit(0,"");

    // $myPicture = new pImage(700,350,$myData,TRUE);

    /* Add a border to the picture */
    // $myPicture->drawRectangle(0,0,600,300,array("R"=>0,"G"=>0,"B"=>0));

    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>15));
    $TextSettings = array("Align"=>TEXT_ALIGN_MIDDLEMIDDLE
    , "R"=>0, "G"=>0, "B"=>0);
    $myPicture->drawText(350,25," Top des alertes par  règle du ".date("d/m/Y", strtotime($date_courant))." ",$TextSettings);
    $myPicture->setGraphArea(50,50,675,270);
    $myPicture->setFontProperties(array("R"=>0,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>10));

    $Settings = array("Pos"=>SCALE_POS_LEFTRIGHT
    , "Mode"=>SCALE_MODE_FLOATING
    , "LabelingMethod"=>LABELING_ALL
    , "GridR"=>0, "GridG"=>0, "GridB"=>0, "GridAlpha"=>10, "TickR"=>227, "TickG"=>2, "TickB"=>70, "TickAlpha"=>50, "LabelRotation"=>0, "CycleBackground"=>1, "DrawXLines"=>1, "DrawYLines"=>ALL);

    $myPicture->drawLegend(300,320,array("Style"=>LEGEND_NOBORDER,"Mode"=>LEGEND_HORIZONTAL));

    // "DisplayValues"=>1, "AroundZero"=>1
    $myPicture->drawScale($Settings);
    $pCharts = new pCharts($myPicture);
    // $pCharts->drawLineChart();
    // $myPicture->drawPlotChart(array("PlotBorder"=>TRUE,"BorderSize"=>1,"Surrounding"=>-60,"BorderAlpha"=>80));
    $pCharts->drawBarChart(array("PlotBorder"=>TRUE,"DisplayValues"=>TRUE,"BorderSize"=>1,"Surrounding"=>-60,"BorderAlpha"=>80));

    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/img_alerte_regle_".date("d-m-Y", strtotime($date_courant)).".png");


}
function getGenereImg1($date_debut,$date_fin,$dateCourant,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)
{


    $myPicture = new pDraw(700,280);
    $palette_light = [[255,255,255,100],[40,69,119,100]];

    $myPicture->myData->loadPalette($palette_light, $overwrite=TRUE);
    $myPicture->myData->addPoints(array("0"),"1");
    $myPicture->myData->addPoints(array(calculeDureeArretGABInferieur($dateCourant,1440,0,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("Depuis 1j\n  <=24h"),"Labels");

    $myPicture->myData->addPoints(array(calculeDureeArretGABInferieur($dateCourant,1440,0,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeDureeArretGAB($dateCourant,1440,2880,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("   Depuis 2j\n24h<D<=48h"),"Labels");

    $myPicture->myData->addPoints(array(calculeDureeArretGABInferieur($dateCourant,1440,0,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeDureeArretGAB($dateCourant,2880,4320,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("   Depuis 3j\n48h<D<=72h"),"Labels");

    $myPicture->myData->addPoints(array(calculeDureeArretGABInferieur($dateCourant,1440,0,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeDureeArretGAB($dateCourant,4320,7200,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array(" Entre 4j et 5j\n72h<D<=120h"),"Labels");

    $myPicture->myData->addPoints(array(calculeDureeArretGABInferieur($dateCourant,1440,0,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeDureeArretGABSup($dateCourant,7200,0,$categorie,$list_gab,$motif_inclus,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("Plus que 5j\n  D>120h"),"Labels");
    $myPicture->myData->setSerieDescription("Labels","Indispo");
    $myPicture->myData->setAbscissa("Labels");

    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>14));
    $TextSettings = array("Align"=>TEXT_ALIGN_MIDDLEMIDDLE, "R"=>0, "G"=>0, "B"=>0);
// $myPicture->drawText(370,25,"Répartition des incidents ouverts par durée ",$TextSettings);
    $myPicture->setGraphArea(50,50,695,250);
    $myPicture->setFontProperties(array("R"=>250,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>9));

    $scaleSettings =array("DrawSubTicks"=>TRUE,"Mode"=>SCALE_MODE_ADDALL_START0);
    $myPicture->drawScale($scaleSettings);
    $myPicture->setShadow(FALSE);

// (new pCharts($myPicture))->drawStackedBarChart(array("InnerSurrounding"=>0,"DisplayPos"=>LABEL_POS_INSIDE,"DisplayValues"=>TRUE));
    $pCharts = new pCharts($myPicture);
    $pCharts->drawStackedBarChart(["DisplayValues"=>TRUE,"DisplayType"=>DISPLAY_AUTO,"Rounded"=>TRUE,"Surrounding"=>60]);

    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/img_incident_ouvert_par_duree_".date("d-m-Y", strtotime($dateCourant)).".png");

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getGenereImg($date_debut,$date_fin,$dateCourant,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)
{
    // echo "test".$dateCourant;
    // echo "<br>test".date("d-m-Y", strtotime($dateCourant));
    $myPicture = new pDraw(700,280);
    $palette_light = [[255,255,255,100],[40,69,119,100]];

    $myPicture->myData->loadPalette($palette_light, $overwrite=TRUE);

    $myPicture->myData->addPoints(array("0"),"1");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'1',$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("CASABLANCA"),"Labels");

    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'1',$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'2',$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("FES"),"Labels");


    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'1,2',$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'3',$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("MARRAKECH"),"Labels");


    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'1,2,3',$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'4',$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("RABAT"),"Labels");


    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'1,2,3,4',$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'5',$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("TANGER"),"Labels");


    $myPicture->myData->setSerieDescription("Labels","Indispo");
    $myPicture->myData->setAbscissa("Labels");

    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>14));
    $TextSettings = array("Align"=>TEXT_ALIGN_MIDDLEMIDDLE, "R"=>0, "G"=>0, "B"=>0);
// $myPicture->drawText(370,25,"Répartition des incidents GAB ouverts par catégorie ",$TextSettings);
    $myPicture->setGraphArea(50,50,695,250);
    $myPicture->setFontProperties(array("R"=>250,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>9));

    $scaleSettings =array("DrawSubTicks"=>TRUE,"Mode"=>SCALE_MODE_ADDALL_START0);
    $myPicture->drawScale($scaleSettings);
    $myPicture->setShadow(FALSE);

// (new pCharts($myPicture))->drawStackedBarChart(array("InnerSurrounding"=>0,"DisplayPos"=>LABEL_POS_INSIDE,"DisplayValues"=>TRUE));
    $pCharts = new pCharts($myPicture);
    $pCharts->drawStackedBarChart(["DisplayValues"=>TRUE,"DisplayType"=>DISPLAY_AUTO,"Rounded"=>TRUE,"Surrounding"=>60]);

    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/img_incident_ouvert_par_region_".date("d-m-Y", strtotime($dateCourant)).".png");
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getGenereImg2($date_debut,$date_fin,$dateCourant,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)
{
    // echo "test".$dateCourant;
    // echo "<br>test".date("d-m-Y", strtotime($dateCourant));
    $myPicture = new pDraw(700,280);
    $palette_light = [[255,255,255,100],[40,69,119,100]];

    $myPicture->myData->loadPalette($palette_light, $overwrite=TRUE);

    $myPicture->myData->addPoints(array("0"),"1");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'1',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("HardWare"),"Labels");

    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'1',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'5',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("Fonds"),"Labels");


    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'1,5',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'4',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("Consommable"),"Labels");


    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'1,5,4',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'2',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("Télécom"),"Labels");


    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'1,5,4,2',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'6',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("Electricité"),"Labels");

    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'1,5,4,2,6',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'3',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("       Connexion\nserveur monétique"),"Labels");

    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'1,5,4,2,3,6',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"1");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'7',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("Autres"),"Labels");

    $myPicture->myData->setSerieDescription("Labels","Indispo");
    $myPicture->myData->setAbscissa("Labels");

    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>14));
    $TextSettings = array("Align"=>TEXT_ALIGN_MIDDLEMIDDLE, "R"=>0, "G"=>0, "B"=>0);
// $myPicture->drawText(370,25,"Répartition des incidents GAB ouverts par catégorie ",$TextSettings);
    $myPicture->setGraphArea(50,50,695,250);
    $myPicture->setFontProperties(array("R"=>250,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>9));

    $scaleSettings =array("DrawSubTicks"=>TRUE,"Mode"=>SCALE_MODE_ADDALL_START0);
    $myPicture->drawScale($scaleSettings);
    $myPicture->setShadow(FALSE);

// (new pCharts($myPicture))->drawStackedBarChart(array("InnerSurrounding"=>0,"DisplayPos"=>LABEL_POS_INSIDE,"DisplayValues"=>TRUE));
    $pCharts = new pCharts($myPicture);
    $pCharts->drawStackedBarChart(["DisplayValues"=>TRUE,"DisplayType"=>DISPLAY_AUTO,"Rounded"=>TRUE,"Surrounding"=>60]);

    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/img_incident_ouvert_par_categorie_".date("d-m-Y", strtotime($dateCourant)).".png");
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getGenereImg5($date_debut,$date_fin,$dateCourant,$categorie,$motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque,$list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)
{

    $myPicture = new pDraw(700,290);

    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'1',$type_gab,$type_gestionnaire)),"CASABLANCA");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'2',$type_gab,$type_gestionnaire)),"FES");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'3',$type_gab,$type_gestionnaire)),"MARRAKECH");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'4',$type_gab,$type_gestionnaire)),"RABAT");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,'5',$type_gab,$type_gestionnaire)),"TANGER");
    $myPicture->myData->addPoints(array("Service retrait d'argent"),"Labels");

    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_depot_argent,$motif_depot_argent,'1',$type_gab,$type_gestionnaire)),"CASABLANCA");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_depot_argent,$motif_depot_argent,'2',$type_gab,$type_gestionnaire)),"FES");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_depot_argent,$motif_depot_argent,'3',$type_gab,$type_gestionnaire)),"MARRAKECH");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_depot_argent,$motif_depot_argent,'4',$type_gab,$type_gestionnaire)),"RABAT");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_depot_argent,$motif_depot_argent,'5',$type_gab,$type_gestionnaire)),"TANGER");
    $myPicture->myData->addPoints(array("Service dépôt d'argent"),"Labels");


    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_depot_cheque,$motif_depot_cheque,'1',$type_gab,$type_gestionnaire)),"CASABLANCA");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_depot_cheque,$motif_depot_cheque,'2',$type_gab,$type_gestionnaire)),"FES");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_depot_cheque,$motif_depot_cheque,'3',$type_gab,$type_gestionnaire)),"MARRAKECH");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_depot_cheque,$motif_depot_cheque,'4',$type_gab,$type_gestionnaire)),"RABAT");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,$categorie,$list_gab_depot_cheque,$motif_depot_cheque,'5',$type_gab,$type_gestionnaire)),"TANGER");
    $myPicture->myData->addPoints(array("Service dépôt de chèque"),"Labels");


    $myPicture->myData->setSerieDescription("Labels","Indispo");
    $myPicture->myData->setAbscissa("Labels");



    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>14));
    $TextSettings = array("Align"=>TEXT_ALIGN_MIDDLEMIDDLE, "R"=>0, "G"=>0, "B"=>0);
// $myPicture->drawText(370,25,"Répartition des incidents ouverts par service et par catégorie ",$TextSettings);

    $myPicture->setGraphArea(50,50,695,250);
    $myPicture->setFontProperties(array("R"=>0,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>9));
    $scaleSettings =array("DrawSubTicks"=>TRUE,"Mode"=>SCALE_MODE_ADDALL_START0);
    $myPicture->drawScale($scaleSettings);

    $myPicture->setShadow(FALSE);

    $pCharts = new pCharts($myPicture);
    $pCharts->drawStackedBarChart(["DisplayValues"=>TRUE,"DisplayType"=>DISPLAY_AUTO,"Rounded"=>TRUE,"Surrounding"=>60]);

    $myPicture->setFontProperties(array("R"=>0,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>12));
    $myPicture->drawLegend(190,277,array("Style"=>LEGEND_NOBORDER,"Mode"=>LEGEND_HORIZONTAL));

    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/img_incident_ouvert_par_region_service_".date("d-m-Y", strtotime($dateCourant)).".png");
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getGenereImg7($date_debut,$date_fin,$dateCourant,$categorie,$motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque,$list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)
{

    $myPicture = new pDraw(700,280);

    $myPicture->myData->addPoints(array(get_nbr_incident_inpact_service(3,$categorie,$motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque,$list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("Incident ouvert impactant 3\n                  service"),"Labels");

    $myPicture->myData->addPoints(array(get_nbr_incident_inpact_service(2,$categorie,$motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque,$list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("Incident ouvert impactant 2\n                  service"),"Labels");

    $myPicture->myData->addPoints(array(get_nbr_incident_inpact_service(1,$categorie,$motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque,$list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("Incident ouvert impactant 1\n                  service"),"Labels");

    $myPicture->myData->addPoints(array(get_nbr_incident_inpact_service(0,$categorie,$motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque,$list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)),"2");
    $myPicture->myData->addPoints(array("Incident ouvert impactant 0\n                 service"),"Labels");

    $myPicture->myData->setSerieDescription("Labels","Indispo");
    $myPicture->myData->setAbscissa("Labels");

    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>14));
    $TextSettings = array("Align"=>TEXT_ALIGN_MIDDLEMIDDLE, "R"=>0, "G"=>0, "B"=>0);
// $myPicture->drawText(370,25,"Répartition des incidents ouverts par niveau d'impact ",$TextSettings);

    $myPicture->setGraphArea(50,50,695,250);
    $myPicture->setFontProperties(array("R"=>0,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>9));
    $scaleSettings =array("DrawSubTicks"=>TRUE,"Mode"=>SCALE_MODE_ADDALL_START0);
    $myPicture->drawScale($scaleSettings);

    $myPicture->setShadow(FALSE);

    $pCharts = new pCharts($myPicture);
    $pCharts->drawStackedBarChart(["DisplayValues"=>TRUE,"DisplayType"=>DISPLAY_AUTO,"Rounded"=>TRUE,"Surrounding"=>60]);

    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/img_incident_ouvert_par_niveau_impact_".date("d-m-Y", strtotime($dateCourant)).".png");

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getGenereImg8($dateCourant,$tx_dispo_final,$tx_cont,$num)
{



    $myPicture = new pDraw(310,220);
    $palette_light = [[38,68,120,100],[165,165,165,100]];
    $myPicture->myData->loadPalette($palette_light, $overwrite=TRUE);

    $myPicture->myData->addPoints(array($tx_dispo_final,$tx_cont),"ScoreA");
    $myPicture->myData->setSerieDescription("ScoreA","Application A");
    $myPicture->myData->addPoints(array("Taux de disponibilité","Taux d'indisponibilité"),"Labels");
    $myPicture->myData->setAbscissa("Labels");
    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>16));
    $TextSettings = array("Align"=>TEXT_ALIGN_MIDDLEMIDDLE, "R"=>0, "G"=>0, "B"=>0);
// $myPicture->drawText(145,35, $titre, $TextSettings);
    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>9,"R"=>250, "G"=>0, "B"=>0));
    $PieChart = new pPie($myPicture);
// $PieChart->draw2DRing(160,140,["WriteValues"=>TRUE,"ValueColor"=>ColorWhite(),"Border"=>TRUE]);
    $PieChart->draw3DPie(89,130,array("WriteValues"=>PIE_VALUE_PERCENTAGE,"DrawXLines"=>0,'ValueR'=>140, 'ValueG'=>140, 'ValueB'=>140, "DrawYLines"=>ALL,"LabelStacked"=>TRUE,"Border"=>TRUE));
// $PieChart->draw2DRing(99,150,array("Radius"=>140,"WriteValues"=>PIE_VALUE_PERCENTAGE,"DrawXLines"=>0,'ValueR'=>140, 'ValueG'=>140, 'ValueB'=>140, "DrawYLines"=>ALL,"LabelStacked"=>TRUE,"Border"=>TRUE));
    $myPicture->setShadow(FALSE);
    $PieChart->drawPieLegend(170,80,["Color"=>new pColor(250,250,250,20)]);



    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/img_".$num."_taux_dispo_global_".date("d-m-Y", strtotime($dateCourant)).".png");

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getGenereImg6($date_debut,$date_fin,$dateCourant,$categorie,$motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque,$list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)
{

    $myPicture = new pDraw(700,290);

    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'1',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"Hardware");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'5',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"Fonds");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'4',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"Consommable");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'2',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"Télécom");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'6',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"Electricité");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'7',$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)),"Autres");
    $myPicture->myData->addPoints(array("Service retrait d'argent"),"Labels");

    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'1',$list_gab_depot_argent,$motif_depot_argent,$id_filiales,$type_gab,$type_gestionnaire)),"Hardware");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'5',$list_gab_depot_argent,$motif_depot_argent,$id_filiales,$type_gab,$type_gestionnaire)),"Fonds");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'4',$list_gab_depot_argent,$motif_depot_argent,$id_filiales,$type_gab,$type_gestionnaire)),"Consommable");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'2',$list_gab_depot_argent,$motif_depot_argent,$id_filiales,$type_gab,$type_gestionnaire)),"Télécom");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'6',$list_gab_depot_argent,$motif_depot_argent,$id_filiales,$type_gab,$type_gestionnaire)),"Electricité");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'7',$list_gab_depot_argent,$motif_depot_argent,$id_filiales,$type_gab,$type_gestionnaire)),"Autres");
    $myPicture->myData->addPoints(array("Service dépôt d'argent"),"Labels");


    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'1',$list_gab_depot_cheque,$motif_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)),"Hardware");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'5',$list_gab_depot_cheque,$motif_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)),"Fonds");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'4',$list_gab_depot_cheque,$motif_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)),"Consommable");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'2',$list_gab_depot_cheque,$motif_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)),"Télécom");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'6',$list_gab_depot_cheque,$motif_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)),"Electricité");
    $myPicture->myData->addPoints(array(calculeNbIncidentOuvert($date_debut,$date_fin,'7',$list_gab_depot_cheque,$motif_depot_cheque,$id_filiales,$type_gab,$type_gestionnaire)),"Autres");
    $myPicture->myData->addPoints(array("Service dépôt de chèque"),"Labels");


    $myPicture->myData->setSerieDescription("Labels","Indispo");
    $myPicture->myData->setAbscissa("Labels");



    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>14));
    $TextSettings = array("Align"=>TEXT_ALIGN_MIDDLEMIDDLE, "R"=>0, "G"=>0, "B"=>0);
// $myPicture->drawText(370,25,"Répartition des incidents ouverts par service et par catégorie ",$TextSettings);

    $myPicture->setGraphArea(50,50,695,250);
    $myPicture->setFontProperties(array("R"=>0,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>9));
    $scaleSettings =array("DrawSubTicks"=>TRUE,"Mode"=>SCALE_MODE_ADDALL_START0);
    $myPicture->drawScale($scaleSettings);

    $myPicture->setShadow(FALSE);

    $pCharts = new pCharts($myPicture);
    $pCharts->drawStackedBarChart(["DisplayValues"=>TRUE,"DisplayType"=>DISPLAY_AUTO,"Rounded"=>TRUE,"Surrounding"=>60]);

    $myPicture->setFontProperties(array("R"=>0,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>12));
    $myPicture->drawLegend(120,277,array("Style"=>LEGEND_NOBORDER,"Mode"=>LEGEND_HORIZONTAL));

    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/img_incident_ouvert_par_categorie_service_".date("d-m-Y", strtotime($dateCourant)).".png");
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getGenereImg3($date_debut,$date_fin,$dateCourant,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$type_gestionnaire)
{
    $myPicture = new pDraw(700,280);

// $myPicture->myData->addPoints(array(get_nbr_incident_inpact_service(3)),"2");
// $myPicture->myData->addPoints(array("Incident ouvert impactant 3\n                  service"),"Labels");

// $myPicture->myData->addPoints(array(get_nbr_incident_inpact_service(2)),"2");
// $myPicture->myData->addPoints(array("Incident ouvert impactant 2\n                  service"),"Labels");

// $myPicture->myData->addPoints(array(get_nbr_incident_inpact_service(1)),"2");
// $myPicture->myData->addPoints(array("Incident ouvert impactant 1\n                  service"),"Labels");

// $myPicture->myData->addPoints(array(get_nbr_incident_inpact_service(0)),"2");
// $myPicture->myData->addPoints(array("Incident ouvert impactant 0\n                 service"),"Labels");

// $myPicture->myData->setSerieDescription("Labels","Indispo");
// $myPicture->myData->setAbscissa("Labels");
    $palette_light = [[255,255,255,100],[40,69,119,100]];
    $myPicture->myData->loadPalette($palette_light, $overwrite=TRUE);

    $k=1;
    $j=0;
    $array_id = array();
    foreach (get_array_id_responsable('') AS $id_responsable)
    {



        if($k==1)
        {
            $myPicture->myData->addPoints(array("0"),"1");
            $myPicture->myData->addPoints(array(get_compte_nb_incident_ouvert_responsable($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$id_responsable)),"2");
            $myPicture->myData->addPoints(array(get_libelle_responsable($id_responsable)),"Labels");

        }
        else
        {
            $myPicture->myData->addPoints(array(get_compte_nb_incident_ouvert_responsable($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,implode(',',$array_id))),"1");
            $myPicture->myData->addPoints(array(get_compte_nb_incident_ouvert_responsable($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,$motif_retrait_argent,$id_filiales,$type_gab,$id_responsable)),"2");
            $myPicture->myData->addPoints(array(get_libelle_responsable($id_responsable)),"Labels");
        }


        $array_id[$j]=$id_responsable;
        $k++;
        $j++;
    }

    $myPicture->myData->setSerieDescription("Labels","Indispo");
    $myPicture->myData->setAbscissa("Labels");

    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>14));
    $TextSettings = array("Align"=>TEXT_ALIGN_MIDDLEMIDDLE, "R"=>0, "G"=>0, "B"=>0);
// $myPicture->drawText(370,25,"Répartition des incidents GAB ouverts par responsable ",$TextSettings);

    $myPicture->setGraphArea(50,50,695,250);
    $myPicture->setFontProperties(array("R"=>0,"G"=>0,"B"=>0,"FontName"=>"fonts/calibri.ttf","FontSize"=>9));
    $scaleSettings =array("DrawSubTicks"=>TRUE,"Mode"=>SCALE_MODE_ADDALL_START0);
    $myPicture->drawScale($scaleSettings);

    $myPicture->setShadow(FALSE);

    $pCharts = new pCharts($myPicture);
    $pCharts->drawStackedBarChart(["DisplayValues"=>TRUE,"DisplayType"=>DISPLAY_AUTO,"Rounded"=>TRUE,"Surrounding"=>60]);


    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/img_incident_ouvert_par_responsable_".date("d-m-Y", strtotime($dateCourant)).".png");
}
//////////////////////////////////////////////////////////////////////////////////////////
function genere_img_taux_dispo_nbr_incident_categorie($date_debut,$date_fin,$tx_dispo_final,$categorie,$titre,$name_image)
{

    $myPicture = new pDraw(410,220);
    $palette_light =  [[38,68,120,100],[161,13,13,100],[235,124,57,100],[165,165,165,100],[74,16,171,100],[19,75,81,100],[24,140,230,100]];
// $palette_light = [];
    $myPicture->myData->loadPalette($palette_light, $overwrite=TRUE);

    $myPicture->myData->addPoints($tx_dispo_final,"ScoreA");
    $myPicture->myData->setSerieDescription("ScoreA","Application A");
    $myPicture->myData->addPoints($categorie,"Labels");
    $myPicture->myData->setAbscissa("Labels");
    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>14));
    $TextSettings = array("Align"=>TEXT_ALIGN_MIDDLEMIDDLE, "R"=>0, "G"=>0, "B"=>0);
// $myPicture->drawText(145,35, $titre, $TextSettings);
    $myPicture->setFontProperties(array("FontName"=>"fonts/calibri.ttf","FontSize"=>9,"R"=>250, "G"=>0, "B"=>0));
    $PieChart = new pPie($myPicture);
// $PieChart->draw2DRing(160,140,["WriteValues"=>TRUE,"ValueColor"=>ColorWhite(),"Border"=>TRUE]);
    $PieChart->draw3DPie(89,130,array("WriteValues"=>PIE_VALUE_PERCENTAGE,"DrawXLines"=>0,'ValueR'=>140, 'ValueG'=>140, 'ValueB'=>140, "DrawYLines"=>ALL,"LabelStacked"=>TRUE,"Border"=>TRUE));
// $PieChart->draw2DRing(99,150,array("Radius"=>140,"WriteValues"=>PIE_VALUE_PERCENTAGE,"DrawXLines"=>0,'ValueR'=>140, 'ValueG'=>140, 'ValueB'=>140, "DrawYLines"=>ALL,"LabelStacked"=>TRUE,"Border"=>TRUE));
    $myPicture->setShadow(FALSE);
    $PieChart->drawPieLegend(180,80,["Color"=>new pColor(250,250,250,20)]);
    $myPicture->Render("/var/www/html/backoffice/demo-monitoring/rapport/img/".$name_image.".png");
}


?>