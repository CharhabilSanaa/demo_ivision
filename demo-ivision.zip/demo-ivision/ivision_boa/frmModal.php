
<?php if (((isset($_SESSION['user']))&&(verif_user($_SESSION['user'],$_SESSION['mdp'])==true)) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true) || (verif_habilitation($_SESSION['autorisation_projet'],37)==true))):?>
    <!-- - - DISPONIBILTE INTERVENTION- -->
    <!-- The Modal -->
    <meta charset="utf-8">
    <div class="modal" id="detailPeripheralStatus">
        <div id="divModalDetailPeripheralStatus"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailConfigServiceATM">
        <div id="divModalConfigServiceATM"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailConfigLogicalNameServiceATM">
        <div id="divModalConfigLogicalNameServiceATM"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailConfigStatusLogicalNameATM">
        <div id="divModalConfigStatusLogicalNameATM"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailConfigStatusXFSNameATM">
        <div id="divModalConfigStatusXFSNameATM"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailRedemarrerATM">
        <div id="divModalRedemarrerATM"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailPingATM">
        <div id="divModalPingATM"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailAffectIncid_gab_ouv">
        <div id="divModalAffectIncid_gab_ouv"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailScreenshotATM">
        <div id="divModalScreenshotATM"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="showScreenshotATM" style="z-index: 1080 !important;padding-top: 65px;">
        <div id="divModalshowScreenshotATM"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="showFileUpload" style="z-index: 1080 !important;">
        <div id="divModalshowFileUpload"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="show_remarque_incident" style="z-index: 1080 !important;">
        <div id="divModalremarque_incident"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="myModalComp_success">
        <div id="divModal_Comp_success"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="myModalComp_not_yet">
        <div id="divModal_Comp_not_yet"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="myModalComp_non_déployée">
        <div id="divModal_Comp_non_déployée"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="myModalComp_Time_out">
        <div id="divModal_Comp_Time_out"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="myModal_Show_Image" style="z-index: 1080 !important;">
        <div id="divModal_Show_Image"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailALLShowImage">
        <div id="divModal_ALL_Show_Image"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="moduledeclarerNouveauGAB">
        <div id="divModaldeclarerNouveauGAB"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="moduleModifierGAB">
        <div id="divModalModifierGAB"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="moduleModifierATMConfirmed">
        <div id="divModalModifierATMConfirmed"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="moduleDownloadFileGAB">
        <div id="divModalDownloadFileGAB"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="moduleModifierAgence">
        <div id="divModalModifierAgence"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailjournalATM" style="z-index: 1080 !important;">
        <div id="divModaljournalATM"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailTrait_Mass">
        <div id="divModalTrait_Mass"></div>
    </div>

    <!-- The Modal -->
    <div class="modal" id="detaildeconATM">
        <div id="divModaldeconATM"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailcommandeATM">
        <div id="divModalcommandeATM"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailscreenincid">
        <div id="divModalscreenincident"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="myModalSuprimerGAB">
        <div id="divModalSuprimerGAB"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="detailVacationATM">
        <div id="divModalVacationATM"></div>
    </div>

    <!-- The Modal -->
    <div class="modal" id="moduleDashboardATM">
        <div id="divModalDashboardATM"></div>
    </div>

    <div class="modal fade" id="ajouter_Region" tabindex="-1" role="dialog" aria-labelledby="Label_ajouter_Region" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="Label_ajouter_Region">Ajouter Région  </h4>
                </div>
                <div class="modal-body">
                    <!-- Modal -->
                    <div id="Lightbox_Label_ajouter_Region">
                        <?php
                        // echo ajouter_relance_agence($_POST['id_alert']);?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                    <button type="button" class="btn btn-primary"  onClick="javascript:ajouterRegion()" data-dismiss="modal">Ajouter</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- -- -->

    <div class="modal fade" id="ajouter_Profil" tabindex="-1" role="dialog" aria-labelledby="Label_ajouter_Profil" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="Label_ajouter_Profil">Ajouter Profil  </h4>
                </div>
                <div class="modal-body">
                    <!-- Modal -->
                    <div id="Lightbox_Label_ajouter_Profil">
                        <?php
                        // echo ajouter_relance_agence($_POST['id_alert']);?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                    <button type="button" class="btn btn-primary"  onClick="javascript:ajouterProfil()" data-dismiss="modal">Ajouter</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- -- -->



    <div class="modal fade" id="ajouter_rappel_detail_3" tabindex="-1" role="dialog" aria-labelledby="Label_ajouter_rappel_detail" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="Label_ajouter_rappel_detail"><?php echo $lang['add_rel'];?> </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">
                    <!-- Modal -->
                    <div id="Lightbox_modifier_rappel_detail_prestataire">

                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo $lang['close'];?></button>
                    <button type="button" class="btn btn-primary"  onClick="javascript:ajouter_rappel_detail_3(1)" data-dismiss="modal"><?php echo $lang['confir'];?></button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->


    <!-- - -Modifier incident Rappel detail- -->
    <div class="modal fade" id="modifier_detail_5" tabindex="-1" role="dialog" aria-labelledby="Label_modifier_detail_5" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="Label_modifier_detail_5"><?php echo $lang['mod_inc_gab'];?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>

                </div>
                <div class="modal-body">
                    <!-- Modal -->
                    <div id="Lightbox_Label_modifier_detail_5">
                        <?php // echo ajouter_relance_agence($_POST['id_alert']);?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo $lang['close'];?></button>
                    <button type="button" class="btn btn-primary"  onClick="javascript:modifier_detail_5(3)" data-dismiss="modal"><?php echo $lang['modifier'];?></button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- - -Modifier incident Rappel detail- -->

    <div class="modal fade" id="cloturer_detail_6" tabindex="-1" role="dialog" aria-labelledby="Label_cloturer_detail_6" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="Label_cloturer_detail_6"><?php echo $lang['clot_inter_gab'];?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body">
                    <!-- Modal -->
                    <div id="Lightbox_Label_cloturer_detail_6">
                        <?php // echo ajouter_relance_agence($_POST['id_alert']);?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo $lang['close'];?></button>
                    <button type="button" class="btn btn-primary"  onClick="javascript:cloturer_detail_6(4)" data-dismiss="modal"><?php echo $lang['clo_inc'];?></button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->




    <div class="modal fade" id="nouveau_appel_gab" tabindex="-1" role="dialog" aria-labelledby="Label_nouveau_appel_gab" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="Label_nouveau_appel_gab">Ajouter nouveau appel </h4>
                </div>
                <div class="modal-body">
                    <!-- Modal -->
                    <div id="Lightbox_nouveau_appel_gab">

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- - - AJOUTER DIRECTION- -->

    <!-- The Modal -->
    <div class="modal" id="ajouter_Post">
        <div id="divModal_ajouter_Post"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="Modifier_Post">
        <div id="divModal_Modifier_Post"></div>
    </div>


    <!-- - - AJOUTER RAPPORT SYNTHESE- -->

    <div class="modal fade" id="detailler_email" tabindex="-1" role="dialog" aria-labelledby="Label_email" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="Label_email">Détail</h4>
                </div>
                <div class="modal-body">
                    <!-- Modal -->
                    <div id="Lightbox_detailler_email">
                        <?php // echo ajouter_relance_agence($_POST['id_alert']);?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- - -MODIFIER DETAIL ACTION ALERTE- -->

    <!-- - ------------------------------>
    <div class="modal fade" id="mail_prestataire_declarer" tabindex="-1" role="dialog" aria-labelledby="Label_mail_prestataire_declarer" aria-hidden="true" >
        <div class="modal-dialog modal-lg" >
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="Label_mail_prestataire_declarer"> <?php echo $lang['genr_mail'];?>  </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body" >
                    <!-- Modal -->
                    <?php

                    echo ' <div id="Lightbox_mail_prestataire_declarer">        </div>';

                    // echo ajouter_relance_agence($_POST['id_alert']);?>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo $lang['close'];?></button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- - - DISPONIBILTE INTERVENTION- -->
<?php
else:
    header("location: index.php");
endif ?>  