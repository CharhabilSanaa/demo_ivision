<?php
include "lib/auth/config.php";

?>
<!DOCTYPE html>
<html lang="<?php echo $lang['lang'] ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php include 'header_star.php'; ?>
    <style type="text/css">
        * {
            margin: 0;
            padding: 0
        }

        html {
            height: 100%
        }

        /* #grad1 {
             background-color: : #9C27B0;
             background-image: linear-gradient(120deg, #FF4081, #81D4FA)
         }*/

        #form_upload_schedule {
            text-align: center;
            position: relative;
            margin-top: 20px
        }

        #form_upload_schedule fieldset .form-card {
            /*background: white;*/
            background-color: : #9C27B0;
            background-image: linear-gradient(120deg, #FF4081, #81D4FA)
            border: 0 none;
            border-radius: 0px;
            box-shadow: 0 2px 2px 2px rgba(0, 0, 0, 0.2);
            padding: 20px 40px 30px 40px;
            box-sizing: border-box;
            width: 94%;
            margin: 0 3% 20px 3%;
            position: relative
        }

        #form_upload_schedule fieldset {
            /*background: white;*/
            background-color: : #9C27B0;
            background-image: linear-gradient(120deg, #FF4081, #81D4FA)
            border: 0 none;
            border-radius: 0.5rem;
            box-sizing: border-box;
            width: 100%;
            margin: 0;
            padding-bottom: 20px;
            position: relative
        }

        #form_upload_schedule fieldset:not(:first-of-type) {
            display: none
        }

        #form_upload_schedule fieldset .form-card {
            text-align: left;
            color: #9E9E9E
        }

        #form_upload_schedule input,
        #form_upload_schedule textarea {
            padding: 0px 8px 4px 8px;
            border: none;
            border-bottom: 1px solid #ccc;
            border-radius: 0px;
            margin-bottom: 25px;
            margin-top: 2px;
            width: 100%;
            box-sizing: border-box;

            color: #2C3E50;
            font-size: 16px;
            letter-spacing: 1px
        }

        #form_upload_schedule input:focus,
        #form_upload_schedule textarea:focus {
            -moz-box-shadow: none !important;
            -webkit-box-shadow: none !important;
            box-shadow: none !important;
            border: none;
            font-weight: bold;
            border-bottom: 2px solid skyblue;
            outline-width: 0
        }

        #form_upload_schedule .action-button {
            width: 100px;
            /*background: skyblue;*/
            background-color: : #9C27B0;
            background-image: linear-gradient(120deg, #FF4081, #81D4FA)
            font-weight: bold;
            color: white;
            border: 0 none;
            border-radius: 0px;
            cursor: pointer;
            padding: 10px 5px;
            margin: 10px 5px
        }

        #form_upload_schedule .action-button:hover,
        #form_upload_schedule .action-button:focus {
            box-shadow: 0 0 0 2px white, 0 0 0 3px skyblue
        }

        #form_upload_schedule .action-button-previous {
            width: 100px;
            background: #616161;
            font-weight: bold;
            color: white;
            border: 0 none;
            border-radius: 0px;
            cursor: pointer;
            padding: 10px 5px;
            margin: 10px 5px
        }

        #form_upload_schedule .action-button-previous:hover,
        #form_upload_schedule .action-button-previous:focus {
            box-shadow: 0 0 0 2px white, 0 0 0 3px #616161
        }

        select.list-dt {
            border: none;
            outline: 0;
            border-bottom: 1px solid #ccc;
            padding: 2px 5px 3px 5px;
            margin: 2px
        }

        select.list-dt:focus {
            border-bottom: 2px solid skyblue
        }

        .card {
            border: none;
            border-radius: 0.5rem;
            position: relative
        }

        .fs-title {
            font-size: 25px;
            color: #2C3E50;
            margin-bottom: 10px;
            font-weight: bold;
            text-align: left
        }

        #progressbar {
            margin-bottom: 30px;
            overflow: hidden;
            color: lightgrey
        }

        #progressbar .active {
            color: #000000
        }

        #progressbar li {
            list-style-type: none;
            font-size: 12px;
            width: 33.3%;
            float: left;
            position: relative
        }

        #progressbar #account:before {
            font-family: FontAwesome;
            content: "\f05a"
        }

        #progressbar #personal:before {
            font-family: FontAwesome;
            content: "\f03e"
        }

        #progressbar #payment:before {
            font-family: FontAwesome;
            content: "\f115"
        }

        #progressbar #confirm:before {
            font-family: FontAwesome;
            content: "\f00c"
        }

        #progressbar li:before {
            width: 50px;
            height: 50px;
            line-height: 45px;
            display: block;
            font-size: 18px;
            color: #ffffff;
            background: lightgray;
            border-radius: 50%;
            margin: 0 auto 10px auto;
            padding: 2px
        }

        #progressbar li:after {
            content: '';
            width: 100%;
            height: 2px;
            background: lightgray;
            position: absolute;
            left: 0;
            top: 25px;
            z-index: -1
        }

        #progressbar li.active:before,
        #progressbar li.active:after {

            background-color: : #9C27B0;
            background-image: linear-gradient(120deg, #FF4081, #81D4FA)
        }

        .radio-group {
            position: relative;
            margin-bottom: 25px
        }

        .radio {
            display: inline-block;
            width: 204;
            height: 104;
            border-radius: 0;

            background-color: : #9C27B0;
            background-image: linear-gradient(120deg, #FF4081, #81D4FA)
            box-shadow: 0 2px 2px 2px rgba(0, 0, 0, 0.2);
            box-sizing: border-box;
            cursor: pointer;
            margin: 8px 2px
        }

        .radio:hover {
            box-shadow: 2px 2px 2px 2px rgba(0, 0, 0, 0.3)
        }

        .radio.selected {
            box-shadow: 1px 1px 2px 2px rgba(0, 0, 0, 0.1)
        }

        .fit-image {
            width: 100%;
            object-fit: cover
        }
    </style>

    <link href="vendors/bootstrap/fileinput/css/fileinput.css" rel="stylesheet">
    <link href="vendors/bootstrap/fileinput/css/fileinput.min.css" media="all" rel="stylesheet" type="text/css" />
    <link href="vendors/bootstrap/fileinput/css/fileinput-rtl.min.css" rel="stylesheet">

</head>
<?php

if (verif_user($_SESSION['user'],$_SESSION['mdp'])==true): ?>
    <?php if ((verif_user($_SESSION['user'],$_SESSION['mdp'])==true) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true))): ?>
        <body class="c-app">
        <?php
        include 'sidebar.php';
        $date_today= date("Y-m-d");

        if(empty($_POST['dated'])){$date_today= date("Y-m-d");}else{$date_today = $_POST['dated'];}
        if(empty($_POST['datef'])){$date_yestday= date("Y-m-d", strtotime("-1 day"));}else{$date_yestday = $_POST['datef'];}

        setlocale(LC_TIME, 'fr_FR.utf8', 'fra');
        $profil =0;
        ?>
        <div class="c-wrapper c-fixed-components">
            <?php  include 'navbar_star.php'; ?>
            <div class="c-body">
                <main class="c-main">
                    <div class="container-fluid">
                        <div class="fade-in">
                            <input type="hidden" id="hdnSession" data-value="1"/>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="start.php">I-Vision</a></li>
                                    <li class="breadcrumb-item"><a href="start.php"><?php echo $lang['bank'];?></a></li>
                                    <li class="breadcrumb-item" aria-current="page"><?php echo $lang['pooling_ej'];?></li>
                                    <li class="breadcrumb-item" aria-current="page">Schedule a download E-J</li>
                                </ol>
                            </nav>

                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <form id="form_Schedule_pub" method="post" enctype="multipart/form-data">
                                                <div class="row d-flex">

                                                    <div class="col-md-4">
                                                        <div class="panel-group">
                                                            <div class="input-group date" >
                                                                <input type="date" id="dated" name="dated" class="form-control required" value="<?php echo $date_yestday  ;  ?>" required="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="panel-group">
                                                            <div class="input-group date" >
                                                                <input type="date" id="datef" name="datef" class="form-control required" value="<?php echo $date_today;  ?>" required="">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-2 search-box">
                                                        <button class="btn btn-block btn-outline-primary rounded-pill my-2 my-sm-0" type="submit"><?php echo $lang['search'];  ?>
                                                            <svg class="c-icon float-right">
                                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-search"></use>
                                                            </svg>
                                                        </button>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <button type="button" class="btn btn-block btn-secondary  rounded-pill my-2 my-sm-0" data-toggle="modal" data-target="#exampleModalXl" title="New deployments">+</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">

                                        <div class="card-header"><i class="fa fa-align-justify"></i> <?php echo $lang['li_planig_pull'] ;?> </div>
                                        <div class="card-body">

                                            <table id="his_p_i" class="table table-responsive-sm table-hover table-outline mb-0">
                                                <thead class="thead-light">
                                                <tr>
                                                    <th class="text-center">#</th>
                                                    <th class="text-center">Schedule name</th>
                                                    <th class="text-center">Creation Date</th>
                                                    <th class="text-center">Schedule date</th>
                                                    <th class="text-center">Execution date</th>
                                                    <th class="text-center">Modify</th>
                                                </tr>
                                                </thead>

                                                <tbody id="tb_schedule_pub">

                                                <?php
                                                get_schedule_ej_pub($lang);
                                                ?>
                                                </tbody>
                                            </table>

                                            <div class="modal fade" id="exampleModalXl"  tabindex="-1" aria-labelledby="exampleModalXlLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-xl" >
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal"  aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                        </div>
                                                        <div class="modal-body">

                                                            <div class="container-fluid" id="grad1">
                                                                <div class="row justify-content-center mt-0">
                                                                    <div class="col-11 col-sm-9 col-md-7 col-lg-12 text-center p-0 mt-3 mb-2">
                                                                        <div class="card px-0 pt-4 pb-0 mt-3 mb-3">
                                                                            <h2><strong>Schedule E-J name</strong></h2>
                                                                            <p><?php echo $lang['form_field'];?></p>
                                                                            <div class="row">
                                                                                <div class="col-md-12 mx-0">
                                                                                    <form id="form_upload_schedule">

                                                                                        <ul id="progressbar">
                                                                                            <li class="active" id="account"><strong>Information</strong></li>
                                                                                            <li id="payment"><strong><?php echo $lang['terminal'];?></strong></li>
                                                                                            <li id="confirm"><strong><?php echo $lang['finish'];?></strong></li>
                                                                                        </ul>
                                                                                        <fieldset>
                                                                                            <div class="form-card">
                                                                                                <h2 class="fs-title">E-J information</h2>
                                                                                                <br>
                                                                                                <div class="mb-3 row">
                                                                                                    <label class="col-sm-2 col-form-label" for="staticEmail"></label>
                                                                                                    <div class="col-sm-10">
                                                                                                        <input type="text" id="nom_dépl" name="nom_dépl" class="form-control required" placeholder="Pulling name" required="required" />
                                                                                                    </div>
                                                                                                </div>

                                                                                                <div class="mb-3 row">
                                                                                                    <label class="col-sm-2 col-form-label" for="staticEmail"><?php echo $lang['date_exc'];?></label>

                                                                                                    <div class="col-sm-5">
                                                                                                        <input type="time" id="time_dep" name="time_dep" value="07:00" >
                                                                                                    </div>
                                                                                                    <div class="col-sm-5">
                                                                                                        <select class="list-dt" id="month" name="frenq_date">
                                                                                                            <option value="Daily" selected>Daily</option>
                                                                                                            <option value="Weekly">Weekly</option>
                                                                                                            <option value="Monthly">Monthly</option>
                                                                                                        </select>
                                                                                                    </div>
                                                                                                </div>

                                                                                                <div class="mb-3 row">
                                                                                                    <label class="col-sm-2 col-form-label" for="staticEmail">Description</label>
                                                                                                    <div class="col-sm-10">
                                                                                                        <textarea class="form-control" id="description_dépl" name="description_dépl" rows="7" placeholder="Description ..."></textarea>
                                                                                                    </div>
                                                                                                </div>

                                                                                            </div>
                                                                                            <button type="button" name="next" class="next btn btn-secondary"><?php echo $lang['next_step'];?></button>
                                                                                        </fieldset>
                                                                                        <fieldset>
                                                                                            <div class="form-card">
                                                                                                <h2 class="fs-title"><?php echo $lang['atm_list'];?></h2>
                                                                                                <br>
                                                                                                <div class="mb-3 row">
                                                                                                    <label class="col-sm-2 col-form-label" for="profil[]"><?php echo $lang['atm_profil'];?></label>
                                                                                                    <div class="col-sm-10">
                                                                                                        <select id="profil[]" class="form-control" onchange="javascript:get_atm_new_comp(<?php echo $profil ;?>)" required>
                                                                                                            <?php get_select_profile();?>
                                                                                                        </select>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="mb-3 row">

                                                                                                    <div class="col-sm-12">
                                                                                                        <table id="tbl_prof" class="table table-responsive-sm table-hover table-outline mb-0">
                                                                                                            <thead class="thead-light">
                                                                                                            <th class="text-center">
                                                                                                                <div class="form-check">
                                                                                                                </div>
                                                                                                                <input class="checkbox" type="checkbox" id="checkAddcompaign" onclick="chackaddcomp()" value="0">
                                                                                                            </th>
                                                                                                            <th class="text-center">ID</th>
                                                                                                            <th class="text-center"><?php echo $lang['atm_name'];?></th>
                                                                                                            <th class="text-center"><?php echo $lang['atm_id'];?></th>
                                                                                                            <th class="text-center"><?php echo $lang['atm_profil'];?></th>
                                                                                                            <th class="text-center"><?php echo $lang['dat_der_dep'];?></th>
                                                                                                            <th class="text-center"><?php echo $lang['stat_dep'];?></th>
                                                                                                            </thead>
                                                                                                            <tbody id="tbl_prof_tbody">
                                                                                                            <?php get_atm_new_comp($profil); ?>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>

                                                                                            <button type="button" name="previous" class="previous btn btn-secondary" ><?php echo $lang['previous'];?></button>
                                                                                            <button type="button" name="next" class="next btn btn-secondary" ><?php echo $lang['next_step'];?></button>
                                                                                        </fieldset>
                                                                                        <fieldset id="step-4">
                                                                                            <div class="form-card">
                                                                                                <div class="col-xs-12">
                                                                                                    <div class="col-md-12">
                                                                                                        <br>
                                                                                                        <br>
                                                                                                        <h3>Confirmation</h3>
                                                                                                        <p><?php echo $lang['conf_dep'];?>. </p>
                                                                                                        <button type="submit" class="btn btn-primary btn-info-full"><?php echo $lang['send'];?></button>
                                                                                                        <br>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <button type="button" name="previous" class="previous btn btn-secondary" ><?php echo $lang['previous'];?></button>

                                                                                        </fieldset>
                                                                                    </form>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <div class="modal-footer" style="background-color:#e9ecef;color:#2b3449;">
                                                            <ul class="list-inline pull-right">
                                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.col-lg-4 (nested) -->

                                <!-- /.col-lg-8 (nested) -->
                            </div>

                        </div>
                    </div>
                </main>
            </div>

        </div>

        <?php
        //header NAV Bar
        include 'footer.php';
        ?>
        <script>
            $(document).ready(function(){

                //  $("#datedep").val(new Date().toJSON().slice(0,19) );

                var current_fs, next_fs, previous_fs; //fieldsets
                var opacity;

                $(".next").click(function(){

                    current_fs = $(this).parent();
                    next_fs = $(this).parent().next();

//Add Class Active
                    $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

//show the next fieldset
                    next_fs.show();
//hide the current fieldset with style
                    current_fs.animate({opacity: 0}, {
                        step: function(now) {
// for making fielset appear animation
                            opacity = 1 - now;

                            current_fs.css({
                                'display': 'none',
                                'position': 'relative'
                            });
                            next_fs.css({'opacity': opacity});
                        },
                        duration: 600
                    });
                });

                $(".previous").click(function(){

                    current_fs = $(this).parent();
                    previous_fs = $(this).parent().prev();

                    //Remove class active
                    $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

                    //show the previous fieldset
                    previous_fs.show();

//hide the current fieldset with style
                    current_fs.animate({opacity: 0}, {
                        step: function(now) {
// for making fielset appear animation
                            opacity = 1 - now;

                            current_fs.css({
                                'display': 'none',
                                'position': 'relative'
                            });
                            previous_fs.css({'opacity': opacity});
                        },
                        duration: 600
                    });
                });

                $('.radio-group .radio').click(function(){
                    $(this).parent().find('.radio').removeClass('selected');
                    $(this).addClass('selected');
                });

                $(".submit").click(function(){
                    return false;
                })

            });
        </script>

        <script>

            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            function get_comp_atm(profil,id_compaign,idatms) {
                token = localStorage.getItem('token');
                var xhr = getXhr();
                // On défini ce qu'on va faire quand on aura la réponse

                xhr.onreadystatechange = function(){
                    // On ne fait quelque chose que si on a tout reçu et que le serveur est ok
                    if(xhr.readyState == 1)
                    {
                        //document.getElementById("listedepeche").className="invisible";
                        //document.getElementById("message").className="tumevois";

                    }
                    if(xhr.readyState == 4 && xhr.status == 200)
                    {
                        document.getElementById("tbody_tbl_gab_prof"+id_compaign).innerHTML=xhr.responseText;
                    }

                }
                // Ici on va voir comment faire du post
                xhr.open("POST","ajax/ajaxAchraf.php",true);

                // ne pas oublier ça pour le post
                xhr.setRequestHeader('x-access-token',token);
                xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                xhr.send("function=get_atm_comp&profil="+profil.value+
                    '&idatms='+idatms+
                    '&id_compaign='+id_compaign);


            }
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            function chackallcomp(divid) {
                var select_all = document.getElementById("checkAllcompaign"+divid); //select all checkbox
                var checkboxes = document.getElementsByClassName("checkbox"+divid); //checkbox items

//select all checkboxes
                select_all.addEventListener("change", function(e){
                    for (i = 0; i < checkboxes.length; i++)
                    {
                        checkboxes[i].checked = select_all.checked;
                    }
                });


                for (var i = 0; i < checkboxes.length; i++) {
                    checkboxes[i].addEventListener('change', function(e){ //".checkbox" change
                        //uncheck "select all", if one of the listed checkbox item is unchecked
                        if(this.checked == false){
                            select_all.checked = false;

                        }
                        //check "select all" if all checkbox items are checked
                        if(document.querySelectorAll('.checkbox:checked').length == checkboxes.length){
                            select_all.checked = true;
                        }
                    });
                }

            }
            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            function chackaddcomp() {
                var select_all = document.getElementById("checkAddcompaign"); //select all checkbox
                var checkboxes = document.getElementsByClassName("checkbox"); //checkbox items

//select all checkboxes
                select_all.addEventListener("change", function(e){
                    for (i = 0; i < checkboxes.length; i++) {
                        checkboxes[i].checked = select_all.checked;
                    }
                });


                for (var i = 0; i < checkboxes.length; i++)
                {
                    checkboxes[i].addEventListener('change', function(e){ //".checkbox" change
                        //uncheck "select all", if one of the listed checkbox item is unchecked
                        if(this.checked == false){
                            select_all.checked = false;
                        }
                        //check "select all" if all checkbox items are checked
                        if(document.querySelectorAll('.checkbox:checked').length == checkboxes.length){
                            select_all.checked = true;
                        }
                    });
                }

            }

            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            function UpdateScheduled (id_compaign)
            {
                token = localStorage.getItem('token');
                var formData = new FormData();
                formData.append('function', 'updatescheduled');
                var searchIDs = $("#tbl_prof"+id_compaign+" input:checkbox:checked").map(function(){
                    return $(this).val();
                }).get();

                var nom_compagne = $("#nom_compagne"+id_compaign).map(function(){
                    return $(this).val();
                }).get();
                var datedep = $("#time_dep_dep"+id_compaign).map(function(){
                    return $(this).val();
                }).get();
                var frequenxe = $("#month_dep"+id_compaign).map(function(){
                    return $(this).val();
                }).get();
                var checkbox_compagne = $("#checkbox"+id_compaign).map(function(){
                    return $(this).val();
                }).get();

                formData.append('id_compaign', id_compaign);
                formData.append('nom_compagne', nom_compagne);
                formData.append('datedep', datedep);
                formData.append('frequenxe', frequenxe);
                formData.append('idatms', searchIDs);
                formData.append('checkbox_compagne', checkbox_compagne);
                $.ajax({
                    type: "POST",
                    headers: {
                        'x-access-token': token
                    },
                    url: "ajax/ajaxAchraf.php",
                    data: formData,
                    cache       : false,
                    contentType : false,
                    processData : false,
                    success: function(data)
                    {

                        var messageAlert = 'alert-' + data.type;
                        var messageText = data.message;
                        var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
                        if (messageAlert && messageText) {
                            $("#form_modif_withrawel_rate"+id_compaign).html(alertBox);
                        }
                        $( "#td_" +id_compaign ).load(window.location.href + " #td_" +id_compaign );
                    },
                    error: function (data)
                    {
                        var messageAlert = 'alert-' + data.type;
                        var messageText = data.message;
                        var alertBox = '<div class="col-sm-12" ><br><div class="alert '+ messageAlert + '" align="center"><strong>' + messageText + '</strong></div>';
                        if (messageAlert && messageText) {
                            $("#form_detail_Compagnes_pub"+id_compaign).html(alertBox);
                        }
                    }
                });
            }
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            function Updatechek(id_compaign)
            {

                var checkbox_compagne = $("#checkbox"+id_compaign).map(function(){
                    return $(this).val();
                }).get();


                if(checkbox_compagne == 2)
                {
                    $("#checkbox"+id_compaign).val("0");
                    $("#nom_compagne"+id_compaign ).prop("disabled", false );
                    $("#time_dep_dep"+id_compaign ).prop("disabled", false );
                    $("#month_dep"+id_compaign ).prop("disabled", false );
                    $("#profgab"+id_compaign ).prop("disabled", false );
                    $("#tbl_prof"+id_compaign ).prop("disabled", false );
                    $("#checkAllcompaign"+id_compaign ).prop("disabled", false );

                    $("#div_profgab"+id_compaign ).prop("disabled", false );

                    $("input:checkbox[class='checkbox"+id_compaign+"']").prop("disabled", false );

                    //  $(".dropdown-toggle").prop("disabled", false);
                }
                else
                {
                    $("#checkbox"+id_compaign).val("2");
                    $( "#nom_compagne"+id_compaign ).prop( "disabled", true);
                    $("#time_dep_dep"+id_compaign ).prop("disabled", true );
                    $("#month_dep"+id_compaign ).prop("disabled", true );
                    $("#profgab"+id_compaign ).prop("disabled", true );
                    $("#tbl_prof"+id_compaign ).prop("disabled", true );
                    $("#checkAllcompaign"+id_compaign ).prop("disabled", true );

                    $("#div_profgab"+id_compaign ).prop("disabled", true );

                    $("input:checkbox[class='checkbox"+id_compaign+"']").prop("disabled", true );

                    // $(".dropdown-toggle").prop("disabled", true);
                }
            }

            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        </script>


        <script src="vendors/bootstrap/fileinput/js/plugins/piexif.min.js"></script>
        <script src="vendors/bootstrap/fileinput/js/plugins/sortable.min.js"></script>
        <script src="vendors/bootstrap/fileinput/js/plugins/purify.min.js"></script>
        <script src="vendors/bootstrap/fileinput/js/fileinput.min.js"></script>
        <script src="vendors/bootstrap/fileinput/js/fileinput.js"></script>
        <script id="dsq-count-scr" src="vendors/bootstrap/fileinput/js/count.js" async></script>
        <script src="vendors/bootstrap/fileinput/js/locales/fr.js"></script>

        <script>
            $(document).ready(function(){

                // $("#uploadimage").fileinput({'showUpload':false, 'previewFileType':'any'});
                $("#uploadimage").fileinput({
                    language: 'en',
                    theme: 'fas',
                    uploadUrl: '#',
                    showUpload: false,
                    showCaption: false,
                    maxFileCount: 20,
                    maxFileSize: 5120,
                    required: true,
                    allowedFileTypes: ["image"],
                    browseClass: "btn btn-dark",
                    fileActionSettings: {
                        showUpload: false,
                        showIndicatorNew: false
                    },


                });
                var navListItems = $('div.setup-panel div a'),
                    allWells = $('.setup-content'),
                    allNextBtn = $('.nextBtn'),
                    allPrevBtn = $('.prevBtn');

                allWells.hide();

                navListItems.click(function (e) {
                    e.preventDefault();
                    var $target = $($(this).attr('href')),
                        $item = $(this);

                    if (!$item.hasClass('disabled')) {
                        navListItems.removeClass('btn-primary').addClass('btn-default');
                        $item.addClass('btn-primary');
                        allWells.hide();
                        $target.show();
                        $target.find('input:eq(0)').focus();
                    }
                });

                allNextBtn.click(function(){
                    var curStep = $(this).closest(".setup-content"),
                        curStepBtn = curStep.attr("id"),
                        nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
                        curInputs = curStep.find("input[type='text'],input[type='file'],input[type='url']"),
                        isValid = true;

                    $(".form-group").removeClass("has-error");
                    for(var i=0; i<curInputs.length; i++){
                        if (!curInputs[i].validity.valid){
                            isValid = false;
                            $(curInputs[i]).closest(".form-group").addClass("has-error");
                        }
                    }

                    if (isValid)
                        nextStepWizard.removeAttr('disabled').trigger('click');
                });
                allPrevBtn.click(function(){

                    var curStep = $(this).closest(".setup-content"),

                        curStepBtn = curStep.attr("id"),

                        prevStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().prev().children("a");

                    prevStepWizard.removeAttr('disabled').trigger('click');

                });

                $('div.setup-panel div a.btn-primary').trigger('click');

            });
        </script>

        </body>

    <?php
    else:
        header("location: start.php");
    endif ?>
<?php
else:
    header("location: index.php");
endif ?>
</html>
