<?php
// session_start();
    if ((isset($_SESSION['user']))&&(verif_user($_SESSION['user'],$_SESSION['mdp'])==true)):
        if (verif_habilitation($_SESSION['autorisation_projet'],24)==true):
  ?>
        <!-- Navigation-->
            <div class="c-sidebar c-sidebar-dark c-sidebar-fixed c-sidebar-lg-show" id="sidebar">

                <ul class="c-sidebar-nav">
                    <div class="c-sidebar-brand c-sidebar-nav-title d-lg-down-none">
                        <a class="navbar-brand" href="start.php"> &nbsp; <img style="height: 50px"  src="img/Logo Blanc 110.png" alt="logo IPRC " ></a>
                    </div>
                    <li class="c-sidebar-nav-title ">
                        <div class="form-inline" id="frm_search_atm" >
                            <ul class="navbar-nav mr-auto form-inline">
                                <li class="nav-item dropdown">
                                    <div class="row" style="margin-left:0px;">
                                        <div class="search-box form-inline ">
                                            <input id="search_input" class="form-control mr-sm-2" autocomplete="off" type="search" placeholder="<?php echo $lang['search'] ?>" required/>
                                            <div class="result"></div>
                                        </div>
                                        <button type="button" class="btn btn-default" onclick="javascript:search_atm()">
                                            <i class="cil-send" style="color:#ffffff;font-size: 130%"></i>
                                        </button>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </li>

                    <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],1)==true): ?>
                        <li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="start.php" title="<?php echo $lang['home'] ?>">
                                <svg class="c-sidebar-nav-icon">
                                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-home"></use>
                                </svg> <?php echo $lang['home'] ?></a></li>
                    <?php endif ?>

                    <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],1)==true): ?>
                        <li class="c-sidebar-nav-item c-sidebar-nav-dropdown"><a class="c-sidebar-nav-dropdown-toggle" >
                                <svg class="c-sidebar-nav-icon">
                                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-monitor"></use>
                                </svg> <?php echo $lang['supervision'] ?></a>
                            <ul class="c-sidebar-nav-dropdown-items">
                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],10)==true): ?><li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="horsServiceV2.php"><?php echo $lang['gab_hors_ser'] ?></a></li><?php endif ?>

                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],19)==true): ?><li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="gab_deconnect.php"><?php echo $lang['gab_decc'] ?></a></li><?php endif ?>

                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],11)==true): ?><li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="gab_passif.php"><?php echo $lang['gab_pass'] ?></a></li><?php endif ?>

                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],13)==true): ?><li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="etat_parcGAB.php"><?php echo $lang['park_gab'] ?></a></li><?php endif ?>

                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],22)==true): ?><li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="declarer.php"><?php echo $lang['declar'] ?></a></li><?php endif ?>
                            </ul>
                        </li>
                    <?php endif ?>

                    <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],5)==true): ?>
                        <li class="c-sidebar-nav-item c-sidebar-nav-dropdown"><a class="c-sidebar-nav-dropdown-toggle" >
                                <svg class="c-sidebar-nav-icon">
                                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-reload"></use>
                                </svg> <?php echo $lang['suivi_inci'] ?></a>
                            <ul class="c-sidebar-nav-dropdown-items">
                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],20)==true): ?><li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="rappelAlerte.php"><?php echo $lang['relance'] ?></a></li><?php endif ?>

                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],21)==true): ?><li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="AlerteOuvert.php"><?php echo $lang['incid_ouv'] ?></a></li><?php endif ?>

                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],2)==true): ?><li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="suiviIncident.php"><?php echo $lang['hist_inci'] ?></a></li><?php endif ?>

                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],40)==true): ?><li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="historique_redemarrage.php"><?php echo $lang['hist_redem'] ?></a></li><?php endif ?>

                            </ul>
                        </li>
                    <?php endif ?>

                    <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],23)==true): ?>
                        <li class="c-sidebar-nav-dropdown"><a class="c-sidebar-nav-dropdown-toggle" href="#" >
                                <svg class="c-sidebar-nav-icon">
                                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-bullhorn"></use>
                                </svg> <?php echo $lang['comp_pub'] ?></a>
                            <ul class="c-sidebar-nav-dropdown-items">
                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],24)==true): ?>
                                    <li class="c-sidebar-nav-item">
                                        <a class="c-sidebar-nav-link" href="deploiement_compagne_pub.php">
                                            <!--<svg class="c-sidebar-nav-icon">
                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-layers"></use>
                                            </svg>--> <?php echo $lang['planig_comp'] ?></a></li>
                                <?php endif ?>

                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],25)==true): ?>
                                    <li class="c-sidebar-nav-dropdown">
                                        <a class="c-sidebar-nav-dropdown-toggle" href="#">
                                            <svg class="c-sidebar-nav-icon">
                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-cloud-upload"></use>
                                            </svg><?php echo $lang['man_dep'] ?></a>
                                        <ul class="c-sidebar-nav-dropdown-items">
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],27)==true): ?><a href="refairedepimage.php"   class="c-sidebar-nav-link" ><?php echo $lang['dep_ech'] ?></a><?php endif ?>
                                            </li>
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],26)==true): ?>  <a href="selectimagepofil.php"  class="c-sidebar-nav-link"><?php echo $lang['telech_img'] ?></a><?php endif ?>
                                            </li>
                                        </ul>
                                    </li>
                                <?php endif ?>
                             </ul>
                        </li>
                    <?php endif ?>

                    <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],23)==true): ?>
                        <li class="c-sidebar-nav-dropdown"><a class="c-sidebar-nav-dropdown-toggle" href="#" >
                                <svg class="c-sidebar-nav-icon">
                                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-cloud-download"></use>
                                </svg> <?php echo $lang['pooling_ej'] ?></a>
                            <ul class="c-sidebar-nav-dropdown-items">
                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],24)==true): ?>
                                    <li class="c-sidebar-nav-item">
                                        <a class="c-sidebar-nav-link" href="pull_ej.php">
                                             <?php echo $lang['downd_ej'] ?></a></li>
                                    <li class="c-sidebar-nav-item">
                                        <a class="c-sidebar-nav-link" href="schedule_pull_ej.php">
                                            <?php echo $lang['planig_pull']; ?></a></li>
                                <?php endif ?>

                            </ul>
                        </li>
                    <?php endif ?>

                    <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],4)==true): ?>
                        <li class="c-sidebar-nav-dropdown"><a class="c-sidebar-nav-dropdown-toggle" href="#" >
                                <svg class="c-sidebar-nav-icon">
                                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-settings"></use>
                                </svg><?php echo $lang['administrate'];?></a>
                            <ul class="c-sidebar-nav-dropdown-items">

                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],28)==true): ?>
                                    <li class="c-sidebar-nav-dropdown">
                                        <a class="c-sidebar-nav-dropdown-toggle" href="#">
                                            <svg class="c-sidebar-nav-icon">
                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-color-border"></use>
                                            </svg><?php echo $lang['admin_gab'] ?></a>
                                        <ul class="c-sidebar-nav-dropdown-items">
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],27)==true): ?><a href="suiviGAB.php"   class="c-sidebar-nav-link" ><?php echo $lang['park_gab_admin'] ?></a><?php endif ?>
                                            </li>
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],26)==true): ?>  <a href="parametrage.php"  class="c-sidebar-nav-link"><?php echo $lang['incid_sett'] ?></a><?php endif ?>
                                            </li>

                                        </ul>
                                    </li>
                                <?php endif ?>
                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],29)==true): ?>
                                    <li class="c-sidebar-nav-dropdown">
                                        <a class="c-sidebar-nav-dropdown-toggle" href="#">
                                            <svg class="c-sidebar-nav-icon">
                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-info"></use>
                                            </svg><?php echo $lang['info_atm'];?></a>
                                        <ul class="c-sidebar-nav-dropdown-items">
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],14)==true): ?><a href="listeGAB.php"   class="c-sidebar-nav-link" ><?php echo $lang['atm_list'];?></a><?php endif ?>
                                            </li>
                                            <!--<li class="c-sidebar-nav-item">
                                                <?php /*if (verif_habilitation($_SESSION['habilitation_backoffice'],15)==true): */?>  <a href="region.php"  class="c-sidebar-nav-link"><?php /*echo $lang['reg_pro'];*/?></a><?php /*endif */?>
                                            </li>-->

                                        </ul>
                                    </li>
                                <?php endif ?>
                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],30)==true): ?>
                                    <li class="c-sidebar-nav-dropdown">
                                        <a class="c-sidebar-nav-dropdown-toggle" href="#">
                                            <svg class="c-sidebar-nav-icon">
                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-cloud-download"></use>
                                            </svg><?php echo $lang['dep_cli'];?></a>
                                        <ul class="c-sidebar-nav-dropdown-items">
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],35)==true): ?><a href="selectbinaireprofil.php"   class="c-sidebar-nav-link" ><?php echo $lang['tel_clien'];?></a><?php endif ?>
                                            </li>
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],36)==true): ?>  <a href="selectbinaireprofil_echoues.php"  class="c-sidebar-nav-link"><?php echo $lang['tel_clien_ech'];?></a><?php endif ?>
                                            </li>
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],37)==true): ?>  <a href="suiviExecutionClient.php"  class="c-sidebar-nav-link"><?php echo $lang['suiv_vers'];?></a><?php endif ?>
                                            </li>
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],38)==true): ?>  <a href="gestioncommandes.php"  class="c-sidebar-nav-link"><?php echo $lang['chang_conf'];?></a><?php endif ?>
                                            </li>
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],39)==true): ?>  <a href="arretClients.php"  class="c-sidebar-nav-link"><?php echo $lang['arr_enc_clint'];?></a><?php endif ?>
                                            </li>

                                        </ul>
                                    </li>
                                <?php endif ?>
                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],38)==true): ?>
                                    <li class="c-sidebar-nav-item">
                                        <a class="c-sidebar-nav-link" href="gestioncommandes.php">
                                            <svg class="c-sidebar-nav-icon">
                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-layers"></use>
                                            </svg><?php echo $lang['gest_cmd'];?></a>
                                    </li>
                                <?php endif ?>
                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],8)==true): ?>
                                    <li class="c-sidebar-nav-dropdown">
                                        <a class="c-sidebar-nav-dropdown-toggle" href="#">
                                            <svg class="c-sidebar-nav-icon">
                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-history"></use>
                                            </svg><?php echo $lang['hist'];?></a>
                                        <ul class="c-sidebar-nav-dropdown-items">
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],41)==true): ?><a href="historique_deploiement.php"   class="c-sidebar-nav-link" ><?php echo $lang['hist_dep_imd'];?></a><?php endif ?>
                                            </li>
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],42)==true): ?>  <a href="historique_dep_binaire.php"  class="c-sidebar-nav-link"><?php echo $lang['hist_dep_bnr'];?></a><?php endif ?>
                                            </li>
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],43)==true): ?>  <a href="historique_monitor_server.php"  class="c-sidebar-nav-link"><?php echo $lang['hist_exc_srv'];?></a><?php endif ?>
                                            </li>
                                            <li class="c-sidebar-nav-item">
                                                <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],43)==true): ?>  <a href="moyen_dispo_gab.php"  class="c-sidebar-nav-link"><?php echo $lang['disp_gab'];?></a><?php endif ?>
                                            </li>
                                        </ul>
                                    </li>
                                <?php endif ?>

                            </ul>

                        </li>
                        <?php if (verif_habilitation($_SESSION['habilitation_backoffice'],5)==true): ?>
                            <!--<li class="c-sidebar-nav-item c-sidebar-nav-dropdown"><a class="c-sidebar-nav-dropdown-toggle" >
                                    <svg class="c-sidebar-nav-icon">
                                        <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-graph"></use>
                                    </svg> <?php /*echo $lang['titre_reppot'];*/?></a>
                                <ul class="c-sidebar-nav-dropdown-items">
                                    <?php /*if (verif_habilitation($_SESSION['habilitation_backoffice'],20)==true): */?><li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="https://192.168.1.110/backoffice/demo-monitoring/report_daily.php"><?php /*echo $lang['titre_page_reppot'];*/?></a></li><?php /*endif */?>
                                    <?php /*if (verif_habilitation($_SESSION['habilitation_backoffice'],20)==true): */?><li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="https://192.168.1.110/backoffice/demo-monitoring/report_by_date.php"><?php /*echo $lang['titre_page_reppot2'];*/?></a></li><?php /*endif */?>
                                </ul>
                            </li>-->
                        <?php endif ?>
                        <li class="c-sidebar-nav-dropdown">
                            <a class="c-sidebar-nav-dropdown-toggle" href="#">
                                <svg class="c-sidebar-nav-icon">
                                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-account-logout"></use>
                                </svg><?php echo $lang['Logout'];?></a>
                            <ul class="c-sidebar-nav-dropdown-items">
                                <li class="c-sidebar-nav-item">
                                    <a onclick="logout()" href="logout.php" class="c-sidebar-nav-link" ><?php echo $lang['page_conn'];?></a>
                                </li>


                            </ul>
                        </li>
                    <?php endif ?>

                </ul>
                <button class="c-sidebar-minimizer c-class-toggler" type="button" data-target="_parent" data-class="c-sidebar-minimized"></button>
            </div>
    <?php
    endif
    ?>

<?php else:
    header("location: index.php");
endif

?>