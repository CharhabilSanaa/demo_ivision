<?php

if ((isset($_SESSION['user']))&&(verif_user($_SESSION['user'],$_SESSION['mdp'])==true)):
    if (verif_habilitation($_SESSION['autorisation_projet'],24)==true):

        $mystring = $_SERVER['REQUEST_URI'];
        $findme   = '?';
        $find_get   = 'lang=';
        $pos = strpos($_SERVER['REQUEST_URI'], $findme);
        $pos_get  = strpos($_SERVER['REQUEST_URI'], $find_get);

        if ($pos === false)
        {
            $var_lien= $_SERVER['REQUEST_URI']."?lang=";
        }
        else
        {
            if ($pos_get==false)
            {
                $var_lien= $_SERVER['REQUEST_URI']."&lang=";
            }
            else
            {
                $var_lien=explode('lang=', $_SERVER['REQUEST_URI'], 2)[0]."lang=";
            }
        }
        ?>
        <header class="c-header c-header-light c-header-fixed c-header-with-subheader">
            <button class="c-header-toggler c-class-toggler d-lg-none mfe-auto" type="button" data-target="#sidebar" data-class="c-sidebar-show">
                <svg class="c-icon c-icon-lg">
                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-menu"></use>
                </svg>
            </button><a class="c-header-brand d-lg-none" href="start.php">
                <img style="height: 50px"  src="img/Logo noir 110.png" alt="logo IPRC " ></a>
            <button class="c-header-toggler c-class-toggler mfs-3 d-md-down-none" type="button" data-target="#sidebar" data-class="c-sidebar-lg-show" responsive="true">
                <svg class="c-icon c-icon-lg">
                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-menu"></use>
                </svg>
            </button>
            <div class="c-header-nav ml-auto">
                <h4 class="page-header"><?php echo $lang['title'] ?></h4>
            </div>

            <ul class="c-header-nav ml-auto">

                <li class="c-header-nav-item dropdown"><a class="c-header-nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                        <div class="c-avatar">
                            <?php
                            if(return_sexe_user($_SESSION['id_utilisateur'])==="M")
                            {
                                echo '<img class="c-avatar-img" src="assets/img/avatars/13.jpg" alt="'.$_SESSION['user'].'">';
                            }
                            else
                            {
                                echo '<img class="c-avatar-img" src="assets/img/avatars/12.jpg" alt="'.$_SESSION['user'].'">';
                            }
                            ?>

                            <span class="c-avatar-status bg-success"></span>
                        </div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right pt-0">
                        <div class="dropdown-header bg-light py-2"><strong><?php echo $lang['language'] ?></strong></div>
                        <h5 class="card-title text-center mb-1 mt-1" align="center">

                            <a style="text-decoration: none;" href="<?php echo $var_lien?>en">
                                <svg class="c-icon c-icon-xl">
                                    <use xlink:href="vendors/@coreui/icons/svg/flag.svg#cif-gb"></use>
                                </svg>
                            </a>
                            |
                            <a style="text-decoration: none;" href="<?php echo $var_lien?>fr">
                                <svg class="c-icon c-icon-xl">
                                    <use xlink:href="vendors/@coreui/icons/svg/flag.svg#cif-fr"></use>
                                </svg>
                            </a>
                        </h5>
                        <div class="dropdown-header bg-light py-2"><strong><?php echo $lang['Account'] ?></strong></div>
                        <a class="dropdown-item" onclick="logout()" href="logout.php">
                            <svg class="c-icon mr-2">
                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-account-logout"></use>
                            </svg> <?php echo $lang['Logout'] ?></a>


                    </div>
                </li>
            </ul>

        </header>
    <?php
    endif
    ?>

<?php else:
    header("location: index.php");
endif

?>