<?php
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//include "lib/auth/config.php";
function getAllimage()
{
    $connexion=ma_db_connexion();
    $idatmm=$_GET['id_atm'];
    $SQL = "SELECT `images`.`id_atm`,`images`.`name_picture`,`images`.`path`,`images`.`date_insertion`,`images`.`date_deploiement`,`state_image`.`description`,`images`.`state`
            FROM `images`,`state_image` WHERE `images`.`state`= `state_image`.`id` 
            AND `images`.`id_atm` = $idatmm ORDER BY `images`.`date_insertion` DESC LIMIT 20";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");

    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 100: ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 100 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $datedepl= $row["date_deploiement"];
                if(($datedepl=="0000-00-00 00:00:00") || (($row["state"]  != "0") && ($row["state"] != "2") && ($row["state"] != "1" )))
                {
                    $datedepl="---";
                }
                if ($row["state"]  == "0" || $row["state"] == "2")
                {
                    echo '<tr style="padding: 3px">
                    <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                    <td style="padding: 3px">' . $row["id_atm"] . '</td>
                    <td style="padding: 3px">' . $row["name_picture"] . '</td>
                    <td style="padding: 3px">' . $row["path"] . '</td>
                    <td style="padding: 3px" align="center">' . $row["date_insertion"] . '</td>
                    <td style="padding: 3px" align="center">' . $datedepl . '</td>
                    <td style="padding: 3px">' . $row["description"] . '<span class="cil-cloud-upload" style="color: #5CB85C;" aria-hidden="false"></span> </td>
                    </tr>';
                }
                else if ($row["state"] == "1" )
                {
                    echo '<tr style="padding: 3px">
                    <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                    <td style="padding: 3px">' . $row["id_atm"] . '</td>
                    <td style="padding: 3px">' . $row["name_picture"] . '</td>
                    <td style="padding: 3px">' . $row["path"] . '</td>
                    <td style="padding: 3px" align="center">' . $row["date_insertion"] . '</td>
                    <td style="padding: 3px" align="center">' . $datedepl . '</td>
                    <td style="padding: 3px">' . $row["description"] . '<span class="cil-cloud-upload" style="color: #FFA07A;" aria-hidden="false"></span> </td>
                    </tr>';
                }
                else
                {
                    echo '<tr style="padding: 3px">
                    <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                    <td style="padding: 3px">' . $row["id_atm"] . '</td>
                    <td style="padding: 3px">' . $row["name_picture"] . '</td>
                    <td style="padding: 3px">' . $row["path"] . '</td>
                    <td style="padding: 3px" align="center">' . $row["date_insertion"] . '</td>
                    <td style="padding: 3px" align="center">' . $datedepl . '</td>
                    <td style="padding: 3px">' . $row["description"] . '<span class="cil-cloud-upload" style="color: #FF0000;" aria-hidden="false"></span> </td>
                    </tr>';
                }
                $g++;
            }
        }
        else
        {
            echo'<tr>
            <td colspan="7" align="center"></td>
		    </tr> ';
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

}
function getalljournalATM($id_atm)
{
    $libelle_type_return = 'libelle_type_return';
    if ($_SESSION['lang']== 'en')
    {
        $libelle_type_return = 'libelle_type_return_en';
    }
    include("../pagination.php");
    echo ' 	<tbody>';
    $connexion=ma_db_connexion();
    $SQL1 = "SELECT `journal_contents_ncr`.`id_atm`,`journal_contents_ncr`.`dateligne`,`list_events`.`name_event`,`type_transaction`.`libelle_type`,
 `type_return_transaction`.".$libelle_type_return." as libelle_type_return, `journal_contents_ncr`.`amount_withdraw`,`type_card_returned`.`libelle_card_returned`,
 `type_card_insert`.`libelle_type_card_insert`, `journal_contents_ncr`.`type_return_motif` FROM `journal_contents_ncr`,`list_events`,`type_transaction`,`type_return_transaction`,
 `type_card_returned`, `type_card_insert` WHERE `journal_contents_ncr`.`id_atm` = '" . mysqli_real_escape_string($connexion,$id_atm) . "' AND `journal_contents_ncr`.`type_transaction`= `type_transaction`.`id` 
 AND `journal_contents_ncr`.`type_return_transaction` = `type_return_transaction`.`id` AND `journal_contents_ncr`.`type_card_returned` = `type_card_returned`.`id` 
 AND `journal_contents_ncr`.`type_card_insert` = `type_card_insert`.`id` AND `journal_contents_ncr`.`id_event` = `list_events`.`id_event` ORDER BY `journal_contents_ncr`.`dateligne` DESC LIMIT 30";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 101:  ".$SQL1."    ".mysqli_error($connexion));
        die('ERREUR QUERY 101 !');
    }
    if($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $date_evenement=$row["dateligne"];
                $statut_evenement=$row["name_event"];
                $type_authentification=$row["libelle_type_card_insert"];
                $type_transaction=$row["libelle_type"];
                $return_transaction=$row["libelle_card_returned"];
                $statut_retour=$row["libelle_type_return"];
                $return_motif_rejet=$row["type_return_motif"];
                $montant_retirer=number_format($row["amount_withdraw"],2,'.',','). " MGA";



                if ($type_authentification== "Indefinie" || $type_authentification == "" || $type_authentification == "Indéfinie" || $type_authentification == "Indefined")
                {
                    $type_authentification = "---";
                }
                if ($type_transaction == "Indefinie" || $type_transaction == "" || $type_transaction == "Indéfinie" || $type_transaction == "Indefined") {
                    $type_transaction = "---";
                }
                if ($return_transaction == "Indefinie" || $return_transaction == "" || $return_transaction == "Indéfinie" || $return_transaction == "Indefined") {
                    $return_transaction = "---";
                }
                if ($statut_retour == "Inconnue" || $statut_retour == "Indefinie" || $statut_retour == "" || $statut_retour == "Indéfinie" || $statut_retour == "Indefined") {
                    $statut_retour = "---";
                }
                if ($return_motif_rejet == "Indefinie" || $return_motif_rejet == "" || $return_motif_rejet == "Indéfinie" || $return_motif_rejet == "Indefined") {
                    $return_motif_rejet = "---";
                }
                if ($row["amount_withdraw"] == "0") {
                    $montant_retirer = "---";
                }

                if ($statut_evenement == "SST OUT OF SERVICE")
                {
                    echo '<tr style="background-color:#FF866A;">
                    <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                    <td style="padding: 3px" align="center">' . $date_evenement . '</td>
                    <td style="padding: 3px" align="center">' . $statut_evenement . '</td>
                    <td style="padding: 3px" align="center">' . $type_authentification . '</td>
                    <td style="padding: 3px" align="center">' . $type_transaction . '</td>
                    <td style="padding: 3px" align="center">' . $return_transaction . ' </td>
                    <td style="padding: 3px" align="center">' . $statut_retour . ' </td>
                    <td style="padding: 3px" align="center">' . $return_motif_rejet . ' </td>
                    <td style="padding: 3px" align="center">' . $montant_retirer . ' </td>
                    </tr>';
                }
                else if ($statut_evenement == "SST OFF-LINE")
                {
                    echo '<tr style="background-color:#ff4d4d;">
                    <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                    <td style="padding: 3px" align="center">' . $date_evenement . '</td>
                    <td style="padding: 3px" align="center">' . $statut_evenement . '</td>
                    <td style="padding: 3px" align="center">' . $type_authentification . '</td>
                    <td style="padding: 3px" align="center">' . $type_transaction . '</td>
                    <td style="padding: 3px" align="center">' . $return_transaction . ' </td>
                    <td style="padding: 3px" align="center">' . $statut_retour . ' </td>
                    <td style="padding: 3px" align="center">' . $return_motif_rejet . ' </td>
                    <td style="padding: 3px" align="center">' . $montant_retirer . ' </td>
                    </tr>';
                }
                else if ($statut_evenement == "SST ON-LINE")
                {
                    echo '<tr> 
                    <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                    <td style="padding: 3px" align="center">' . $date_evenement . '</td>
                    <td style="padding: 3px" align="center">' . $statut_evenement . ' <span class="cil-check" style="color: #5CB85C;" aria-hidden="false"></span></td>
                    <td style="padding: 3px" align="center">' . $type_authentification . '</td>
                    <td style="padding: 3px" align="center">' . $type_transaction . '</td>
                    <td style="padding: 3px" align="center">' . $return_transaction . ' </td>
                    <td style="padding: 3px" align="center">' . $statut_retour . ' </td>
                    <td style="padding: 3px" align="center">' . $return_motif_rejet . ' </td>
                    <td style="padding: 3px" align="center">' . $montant_retirer . ' </td>
                    </tr>';
                }
                else if ($statut_evenement == "SST IN SERVICE")
                {
                    echo '<tr> 
                   <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                    <td style="padding: 3px" align="center">' . $date_evenement . ' </td>
                    <td style="padding: 3px" align="center">' . $statut_evenement . ' <span class="cil-check" style="color: #5CB85C;" aria-hidden="false"></span> <span class="cil-check" style="color: #5CB85C;" aria-hidden="false"></span></td>
                    <td style="padding: 3px" align="center">' . $type_authentification . '</td>
                    <td style="padding: 3px" align="center">' . $type_transaction . '</td>
                    <td style="padding: 3px" align="center">' . $return_transaction . ' </td>
                    <td style="padding: 3px" align="center">' . $statut_retour . ' </td>
                    <td style="padding: 3px" align="center">' . $return_motif_rejet . ' </td>
                    <td style="padding: 3px" align="center">' . $montant_retirer . ' </td>
                    </tr>';
                }
                else
                {
                    echo '<tr> 
                    <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                    <td style="padding: 3px" align="center">' . $date_evenement . '</td>
                    <td style="padding: 3px" align="center">' . $statut_evenement . '</td>
                    <td style="padding: 3px" align="center">' . $type_authentification . '</td>
                    <td style="padding: 3px" align="center">' . $type_transaction . '</td>
                    <td style="padding: 3px" align="center">' . $return_transaction . ' </td>
                    <td style="padding: 3px" align="center">' . $statut_retour . ' </td>
                    <td style="padding: 3px" align="center">' . $return_motif_rejet . ' </td>
                    <td style="padding: 3px" align="center">' . $montant_retirer . ' </td>
                    </tr>';
                }
                $g++;
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

    echo '<tr>
            <td colspan="9" align="center"></td>
		  </tr> 
         </tbody>';
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function uploadpic($hdin, $pathimage, $uploadimage)
{
    $chek=true;
    $okMessage ="Images enregistrées";
    $errorMessage = "Images non enregistrées";
	$conn= ma_db_connexion();
    $total = count($_FILES['uploadimage']['name']);
    $pathimage = addslashes($pathimage);
    if($total <=20  && (!empty($hdin)))
    {
        for ($i=0 ; $i < $total ; $i++ )
        {
            $image_mime = check_file_mime($_FILES["uploadimage"]["tmp_name"][$i], 'image/');
            $size = $_FILES['uploadimage']['size'][$i];
            if ($size <= 5242880 && $size != 0 && ($image_mime))
            {
                $chek=true;
            }
            else
            {
                $chek=false;
                break;
            }
        }

        for( $i=0 ; $i < $total ; $i++ )
        {
            $image_mime = check_file_mime($_FILES["uploadimage"]["tmp_name"][$i], 'image/');
            $size = $_FILES['uploadimage']['size'][$i];
            if ($size <= 5242880 && $size != 0 && ($image_mime) && ($chek))
            {
                $fileData = addslashes(file_get_contents($_FILES["uploadimage"]["tmp_name"][$i]));
                $namefile = $_FILES["uploadimage"]["name"][$i];

                /***************************GET ID IMAGES*************************/
                $req1 = "INSERT INTO images_compaign (" .
                    " data, md5,name_picture,date_insert" .
                    ") VALUES ( '{$fileData}', " . "'" . hash_file("sha256",$_FILES["uploadimage"]["tmp_name"][$i]) . "', " . "'" . $namefile . "', now()) ";

                $result=mysqli_query($conn,$req1);
                if ($result)
                {
                    $id_image=mysqli_insert_id($conn);
                    /*****************************************************************/
                    $req = "INSERT INTO images (" .
                        " data, md5, date_insertion, path,id_atm,name_picture,state,id_image" .
                        ") VALUES ( '{$fileData}', " . "'" . hash_file("sha256",$_FILES["uploadimage"]["tmp_name"][$i]) . "',  now() , " . "'" . $pathimage . "'," . "'" . $hdin . "', " . "'" . $namefile . "',1,".$id_image.") ";

                    $result1=mysqli_query($conn,$req);
                    if ($result1)
                    {
                        $responseArray = array('type' => 'success', 'message' => $okMessage);
                    }
                    else
                    {
                        $responseArray = array('type' => 'danger', 'message' => $errorMessage." \n Erreur QUERY 103");
                        error_log("Erreur SQL 103:  ".$req1."  ".mysqli_error($conn));
                        break;
                    }
                }
                else
                {

                    $responseArray = array('type' => 'danger', 'message' => $errorMessage." \n Erreur QUERY 102");
                    error_log("Erreur SQL 102:  ".$req1."  ".mysqli_error($conn));
                    break;
                }
            }
            else
            {
                $responseArray = array('type' => 'danger', 'message' => 'Taille ou format image(s) invalide ');
                break;
            }

        }
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Aucun GAB selectionné');
    }

    mysqli_close($conn);
    $encoded = json_encode($responseArray);
    header('Content-Type: application/json');
    echo $encoded;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function uploadpicprofil($idatms, $pathimage, $uploadimage)
{
    $okMessage ="Images enregistrées";
    $errorMessage = "Images non enregistrées";
	$conn= ma_db_connexion();
    $chek=true;
    $total = count($_FILES['uploadimage']['name']);

    $pathimage = addslashes($pathimage);
    if($total <=20  && (!empty($idatms)))
    {
        for ($i=0 ; $i < $total ; $i++ )
        {
            $image_mime = check_file_mime($_FILES["uploadimage"]["tmp_name"][$i], 'image/');
            $size = $_FILES['uploadimage']['size'][$i];
            if ($size <= 5242880 && $size != 0 && ($image_mime))
            {
                $chek=true;
            }
            else
            {
                $chek=false;
                break;
            }
        }
        for( $i=0 ; $i < $total ; $i++ )
        {

            $image_mime = check_file_mime($_FILES["uploadimage"]["tmp_name"][$i], 'image/');
            $size = $_FILES['uploadimage']['size'][$i];
            if ($size <= 5242880 && $size != 0 && ($image_mime) && ($chek))
            {
                $fileData = addslashes(file_get_contents($_FILES["uploadimage"]["tmp_name"][$i]));
                $namefile = $_FILES["uploadimage"]["name"][$i];

                /***************************GET ID IMAGES*************************/
                $req1 = "INSERT INTO images_compaign (" .
                    " data, md5,name_picture,date_insert" .
                    ") VALUES ( '{$fileData}', " . "'" . mysqli_real_escape_string($conn,hash_file("sha256", $_FILES["uploadimage"]["tmp_name"][$i])) . "', " . "'" . mysqli_real_escape_string($conn,$namefile) . "', now()) ";
                //echo $req;
                $result=mysqli_query($conn,$req1);

                if ($result)
                {
                    $id_image = mysqli_insert_id($conn);
                    /*****************************************************************/
                    $array = explode(",", $idatms);
                    foreach ($array as $item)
                    {
                        if ($item != 0)
                        {
                            $req = "INSERT INTO images (" .
                                " data, md5, date_insertion, path,id_atm,name_picture,state,id_image" .
                                ") VALUES ( '{$fileData}', " . "'" . mysqli_real_escape_string($conn,hash_file("sha256", $_FILES["uploadimage"]["tmp_name"][$i])) . "',  now() , " . "'" . $pathimage . "'," . "'" . mysqli_real_escape_string($conn,$item) . "', 
								" . "'" . mysqli_real_escape_string($conn,$namefile) . "',1," . mysqli_real_escape_string($conn,$id_image) . ") ";

                            $result1=mysqli_query($conn,$req);

                            if ($result1)
                            {
                                $responseArray = array('type' => 'success', 'message' => $okMessage);
                            }
                            else
                            {
                                unset($item);
                                $responseArray = array('type' => 'danger', 'message' => $errorMessage." \n Erreur QUERY 105");
                                error_log("Erreur SQL 104:  ".$req1."  ".mysqli_error($conn));
                                break;
                            }
                        }
                        else
                        {
                            unset($item);
                            $responseArray = array('type' => 'danger', 'message' => $errorMessage);
                            break;
                        }

                    }
                }
                else
                {
                    unset($item);
                    $responseArray = array('type' => 'danger', 'message' => $errorMessage." \n Erreur QUERY 104");
                    error_log("Erreur SQL 104:  ".$req1."  ".mysqli_error($conn));
                    break;
                }
            }
            else
            {
                unset($item);
                $responseArray = array('type' => 'danger', 'message' => 'Taille ou format image(s) invalide ');
                break;
            }
        }
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Aucun GAB selectionné');
    }

    mysqli_close($conn);
    $encoded = json_encode($responseArray);
    header('Content-Type: application/json');
    echo $encoded;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function uploadschedule($nom_dépl,$time_dep,$frenq_date,$description_dépl,$idatms)
{
    $connexion=ma_db_connexion();
    $okMessage ="Schedule saved successfully !!!";
    $errorMessage = "Schedule not saved  !!!";


    $listFinalMotif="";
    $listFinalMotifatm="";

    $list_id_atm=array();

    $nom_dépl = addslashes($nom_dépl);

    $array =explode(",",$idatms);

    foreach ($array as $item)
    {
        if($item != 0)
        {
            $list_id_atm[]=$item;
            if(isset($list_id_atm)){$listFinalMotifatm = implode(',',$list_id_atm); } else { $listFinalMotifatm=""; }
        }
    }

    if(!empty($list_id_atm))
    {
        $req = "INSERT INTO schedule_pulling_ej (" .
        " name,start_date_programed,frequenxe,description,atm_concerned,user_create,date_create" .
         ") VALUES (  '" . $nom_dépl . "' , '" . mysqli_real_escape_string($connexion,$time_dep) . "' , '" . mysqli_real_escape_string($connexion,$frenq_date) . "' 
				,'" . $description_dépl . "',
				'" . mysqli_real_escape_string($connexion,$listFinalMotifatm) . "','" . mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur']) . "', now()) ";
        $result=mysqli_query($connexion,$req);
        if ($result)
        {
            $responseArray = array('type' => 'success', 'message' => $okMessage);
        }
        else
        {
            error_log("Erreur SQL 107:  ".$req."  ".mysqli_error($connexion));
            $responseArray = array('type' => 'danger', 'message' => $errorMessage."Erreur SQL 107");
        }
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Aucun GAB selectionné');
    }

    mysqli_close($connexion);
    $encoded = json_encode($responseArray);
    header('Content-Type: application/json');
    echo $encoded;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function uploadcompagne($nom_dépl,$datedep,$description_dépl,$chemin_dépl,$idatms, $uploadimage)
{
    $connexion=ma_db_connexion();
        $okMessage ="Campaign saved successfully !!!";
    $errorMessage = "Campaign not saved  !!!";
    $errorsql="";
    $chek=true;
    $condition = true;
    $listFinalMotif="";
    $listFinalMotifatm="";
    $list_id_image=array();
    $list_id_atm=array();
    $total = count($_FILES['uploadimage']['name']);
    $chemin_dépl = addslashes($chemin_dépl);
    $description_dépl = addslashes($description_dépl);
    $nom_dépl = addslashes($nom_dépl);

    $array =explode(",",$idatms);

    foreach ($array as $item)
    {
        if($item != 0)
        {
            $list_id_atm[]=$item;
            if(isset($list_id_atm)){$listFinalMotifatm = implode(',',$list_id_atm); } else { $listFinalMotifatm=""; }
        }
    }
    for ($i=0 ; $i < $total ; $i++ )
    {
        $image_mime = check_file_mime($_FILES["uploadimage"]["tmp_name"][$i], 'image/');
        $size = $_FILES['uploadimage']['size'][$i];
        if ($size <= 5242880 && $size != 0 && ($image_mime))
        {
            $chek=true;
        }
        else
        {
            $chek=false;
            break;
        }
    }
    if($total <=20  && (!empty($list_id_atm)))
    {
        for( $i=0 ; $i < $total ; $i++ )
        {
            $image_mime= check_file_mime($_FILES["uploadimage"]["tmp_name"][$i],'image/');

            $size = $_FILES['uploadimage']['size'][$i];
            if($size <= 5242880 && $size != 0 && ($image_mime)&& ($chek))
            {
                //echo "image_mime : ".$image_mime;
                $fileData = addslashes(file_get_contents($_FILES["uploadimage"]["tmp_name"][$i]));
                $namefile = $_FILES["uploadimage"]["name"][$i];
                $req = "INSERT INTO images_compaign (" .
                    " data, md5,name_picture,date_insert" .
                    ") VALUES ( '{$fileData}', " . "'" .  mysqli_real_escape_string($connexion,hash_file("sha256",$_FILES["uploadimage"]["tmp_name"][$i])) . "', 
					" . "'" . mysqli_real_escape_string($connexion,$namefile) . "', now()) ";

                $result=mysqli_query($connexion,$req);

                  if ($result)
                  {
                    $list_id_image[]=mysqli_insert_id($connexion);
                    if(isset($list_id_image)){$listFinalMotif = implode(',',$list_id_image); } else { $listFinalMotif=""; }
                  }
                  else
                  {
                      unset($list_id_image);
                      error_log("Erreur SQL 106:  ".$req."  ".mysqli_error($connexion));
                      $errorsql="Erreur SQL 106";
                      $condition=false;
                      break;
                  }
            }
            else
            {
                $errorMessage = $errorMessage. ' : Taille ou format image(s) invalide ';
                unset($list_id_image);
                $condition=false;
                break;
            }
        }

        if(!empty($list_id_image) || ($condition))
        {
            $req = "INSERT INTO advertising_compaign (" .
                " name,start_date_programed,path,description,atm_concerned,images_concerned,user_create,date_create" .
                ") VALUES (  '" . $nom_dépl . "' , '" . mysqli_real_escape_string($connexion,$datedep) . "' 
				,'" . $chemin_dépl . "','" . $description_dépl . "',
				'" . mysqli_real_escape_string($connexion,$listFinalMotifatm) . "','" . mysqli_real_escape_string($connexion,$listFinalMotif) . "','" . mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur']) . "', now()) ";
                $result=mysqli_query($connexion,$req);
            if ($result)
            {
                $responseArray = array('type' => 'success', 'message' => $okMessage);
            }
            else
            {
                error_log("Erreur SQL 107:  ".$req."  ".mysqli_error($connexion));
                $responseArray = array('type' => 'danger', 'message' => $errorMessage."Erreur SQL 107");
            }
        }
        else
        {
            $responseArray = array('type' => 'danger', 'message' => $errorMessage." ".$errorsql);
        }
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Aucun GAB selectionné');
    }

    mysqli_close($connexion);
    $encoded = json_encode($responseArray);
    header('Content-Type: application/json');
    echo $encoded;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function check_file_mime($tmpname,$type){
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mtype = finfo_file($finfo, $tmpname);

    if(strpos($mtype, $type) === 0)
    {
        finfo_close($finfo);
        return true;
    }
    else
    {
        finfo_close($finfo);
        return false;
    }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function TraitMassive($idincid)
{
   // var_dump($idincid);
    $okMessage ="Incident Traiter";
    $errorMessage = "Incident non Traiter";
    $connexion=ma_db_connexion();
    $list_id_atm=array();
    $id_motif=2;
    $array =explode(",",$idincid);
    $Chemin_images = addslashes($Chemin_images);
    foreach ($array as $item)
    {
        if($item != 0)
        {
            $list_id_atm[]=$item;
            if(isset($list_id_atm)){$listFinalMotifatm = implode(',',$list_id_atm); } else { $listFinalMotifatm=""; }
        }
    }
    if(!empty($list_id_atm))
    {
       // echo "<pre>";print_r($list_id_atm);echo"</pre>";
        //echo "<pre>";print_r($listFinalMotifatm);echo "</pre>";

        $SQL1 = "UPDATE atm_list_stopped_test SET if_checked = 1 , check_date = now(),check_user = ".$_SESSION['id_utilisateur']." , 
	    check_cause = ".mysqli_real_escape_string($connexion,$id_motif)."   WHERE id_insert IN (".mysqli_real_escape_string($connexion,$listFinalMotifatm).") ";


        //var_dump($sql);
        mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
        $result=mysqli_query($connexion,$SQL1);
        if ($result)
        {
            $responseArray = array('type' => 'success', 'message' => $okMessage);
        }
        else
        {
            error_log("Erreur SQL 00108:  ".$SQL1."  ".mysqli_error($connexion));
            $responseArray = array('type' => 'danger', 'message' => $errorMessage."Erreur SQL 00108");
        }
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Aucun Incident selectionné');
    }
    foreach ($array as $item)
    {
        if($item != 0)
        {
            //var_dump($item);echo "<br>";
            delete_checked_in_service_arret($item);
        }
    }

// todo: json envois form

    mysqli_close($connexion);
    $encoded = json_encode($responseArray);
    header('Content-Type: application/json');
    echo $encoded;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function updatecompagne($id_compaign,$nom_compagne,$datedep,$Chemin_images,$idatms,$checkbox_compagne)
{
    $okMessage ="Campaign edit";
    $errorMessage = "Unmodified campaign";
    $connexion=ma_db_connexion();
    $list_id_atm=array();
    $array =explode(",",$idatms);
    $Chemin_images = addslashes($Chemin_images);
    foreach ($array as $item)
    {
        if($item != 0)
        {
            $list_id_atm[]=$item;
            if(isset($list_id_atm)){$listFinalMotifatm = implode(',',$list_id_atm); } else { $listFinalMotifatm=""; }
        }
    }
    if(!empty($list_id_atm))
    {
        $SQL1 ="UPDATE advertising_compaign  SET `name` ='".mysqli_real_escape_string($connexion,$nom_compagne)."' ,
			`path`= '".$Chemin_images."' , 			
			`start_date_programed`= '".mysqli_real_escape_string($connexion,$datedep)."' , 			
			`atm_concerned`= '".mysqli_real_escape_string($connexion,$listFinalMotifatm)."',
			`state_execution`= '".mysqli_real_escape_string($connexion,$checkbox_compagne)."'
			WHERE `id_compaign` ='".mysqli_real_escape_string($connexion,$id_compaign)."' ";


        mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
        $result=mysqli_query($connexion,$SQL1);
        if ($result)
        {
            $responseArray = array('type' => 'success', 'message' => $okMessage);
        }
        else
        {
            error_log("Erreur SQL 108:  ".$SQL1."  ".mysqli_error($connexion));
            $responseArray = array('type' => 'danger', 'message' => $errorMessage."Erreur SQL 108");
        }
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Aucun GAB selectionné');
    }
// todo: json envois form

    mysqli_close($connexion);
    $encoded = json_encode($responseArray);
    header('Content-Type: application/json');
    echo $encoded;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function updatescheduled($id_compaign,$nom_compagne,$datedep,$frequenxe,$idatms,$checkbox_compagne)
{
    $okMessage ="Schedule edit";
    $errorMessage = "Unmodified Schedule";

    $connexion=ma_db_connexion();
    $list_id_atm=array();
    $array =explode(",",$idatms);
    foreach ($array as $item)
    {
        if($item != 0)
        {
            $list_id_atm[]=$item;
            if(isset($list_id_atm)){$listFinalMotifatm = implode(',',$list_id_atm); } else { $listFinalMotifatm=""; }
        }
    }

    if(!empty($list_id_atm))
    {
        $SQL1 ="UPDATE schedule_pulling_ej  SET `name` ='".mysqli_real_escape_string($connexion,$nom_compagne)."' ,
			`frequenxe`= '".$frequenxe."' , 			
			`start_date_programed`= '".mysqli_real_escape_string($connexion,$datedep)."' , 			
			`atm_concerned`= '".mysqli_real_escape_string($connexion,$listFinalMotifatm)."'
			WHERE `id_schedule` ='".mysqli_real_escape_string($connexion,$id_compaign)."' ";



        mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
        $result=mysqli_query($connexion,$SQL1);
        if ($result)
        {
            $responseArray = array('type' => 'success', 'message' => $okMessage);
        }
        else
        {
            error_log("Erreur SQL 108:  ".$SQL1."  ".mysqli_error($connexion));
            $responseArray = array('type' => 'danger', 'message' => $errorMessage."Erreur SQL 108");
        }

    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Aucun GAB selectionné');
    }
// todo: json envois form

    mysqli_close($connexion);
    $encoded = json_encode($responseArray);
    header('Content-Type: application/json');
    echo $encoded;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function uploadbinaireprofil($idatms, $pathbinaire, $uploadbinaire)
{
    $okMessage ="Binaire déployé";
    $errorMessage = "Binaire non déployé";
    $connexion=ma_db_connexion();

    $fileData = addslashes(file_get_contents($_FILES["uploadbinaire"]["tmp_name"]));
    $total = count($_FILES['uploadbinaire']['name']);

    $pathbinaire = addslashes($pathbinaire);
    $namefile = $_FILES["uploadbinaire"]["name"];
    $array =explode(",",$idatms);

    if($total <=1  && (!empty($idatms)))
    {
        foreach ($array as $item)
        {
            $image_mime = check_file_mime($_FILES["uploadbinaire"]["tmp_name"], 'application/x-dosexec');
            $size = $_FILES['uploadbinaire']['size'];

            if ($size <= 5242880 && $size != 0 && ($image_mime))
            {
                if($item != 0)
                {
                    $req = "INSERT INTO binaire_client (" .
                        " data, md5, date_insertion, path,id_atm,name_binaire,state_binaire" .
                        ") VALUES ( '{$fileData}', " . "'" . mysqli_real_escape_string($connexion,hash_file("sha256",$_FILES["uploadbinaire"]["tmp_name"])). "',  now() ,
						" . "'" . $pathbinaire . "'," . "'" . mysqli_real_escape_string($connexion,$item) . "', " . "'" . mysqli_real_escape_string($connexion,$namefile) . "',1) ;";

                    $result=mysqli_query($connexion,$req);
                    if ($result)
                    {
                        $responseArray = array('type' => 'success', 'message' => $okMessage);
                    }
                    else
                    {
                        unset($item);
                        $responseArray = array('type' => 'danger', 'message' => $errorMessage." \n : Erreur QUERY 109");
                        error_log("Erreur SQL 109:  ".$req."  ".mysqli_error($connexion));
                        break;
                    }
                }
                else
                {
                    $responseArray = array('type' => 'danger', 'message' => $errorMessage.' : Aucun GAB selectionné');
                }
            }
            else
            {
                unset($item);
                $responseArray = array('type' => 'danger', 'message' => 'Taille ou format Binaire invalide ');
                break;
            }

        }
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => $errorMessage.' : Aucun GAB selectionné');
    }

    mysqli_close($connexion);
    $encoded = json_encode($responseArray);
    header('Content-Type: application/json');
    echo $encoded;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getjournalATMdate($id_atm,$terminalID, $date_d, $date_f, $idev,$idev2,$idev3, $page)
{
    include "../languages/" . $_SESSION['lang'] . ".php";

    $dated = date("Y-m-d H:i:s", strtotime($date_d));
    $datef = date("Y-m-d H:i:s", strtotime($date_f));

    $val=get_name_terminal_gag($id_atm);
    include("../pagination.php");
    echo '<div class="modal-dialog modal-xl" role="document" style="max-width: 1700px;">
									
	<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;" >				
	
	    <!-- Modal Header -->
	    <div class="modal-header">
            <h4 class="modal-title"> '.$lang['det_jour_gab'].' : '.$id_atm.' - Terminal :  '.$terminalID.' - '.$val[1].' </h4>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        </div>	
    																										
		<!-- Modal body -->
	    <div class="modal-body">	
		    <form class="form-horizontal" role="form">
			    <div class="container col-md-12">
				    <div class="row">
					    <div class="col-md-3">
						    <div class="panel-group">
							    <div class="input-group date" id="datetimepicker6">
                                    <input value="'.$date_d.'" type="datetime-local"  id="dated" class="form-control required" placeholder="Date début" required/>
                                        
								</div>
							</div>
						</div>
                        <div class="col-md-3">
                            <div class="panel-group">
                                <div class="input-group date" id="datetimepicker7">
                                    <input value="'.$date_f.'" type="datetime-local"  id="datef" class="form-control required" placeholder="Date fin" required/>
                                    
                                </div>
                            </div>
                        </div>
																				
						<div class="col-md-2">
						    <select id="eventid"  class="form-control" title="Evénement">
						    <';
    getEvent($idev);
    echo '</select>
						</div>												  
                        <div class="col-md-2">
                            <select id="type_transaction_id"  class=" form-control" title="Transaction" >';
    getTypeTransaction($idev2);
    echo '</select>
                        </div>												  
                        <div class="col-md-2">
                            <select id="type_authentification_id"  class=" form-control"  title="Authentification">';
    getTypeAuthentification($idev3);
    echo '</select>
                        </div>
																			  
					</div>
				</div>
                <div class="modal-footer" style="border-top : 0px">												   																				
                    <button type="button" class="btn btn-danger " data-target="#detailjournalATM" onClick="javascript:getjournalATMdate(\'' . $id_atm . '\',\'' . $terminalID . '\')" >'.$lang['search'].' <i id="btn_detailjournalATM"></i></button>
                </div>
																		
                <div class="table-responsive">				
                <table class="table table-bordered table-hover table-striped">
                    <thead class="thead-light">
                    <th>#</th>
                    <th>'.$lang['date_env'].' </th>
                    <th>'.$lang['event'].'</th>
                    <th>'.$lang['type_auth'].'</th>
                    <th>'.$lang['type_trans'].'</th>
                    <th>'.$lang['ret_car'].'</th>
                    <th>'.$lang['stat_ret'].'</th>
                    <th>'.$lang['mot_ret'].'</th>
                    <th>'.$lang['mtn'].'</th>
                </thead>
                        <tbody>';
    $connexion=ma_db_connexion();
    $libelle_type_return = 'libelle_type_return';
    if ($_SESSION['lang']== 'en')
    {
        $libelle_type_return = 'libelle_type_return_en';
    }
    $SQL1 = "SELECT `journal_contents_ncr`.`id_atm`,`journal_contents_ncr`.`dateligne`,`list_events`.`name_event`,`type_transaction`.`libelle_type`,
         `type_return_transaction`.".$libelle_type_return." as libelle_type_return, `journal_contents_ncr`.`amount_withdraw`,`type_card_returned`.`libelle_card_returned`,
         `type_card_insert`.`libelle_type_card_insert`, `journal_contents_ncr`.`type_return_motif` FROM `journal_contents_ncr`,`list_events`,`type_transaction`,`type_return_transaction`,
         `type_card_returned`, `type_card_insert` WHERE `journal_contents_ncr`.`id_atm` = '" . mysqli_real_escape_string($connexion,$id_atm) . "' AND ";

    if ($idev != "0")
    {
        $SQL1 = $SQL1 . "`list_events`.`id_event` IN (" . $idev . ") AND ";
    }

    if ($idev2 != "0")
    {
        $SQL1 = $SQL1 . "`type_transaction`.`id` IN (" . $idev2 . ") AND ";
    }

    if ($idev3 != "0")
    {
        $SQL1 = $SQL1 . "`type_card_insert`.`id` IN (" . $idev3 . ") AND ";
    }

    $SQL1 = $SQL1 . "`journal_contents_ncr`.`type_transaction`= `type_transaction`.`id` 
         AND `journal_contents_ncr`.`type_return_transaction` = `type_return_transaction`.`id` AND `journal_contents_ncr`.`type_card_returned` = `type_card_returned`.`id` 
         AND `journal_contents_ncr`.`type_card_insert` = `type_card_insert`.`id` AND `journal_contents_ncr`.`id_event` = `list_events`.`id_event` AND `journal_contents_ncr`.`dateligne` 
		 BETWEEN '" . mysqli_real_escape_string($connexion,$dated) . "' AND '" . mysqli_real_escape_string($connexion,$datef) . "' ORDER BY `journal_contents_ncr`.`dateligne` DESC ";

    $page = new Pagination($SQL1, 20);

    $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
    $SQL = $page->req();
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 110:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 110 !');
    }
    if ($result)
    {
        $idev == "";
        if(mysqli_num_rows($result)>0)
        {

            $g=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $date_evenement = $row["dateligne"];
                $statut_evenement = $row["name_event"];
                $type_authentification = $row["libelle_type_card_insert"];
                $type_transaction = $row["libelle_type"];
                $return_transaction = $row["libelle_card_returned"];
                $statut_retour = $row["libelle_type_return"];
                $return_motif_rejet = $row["type_return_motif"];
                $montant_retirer = number_format($row["amount_withdraw"],2,'.',',')." MGA";


                if ($type_authentification== "Indefinie" || $type_authentification == "" || $type_authentification == "Indéfinie" || $type_authentification == "Indefined")
                {
                    $type_authentification = "---";
                }
                if ($type_transaction == "Indefinie" || $type_transaction == "" || $type_transaction == "Indéfinie" || $type_transaction == "Indefined") {
                    $type_transaction = "---";
                }
                if ($return_transaction == "Indefinie" || $return_transaction == "" || $return_transaction == "Indéfinie" || $return_transaction == "Indefined") {
                    $return_transaction = "---";
                }
                if ($statut_retour == "Inconnue" || $statut_retour == "Indefinie" || $statut_retour == "" || $statut_retour == "Indéfinie" || $statut_retour == "Indefined") {
                    $statut_retour = "---";
                }
                if ($return_motif_rejet == "Indefinie" || $return_motif_rejet == "" || $return_motif_rejet == "Indéfinie" || $return_motif_rejet == "Indefined") {
                    $return_motif_rejet = "---";
                }
                if ($row["amount_withdraw"] == "0") {
                    $montant_retirer = "---";
                }


                if ($statut_evenement == "SST OUT OF SERVICE")
                {
                    echo '<tr style="background-color:#FF866A;">
                <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                <td style="padding: 3px" align="center">' . $date_evenement . '</td>
                <td style="padding: 3px" align="center">' . $statut_evenement . '</td>
                <td style="padding: 3px" align="center">' . $type_authentification . '</td>
				<td style="padding: 3px" align="center">' . $type_transaction . '</td>
				<td style="padding: 3px" align="center">' . $return_transaction . ' </td>
				<td style="padding: 3px" align="center">' . $statut_retour . ' </td>
				<td style="padding: 3px" align="center">' . $return_motif_rejet . ' </td>
				<td style="padding: 3px" align="center">' . $montant_retirer . ' </td>
                </tr>';
                } else if ($statut_evenement == "SST OFF-LINE") {
                    echo '<tr style="background-color:#ff4d4d;">
                <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                <td style="padding: 3px" align="center">' . $date_evenement . '</td>
                <td style="padding: 3px" align="center">' . $statut_evenement . '</td>
                <td style="padding: 3px" align="center">' . $type_authentification . '</td>
				<td style="padding: 3px" align="center">' . $type_transaction . '</td>
				<td style="padding: 3px" align="center">' . $return_transaction . ' </td>
				<td style="padding: 3px" align="center">' . $statut_retour . ' </td>
				<td style="padding: 3px" align="center">' . $return_motif_rejet . ' </td>
				<td style="padding: 3px" align="center">' . $montant_retirer . ' </td>
                </tr>';
                } else if ($statut_evenement == "SST ON-LINE") {
                    echo '<tr> 
                <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                <td style="padding: 3px" align="center">' . $date_evenement . '</td>
                <td style="padding: 3px" align="center">' . $statut_evenement . ' <span class="cil-check" style="color: #5CB85C;" aria-hidden="false"></span> </td>
                <td style="padding: 3px" align="center">' . $type_authentification . '</td>
				<td style="padding: 3px" align="center">' . $type_transaction . '</td>
				<td style="padding: 3px" align="center">' . $return_transaction . ' </td>
				<td style="padding: 3px" align="center">' . $statut_retour . ' </td>
				<td style="padding: 3px" align="center">' . $return_motif_rejet . ' </td>
				<td style="padding: 3px" align="center">' . $montant_retirer . ' </td>
                </tr>';
                } else if ($statut_evenement == "SST IN SERVICE") {
                    echo '<tr> 
            
               <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                <td style="padding: 3px" align="center">' . $date_evenement . ' </td>
                <td style="padding: 3px" align="center">' . $statut_evenement . ' <span class="cil-check" style="color: #5CB85C;" aria-hidden="false"></span> <span class="cil-check" style="color: #5CB85C;" aria-hidden="false"></span> </td>
                <td style="padding: 3px" align="center">' . $type_authentification . '</td>
				<td style="padding: 3px" align="center">' . $type_transaction . '</td>
				<td style="padding: 3px" align="center">' . $return_transaction . ' </td>
				<td style="padding: 3px" align="center">' . $statut_retour . ' </td>
				<td style="padding: 3px" align="center">' . $return_motif_rejet . ' </td>
				<td style="padding: 3px" align="center">' . $montant_retirer . ' </td>
                </tr>';
                } else {
                    echo '<tr> 
                <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                <td style="padding: 3px" align="center">' . $date_evenement . '</td>
                <td style="padding: 3px" align="center">' . $statut_evenement . '</td>
                <td style="padding: 3px" align="center">' . $type_authentification . '</td>
				<td style="padding: 3px" align="center">' . $type_transaction . '</td>
				<td style="padding: 3px" align="center">' . $return_transaction . ' </td>
				<td style="padding: 3px" align="center">' . $statut_retour . ' </td>
				<td style="padding: 3px" align="center">' . $return_motif_rejet . ' </td>
				<td style="padding: 3px" align="center">' . $montant_retirer . ' </td>
                </tr>';
                }
                $g++;
            }
            echo '<tr><td colspan="9" align="center">';
            echo '<ul class="pagination justify-content-center">' . $page->constructPaginate(5, '', $id_atm,$terminalID, $dated, $datef, $idev,$idev2,$idev3) . ' </ul>';

            echo   '<div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>';
            echo '</td>
			</tr> ';
        }
        else
        {
            echo '<tr>
                 <td colspan="9" align="center"></td>
		      </tr> 
         </tbody>';
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

    echo '
                  </table>												
                </div>
            </form> 
         </div>	
        <!-- Modal footer -->
            <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
            </div>																																		
         </div>
        </div>';

}//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getTraitMassive()
{
    $connexion=ma_db_connexion();

    echo '<div class="modal-dialog modal-lg" style="width:60%" >
									
	<div  class="modal-content" style="background-color:#e9ecef;color:#2b3449;">					
	
	<!-- Modal Header -->
            <div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">×</button>
						<div align="center" style="font-size:13pt;color: #000000;" class="modal-title">Traitement Massive </div>	
			</div>	
																												
        <!-- Modal body -->
        <br>
        <div class="modal-body">	
        
		    <form id="form_trait_massive" class="form-horizontal" role="form" >
			    <div class="table-responsive">				
				    <table id="tbl_trait_massive" class="table table-bordered table-hover table-striped">
					    <thead class="text-warning">
                            <th ><input type="checkbox" id="checkAllcheckbox" value="0" onclick="chackallcheckbox()" checked></th>
                            <th>ID ATM </th>
                            <th>Terminal </th>
                            <th>Libellé GAB </th>
                            <th>Date d\'arrêt</th>    
						    <th>Cause d\'arrêt</th>
						    <th>Détails jounal</th>
						</thead>
						<tbody>';

    $SQL = "SELECT list_atm_confirmed.`id_atm`, list_atm_confirmed.`terminal`,  
    cause_default.description as causeArret, 
    atm_list_stopped_test.id_global_vacation as idVacation,
    `atm_list_stopped_test`.`notificate_in_service_atm`,
    `atm_list_stopped_test`.`stop_date`,
    `list_atm_confirmed`.`last_connexion`  as date_up_atm,
    `atm_list_stopped_test`.`id_insert`,
    `atm_list_stopped_test`.`id_logical_name`,
    `atm_list_stopped_test`.`if_checked` as if_checked,
    `atm_list_stopped_test`.`check_cause` as check_cause
     
    FROM `list_atm_confirmed` , atm_list_stopped_test  ,cause_default
    
    WHERE `atm_list_stopped_test`.`cause_default` = cause_default.id_default
    AND list_atm_confirmed.id_atm= atm_list_stopped_test.id_atm
    AND `cause_default`.`id_default` = 14
    AND atm_list_stopped_test.if_declared=0
    AND list_atm_confirmed. state= 1 ORDER BY atm_list_stopped_test.id_insert  DESC ";
//
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 0000178:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 0000178 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g=0;
            while ($row = mysqli_fetch_assoc($result))
            {

                list($terminalID, $ipAdresseGAB, $nomGAB, $dateAjout,$ville) = explode('---', getinfoATM($row["id_atm"]));
                if (get_gab_up_jrn($row['id_atm'],$row['stop_date']))
                {
                    $g++;
                    echo "<tr>";
                    echo " <td scope='row' style='padding: 3px' align='center'>
                        <input  type='checkbox' checked class='checkbox' value='". $row["id_insert"] ."'>
                        </td>";
                    echo " <td scope='row' style='padding: 3px' align='center'>".$row['id_atm']."</td>";
                    echo " <td scope='row' style='padding: 3px' align='center'>".$row['terminal']."</td>";

                    echo " <td scope='row' style='padding: 3px' align='center'>".$nomGAB."</td>";
                    echo " <td scope='row' style='padding: 3px' align='center'>".$row['stop_date']."</td>";
                    echo " <td scope='row' style='padding: 3px' align='center'>".$row['causeArret']."</td>";
                    echo '<td align="center" style="padding: 3px">';
                    echo '<a tabindex="-1" data-toggle="modal" 
                            onClick="javascript:getjournalATM(\'' . $row["id_atm"] . '\',\'' . $terminalID . '\')"    
                            data-target="#detailjournalATM"> <strong style="color:#52c322" ><i class="fa fa-newspaper-o fa-2x" title="Journal "> </i></strong></a>';
                    echo '</td>	';
                    echo "</tr>";
                }
            }
            if ($g===0)
            {
                echo "<tr>";
                echo " <td colspan='7'></td>";
                echo "</tr>";
            }
        }
        else
            {
                echo "<tr>";
                echo " <td colspan='7'></td>";
                echo "</tr>";
            }
        mysqli_free_result($result);
    }

    echo'</tbody>
                  </table>												
                </div>
                <br>
                <div class="form-group col-sm-10">				
                                <div id="div_btn_modif" class="col-sm-12"  align = "left">
                                    <button id = "btn_modif" type= "button" class = "btn btn-primary" style="padding:7px 40px" onclick="TraitMassive()" >Traiter </button>
                                </div>
                            </div>  
            </form>    
         </div>	
         <br>
		 <br>
        <!-- Modal footer -->
            <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>																																		
         </div>
          
        </div>';
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_gab_up_jrn($id_atm,$date_stoped)
{

    $bool_ret=false;
    $connexion=ma_db_connexion();
    $SQL = "SELECT `journal_contents_ncr`.`id_event` FROM `journal_contents_ncr` 
    WHERE id_atm = '".mysqli_real_escape_string($connexion,$id_atm)."' AND dateligne >= '".mysqli_real_escape_string($connexion,$date_stoped)."'
    AND id_event IN(581,596,604); ";
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 111:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 111 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $bool_ret=true;
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return $bool_ret;

    //mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    //$result=mysqli_query($connexion,$SQL);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getEvent($idev)
{
    $connexion=ma_db_connexion();
    $SQL = "SELECT `name_event` , `id_event` FROM `list_events` WHERE `name_event` NOT LIKE '*%' ORDER BY `id_event` ASC ; ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 111:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 111 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $tableService = array();
            $g=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $selectedOptions = explode(',', str_replace("'", "", $idev));
                $selected = in_array($row["id_event"], $selectedOptions) ? 'selected' : '';
                echo '<option ' . $selected . ' id="' . $g . '" value="' . $row["id_event"] . '">' . $row["name_event"] . '</option>';
                $g++;
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getTypeTransaction($idev2)
{
    $connexion=ma_db_connexion();
    $SQL = "SELECT `libelle_type` , `id` FROM `type_transaction` where id != 4 ORDER BY `id` ASC ; ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 112:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 112 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $selectedOptions = explode(',', str_replace("'", "", $idev2));
                $selected = in_array($row["id"], $selectedOptions) ? 'selected' : '';
                echo '<option ' . $selected . ' id="' . $g . '" value="' . $row["id"] . '">' . $row["libelle_type"] . '</option>';
                $g++;
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getTypeAuthentification($idev3)
{
    $connexion=ma_db_connexion();
    $SQL = "SELECT `libelle_type_card_insert` , `id` FROM `type_card_insert` ORDER BY `id` ASC ; ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 113:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 113 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $selectedOptions = explode(',', str_replace("'", "", $idev3));
                $selected = in_array($row["id"], $selectedOptions) ? 'selected' : '';
                echo '<option ' . $selected . ' id="' . $g . '" value="' . $row["id"] . '">' . $row["libelle_type_card_insert"] . '</option>';
                $g++;
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getjournalATM($id_atm, $terminalID)
{
    include "../languages/" . $_SESSION['lang'] . ".php";
    $val=get_name_terminal_gag($id_atm);
    echo '<div class="modal-dialog modal-xl" role="document" style="max-width: 1700px;">
									
	<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;" >				
	
	    <!-- Modal Header -->
	    <div class="modal-header">
            <h4 class="modal-title"> '.$lang['det_jour_gab'].' : '.$id_atm.' - Terminal :  '.$terminalID.' - '.$val[1].' </h4>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        </div>	
    																										
		<!-- Modal body -->
	    <div class="modal-body">	
		    <form class="form-horizontal" role="form">
			    <div class="container col-md-12">
				    <div class="row">
				    
					    <div class="col-md-3">
						    <div class="panel-group">
							    <div class="input-group date" id="datetimepicker6">
                                        <input type="datetime-local" lang="en" id="dated" class="form-control required" placeholder="Date début" required/>
								</div>
							</div>
						</div>
                        <div class="col-md-3">
                            <div class="panel-group">
                                <div class="input-group date" id="datetimepicker7">
                                    <input type="datetime-local" lang="en" id="datef" class="form-control required" placeholder="Date fin" required/>
                                    
                                </div>
                            </div>
                        </div>
																			
						<div class="col-md-2">
						    <select id="eventid"  class=" form-control" title="Evénement">';
                                getEvent("");
                            echo '</select>
						</div>												  
                        <div class="col-md-2">
                            <select id="type_transaction_id"  class=" form-control" title="Transaction" >';
                            getTypeTransaction("");
                            echo '</select>
                        </div>												  
                        <div class="col-md-2">
                            <select id="type_authentification_id"  class=" form-control"  title="Authentification" >';
                                getTypeAuthentification("");
                            echo '</select>
                        </div>
																			  
					</div>
				</div>
                <div class="modal-footer" style="border-top : 0px">												   																				
                    <button type="button" class="btn btn-danger " data-target="#detailjournalATM" onClick="javascript:getjournalATMdate(\'' . $id_atm . '\',\'' . $terminalID . '\')" >'.$lang['search'].' <i id="btn_detailjournalATM"></i></button>
                </div>
				<div class="table-responsive">				
                    <table class="table table-bordered table-hover table-striped">
                        <thead class="thead-light">
                            <th>#</th>
                            <th>'.$lang['date_env'].' </th>
                            <th>'.$lang['event'].'</th>
                            <th>'.$lang['type_auth'].'</th>
                            <th>'.$lang['type_trans'].'</th>
                            <th>'.$lang['ret_car'].'</th>
                            <th>'.$lang['stat_ret'].'</th>
                            <th>'.$lang['mot_ret'].'</th>
                            <th>'.$lang['mtn'].'</th>
                        </thead>';
                        getalljournalATM($id_atm);
                    echo '</table>					
				    </div>
			</form> 
		</div>																																																					
        <!-- Modal footer -->
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
        </div>																																		
	</div>
</div>';

}


function getFormParametrageEventJRN()
{
    echo ' 
	<div id="div_parametrage_EventJRN">
		<div class="row">			
            <div class="col-sm-12 col-lg-12">
                <div class="card shadow-lg p-3 mb-5 bg-white rounded">
                    <div class="card-header bg-secondary">Journal events parameterization</div>
                    <div  class="card-body">
                        <div id="div_event_jrn">
                            <div class="form-group row"> 
                                <div class="col-md-6">
                                    <div  class="form-group">
                                        <label for="eventid1[]" class=" control-label">Suprervisor mode entry :</label>
                                        <select id="eventid1[]"  class="form-control" > <option value="599">SUPERVISOR MODE ENTRY</option>'; getEvent(""); echo'</select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div  class="form-group">
                                        <label for="eventid2[]" class=" control-label">Supervisor mode exit :</label>
                                        <select id="eventid2[]"  class="form-control" ><option value="600">SUPERVISOR MODE EXIT</option>'; getEvent(""); echo'</select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row"> 
                                <div class="col-md-6">
                                    <div  class="form-group">
                                        <label for="eventid3[]" class=" control-label">Connection to Server :</label>
                                        <select id="eventid3[]"  class="form-control" ><option value="604">CONNEXION </option>'; getEvent(""); echo'</select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div  class="form-group">
                                        <label for="eventid4[]" class=" control-label">In Service :</label>
                                        <select id="eventid4[]"  class="form-control" ><option value="596">SST IN SERVICE </option>'; getEvent(""); echo'</select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row"> 
                                <div class="col-md-6">
                                    <div  class="form-group">
                                        <label for="eventid5[]" class=" control-label">Out of Service :</label>
                                        <select id="eventid5[]"  class="form-control" ><option value="595">SST OUT OF SERVICE</option>'; getEvent(""); echo'</select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div  class="form-group">
                                        <label for="eventid6[]" class=" control-label">Transaction :</label>
                                        <select id="eventid6[]"  class="form-control" ><option value="581">TRANSACTION</option>'; getEvent(""); echo'</select>
                                    </div>
                                </div>
                            </div>

                            <div  class="form-group col-sm-12 text-right">
                                <label  class="col-sm-6 control-label"></label>
                                <div class="col-sm-12 ">
                                    <button type="button" class="btn btn-danger" onclick="javascript:getconfigevrnt()">Validate</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
		</div>
	</div> ';

}
//////////////////////////////////////////////

function get_all_gap_passive()
{

    echo '<tbody id="div_info_gap_passive">
    <div>';
    $connexion=ma_db_connexion();
    $SQL="SELECT `atm_profile`.`description`,`type_transaction`.`libelle_type`,`config_passive_values`.`passive_value`,`config_passive_values`.`passive_value_night`,
	`config_passive_values`.`start_date_day`,`config_passive_values`.`end_date_day`FROM `atm_profile`,`type_transaction`,`config_passive_values`
	WHERE `atm_profile`.`id_profile`=`config_passive_values`.`id_profile` AND `type_transaction`.`id`=`config_passive_values`.`type_transaction` ORDER BY `atm_profile`.`description`;";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 114:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 114 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $passive_val =$row["passive_value"]. "min";
                $passive_val_night =$row["passive_value_night"]. "min";
                $passive_date_day =$row["start_date_day"];
                $passive_end_date_day =$row["end_date_day"];

                if($passive_val==0)
                {
                    $passive_val="---";
                }
                if($passive_val_night==0)
                {
                    $passive_val_night="---";
                }
                if($passive_date_day=="00:00:00")
                {
                    $passive_date_day="---";
                }
                if($passive_end_date_day=="00:00:00")
                {
                    $passive_end_date_day="---";
                }
                echo '<tr>
                    <td style="padding: 3px" align="left"> ' .$row["description"] . '</td>
                    <td style="padding: 3px" align="center"> ' .$row["libelle_type"]  . '</td>
                    <td style="padding: 3px" align="center"> ' . $passive_val . '  / ' . $passive_val_night . ' </td>
                    <td style="padding: 3px" align="center"> ' . $passive_date_day . ' - ' . $passive_end_date_day . '</td>';
                $g++;
            }
        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);

    echo '
                     </td>
                    </tr>
                    </div></tbody>';
}
function get_all_mode_superviseur()
{
    echo '<tbody id="div_info_superviseur">
    <div>';
    $connexion=ma_db_connexion();

    $SQL= "SELECT `atm_profile`.`description`,`config_supervisor_mode_values`.`value` FROM `atm_profile`,`config_supervisor_mode_values` 
	WHERE `atm_profile`.`id_profile`=`config_supervisor_mode_values`.`id_profile`;";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 115:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 115 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $profil =$row["description"];
                $supervisor_mode =$row["value"];
                if($profil=="")
                {
                    $profil="---";
                }
                if($supervisor_mode==0)
                {
                    $supervisor_mode="---";
                }
                echo '<tr>
                    <td style="padding: 3px" align="left"> ' . $profil . '</td>
                    <td style="padding: 3px" align="center"> ' . $supervisor_mode . '</td>';
                $g++;
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

    echo '
             </td>
            </tr>
            </div></tbody>';
}

function getallcongjrn()
{
    echo '<tbody id="div_info_parametrage">
    <div>';
    $connexion=ma_db_connexion();
    $SQL = "SELECT DISTINCT `config_events_journal`.`id_type`,`type_events_journal`.`Description` FROM `config_events_journal` ,`type_events_journal` 
	where `config_events_journal`.id_type=`type_events_journal`.id_type ORDER BY `config_events_journal`.id_type ASC ; ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 116:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 116 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g = 0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_type_jrn = $row["id_type"];
                $sql1 = "SELECT `list_events`.`name_event`,`config_events_journal`.`id_event` FROM `config_events_journal`,`list_events` 
				WHERE `list_events`.`id_event` = `config_events_journal`.`id_event` and `config_events_journal`.`id_type`=". mysqli_real_escape_string($connexion,$id_type_jrn)." ";
                $result1=mysqli_query($connexion,$sql1);
                if (!$result1)
                {
                    error_log("Erreur SQL 117:  ".$sql1."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 117 !');
                }
                if ($result1)
                {
                    echo '<tr>
                    <td style="padding: 3px" align="left"> ' . $row["Description"] . '</td>
                    <td style="padding: 3px" align="left">
                     <ul>';
                    if(mysqli_num_rows($result1)>0)
                    {
                        $j = 0;
                        while ($row1 = mysqli_fetch_assoc($result1))
                        {
                            $d_name_event = $row1["id_event"];
                            echo ' <li>' . $row1["name_event"]  . '
                                     <span class="fa fa-times" style="color: red" onclick="javascript:deletconfigevent(\'' . $d_name_event . '\'); javascript:reloadDiv();"></span>
                                     </li>';
                            $j++;
                        }
                    }
                    mysqli_free_result($result1);
                }
                echo '
                       </ul>
                     </td>
                    </tr>';
                $g++;
            }
        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);

    echo '</div></tbody>';
}

function deletconfigevent($d_name_event)
{
    $connexion=ma_db_connexion();
    $SQL = "DELETE FROM `config_events_journal` WHERE `id_event`='".mysqli_real_escape_string($connexion,$d_name_event)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 118:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 118 !');
    }
    mysqli_close($connexion);
}

function getconfigevrnt($aldiv)
{
    $connexion=ma_db_connexion();
    $req = "INSERT IGNORE INTO config_events_journal (`id_type`,`id_event`) VALUES ".mysqli_real_escape_string($connexion,$aldiv)." ;";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$req);
    if (!$result)
    {
        error_log("Erreur SQL 119:  ".$req."  ".mysqli_error($connexion));
        die('ERREUR QUERY 119 !');
    }
    mysqli_close($connexion);
}
/***************************************************************************************************************************/
function get_atm_profil($profil)
{

    include "languages/" . $_SESSION['lang'] . ".php";
    include "../languages/" . $_SESSION['lang'] . ".php";

    $connexion=ma_db_connexion();
    if(!isset($_POST['profil']))
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`terminal`, 
        `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` , `new_list_gab`.`adresse_gab` ,`atm_profile`.`description`
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm`";
    }
    else if($_POST['profil']==2)
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`terminal`, 
        `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` , `new_list_gab`.`adresse_gab` ,`atm_profile`.`description`
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm`";
    }
    else
    {

        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`terminal`, 
        `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` , `new_list_gab`.`adresse_gab` ,`atm_profile`.`description`
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm` AND `atm_profile`.`id_profile` = ".mysqli_real_escape_string($connexion,$profil)." " ;
    }

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 119:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 119 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g = 0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_attm =$row["id_terminal_xfs"];
                $SQL = "SELECT `history_images`.`date_insertion` as maxdate , `state_image`.`description` as maxstate,
				`history_images`.`state` as state FROM `history_images`,`list_atm_confirmed`,`state_image` where `list_atm_confirmed`.`id_atm` = `history_images`.`id_atm` 
				AND   `history_images`.`state`=`state_image`.`id` AND `history_images`.`id_atm`= ".mysqli_real_escape_string($connexion,$id_attm)." ORDER BY `history_images`.`id` DESC LIMIT 1";
                $result1=mysqli_query($connexion,$SQL);
                if (!$result1)
                {
                    error_log("Erreur SQL 120:  ".$SQL."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 120 !');
                }
                if ($result1)
                {
                    $maxdate="";
                    $maxstate="";
                    $etatstate="";
                    if(mysqli_num_rows($result1)>0)
                    {
                        $row1 = mysqli_fetch_assoc($result1);
                        $maxdate= $row1["maxdate"];
                        $maxstate= $row1["maxstate"];
                        $etatstate= $row1["state"];
                    }
                    if($maxdate=="")
                    {
                        $maxdate="---";
                    }
                    if($maxstate=="")
                    {
                        $maxstate="---";
                    }

                    if ($etatstate  == "0" || $etatstate == "2")
                    {
                        echo '<tr> 
                            <td scope="row" style="padding: 3px" align="center">
                            <input type="checkbox" class="checkbox" value="'. $row["id_terminal_xfs"] .'"   >
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . '</td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            <td style="padding: 3px" align="center">' . $maxstate . '<span class="cil-cloud-upload" style="color: #5CB85C;" aria-hidden="false"></span> </td>
                           </tr>';
                    }
                    else if ($etatstate == "1" )
                    {
                        echo '<tr> 
                            <td scope="row" style="padding: 3px" align="center">
                            <input type="checkbox" class="checkbox" value="'. $row["id_terminal_xfs"] .'"   >
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . ' </td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            <td style="padding: 3px" align="center">' . $maxstate . ' <span class="cil-cloud-upload" style="color: #FFA07A;" aria-hidden="false"></span></td>
                           </tr>';
                    }
                    else if ($etatstate == "3" || $etatstate == "4" || $etatstate == "5" || $etatstate == "6")
                    {
                        echo '<tr> 
                            <td scope="row" style="padding: 3px" align="center">
                            <input type="checkbox" class="checkbox" value="'. $row["id_terminal_xfs"] .'">
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . '</td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            <td style="padding: 3px" align="center">' . $maxstate . ' <span class="cil-cloud-upload" style="color: #FF0000;" aria-hidden="false"></span> </td>
                        </tr>';
                    }
                    else
                    {
                        //echo $row["id_terminal_xfs"]."<br>";
                        echo '<tr> 
                            <td scope="row" style="padding: 3px" align="center">
                                <input type="checkbox" class="checkbox" value="'. $row["id_terminal_xfs"] .'">
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . '</td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            
                            <td style="padding: 3px" align="center">' . $maxstate . '</td>

                        </tr>';
                    }
                    $g++;
                    mysqli_free_result($result1);
                }
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
        echo'
        </tbody>
    </table>';


}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_atm_comp($profil,$idatms,$id_compaign,$disabled)
{
    $connexion=ma_db_connexion();

    if($profil==2)
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`terminal`, 
        `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` , `new_list_gab`.`adresse_gab` ,`atm_profile`.`description`
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm` ";
    }
    else
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`terminal`, 
        `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` , `new_list_gab`.`adresse_gab` ,`atm_profile`.`description`
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm` AND `atm_profile`.`id_profile` = ".mysqli_real_escape_string($connexion,$profil)." ";
    }
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 121:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 121 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g = 0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $selectedOptions = explode(',', $idatms);
               // echo "Count : ".count($selectedOptions);
                $checked = in_array($row["id_terminal_xfs"], $selectedOptions) ? 'checked' : '';
                $id_attm =$row["id_terminal_xfs"];
                $SQL = "SELECT `history_images`.`date_insertion` as maxdate , `state_image`.`description` as maxstate,`history_images`.`state` as state 
				FROM `history_images`,`list_atm_confirmed`,`state_image` where `list_atm_confirmed`.`id_atm` = `history_images`.`id_atm` 
				AND   `history_images`.`state`=`state_image`.`id` AND `history_images`.`id_atm`= ".mysqli_real_escape_string($connexion,$id_attm)." ORDER BY `history_images`.`id` DESC LIMIT 1";
                $result1=mysqli_query($connexion,$SQL);
                if (!$result1)
                {
                    error_log("Erreur SQL 122:  ".$SQL."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 122 !');
                }
                if ($result1)
                {
                    $maxdate="";
                    $maxstate="";
                    $etatstate="";
                    if(mysqli_num_rows($result1)>0)
                    {
                        $row1 = mysqli_fetch_assoc($result1);
                        $maxdate= $row1["maxdate"];
                        $maxstate= $row1["maxstate"];
                        $etatstate= $row1["state"];
                    }
                    if($maxdate=="")
                    {
                        $maxdate="---";
                    }
                    if($maxstate=="")
                    {
                        $maxstate="---";
                    }
                    if ($etatstate  == "0" || $etatstate == "2")
                    {
                        echo '<tr> 
                            <td scope="row" style="padding: 3px">
                            <input  type="checkbox" '.$checked.' '.$disabled.'  class="checkbox'.$id_compaign.'" value="'. $row["id_terminal_xfs"] .'"   >
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . '</td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            <td style="padding: 3px" align="center">' . $maxstate . '<span class="cil-cloud-upload" style="color: #5CB85C;" aria-hidden="false"></span> </td>
                           </tr>';
                    }
                    else if ($etatstate == "1" )
                    {
                        echo '<tr> 
                            <td scope="row" style="padding: 3px">
                            <input type="checkbox" '.$checked.' '.$disabled.' class="checkbox'.$id_compaign.'" value="'. $row["id_terminal_xfs"] .'"   >
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . ' </td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            <td style="padding: 3px" align="center">' . $maxstate . ' <span class="cil-cloud-upload" style="color: #FFA07A;" aria-hidden="false"></span></td>
                           </tr>';
                    }
                    else if ($etatstate == "3" || $etatstate == "4" || $etatstate == "5" || $etatstate == "6")
                    {
                        echo '<tr> 
                            <td scope="row" style="padding: 3px">
                            <input  type="checkbox" '.$checked.' '.$disabled.'  class="checkbox'.$id_compaign.'" value="'. $row["id_terminal_xfs"] .'">
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . '</td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            <td style="padding: 3px" align="center">' . $maxstate . ' <span class="cil-cloud-upload" style="color: #FF0000;" aria-hidden="false"></span> </td>
                        </tr>';
                    }
                    else
                    {
                        echo '<tr> 
                            <td scope="row" style="padding: 3px">
                            <input  type="checkbox" '.$checked.' '.$disabled.' class="checkbox'.$id_compaign.'" value="'. $row["id_terminal_xfs"] .'">
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . '</td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            <td style="padding: 3px" align="center">' . $maxstate . ' </td>
                        </tr>';
                    }


                    $g++;
                    mysqli_free_result($result1);
                }
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    echo'<tr>
            <td colspan="8" align="center"></td>
        </tr> ';


}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_atm_new_comp($profil)
{
    $connexion=ma_db_connexion();
    if(!isset($_POST['profil']))
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`terminal`, 
        `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` , `new_list_gab`.`adresse_gab` ,`atm_profile`.`description`
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm` AND `new_list_gab`.id_activation = 1";

    }
    else if($_POST['profil']==2)
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`terminal`, 
        `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` , `new_list_gab`.`adresse_gab` ,`atm_profile`.`description`
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm` AND `new_list_gab`.id_activation = 1";

    }
    else
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`terminal`, 
        `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` , `new_list_gab`.`adresse_gab` ,`atm_profile`.`description`
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm` AND `new_list_gab`.id_activation = 1 AND `atm_profile`.`id_profile` = ".mysqli_real_escape_string($connexion,$profil)." " ;

    }

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 123:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 123 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g = 0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_attm =$row["id_terminal_xfs"];
                $SQL = "SELECT `history_images`.`date_insertion` as maxdate , `state_image`.`description` as maxstate,`history_images`.`state` as state 
				FROM `history_images`,`list_atm_confirmed`,`state_image` where `list_atm_confirmed`.`id_atm` = `history_images`.`id_atm` AND   `history_images`.`state`=`state_image`.`id` 
				AND `history_images`.`id_atm`= ".mysqli_real_escape_string($connexion,$id_attm)." ORDER BY `history_images`.`id` DESC LIMIT 1";
                $result1=mysqli_query($connexion,$SQL);
                if (!$result1)
                {
                    error_log("Erreur SQL 124:  ".$SQL."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 124 !');
                }
                if ($result1)
                {
                    $maxdate="";
                    $maxstate="";
                    $etatstate="";
                    if(mysqli_num_rows($result1)>0)
                    {
                        $row1 = mysqli_fetch_assoc($result1);
                        $maxdate= $row1["maxdate"];
                        $maxstate= $row1["maxstate"];
                        $etatstate= $row1["state"];
                    }
                    if($maxdate=="")
                    {
                        $maxdate="---";
                    }
                    if($maxstate=="")
                    {
                        $maxstate="---";
                    }
                    if ($etatstate  == "0" || $etatstate == "2")
                    {
                        echo '<tr> 
                            <td scope="row" style="padding: 3px">
                            <input type="checkbox" class="checkbox" value="'. $row["id_terminal_xfs"] .'"   >
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . '</td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            <td style="padding: 3px" align="center">' . $maxstate . '<span class="cil-cloud-upload" style="color: #5CB85C;" aria-hidden="false"></span> </td>
                           </tr>';
                    }
                    else if ($etatstate == "1" )
                    {
                        echo '<tr> 
                            <td scope="row" style="padding: 3px">
                            <input type="checkbox" class="checkbox" value="'. $row["id_terminal_xfs"] .'"   >
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . ' </td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            <td style="padding: 3px" align="center">' . $maxstate . ' <span class="cil-cloud-upload" style="color: #FFA07A;" aria-hidden="false"></span></td>
                           </tr>';
                    }
                    else if ($etatstate == "3" || $etatstate == "4" || $etatstate == "5" || $etatstate == "6")
                    {
                        echo '<tr> 
                            <td scope="row" style="padding: 3px">
                            <input type="checkbox" class="checkbox" value="'. $row["id_terminal_xfs"] .'">
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . '</td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            <td style="padding: 3px" align="center">' . $maxstate . ' <span class="cil-cloud-upload" style="color: #FF0000;" aria-hidden="false"></span> </td>
                        </tr>';
                    }
                    else
                    {
                        echo '<tr> 
                            <td scope="row" style="padding: 3px">
                            <input type="checkbox" class="checkbox" value="'. $row["id_terminal_xfs"] .'">
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . '</td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            <td style="padding: 3px" align="center">' . $maxstate . ' </td>
                        </tr>';
                    }
                    $g++;
                    mysqli_free_result($result1);
                }
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    echo'<tr>
                <td colspan="8" align="center"></td>
            </tr>
        </tbody>
    </table>';


}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_atm_relaunch_Campaign($id_compaign)
{

    echo' <table id="tbl_relaunch_Campaign'.$id_compaign.'"  class="table table-bordered table-hover table-striped"   width="100%">
                                <thead class="text-warning">
                                    <th ><input type="checkbox" id="checkAllcompaign'.$id_compaign.'" value="0" onclick="chackallcomp(\'' .$id_compaign .'\')" checked></th>
                                    <th>ID</th>
                                    <th>ATM Name</th>
                                    <th>ATM ID	</th>
                                    <th>ATM profile</th>
                                    <th>Number of undeployed images</th>
                                </thead>
                                <tbody id="tbody_tbl_relaunch_Campaign'.$id_compaign.'">';


    $connexion=ma_db_connexion();

    $SQL1="SELECT `history_images`.`id_atm`, `new_list_gab`.`terminal`,`new_list_gab`.`nom_gab` ,`atm_profile`.`description`,count(`history_images`.`id`) as `nbr_image`
          FROM `history_images`,`new_list_gab`,`atm_profile` WHERE `new_list_gab`.`id_terminal_xfs`=`history_images`.`id_atm` AND `new_list_gab`.`id_profil` = `atm_profile`.`id_profile`  
	 AND `history_images`.`state` NOT IN (0,2,1) AND `history_images`.`state_relance` = 0 AND  `history_images`.`id_compaign` = '" . mysqli_real_escape_string($connexion,$id_compaign) . "'  
	 GROUP BY `history_images`.`id_atm` ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 125:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 125 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                    echo '<tr> 
                        <td scope="row" style="padding: 3px">
                        <input  type="checkbox" checked class="checkbox'.$id_compaign.'" value="'. $row["id_atm"] .'"   >
                        </td>
                        <td style="padding: 3px" align="center">' . $row["id_atm"] . '</td>
                        <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                        <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                        <td style="padding: 3px" align="center">' . $row["description"] . '</td>
                        <td style="padding: 3px" align="center">' . $row["nbr_image"] . '</td>
                       </tr>';
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    echo'<tr>
            <td colspan="8" align="center"></td>
        </tr> 
        </tbody>
         </table>';


}

/**********************************************************************/
function get_images_relaunch_Campaign($id_compaign)
{
    $connexion=ma_db_connexion();
    echo' <table id="tbl_image_Campaign'.$id_compaign.'"  class="table table-bordered table-hover table-striped"  width="100%">
                                <thead class="text-warning">
                                    <th>ID GAB</th>
                                    <th>Nom Image</th>
                                    <th>Etat Image</th>
                                </thead>
                                <tbody id="tbody_tbl_image_Campaign'.$id_compaign.'">';
    $SQL1 = "SELECT   `name_picture`, `description`,`id_atm` FROM `history_images`,`state_image`,`new_list_gab`
             WHERE `history_images`.`id_atm`=`new_list_gab`.`id_terminal_xfs` and `history_images`.`state`=`state_image`.`id`
			 AND `id_compaign` = ".mysqli_real_escape_string($connexion,$id_compaign)." AND `state` IN (3,4,5,6)";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 126:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 126 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<tr> 
                        <td style="padding: 3px" align="center">' . $row["id_atm"] . '</td>
                        <td style="padding: 3px" align="center">' . $row["name_picture"] . '</td>
                        <td style="padding: 3px" align="center">' . $row["description"] . '</td>
                       </tr>';
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

    echo'<tr>
            <td colspan="2" align="center"></td>
        </tr> 
        </tbody>
         </table>';
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function RelaunchComp($id_compaign,$id_atms)
{
    $okMessage ="Compagne relancer";
    $errorMessage = "Compagne non relancer";
    $connexion=ma_db_connexion();
    $array =explode(",",$id_atms);
    if(!empty($id_atms))
    {
        foreach ($array as $item)
        {
            $SQL = "SELECT `images_compaign`.`data` as `data_image`,`images_compaign`.`md5` as `md5`,`images_compaign`.`name_picture` as `name_picture`,`images_compaign`.`date_insert` as `date_insert`,
            `history_images`.`path` as `path`,`history_images`.`idprofil` as `idprofil`,`images_compaign`.`id_image` as `id_image`,`history_images`.`id` as `id_history_images`
                FROM `images_compaign`,`history_images` WHERE `history_images`.`id_atm` = ".mysqli_real_escape_string($connexion,$item)." 
				AND `history_images`.`id_compaign`=".mysqli_real_escape_string($connexion,$id_compaign) ."
                AND `history_images`.`id_image` = `images_compaign`.`id_image` AND `history_images`.`state_relance` = 0 AND `history_images`.`state` NOT IN(0,1,2);";

            mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
            $result=mysqli_query($connexion,$SQL);

            if ($result)
            {
                if(mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {
                        $dataImage= addslashes($row["data_image"]);
                        $md5Imag= mysqli_real_escape_string($connexion,$row["md5"]);
                        $pathImag= addslashes($row["path"]);

                        $SQL1 = "INSERT INTO images (" .
                            " data, md5, date_insertion, path,id_atm,name_picture,state,id_image,id_compaign,idprofil" .
                            ") VALUES ( " . "'" . $dataImage . "', 
							" . "'" . $md5Imag . "', now() , " . "'" . $pathImag . "',
							" . "'" . mysqli_real_escape_string($connexion,$item) . "', " . "'" . mysqli_real_escape_string($connexion,$row["name_picture"]) . "'
							,1,".mysqli_real_escape_string($connexion,$row["id_image"]).",".mysqli_real_escape_string($connexion,$id_compaign).",".mysqli_real_escape_string($connexion,$row["idprofil"])."); ";

                        $result1=mysqli_query($connexion,$SQL1);
                        if ($result1)
                        {
                            $responseArray = array('type' => 'success', 'message' => $okMessage);
                        }
                        else
                        {
                            error_log("Erreur SQL 128:  ".$SQL1."  ".mysqli_error($connexion));
                            $responseArray = array('type' => 'danger', 'message' => $errorMessage." Erreur SQL 128");
                            break;
                        }


                        $SQL2 ="UPDATE `history_images`  SET `history_images`.`state_relance` = 1 		
                        WHERE `history_images`.`id`= ".mysqli_real_escape_string($connexion,$row["id_history_images"])."; ";
                        $result2=mysqli_query($connexion,$SQL2);
                        if ($result2)
                        {
                            $responseArray = array('type' => 'success', 'message' => $okMessage);
                        }
                        else
                        {
                            error_log("Erreur SQL 129:  ".$SQL2."  ".mysqli_error($connexion));
                            $responseArray = array('type' => 'danger', 'message' => $errorMessage." Erreur SQL 129");
                            break;
                        }

                    }
                }
                mysqli_free_result($result);
            }
            else
            {
                error_log("Erreur SQL 127:  ".$SQL."  ".mysqli_error($connexion));
                $responseArray = array('type' => 'danger', 'message' => $errorMessage."Erreur SQL 127");
            }
        }
    }

    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Aucun GAB selectionné');
    }

mysqli_close($connexion);
$encoded = json_encode($responseArray);
header('Content-Type: application/json');
echo $encoded;


}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function get_bianire_profil($profil)
{

    $connexion=ma_db_connexion();
    if(!isset($_POST['profil']))
    {
        $SQL1 = "SELECT new_list_gab.id_terminal_xfs as id_terminal_xfs, new_list_gab.nom_gab as nom_gab , new_list_gab.code_bank as code_bank, 
	    new_list_gab.adresse_gab as adresse_gab,atm_profile.description as description , new_list_gab.terminal as terminal
	    FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` WHERE new_list_gab.id_profil= atm_profile.id_profile  
	    AND new_list_gab.id_terminal_xfs=list_atm_confirmed.id_atm ";

    }
    else if($_POST['profil']==2)
    {
        $SQL1 = "SELECT new_list_gab.id_terminal_xfs as id_terminal_xfs, new_list_gab.nom_gab as nom_gab , new_list_gab.code_bank as code_bank, 
	    new_list_gab.adresse_gab as adresse_gab,atm_profile.description as description , new_list_gab.terminal as terminal
	    FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` WHERE new_list_gab.id_profil= atm_profile.id_profile  
	    AND new_list_gab.id_terminal_xfs=list_atm_confirmed.id_atm ";

    }
    else
    {
        $SQL1 = "SELECT new_list_gab.id_terminal_xfs as id_terminal_xfs, new_list_gab.nom_gab as nom_gab , new_list_gab.code_bank as code_bank, 
	    new_list_gab.adresse_gab as adresse_gab,atm_profile.description as description , new_list_gab.terminal as terminal
	    FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` WHERE new_list_gab.id_profil= atm_profile.id_profile  
	    AND new_list_gab.id_terminal_xfs=list_atm_confirmed.id_atm AND atm_profile.id_profile = ".mysqli_real_escape_string($connexion,$profil)." " ;

    }

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 130:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 130 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g = 0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_attm = $row["id_terminal_xfs"];
                $SQL2 = "SELECT `history_binaire_client`.`date_insertion` as maxdate , `state_binaire`.`description` as maxstate,`history_binaire_client`.`state_binaire` as state 
				FROM `history_binaire_client`,`list_atm_confirmed`,`state_binaire` where `list_atm_confirmed`.`id_atm` = `history_binaire_client`.`id_atm` 
				AND   `history_binaire_client`.`state_binaire`=`state_binaire`.`id` AND `history_binaire_client`.`id_atm`= ".mysqli_real_escape_string($connexion,$id_attm)." ORDER BY `history_binaire_client`.`id` DESC LIMIT 1";
                $result1=mysqli_query($connexion,$SQL2);
                if (!$result1)
                {
                    error_log("Erreur SQL 131:  ".$SQL2."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 131 !');
                }
                if ($result1)
                {
                    $maxdate="";
                    $maxstate="";
                    $etatstate="";
                    if(mysqli_num_rows($result1)>0)
                    {
                        $row1 = mysqli_fetch_assoc($result1);
                        $maxdate= $row1["maxdate"];
                        $maxstate= $row1["maxstate"];
                        $etatstate= $row1["state"];
                    }
                    if($maxdate=="")
                    {
                        $maxdate="---";
                    }
                    if($maxstate=="")
                    {
                        $maxstate="---";
                    }
                    if ($etatstate  == "0" || $etatstate == "2")
                    {
                        echo '<tr> 
                            <td class="text-center">
                                <input type="checkbox" class="checkbox check_prof" name="chekedTreminal[]" value="'. $row["id_terminal_xfs"] .'" >
                            </td>
                            <td class="text-center">' . $row["id_terminal_xfs"] . '</td>
                            <td class="text-center">' . $row["terminal"] . '</td>
                            <td class="text-center">' . $row["nom_gab"] . '</td>
                            <td class="text-center">' . $row["description"] . '</td>
                            <td class="text-center">' . $maxdate . '</td>
                            <td class="text-center">' . $maxstate . '<span class="cil-cloud-upload" style="color: #5CB85C;" aria-hidden="false"></span> </td>
                           </tr>';
                    }
                    else if ($etatstate == "1" )
                    {
                        echo '<tr> 
                            <td class="text-center">
                                <input type="checkbox" class="checkbox check_prof" name="chekedTreminal[]" value="'. $row["id_terminal_xfs"] .'" >
                            </td>
                            <td class="text-center">' . $row["id_terminal_xfs"] . '</td>
                            <td class="text-center">' . $row["terminal"] . '</td>
                            <td class="text-center">' . $row["nom_gab"] . '</td>
                            <td class="text-center">' . $row["description"] . ' </td>
                            <td class="text-center">' . $maxdate . '</td>
                            <td class="text-center">' . $maxstate . ' <span class="cil-cloud-upload" style="color: #FFA07A;" aria-hidden="false"></span></td>
                           </tr>';
                    }
                    else if ($etatstate == "3" || $etatstate == "4" || $etatstate == "5" || $etatstate == "6")
                    {
                        echo '<tr> 
                            <td class="text-center">
                                <input type="checkbox" class="checkbox check_prof" name="chekedTreminal[]" value="'. $row["id_terminal_xfs"] .'" >
                            </td>
                            <td class="text-center">' . $row["id_terminal_xfs"] . '</td>
                            <td class="text-center">' . $row["terminal"] . '</td>
                            <td class="text-center">' . $row["nom_gab"] . '</td>
                            <td class="text-center">' . $row["description"] . '</td>
                            <td class="text-center">' . $maxdate . '</td>
                            <td class="text-center">' . $maxstate . ' <span class="cil-cloud-upload" style="color: #FF0000;" aria-hidden="false"></span> </td>
                        </tr>';
                    }
                    else
                    {
                        echo '<tr> 
                            <td class="text-center">
                                <input type="checkbox" class="checkbox check_prof" name="chekedTreminal[]" value="'. $row["id_terminal_xfs"] .'" >
                            </td>
                            <td class="text-center">' . $row["id_terminal_xfs"] . '</td>
                            <td class="text-center">' . $row["terminal"] . '</td>
                            <td class="text-center">' . $row["nom_gab"] . '</td>
                            <td class="text-center">' . $row["description"] . '</td>
                            <td class="text-center">' . $maxdate . '</td>
                            <td class="text-center">' . $maxstate . ' </td>
                        </tr>';
                    }

                    $g++;
                    mysqli_free_result($result1);
                }
            }

        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);

}
/**********************************************************************************************************************************/
function get_bianire_profil_echoues($profil)
{

    $connexion=ma_db_connexion();
    if(!isset($_POST['profil']))
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`nom_gab` , `new_list_gab`.`terminal` , `atm_profile`.`description` 
	    FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
	    AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm`";
    }
    else if($_POST['profil']==2)
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`nom_gab` , `new_list_gab`.`terminal`  ,`atm_profile`.`description` 
	    FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
    	AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm`";
    }
    else
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`nom_gab` , `new_list_gab`.`terminal` ,`atm_profile`.`description` 
	    FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
    	AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm` AND `atm_profile`.`id_profile` = ".mysqli_real_escape_string($connexion,$profil)." ";
    }


    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 132:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 132 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g = 0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_attm = $row["id_terminal_xfs"];
                $SQL2 = "SELECT `history_binaire_client`.`date_insertion`,`state_binaire`.`description` ,history_binaire_client.state_binaire
			    FROM `history_binaire_client`,`list_atm_confirmed`,`state_binaire` where `list_atm_confirmed`.`id_atm` = `history_binaire_client`.`id_atm` 
			    AND `state_binaire`.`id`= `history_binaire_client`.`state_binaire` AND `history_binaire_client`.`state_binaire` NOT IN (0,1,2) 
				AND `history_binaire_client`.`id_atm`= ".mysqli_real_escape_string($connexion,$id_attm)." 
			    ORDER BY `history_binaire_client`.`id`  DESC ";
                $result1=mysqli_query($connexion,$SQL2);
                if (!$result1)
                {
                    error_log("Erreur SQL 133:  ".$SQL2."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 133 !');
                }
                if ($result1)
                {
                    if(mysqli_num_rows($result1)>0 )
                    {
                        $row1 = mysqli_fetch_assoc($result1);

                            $maxdate = $row1["date_insertion"];
                            $maxstate = $row1["description"];
                        echo '<tr> 
                            <td scope="row" style="padding: 3px" align="center">
                            <input type="checkbox" class="custom-control-input check_prof" name="chekedTreminal[]" value="'. $row["id_terminal_xfs"] .'"   >
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . '</td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            <td style="padding: 3px" align="center">' . $maxstate . ' <span class="cil-cloud-upload" style="color: #FF0000;" aria-hidden="false"></span> </td>
                        </tr>';

                    }
                    $g++;
                    mysqli_free_result($result1);
                }
            }
        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);



}
/**********************************************************************************************************************************/
function get_bianire_profil_for_commande($profil)
{
    include "languages/" . $_SESSION['lang'] . ".php";
    include "../languages/" . $_SESSION['lang'] . ".php";

    $connexion=ma_db_connexion();

    echo '
        
		<table id="tbl_prof" class="table table-responsive-sm table-hover table-outline mb-0">
            <thead class="thead-light">
            <tr>
                <th class="text-center" ><input type="checkbox" id="checkAll" value="0"></th>
                <th class="text-center">ID</th>
                <th class="text-center">'.$lang['atm_id'].'</th>
                <th class="text-center">'.$lang['atm_name'].'</th>
                <th class="text-center">'.$lang['atm_profil'].'</th>
                <th class="text-center">'.$lang['dat_cmd'].' </th>
                <th class="text-center">'.$lang['type_cmd'].'</th> 
                <th class="text-center">'.$lang['dat_exc_cmd'].'</th> 
                <th class="text-center">'.$lang['return_cmd'].'</th>
            </tr>
            </thead>
            <tbody id="tbl_prof_tbody" >';

    if(!isset($_POST['profil']))
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` , 
        `new_list_gab`.`adresse_gab` ,`atm_profile`.`description` , `new_list_gab`.`terminal`
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm` 
        and `list_atm_confirmed`.`state` = 1 ";
    }
    else if($profil==2)
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` , 
        `new_list_gab`.`adresse_gab` ,`atm_profile`.`description` , `new_list_gab`.`terminal`
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm`
        AND `list_atm_confirmed`.`state` = 1 ";
    }
    else
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` , 
        `new_list_gab`.`adresse_gab` ,`atm_profile`.`description` , `new_list_gab`.`terminal`
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm` AND `atm_profile`.`id_profile` = ".mysqli_real_escape_string($connexion,$profil)." 
        AND `list_atm_confirmed`.`state` = 1";
    }


    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 134:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 134 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g = 0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_attm = $row["id_terminal_xfs"];
                $SQL = "SELECT list_cmd_for_atm.description_cmd, hist_cmd_execution.date_send_cmd, hist_cmd_execution.date_after_exec_cmd,hist_cmd_execution.value_cmd,hist_cmd_execution.if_executed
			    FROM hist_cmd_execution,list_cmd_for_atm
			    WHERE  id_atm = ".mysqli_real_escape_string($connexion,$id_attm)."
				AND hist_cmd_execution.id_cmd=  list_cmd_for_atm.id_command		 
				ORDER BY id_exec_cmd DESC LIMIT 1	";
                mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
                $result1=mysqli_query($connexion,$SQL);
                if (!$result1)
                {
                    error_log("Erreur SQL 135:  ".$SQL."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 135 !');
                }
                if ($result1)
                {
                    $row1 = mysqli_fetch_assoc($result1);
                    if(mysqli_num_rows($result1)>0)
                    {
                        $dateSend=$row1["date_send_cmd"];
                        $dateAfter=$row1["date_after_exec_cmd"];
                        $if_executed=$row1["if_executed"];
                        $typeCmd= $row1["description_cmd"];
                    }
                    else
                    {
                        $dateSend="---";
                        $if_executed="0";
                        $dateAfter="---";
                        $typeCmd="---";
                    }

                if($typeCmd == "Capture écran" && $if_executed != "0")
                {
                    echo '<tr>

                        <td style="padding: 3px" class="text-center">
                            <input type="checkbox" class="checkbox check_prof" name="chekedTreminal[]" value="'. $row["id_terminal_xfs"] .'"   >
                        </td>
                        
                        <td style="padding: 3px" class="text-center">' . $row["id_terminal_xfs"] . '</td>
                        <td style="padding: 3px" class="text-center">' . $row["terminal"] . '</td>
                        <td style="padding: 3px" class="text-center">' . $row["nom_gab"] . '</td>
                        <td style="padding: 3px" class="text-center">' . $row["description"] . '</td>
                        <td style="padding: 3px" class="text-center">' . $dateSend . '</td>
                        <td style="padding: 3px" class="text-center">' . $typeCmd . '</td>
                        <td style="padding: 3px" class="text-center">' . $dateAfter . '</td>
                        <td style="padding: 3px" class="text-center">
                             <a tabindex="-1"  data-toggle="modal"  
                             onClick="javascript:ShowScreenshotATM(\''.$id_attm.'\',\''.$row1["value_cmd"].'\')"   
                              data-target="#showScreenshotATM"><i class="fa fa-eye" title="Capture écran"></i>
                        </td>
                    
                    </tr>';
                }
                else
                {
                    echo '<tr> 
                        <td style="padding: 3px" class="text-center">
                            <input type="checkbox" class="checkbox check_prof" name="chekedTreminal[]" value="'. $row["id_terminal_xfs"] .'"   >
                        </td>
                        <td style="padding: 3px" class="text-center">' . $row["id_terminal_xfs"] . '</td>
                        <td style="padding: 3px" class="text-center">' . $row["terminal"] . '</td>
                        <td style="padding: 3px" class="text-center">' . $row["nom_gab"] . '</td>
                        <td style="padding: 3px" class="text-center">' . $row["description"] . '</td>
                        <td style="padding: 3px" class="text-center">' . $dateSend . '</td>
                        <td style="padding: 3px" class="text-center">' . $typeCmd . '</td>
                        <td style="padding: 3px" class="text-center">' . $dateAfter . '</td>
                        <td style="padding: 3px" class="text-center">' . $row1["value_cmd"] . '</td>
                    </tr>';
                 }

                    $g++;
                    mysqli_free_result($result1);
                }
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

    echo'</tbody></table>';
}
/**********************************************************************************************************************************/

/**********************************************************************************************************************************/
function get_bianire_profil_for_mode_execution($profil)
{

    $connexion=ma_db_connexion();

    if(!isset($_POST['profil']))
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` ,
        `new_list_gab`.`adresse_gab` ,`atm_profile`.`description` , `new_list_gab`.terminal
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm`  ";

    }
    else if($profil==2)
    {

        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` ,
        `new_list_gab`.`adresse_gab` ,`atm_profile`.`description` , `new_list_gab`.terminal
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm`  ";

    }
    else
    {

        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`nom_gab` , `new_list_gab`.`code_bank` ,
        `new_list_gab`.`adresse_gab` ,`atm_profile`.`description` , `new_list_gab`.terminal
        FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed` where `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  
        AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm` AND `atm_profile`.`id_profile` = ".mysqli_real_escape_string($connexion,$profil)." ";

    }

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 136:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 136 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g = 0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_attm = $row["id_terminal_xfs"];
                $SQL = "SELECT execution_mode_version,date_change_mode,description_mode
                FROM type_execution_mode,hist_execution_mode
                where type_execution_mode.id_mode=hist_execution_mode.execution_mode AND id_atm= ".mysqli_real_escape_string($connexion,$id_attm)."
                ORDER BY id_insert DESC LIMIT 1";
                $result1=mysqli_query($connexion,$SQL);
                if (!$result1)
                {
                    error_log("Erreur SQL 137:  ".$SQL."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 137 !');
                }
                if ($result1)
                {

                    if(mysqli_num_rows($result1)>0)
                    {
                        $row1 = mysqli_fetch_assoc($result1);
                        $dateChang = $row1["date_change_mode"];
                        $typeCang = $row1["description_mode"];
                        $version = $row1["execution_mode_version"];
                    }
                    else
                    {
                        $dateChang="---";
                        $typeCang="---";
                        $version="---";
                    }

                    echo '<tr> 
                        
                    <td class="text-center" style="padding: 3px" >
                    <input type="checkbox" class="check_prof" name="chekedTreminal[]"   value="'. $row["id_terminal_xfs"] .'"   >
                    </td>
                    <td style="padding: 3px" class="text-center">' . $row["id_terminal_xfs"] . '</td>
                    <td style="padding: 3px" class="text-center">' . $row["terminal"] . '</td>
                    <td style="padding: 3px" class="text-center">' . $row["nom_gab"] . '</td>
					<td style="padding: 3px" class="text-center">' .$row["description"] . '</td>
                    <td style="padding: 3px" class="text-center">' . $dateChang . '</td>
                    <td style="padding: 3px" class="text-center">' . $typeCang . '</td>
                    <td style="padding: 3px" class="text-center">' . $version . '</td>
                    </tr>';
                    $g++;
                    mysqli_free_result($result1);
                }
            }

        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);

}
/**********************************************************************************************************************************/
function get_list_atm_suivi_client()
{

    include "languages/" . $_SESSION['lang'] . ".php";
    include "../languages/" . $_SESSION['lang'] . ".php";
    $connexion=ma_db_connexion();
    echo '
		 <table id="tbl_prof" class="table table-responsive-sm table-hover table-outline mb-0">
            <thead class="thead-light">
            <tr>
                <th class="text-center">ID</th>
                <th class="text-center">'. $lang['atm'].'</th>
                <th class="text-center">'. $lang['atm_name'].'</th>
                <th class="text-center">'. $lang['atm_profil'].'</th>
                <th class="text-center">'. $lang['last_date_conn_ver'].'</th>
                <th class="text-center">'. $lang['last_vers_conn_ver'].'</th>
            </tr>
            </thead>
            <tbody id="tbl_prof_tbody" >';


    $SQL1 = "SELECT new_list_gab.id_terminal_xfs, new_list_gab.nom_gab , new_list_gab.code_bank ,
	new_list_gab.adresse_gab ,atm_profile.description , new_list_gab.terminal,list_atm_confirmed.last_version,
	list_atm_confirmed.last_connexion FROM new_list_gab,atm_profile,list_atm_confirmed WHERE new_list_gab.id_profil = atm_profile.id_profile  
	AND new_list_gab.id_terminal_xfs=list_atm_confirmed.id_atm ";


    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 138:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 138 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<tr> 
                <td class="text-center">' . $row["id_terminal_xfs"] . '</td>
                <td class="text-center">' . $row["terminal"] . '</td>
                <td class="text-center">' . $row["nom_gab"] . '</td>
                <td class="text-center">' . $row["description"] . '</td>
                <td class="text-center">' . $row["last_connexion"] . '</td>
                <td class="text-center">' . $row["last_version"] . '</td>
                </tr>';
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    echo'</tbody>			   
            </table>';
}
/**********************************************************************************************************************************/
function getSendCommand($listGab,$valeurCommande,$path)
{
    if($listGab<>"" && $valeurCommande<>""  )
    {
        $connexion=ma_db_connexion();
        $SQL1 ="UPDATE cmd_execution  SET `cmd_execution`.`date_send_cmd` =now() ,
        `cmd_execution`.`id_cmd`= ".mysqli_real_escape_string($connexion,$valeurCommande)." , `cmd_execution`.`value_cmd`='".mysqli_real_escape_string($connexion,$path)."',
        cmd_execution.if_executed=0,
        `cmd_execution`.`user_exec`= ".$_SESSION['id_utilisateur']."				
        WHERE id_atm IN (".$listGab.") ; ";

        mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
        $result=mysqli_query($connexion,$SQL1);
        if (!$result)
        {
            error_log("Erreur SQL 139:  ".$SQL1."  ".mysqli_error($connexion));
            die('ERREUR QUERY 139 !');
        }
        if ($result)
        {
            //todo : json
            echo '<div class="alert alert-success" align="center" style="font-size:15px;font-weight:bold;">Commande enregistré</strong></div>';
        }
        mysqli_close($connexion);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center" style="font-size:15px;font-weight:bold;">Commande non enregistré</strong></div>';
    }
}
/**********************************************************************************************************************************/
function getSendModeExecution($listGab,$valeurCommande,$version)
{
    $okMessage ="Mode enregistrées";
    $errorMessage = "Mode non enregistrées";

    if((!empty($listGab)) && ($valeurCommande<>"" ))
    {
        $connexion=ma_db_connexion();
        $SQL1 ="UPDATE list_atm_confirmed  SET `list_atm_confirmed`.`execution_mode` =".mysqli_real_escape_string($connexion,$valeurCommande)." ,
			`list_atm_confirmed`.`execution_mode_version`= '".mysqli_real_escape_string($connexion,$version)."' 			
			WHERE id_atm IN (".$listGab.") ; ";
        mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
        $result=mysqli_query($connexion,$SQL1);
        if ($result)
        {
            $responseArray = array('type' => 'success', 'message' => $okMessage);
        }
        else
        {
            $responseArray = array('type' => 'danger', 'message' => $errorMessage." \n Erreur QUERY QS41C45");
            error_log("Erreur SQL QS41C45:  ".$SQL1."  ".mysqli_error($connexion));
        }
        
        mysqli_close($connexion);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Aucun GAB selectionné');
    }

    echo '<div class="alert alert-'.$responseArray["type"].' text-center">'.$responseArray["message"].'</strong></div>';


}
/**********************************************************************************************************************************/
function comm_atm_profil($profil)
{
    $connexion=ma_db_connexion();
    if($profil==0)
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`nom_gab` ,`new_list_gab`.`adresse_gab` ,`atm_profile`.`description`, `new_list_gab`.`terminal`
             FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed`
            WHERE `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm`  ";
    }
    else
    {
        $SQL1 = "SELECT `new_list_gab`.`id_terminal_xfs`, `new_list_gab`.`nom_gab` ,`new_list_gab`.`adresse_gab` ,`atm_profile`.`description`, `new_list_gab`.`terminal`
             FROM `new_list_gab`,`atm_profile`,`list_atm_confirmed`
            WHERE `new_list_gab`.`id_profil`= `atm_profile`.`id_profile`  AND `new_list_gab`.`id_terminal_xfs`=`list_atm_confirmed`.`id_atm` AND `atm_profile`.`id_profile` = ".mysqli_real_escape_string($connexion,$profil)." ";
    }
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 141:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 141 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g = 0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_attm = $row["id_terminal_xfs"];
                $SQL = "SELECT `history_images`.`date_insertion` as maxdate , `state_image`.`description` as maxstate,`history_images`.`state` as state 
				FROM `history_images`,`list_atm_confirmed`,`state_image` where `list_atm_confirmed`.`id_atm` = `history_images`.`id_atm` 
				AND   `history_images`.`state`=`state_image`.`id`   AND `history_images`.`id_atm`= ".mysqli_real_escape_string($connexion,$id_attm)."   ORDER BY `history_images`.`id` DESC LIMIT 1";
                $result1=mysqli_query($connexion,$SQL);
                if (!$result1)
                {
                    error_log("Erreur SQL 142:  ".$SQL."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 142 !');
                }
                if ($result1)
                {
                    if(mysqli_num_rows($result1)>0)
                    {
                        $row1 = mysqli_fetch_assoc($result1);
                        $maxdate = $row1["maxdate"];
                        $maxstate = $row1["maxstate"];
                        $state = $row1["state"];

                        if ($maxdate != "" && $state<>0 && $state<>1 && $state<>2)
                        {
                            echo '<tr> 
                            <td scope="row" style="padding: 3px" align="center">
                            <input type="checkbox" class="custom-control-input check_prof" value="' . $row["id_terminal_xfs"] . '"  >
                            </td>
                            <td style="padding: 3px" align="center">' . $row["id_terminal_xfs"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["terminal"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["nom_gab"] . '</td>
                            <td style="padding: 3px" align="center">' . $row["description"] . '</td>
                            <td style="padding: 3px" align="center">' . $maxdate . '</td>
                            <td style="padding: 3px" align="center">' . $maxstate . '  <span class="cil-cloud-upload" style="color: #FF0000;" aria-hidden="false"></span> </td>
                            </tr>';

                        }
                    }
                    $g++;
                    mysqli_free_result($result1);
                }
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_Compagnes_pub($lang)
{
    //var_dump($_POST['dated']);
    include("pagination.php");
    $connexion=ma_db_connexion();


    if(!isset($_POST['dated']) or !isset($_POST['datef']))
    {

        $SQL = "SELECT  `id_compaign`, `name`, `date_create`, `start_date_programed`, `date_execution`,`state_execution`,`description`,`path`,`atm_concerned`,`images_concerned`
                FROM `advertising_compaign` ORDER BY `date_create` DESC ";
        $page = new Pagination($SQL, 12);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();
    }

    else
    {
        include "../languages/" . $_SESSION['lang'] . ".php";
        include("../pagination.php");
        $dated = $_POST['dated']." 00:00:00" ;
        $datef = $_POST['datef']." 23:59:59" ;

        $SQL = "SELECT  `id_compaign`, `name`, `date_create`, `start_date_programed`, `date_execution`,`state_execution`,`description`,`path`,`atm_concerned`,`images_concerned`
                FROM `advertising_compaign` WHERE `start_date_programed` BETWEEN '".mysqli_real_escape_string($connexion,$dated)."' and '".mysqli_real_escape_string($connexion,$datef)."' ORDER BY `date_create` DESC ";

        $page = new Pagination($SQL, 12);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();
    }


    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 143:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 143 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g =0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $list_image=$row["images_concerned"];
                $atm_concerned= substr_count($row["atm_concerned"], ",")+1;
                $images_concerned= substr_count($row["images_concerned"], ",")+1;
              //$atm_concerned= $row["atm_concerned"];
                $id_compaign= $row["id_compaign"];
                $path= $row["path"];
                $description= $row["description"];
                $name_compaign= $row["name"];
                $date_create= $row["date_create"];
                $start_date_programed= $row["start_date_programed"];
                $date_execution= $row["date_execution"];

                $nbr_comp=0;
                $compagnes_success=0;
                $compagnes_Erreur=0;
                $compagnes_Timeout=0;
                $compagnes_not_yet=0;
                $sql1="SELECT id_atm, state 
                 FROM history_images WHERE id_compaign = ".mysqli_real_escape_string($connexion,$id_compaign)." AND `history_images`.`state_relance` = 0 ";
                $result1=mysqli_query($connexion,$sql1);
                if (!$result1)
                {
                    error_log("Erreur SQL 144:  ".$sql1."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 144 !');
                }
                if ($result1)
                {
                    if(mysqli_num_rows($result1)>0)
                    {
                        while ($row = mysqli_fetch_assoc($result1))
                        {
                            $state = $row["state"];
                            if(($state==0) || ($state==2))
                            {
                                $compagnes_success++;
                            }
                            if($state==1)
                            {
                                $compagnes_not_yet++;
                            }
                            if(($state==3) || ($state==4)|| ($state==5))
                            {
                                $compagnes_Erreur++;
                            }
                            if($state==6)
                            {
                                $compagnes_Timeout++;
                            }
                        }
                    }
                    mysqli_free_result($result1);
                }
                $sql2="SELECT id_atm, state 
                 FROM images WHERE id_compaign = ".$id_compaign." ";

                $result2=mysqli_query($connexion,$sql2);
                if (!$result2)
                {
                    error_log("Erreur SQL 145:  ".$sql2."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 145 !');
                }

                if ($result2)
                {
                    if(mysqli_num_rows($result2)>0)
                    {

                        while ($row = mysqli_fetch_assoc($result2))
                        {
                            $state = $row["state"];

                            if($state==1)
                            {
                                $compagnes_not_yet++;
                            }
                        }
                    }
                    mysqli_free_result($result2);
                }


                if($date_create=="0000-00-00 00:00:00")
                {
                    $date_create = "---";
                }
                if($start_date_programed=="0000-00-00 00:00:00")
                {
                    $start_date_programed = "---";
                }
                if($date_execution=="0000-00-00 00:00:00")
                {
                    $date_execution = "---";
                }

                if ($row["state_execution"]  == "0" || $row["state_execution"]  == "2" )
                {
                    echo '<tr style="padding: 3px">
                    <td scope="row" class="text-center" style="padding: 3px">' . ($g + 1) . '</td>
                    <td class="text-center" style="padding: 3px">' . $name_compaign . ' </td>
                    <td class="text-center" style="padding: 3px">' . $date_create. '</td>
                    <td class="text-center" style="padding: 3px">' . $start_date_programed . '</td>
                    <td class="text-center" style="padding: 3px" align="center">' . $date_execution . '</td>
                    <td class="text-center" id="td_'.$id_compaign.'" style="padding: 3px">';
                            if($row["state_execution"]  == "0" )
                            {
                                echo'<span class="cil-cloud-upload" style="color: #FFA07A;" aria-hidden="false" title="Campaign not executed"></span>';
                            }
                            if($row["state_execution"]  == "2" )
                            {
                                echo '<span class="cil-cloud-upload" style="color: #ff0000;" aria-hidden="false" title="Disable campaign"></span>';
                            }

                   echo'</td>
                    <td class="text-center" style="padding: 3px" align="center">';
                   getDetail_Compagnes_publicitaires($id_compaign,$name_compaign,$description,$path,$row["state_execution"]);
                    if(($compagnes_Erreur!=0) || ($compagnes_Timeout!=0))
                    {
                        get_relaunch_Campaign($id_compaign,$name_compaign);
                    }
                    echo'</td>';
                    echo '<td style="padding: 3px" align="center"> <a tabindex="-1"  data-toggle="modal" 
                            onClick="javascript:Show_All_Image_Comp(\''.$id_compaign.'\',\''.$list_image.'\',\''.$name_compaign.'\')"   
                            data-target="#detailALLShowImage"><i class="fa fa-eye" title="Display Image"></i> </a> </td>';
                    echo'</tr>';
                }

                else
                {
                    echo '<tr style="padding: 3px">
                     <td class="text-center" scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                      <td class="text-center" style="padding: 3px">' . $name_compaign . '</td>
                    <td class="text-center" style="padding: 3px">' . $date_create. '</td>
                    <td class="text-center" style="padding: 3px">' . $start_date_programed . '</td>
                    <td class="text-center" style="padding: 3px" align="center">' . $date_execution . '</td>
                 
                    <td class="text-center" style="padding: 3px"><span class="cil-cloud-upload" style="color: #5CB85C;" aria-hidden="false" title="Campagne exécutée"></span> </td>
                   <td class="text-center" style="padding: 3px" align="center">';
                    echo "<a style='vertical-align :middle;' ><span class='cil-people' aria-hidden='false'  title='Cannot edit ad campaigns'></span></a>";
                    if(($compagnes_Erreur!=0) || ($compagnes_Timeout!=0))
                    {
                        get_relaunch_Campaign($id_compaign,$name_compaign);
                    }
                    echo'</td>';
                    echo '<td class="text-center" style="padding: 3px" align="center"> <a tabindex="-1"  data-toggle="modal" 
											onClick="javascript:Show_All_Image_Comp(\''.$id_compaign.'\',\''.$list_image.'\',\''.$name_compaign.'\')" 
											data-target="#detailALLShowImage"><i class="fa fa-eye" title="Afficher Image"></i> </a> </td>';
                   echo'</tr>';
                }
                $g++;
            }
            echo '<tr><td colspan="9" class="text-center">';
            echo   '<ul class="pagination justify-content-center">'.$lien.'</ul>';
            echo   '<div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>';
            echo'</td></tr>';
        }
        else
        {
            echo'
           <tr>
                <td colspan="9" align="center"></td>
		   </tr> ';
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_schedule_ej_pub($lang)
{

    include("pagination.php");
    $connexion=ma_db_connexion();


    if(!isset($_POST['dated']) or !isset($_POST['datef']))
    {

        $SQL = "SELECT  `id_schedule`, `name`, `date_create`, `start_date_programed`, `frequenxe`, `date_execution`,`description`,`atm_concerned`
                FROM `schedule_pulling_ej` ORDER BY `date_create` DESC ";
        $page = new Pagination($SQL, 12);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();
    }

    else
    {
        include "../languages/" . $_SESSION['lang'] . ".php";
        include("../pagination.php");
        $dated = $_POST['dated']." 00:00:00" ;
        $datef = $_POST['datef']." 23:59:59" ;

        $SQL = "SELECT  `id_schedule`, `name`, `date_create`, `start_date_programed`, `frequenxe`, `date_execution`,`description`,`atm_concerned`
                FROM `schedule_pulling_ej` WHERE `date_create` BETWEEN '".mysqli_real_escape_string($connexion,$dated)."' and '".mysqli_real_escape_string($connexion,$datef)."' ORDER BY `date_create` DESC ";
        $page = new Pagination($SQL, 12);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();
    }


    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 143:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 143 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g =0;
            while ($row = mysqli_fetch_assoc($result))
            {

                $id_compaign= $row["id_schedule"];

                $description= $row["description"];
                $name_compaign= $row["name"];
                $date_create= $row["date_create"];
                $start_date_programed= substr_replace($row["start_date_programed"] ,"", -3)." ".$row["frequenxe"];
                $date_execution= $row["date_execution"];

                $nbr_comp=0;
                $compagnes_success=0;
                $compagnes_Erreur=0;
                $compagnes_Timeout=0;
                $compagnes_not_yet=0;




                if($date_create=="0000-00-00 00:00:00")
                {
                    $date_create = "---";
                }
                if($start_date_programed=="0000-00-00 00:00:00")
                {
                    $start_date_programed = "---";
                }
                if($date_execution=="0000-00-00 00:00:00")
                {
                    $date_execution = "---";
                }

                echo '<tr style="padding: 3px">
                    <td scope="row" class="text-center" style="padding: 3px">' . ($g + 1) . '</td>
                    <td class="text-center" style="padding: 3px">' . $name_compaign . ' </td>
                    <td class="text-center" style="padding: 3px">' . $date_create. '</td>
                    <td class="text-center" style="padding: 3px">' . $start_date_programed . '</td>
                    <td class="text-center" style="padding: 3px" align="center">' . $date_execution . '</td>
                    
                    <td class="text-center" style="padding: 3px" align="center">';
                //getDetail_Compagnes_publicitaires($id_compaign,$name_compaign,$description,'','');
                getDetail_Scheduled($id_compaign);
                echo'</td>';

                echo'</tr>';
                $g++;
            }
            echo '<tr><td colspan="9" class="text-center">';
            echo   '<ul class="pagination justify-content-center">'.$lien.'</ul>';
            echo   '<div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>';
            echo'</td></tr>';
        }
        else
        {
            echo'
           <tr>
                <td colspan="9" align="center"></td>
		   </tr> ';
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getDetail_Compagnes_success($id_compaign,$name_compaign)
{
    $connexion=ma_db_connexion();

    echo" <div id='modal_d' class='modal-dialog modal-lg' style='width:90%;height: 90%;'>
				<div class='modal-content'>
					<div class='modal-header'>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
						<div style='font-size:13pt;color: #000000;' class='modal-title' >Détail campagnes publicitaires déployée : " .$name_compaign. " <br></div>
					</div>  
					
					<div class='modal-body'>
					
					<div class='panel panel-default'>	
					
                        <div class='panel-heading' align='left'>GAB déployée <i class='fa fa-check-circle fa-fw ' style='color: #33cc33' aria-hidden='true'></i>  </div>
                        <div class='panel-body'>
                            <table  class='display success table table-bordered' style='font-size:11px;font-weight:bold;text-align: center;width:100%;border-color: #FFFFFF'>
                                    <thead class='text-warning'>
                                    <tr>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>ID GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Nom GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Terminal GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Ville GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Nom Image</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Etat Image</th>
                                    </tr>
                                </thead>
                                <tbody>";
                                $SQL = "SELECT  `id_atm`, `name_picture`, `description`,`terminal`, `ip_adresse_gab`, `nom_gab`, `ville`,`id_image`
                                FROM `history_images`,`state_image`,`new_list_gab` WHERE `history_images`.`id_atm`=`new_list_gab`.`id_terminal_xfs` 
								and `history_images`.`state`=`state_image`.`id` AND `id_compaign` = ".mysqli_real_escape_string($connexion,$id_compaign)." AND `state` IN (0,2) ";
                                mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
                                $result=mysqli_query($connexion,$SQL);
                                if (!$result)
                                {
                                    error_log("Erreur SQL 146:  ".$SQL."  ".mysqli_error($connexion));
                                    die('ERREUR QUERY 146 !');
                                }
                                if ($result)
                                    {
                                    if (mysqli_num_rows($result) > 0)
                                        {
                                            $g=0;
                                            while ($row = mysqli_fetch_assoc($result))
                                            {
                                                echo "<tr >
                                                            <td >     
                                                             ".$row['id_atm']."
                                                            </td>
                                                            <td >     
                                                             ".$row['nom_gab']."
                                                            </td>
                                                            
                                                             <td >     
                                                             ".$row['terminal']."
                                                            </td>
                                                            <td >     
                                                             ".$row['ville']."
                                                            </td>
                    
                                                           <td >
                                                           ".$row['name_picture']."";
                                                echo '<a tabindex="-1"  data-toggle="modal" 
                                                        onClick="javascript:Show_MyModal_Image(\''.$id_compaign.'\',\''.$row['id_image'].'\')"   
                                                        data-target="#myModal_Show_Image"><i class="fa fa-eye fa-lg" aria-hidden="true" title="Afficher Image"></i></a>';
                                                           echo "</td>
                    
                                                            <td>
                                                             ".$row['description']."
                                                            </td>
                                                       </tr>";
                                                   $g++;
                                            }
                                        }
                                        mysqli_free_result($result);
                                    }
                                mysqli_close($connexion);
                           echo"</tbody></table>
                         </div>
                     </div>
                    
					</div>
					
					<div class='modal-footer'>
						
						<button type='button' class='btn btn-default' data-dismiss='modal'>Fermer</button>
						
					</div>
				</div>
			</div>
		 </div>";
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function getDetail_Compagnes_not_yet($id_compaign,$name_compaign)
{
    $connexion=ma_db_connexion();

    echo" <div id='modal_d' class='modal-dialog modal-lg' style='width:90%;height: 90%;'>
				<div class='modal-content'>
					<div class='modal-header'>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
						<div style='font-size:13pt;color: #000000;' class='modal-title' >Détail Campagnes publicitaires en attente de déploiement : " .$name_compaign. " <br></div>
					</div>  
					
					<div class='modal-body' >
					
					<div class='panel panel-default'>	
					
                        <div class='panel-heading' align='left'>GAB en attente de déploiement <i class='fa fa-circle fa-fw ' style='color: #FFA07A' aria-hidden='true'></i>  </div>
                        <div class='panel-body'>
                           
                                    <table  class='display not_yet table table-bordered' style='font-size:11px;font-weight:bold;text-align: center;width: 100%;border-color: #FFFFFF'>
                                <thead class='text-warning'>
                                    <tr>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>ID GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Nom GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Terminal GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Ville GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Nom Image</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Etat Image</th>
                                    </tr>
                                </thead>
                                <tbody>";

                                $SQL = "SELECT  `id_atm`, `name_picture`, `description`,`terminal`, `ip_adresse_gab`, `nom_gab`, `ville`,`id_image`
                                FROM `images`,`state_image`,`new_list_gab` WHERE `images`.`id_atm`=`new_list_gab`.`id_terminal_xfs` and `images`.`state`=`state_image`.`id` 
								AND `id_compaign` = ".mysqli_real_escape_string($connexion,$id_compaign)." AND `state` = 1 ";
                                mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
                                $result=mysqli_query($connexion,$SQL);
                                if (!$result)
                                {
                                    error_log("Erreur SQL 147:  ".$SQL."  ".mysqli_error($connexion));
                                    die('ERREUR QUERY 147 !');
                                }
                                if ($result)
                                    {
                                    if (mysqli_num_rows($result) > 0)
                                        {
                                            $g=0;
                                            while ($row = mysqli_fetch_assoc($result))
                                            {
                                                echo "<tr >";
                                                echo"<td >     
                                                             ".$row['id_atm']."
                                                            </td>
                                                            <td >     
                                                             ".$row['nom_gab']."
                                                            </td>
                                                            
                                                             <td >     
                                                             ".$row['terminal']."
                                                            </td>
                                                            <td >     
                                                             ".$row['ville']."
                                                            </td>
                    
                                                            <td >
                                                           ".$row['name_picture']."";
                                                echo '<a tabindex="-1"  data-toggle="modal" 
                                                        onClick="javascript:Show_MyModal_Image(\''.$id_compaign.'\',\''.$row['id_image'].'\')"   
                                                        data-target="#myModal_Show_Image"><i class="fa fa-eye fa-lg" aria-hidden="true" title="Afficher Image"></i></a>';
                                                           echo "</td>
                    
                                                            <td>
                                                             ".$row['description']."
                                                            </td>
                                                       </tr>";
                                                           $g++;
                                            }
                                        }
                                        mysqli_free_result($result);
                                    }
                                mysqli_close($connexion);
                           echo"</tbody></table>
                            
                            
                         </div>
                     </div>
                    
					</div>
					
					<div class='modal-footer'>
						
						<button type='button' class='btn btn-default' data-dismiss='modal'>Fermer</button>
						
					</div>
				</div>
			</div>
		 </div>";
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function getDetail_Compagnes_non_déployée($id_compaign,$name_compaign)
{
    $connexion=ma_db_connexion();
    echo"<div id='modal_d' class='modal-dialog modal-lg'  style='width:90%;height: 90%;'>
				<div class='modal-content'>
					<div class='modal-header'>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
						<div style='font-size:13pt;color: #000000;' class='modal-title' >Détail campagnes publicitaires non déployée : " .$name_compaign. " <br></div>
					</div>  
					
					<div class='modal-body' >
					
					<div class='panel panel-default'>	
					
                        <div class=' panel-heading' align='left'> GAB non déployée <i class='fa fa-ban fa-fw text-danger ' aria-hidden='true'></i></div>
                        
                        
                        <div class='panel-body'>
                            <table  class='display non_deployee table table-bordered' style='font-size:11px;font-weight:bold;text-align: center;width: 100%;border-color: #FFFFFF'>
                                        <thead class='text-warning'>
                                    <tr>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>ID GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Nom GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Terminal GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Ville GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Nom Image</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Etat Image</th>
                                    </tr>
                                </thead>
                                <tbody>";
                                $SQL = "SELECT  `id_atm`, `name_picture`, `description`,`terminal`, `ip_adresse_gab`, `nom_gab`, `ville`,`id_image`,`id_image`
                                FROM `history_images`,`state_image`,`new_list_gab` WHERE `history_images`.`id_atm`=`new_list_gab`.`id_terminal_xfs`
								and `history_images`.`state`=`state_image`.`id` AND `id_compaign` = ".mysqli_real_escape_string($connexion,$id_compaign)." 
								AND `history_images`.`state_relance` = 0 AND `state` IN (3,4,5) ";
                                mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
                                $result=mysqli_query($connexion,$SQL);
                                if (!$result)
                                {
                                    error_log("Erreur SQL 148:  ".$SQL."  ".mysqli_error($connexion));
                                    die('ERREUR QUERY 148 !');
                                }
                                if ($result)
                                    {
                                    if (mysqli_num_rows($result) > 0)
                                        {
                                            $g=0;
                                            while ($row = mysqli_fetch_assoc($result))
                                            {
                                                echo "<tr >";
                                                echo"<td >     
                                                             ".$row['id_atm']."
                                                            </td>
                                                            <td >     
                                                             ".$row['nom_gab']."
                                                            </td>
                                                            
                                                             <td >     
                                                             ".$row['terminal']."
                                                            </td>
                                                            <td >     
                                                             ".$row['ville']."
                                                            </td>
                    
                                                            <td >
                                                            ".$row['name_picture']."";
                                                echo '<a tabindex="-1"  data-toggle="modal" 
                                                        onClick="javascript:Show_MyModal_Image(\''.$id_compaign.'\',\''.$row['id_image'].'\')"   
                                                        data-target="#myModal_Show_Image"><i class="fa fa-eye fa-lg" aria-hidden="true" title="Afficher Image"></i></a>';
                                                            echo"</td>
                    
                                                            <td>
                                                             ".$row['description']."
                                                            </td>
                                                        
                                                       </tr>";
                                                $g++;
                                            }
                                        }
                                        mysqli_free_result($result);
                                    }
                                mysqli_close($connexion);
                           echo"</tbody></table>
                         </div>
                     </div>
                    
					</div>
					
					<div class='modal-footer'>
						
						<button type='button' class='btn btn-default' data-dismiss='modal'>Fermer</button>
						
					</div>
				</div>
			</div>
		 </div>";
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getDetail_Compagnes_Time_out($id_compaign,$name_compaign)
{
    $connexion=ma_db_connexion();

    echo" <div id='modal_d' class='modal-dialog modal-lg' style='width:90%;height: 90%;'>
				<div class='modal-content'>
					<div class='modal-header'>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
						<div style='font-size:13pt;color: #000000;' class='modal-title' >Détail campagnes publicitaires Time Out : " .$name_compaign. " <br></div>
					</div>  
					
					<div class='modal-body' >
					
					<div class='panel panel-default'>	
					
                        <div class='panel-heading' align='left'>GAB Time Out <i class='fa fa-clock-o fa-fw' style='color: #ff0000' aria-hidden='true'></i>  </div>
                        <div class='panel-body'>
                            <table class='display time_out table table-bordered' style='font-size:11px;font-weight:bold;text-align: center;width: 100%;border-color: #FFFFFF'>
                                     <thead class='text-warning'>
                                    <tr>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>ID GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Nom GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Terminal GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Ville GAB</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Nom Image</th>
                                        <th style='text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;'>Etat Image</th>
                                    </tr>
                                </thead>
                                <tbody>";
                             $SQL = "SELECT  `id_atm`, `name_picture`, `description`,`terminal`, `ip_adresse_gab`, `nom_gab`, `ville`,`id_image`
                                FROM `history_images`,`state_image`,`new_list_gab` WHERE `history_images`.`id_atm`=`new_list_gab`.`id_terminal_xfs` 
								and `history_images`.`state`=`state_image`.`id` AND `id_compaign` = ".mysqli_real_escape_string($connexion,$id_compaign)."
								AND `history_images`.`state_relance` = 0 AND `state` = 6 ";
                                mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
                                $result=mysqli_query($connexion,$SQL);
                                if (!$result)
                                {
                                    error_log("Erreur SQL 149:  ".$SQL."  ".mysqli_error($connexion));
                                    die('ERREUR QUERY 149 !');
                                }
                                if ($result)
                                    {
                                    if (mysqli_num_rows($result) > 0)
                                        {
                                            $g=0;
                                            while ($row = mysqli_fetch_assoc($result))
                                            {
                                                echo "<tr >
                                                        <td>     
                                                         ".$row['id_atm']."
                                                        </td>
                                                        <td >     
                                                         ".$row['nom_gab']."
                                                        </td>
                                                        
                                                         <td >     
                                                         ".$row['terminal']."
                                                        </td>
                                                        <td >     
                                                         ".$row['ville']."
                                                        </td>
                
                                                         <td >
                                                        ".$row['name_picture']."";
                                                        echo '<a tabindex="-1"  data-toggle="modal" 
                                                        onClick="javascript:Show_MyModal_Image(\''.$id_compaign.'\',\''.$row['id_image'].'\')"   
                                                        data-target="#myModal_Show_Image"><i class="fa fa-eye fa-lg" aria-hidden="true" title="Afficher Image"></i></a>';
                                                        echo"</td>

                                                        <td>
                                                         ".$row['description']."
                                                        </td>
                                                       </tr>";
                                                        $g++;
                                            }
                                        }
                                        mysqli_free_result($result);
                                    }
                                mysqli_close($connexion);
                           echo"</tbody></table>
                         </div>
                     </div>
                    
					</div>
					
					<div class='modal-footer'>
						
						<button type='button' class='btn btn-default' data-dismiss='modal'>Fermer</button>
						
					</div>
				</div>
			</div>
		 </div>";
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getDetail_Compagnes_publicitaires($id_compaign,$name_compaign,$description,$path,$state_execution)
{
    include "languages/" . $_SESSION['lang'] . ".php";

    $profil=0;
    $infoGAB=get_info_Compaign($id_compaign);
    $cheked="";
    $disabled="";
    if($state_execution==0)
    {
        $cheked="checked";
        $disabled="";
    }
    if($state_execution==2)
    {
        $cheked=" ";
        $disabled="disabled";
    }

    echo "<a style='vertical-align :middle;' data-toggle='modal' href='#myModalCompg".$id_compaign."'><span class='cil-people' aria-hidden='false'  title='Edit Advertising Campaigns'></span></a>";
    echo" <div class='modal fade' id='myModalCompg".$id_compaign."' role='dialog' tabindex='-1'>
 
			<div class='modal-dialog modal-lg' >
				<div class='modal-content' style='background-color:#e9ecef;color:#2b3449;'>
					<div class='modal-header'>
						
						<h5 class='modal-title' >Edit Advertising Campaigns : " .$name_compaign. "</h5>
						<button type='button' class='close' data-dismiss='modal' >&times;</button>
						
					</div>  
					<div id='myModalbody".$id_compaign."' class='modal-body'  ".$disabled." >




                        <form id='form_detail_Compagnes_pub".$id_compaign."'  class='form-horizontal' role='form' method='post'>
                            <div  class='form-group'>
                                
                               <div class='custom-control custom-switch' id='checkbox_compagne".$id_compaign."' align='left'>
                                    <input type='checkbox' ".$cheked." class='custom-control-input' id='checkbox".$id_compaign."'  value='".$state_execution."' onchange='Updatechek($id_compaign)'>
                                    <label class='custom-control-label' for='checkbox".$id_compaign."' >activate or deactivate </label>
                               </div>
                            </div>  
                            
                            <div  class='form-group mb-3 row'>
                                <label for='nom_compagne' class='col-sm-2 col-form-label'>Campaign name </label>
                                <div id='div_nom_compagne".$id_compaign."' class='col-sm-10'>
                                    <input  id='nom_compagne".$id_compaign."' ".$disabled."  name='nom_compagne".$id_compaign."' type='text'   value='".$infoGAB[0]."' class='form-control required'>
                                </div>
                            </div>
                           
                            
                            <div  class='form-group mb-3 row'>
                                <label for='nom_ATM' class='col-sm-2  col-form-label'>Execution date </label>
                                <div id='div_datedep".$id_compaign."' class='col-sm-10'>
                                    <div class='input-group date' id='ModifdateDeploiment".$id_compaign."'>
                                        <input type='datetime-local' id='datedep".$id_compaign."' ".$disabled."  name='datedep".$id_compaign."' class='form-control required' value='".str_replace(" ","T",$infoGAB[1])."' required/>
                                    </div>
                                </div>
                            </div>
                            
                            <div  class='form-group mb-3 row'>
                                <label for='Chemin_images' class='col-sm-2 col-form-label'>Pictures path </label>
                                <div class='col-sm-10' id='div_Chemin_images".$id_compaign."'>
                                    <input  id='Chemin_images".$id_compaign."' ".$disabled."   name='Chemin_images".$id_compaign."' type='text'   value='".$infoGAB[2]."' class='form-control required'>
                                </div>
                            </div>
                            
                            <div class='form-group mb-3 row' id='div_profgab".$id_compaign."' ".$disabled.">
                                <label for='profgab' class='col-sm-2 col-form-label'>ATM profile </label>
                                <div class='col-sm-10'  >";
                                    echo"<select id='profgab".$id_compaign."' ".$disabled." class=' form-control required' onchange='get_comp_atm(this,$id_compaign,\"".$infoGAB[3]."\")' > ";
                                        get_select_profile();
                                        echo " <option value='2'>All</option> 
                                    </select>
                                </div>
                            </div>
                            
                            <div class='table-responsive'  id='div_tbl_prof".$id_compaign."'>
                                <table id='tbl_prof".$id_compaign."' ".$disabled."  class='table table-responsive-sm table-hover table-outline mb-0'>
                                    <thead class='thead-light'>
                                        <th ><input  type='checkbox' id='checkAllcompaign".$id_compaign."' ".$disabled."  value='0' onclick='chackallcomp($id_compaign)'></th>
                                        <th>ID</th>
                                        <th class='text-center'>" .$lang['atm_name']."</th>
                                         <th class='text-center'>" .$lang['atm_id']."</th>
                                         <th class='text-center'>" .$lang['atm_profil']."</th>
                                         <th class='text-center'>" .$lang['dat_der_dep']."</th>
                                         <th class='text-center'>" .$lang['stat_dep']."</th>
                                    </thead>
                                    <tbody id='tbody_tbl_gab_prof".$id_compaign."'>";
                                        get_atm_comp($profil,$infoGAB[3],$id_compaign,$disabled);
                                    echo" </tbody>
                                </table>
                            </div>
                            
 
                            <div class='form-group col-sm-12'>				
                                <div id='div_btn_modif".$id_compaign."'  align='left'>
                                    <button id='btn_modif".$id_compaign."' type='button' class='btn btn-danger' onclick='UpdateComp($id_compaign)'  data-dismiss='modal' >Modify </button>
                                </div>
                            </div>  
                        </form>
					</div>
	
					<div class='modal-footer'>
						<button type='button' class='btn btn-default' data-dismiss='modal'>Fermer</button>
					</div>
				</div>
			</div>
	</div>";
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDetail_Scheduled ($id_compaign)
{
    include "languages/" . $_SESSION['lang'] . ".php";

    $profil=0;
    $infoGAB=get_info_Scheduled($id_compaign);
    $cheked="";
    $disabled="";
    $cheked="checked";
    $disabled="";
    $state_execution=0;

    echo "<a style='vertical-align :middle;' data-toggle='modal' href='#myModalCompg".$id_compaign."'><span class='cil-people' aria-hidden='false'  title='Edit Advertising Campaigns'></span></a>";
    echo" <div class='modal fade' id='myModalCompg".$id_compaign."' role='dialog' tabindex='-1'>
 
			<div class='modal-dialog modal-lg' >
				<div class='modal-content' style='background-color:#e9ecef;color:#2b3449;'>
					<div class='modal-header'>
						
						<h5 class='modal-title' >Edit Advertising Campaigns : " .$infoGAB[0]. "</h5>
						<button type='button' class='close' data-dismiss='modal' >&times;</button>
						
					</div>  
					<div id='myModalbody".$id_compaign."' class='modal-body'  ".$disabled." >




                        <form id='form_detail_Compagnes_pub".$id_compaign."'  class='form-horizontal' role='form' method='post'>
                            <div  class='form-group'>
                                
                               <div class='custom-control custom-switch' id='checkbox_compagne".$id_compaign."' align='left'>
                                    <input type='checkbox' ".$cheked." class='custom-control-input' id='checkbox".$id_compaign."'  value='".$state_execution."' onchange='Updatechek($id_compaign)'>
                                    <label class='custom-control-label' for='checkbox".$id_compaign."' >activate or deactivate </label>
                               </div>
                            </div>  
                            
                            <div  class='form-group mb-3 row'>
                                <label for='nom_compagne' class='col-sm-2 col-form-label'>Campaign name </label>
                                <div id='div_nom_compagne".$id_compaign."' class='col-sm-10'>
                                    <input  id='nom_compagne".$id_compaign."' ".$disabled."  name='nom_compagne".$id_compaign."' type='text'   value='".$infoGAB[0]."' class='form-control required'>
                                </div>
                            </div>
    
                            <div class='mb-3 row'>
                                <label class='col-sm-2 col-form-label' for='staticEmail'>Execution date</label>
                                <div class='col-sm-5'>
                                    <input class='form-control required' type='time'  id='time_dep_dep".$id_compaign."' name='time_dep_dep".$id_compaign."' value='".$infoGAB[1]."'>
                                </div>
                                <div class='col-sm-5'>
                                    <select class='form-control required' id='month_dep".$id_compaign."' name='month_dep".$id_compaign."' >
                                        <option value='".$infoGAB[2]."' selected>".$infoGAB[2]."</option>
                                        <option value='Daily'>Daily</option>
                                        <option value='Weekly'>Weekly</option>
                                        <option value='Monthly'>Monthly</option>
                                    </select>
                                </div>
                            </div>
      
                            
                            <div class='form-group mb-3 row' id='div_profgab".$id_compaign."' ".$disabled.">
                                <label for='profgab' class='col-sm-2 col-form-label'>ATM profile </label>
                                <div class='col-sm-10'  >";
    echo"<select id='profgab".$id_compaign."' ".$disabled." class=' form-control required' onchange='get_comp_atm(this,$id_compaign,\"".$infoGAB[3]."\")' > ";
    get_select_profile();
    echo " <option value='2'>All</option> 
                                    </select>
                                </div>
                            </div>
                            
                            <div class='table-responsive'  id='div_tbl_prof".$id_compaign."'>
                                <table id='tbl_prof".$id_compaign."' ".$disabled."  class='table table-responsive-sm table-hover table-outline mb-0'>
                                    <thead class='thead-light'>
                                        <th ><input  type='checkbox' id='checkAllcompaign".$id_compaign."' ".$disabled."  value='0' onclick='chackallcomp($id_compaign)'></th>
                                        <th>ID</th>
                                        <th class='text-center'>" .$lang['atm_name']."</th>
                                         <th class='text-center'>" .$lang['atm_id']."</th>
                                         <th class='text-center'>" .$lang['atm_profil']."</th>
                                         <th class='text-center'>" .$lang['dat_der_dep']."</th>
                                         <th class='text-center'>" .$lang['stat_dep']."</th>
                                    </thead>
                                    <tbody id='tbody_tbl_gab_prof".$id_compaign."'>";
    get_atm_comp($profil,$infoGAB[3],$id_compaign,$disabled);
    echo" </tbody>
                                </table>
                            </div>
                            
                            <br>
                            <div class='form-group col-sm-12'>				
                                <div id='div_btn_modif".$id_compaign."'  align='left'>
                                    <button id='btn_modif".$id_compaign."' type='button' class='btn btn-danger'  data-dismiss='modal' onclick='UpdateScheduled($id_compaign)'  >Modify </button>
                                </div>
                            </div>  
                        </form>
					</div>
	
					<div class='modal-footer'>
						<button type='button' class='btn btn-danger' data-dismiss='modal'>Fermer</button>
					</div>
				</div>
			</div>
	</div>";
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_relaunch_Campaign($id_compaign,$name_compaign)
{
    echo '&nbsp; <span class="fa fa-minus" aria-hidden="true"></span> &nbsp;';
    echo '<a  data-toggle="modal" href="#myModalRelaunchComp'.$id_compaign.'"><span class="fa fa-refresh fa-lg" aria-hidden="false"  title="Relaunch Advertising Campaigns"></span></a>';
    echo' <div class="modal fade" id="myModalRelaunchComp'.$id_compaign.'" role="dialog" tabindex="-1">
 
			<div class="modal-dialog modal-lg" >
				<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">
					<div class="modal-header">
						
						<h5  class="modal-title" >Relaunch Advertising Campaigns : ' .$name_compaign. '</h5>
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>  
					<div id="myModalbody'.$id_compaign.'" class="modal-body">
					<form id="form_relaunch_Compagnes_pub'.$id_compaign.'"  class="form-horizontal" role="form" method="POST">
					<div class="table-responsive mh-400" style="height: auto;overflow:auto;">
					<p align="left"><strong>List of non-deployed ATMs :</strong></p>';
                    get_atm_relaunch_Campaign($id_compaign);
                    echo '</div>
                        	<div class="form-group">				
                                <div id="div_btn_relaunch_Campaign'.$id_compaign.'" class="col-sm-12"  align="left">
                                    <button id="btn_relaunch_Campaign'.$id_compaign.'" type="button" class="btn btn-danger" onclick="RelaunchComp(\'' . $id_compaign .'\')" style="padding:7px 40px">Relaunch </button>
                                </div>
                            </div>  
                    </div>
                    </form>
               
					<br>
					<br>	
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
	</div>';

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_info_Compaign($id_compaign)
{
    $connexion=ma_db_connexion();
    $SQL = "SELECT  `name`, `start_date_programed`, `path`,`atm_concerned` 
                                FROM `advertising_compaign` WHERE  `id_compaign` = ".mysqli_real_escape_string($connexion,$id_compaign)." ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 150:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 150 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return array($row["name"],
                    $row["start_date_programed"],
                    $row["path"],
                    $row["atm_concerned"]);
            }
        }
        else
        {
            return array('','','','');
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_info_Scheduled ($id_compaign)
{
    $connexion=ma_db_connexion();
    $SQL = "SELECT  `name`, `start_date_programed`,`frequenxe`,`atm_concerned` 
                                FROM `schedule_pulling_ej` WHERE  `id_schedule` = ".mysqli_real_escape_string($connexion,$id_compaign)." ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 150:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 150 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return array($row["name"],
                    $row["start_date_programed"],
                    $row["frequenxe"],
                    $row["atm_concerned"]);
            }
        }
        else
        {
            return array('','','','');
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function Show_MyModal_Image($id_compaign,$id_image)
{
    $connexion=ma_db_connexion();
    $SQL="SELECT `data`,`name_picture` from `images_compaign` WHERE `id_image`= ".mysqli_real_escape_string($connexion,$id_image).";";


    echo' <div class="modal-dialog modal-lg" >
				<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" >&times;</button>
					</div>  
					<div id="myModalbody" class="modal-body">';
                    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
                    $result=mysqli_query($connexion,$SQL);
                    if (!$result)
                    {
                        error_log("Erreur SQL 151:  ".$SQL."  ".mysqli_error($connexion));
                        die('ERREUR QUERY 151 !');
                    }
                    if ($result)
                    {
                        if (mysqli_num_rows($result) > 0)
                        {
                            while ($row = mysqli_fetch_assoc($result))
                            {
                                $img_name = $row['name_picture'];
                                echo '<div class="img-block">
                                     <img src="data:image/jpeg;base64,'.base64_encode( $row['data'] ).'" title="'.$img_name.'" height="50%" width="100%" />
                                </div>';
                            }
                        }
                        mysqli_free_result($result);
                    }
                    mysqli_close($connexion);

                   echo'</div>
					<br>
					<br>	
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal" >Fermer</button>
					</div>
				</div>
			</div>
	</div>';

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function Show_All_Image_Comp($id_compaign,$id_image,$name_compaign)
{
    include "../languages/" . $_SESSION['lang'] . ".php";
    include("../pagination.php");
    $connexion=ma_db_connexion();
    $SQL = "SELECT `data`,`name_picture` FROM images_compaign
    WHERE images_compaign.id_image IN (".mysqli_real_escape_string($connexion,$id_image).")";

    $page = new Pagination($SQL, 1);
    $total = $page->getCount('Displaying images  %d - %d  ( total  : %d )');
    $SQL1 = $page->req();

    echo '
	<div class="modal-dialog modal-lg">
	    <div class="modal-content">																										  
            <!-- Modal Header -->
            <div class="modal-header">
                <h5 class="modal-title" >Campaign images  :  '.$name_compaign.'</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>				
																																	
												<!-- Modal body -->
												<div class="modal-body">';
                                                mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
                                                $result=mysqli_query($connexion,$SQL1);
                                                if (!$result)
                                                {
                                                    error_log("Erreur SQL 152:  ".$SQL1."  ".mysqli_error($connexion));
                                                    die('ERREUR QUERY 152 !');
                                                }
                                                if ($result)
                                                {
                                                    if (mysqli_num_rows($result) > 0)
                                                    {

                                                        while ($row = mysqli_fetch_assoc($result))
                                                        {
                                                            $img_name = $row['name_picture'];
                                                            echo '<div class="img-block">
                                                                 <img src="data:image/jpeg;base64,'.base64_encode( $row['data'] ).'" title="'.$img_name.'" height="50%" width="100%" /> 
                                                            </div>';
                                                        }
                                                    }
                                                    mysqli_free_result($result);
                                                }
                                                mysqli_close($connexion);

                           /* echo ' <div align="center">
                                            <ul class="pagination"><li>'.$page->Paginate_modal(5, '',$id_compaign,$id_image,$name_compaign).' </li></ul>
                                            <div class="alert" style="background-color:#fabf8f;font-size:18px;color:#fff;line-height: 30%;"><strong>'.$total.'</strong></div>
                                        </div>';*/

    echo '<div align="center">';
    echo   '<ul class="pagination justify-content-center">'.$page->Paginate_modal(5, '',$id_compaign,$id_image,$name_compaign).'</ul>';
    echo   '<div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>';
    echo'</div>';

										    	echo'</div>																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
									</div>
								</div>';

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_hist_deplo()
{
    include "languages/" . $_SESSION['lang'] . ".php";

    include("pagination.php");
    $connexion=ma_db_connexion();

    if(!isset($_POST['dated']) or !isset($_POST['datef']) or !isset($_POST['idatm']))
    {

        $SQL = "SELECT  `id_atm`, `name_picture`, `path`, `date_insertion`, `date_deploiement`,`state`, state_image.description as description
                FROM `images`, state_image WHERE images.state = state_image.id  ORDER BY date_insertion DESC ";
        $page = new Pagination($SQL, 10);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();
    }
    else if(!empty($_POST['idatm']))
    {

        include("../pagination.php");
        $dated = $_POST['dated'] ;
        $datef = $_POST['datef'] ;
        $idatm = $_POST['idatm'] ;
        $SQL = "SELECT  `id_atm`, `name_picture`, `path`, `date_insertion`, `date_deploiement`,`state`, state_image.description as description 
                FROM `images`, state_image WHERE images.state = state_image.id and images.id_atm = '".mysqli_real_escape_string($connexion,$idatm)."' and images.date_insertion 
				BETWEEN '".mysqli_real_escape_string($connexion,$dated)."' and '".mysqli_real_escape_string($connexion,$datef)."' ORDER BY date_insertion DESC ";
        $page = new Pagination($SQL, 10);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();
    }
    else
    {
        include("../pagination.php");
        $dated = $_POST['dated'] ;
        $datef = $_POST['datef'] ;

        $SQL = "SELECT  `id_atm`, `name_picture`, `path`, `date_insertion`, `date_deploiement`,`state`, state_image.description as description 
                FROM `images`, state_image WHERE images.state = state_image.id and images.date_insertion 
				BETWEEN '".mysqli_real_escape_string($connexion,$dated)."' and '".mysqli_real_escape_string($connexion,$datef)."'  ORDER BY date_insertion DESC ";

        $page = new Pagination($SQL, 10);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();
    }

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 153:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 153 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g =0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $datedepl= $row["date_deploiement"];
                if(($datedepl=="0000-00-00 00:00:00") || (($row["state"]  != "0") && ($row["state"] != "2") && ($row["state"] != "1" )))
                {
                    $datedepl="---";
                }
                if ($row["state"]  == "0" || $row["state"] == "2")
                {
                    echo '<tr style="padding: 3px">
                    
                    <td class="text-center">' . $row["id_atm"] . '</td>
                    <td class="text-center">' . $row["name_picture"] . '</td>
                    <td class="text-center">' . $row["path"] . '</td>
                    <td class="text-center">' . $row["date_insertion"] . '</td>
                    <td class="text-center">' . $datedepl . '</td>
                    <td class="text-center">' . $row["description"] . ' <span class="cil-cloud-upload" style="color: #5CB85C;" aria-hidden="false"></span> </td>
                    </tr>';
                }
                else if ($row["state"] == "1" )
                {
                    echo '<tr style="padding: 3px">
                   
                    <td class="text-center">' . $row["id_atm"] . '</td>
                    <td class="text-center">' . $row["name_picture"] . '</td>
                    <td class="text-center">' . $row["path"] . '</td>
                    <td class="text-center">' . $row["date_insertion"] . '</td>
                    <td class="text-center">' . $datedepl . '</td>
                    <td class="text-center">' . $row["description"] . ' <span class="cil-cloud-upload" style="color: #FFA07A;" aria-hidden="false"></span> </td>
                    </tr>';
                }
                else
                {
                    echo '<tr style="padding: 3px">
                  
                    <td class="text-center">' . $row["id_atm"] . '</td>
                    <td class="text-center">' . $row["name_picture"] . '</td>
                    <td class="text-center">' . $row["path"] . '</td>
                    <td class="text-center">' . $row["date_insertion"] . '</td>
                    <td class="text-center">' . $datedepl . '</td>
                    <td class="text-center">' . $row["description"] . ' <span class="cil-cloud-upload" style="color: #FF0000;" aria-hidden="false"></span> </td>
                    </tr>';
                }
                $g++;
            }
            echo '<tr><td colspan="6" class="text-center">';
            echo   '<ul class="pagination justify-content-center">'.$lien.'</ul>';
            echo   '<div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>';
            echo'</td></tr>';

        }
        else
        {

            echo'
           <tr>
                <td colspan="6" class="text-center">---</td>
		   </tr> ';
        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);

}

function get_hist_deplo_binaire()
{
    include "languages/" . $_SESSION['lang'] . ".php";

    include("pagination.php");
    $connexion=ma_db_connexion();
    if(!isset($_POST['dated']) or !isset($_POST['datef']) or !isset($_POST['idatm']))
    {
        $SQL = "SELECT  `id_atm`, `name_binaire`, `path`, `date_insertion`, `date_deploiement`,`state_binaire`, state_binaire.description as description 
                FROM `history_binaire_client`, state_binaire WHERE history_binaire_client.state_binaire = state_binaire.id ORDER BY history_binaire_client.date_insertion DESC  ";
        $page = new Pagination($SQL, 10);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();
    }
    else if(!empty($_POST['idatm']))
    {
        include("../pagination.php");
        $dated = $_POST['dated'] ;
        $datef = $_POST['datef'] ;
        $idatm = $_POST['idatm'] ;

        $SQL = "SELECT  `id_atm`, `name_binaire`, `path`, `date_insertion`, `date_deploiement`,`state_binaire`, state_binaire.description as description 
                FROM `history_binaire_client`, state_binaire WHERE history_binaire_client.state_binaire = state_binaire.id  
                and history_binaire_client.id_atm = '$idatm'
                and history_binaire_client.date_insertion BETWEEN  '".mysqli_real_escape_string($connexion,$dated)."' and '".mysqli_real_escape_string($connexion,$datef)."' ORDER BY history_binaire_client.date_insertion DESC ";
        $page = new Pagination($SQL, 10);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();
    }

    else
    {
        include("../pagination.php");
        $dated = $_POST['dated'] ;
        $datef = $_POST['datef'] ;

        $SQL = "SELECT  `id_atm`, `name_binaire`, `path`, `date_insertion`, `date_deploiement`,`state_binaire`, state_binaire.description as description 
                FROM `history_binaire_client`, state_binaire WHERE history_binaire_client.state_binaire = state_binaire.id and history_binaire_client.date_insertion 
				BETWEEN '".mysqli_real_escape_string($connexion,$dated)."' and '".mysqli_real_escape_string($connexion,$datef)."' ORDER BY history_binaire_client.date_insertion DESC ";
        $page = new Pagination($SQL, 10);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();
    }
	//var_dump($SQL1);
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 154:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 154 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g =0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $datedepl= $row["date_deploiement"];
                if($datedepl=="0000-00-00 00:00:00")
                {
                    $datedepl="---";
                }
                if ($row["state_binaire"]  == "0" || $row["state_binaire"] == "2")
                {
                    echo '<tr style="padding: 3px">
                   
                    <td class="text-center">' . $row["id_atm"] . '</td>
                    <td class="text-center">' . $row["name_binaire"] . '</td>
                    <td class="text-center">' . $row["path"] . '</td>
                    <td class="text-center">' . $row["date_insertion"] . '</td>
                    <td class="text-center">' . $datedepl . '</td>
                    <td class="text-center">' . $row["description"] . ' <span class="cil-cloud-upload" style="color: #5CB85C;" aria-hidden="false"></span> </td>

                    </tr>';
                }
                else if ($row["state_binaire"] == "1" )
                {
                    echo '<tr style="padding: 3px">
                   
                    <td class="text-center">' . $row["id_atm"] . '</td>
                    <td class="text-center">' . $row["name_binaire"] . '</td>
                    <td class="text-center">' . $row["path"] . '</td>
                    <td class="text-center">' . $row["date_insertion"] . '</td>
                    <td class="text-center">' . $datedepl . '</td>
                    <td class="text-center">' . $row["description"] . ' <span class="cil-cloud-upload" style="color: #FFA07A;" aria-hidden="false"></span> </td>
                    </tr>';
                }
                else
                {
                    echo '<tr style="padding: 3px">
                    
                    <td class="text-center">' . $row["id_atm"] . '</td>
                    <td class="text-center">' . $row["name_binaire"] . '</td>
                    <td class="text-center">' . $row["path"] . '</td>
                    <td class="text-center">' . $row["date_insertion"] . '</td>
                    <td class="text-center">' . $datedepl . '</td>
                    <td class="text-center">' .$row["description"] . ' <span class="cil-cloud-upload" style="color: #FF0000;" aria-hidden="false"></span> </td>
                    </tr>';
                }
                $g++;
            }
            echo '<tr><td colspan="6" class="text-center">';
            echo   '<ul class="pagination justify-content-center">'.$lien.'</ul>';
            echo   '<div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>';
            echo'</td></tr>';
        }
        else
        {
            echo'
           <tr>
                <td colspan="6" class="text-center">---</td>
		   </tr> ';
        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_hist_redemarrage()
{
    include "languages/" . $_SESSION['lang'] . ".php";
    include("pagination.php");
    $connexion=ma_db_connexion();
    if(!isset($_POST['dated']) or !isset($_POST['datef']) or !isset($_POST['idatm']))
    {
        $SQL = "SELECT new_list_gab.id_terminal_xfs as id_terminal_xfs ,new_list_gab.nom_gab as nom_gab , atm_profile.description as description, new_list_gab.terminal as terminal,
                list_cmd_for_atm.description_cmd, hist_cmd_execution_reboot.date_send_cmd, hist_cmd_execution_reboot.date_after_exec_cmd
			    FROM hist_cmd_execution_reboot,list_cmd_for_atm,`new_list_gab`,`atm_profile`,`list_atm_confirmed`
			    WHERE list_atm_confirmed.id_atm = hist_cmd_execution_reboot.id_atm and new_list_gab.id_profil= atm_profile.id_profile AND new_list_gab.id_terminal_xfs=list_atm_confirmed.id_atm and
                 hist_cmd_execution_reboot.id_cmd=  list_cmd_for_atm.id_command ORDER BY hist_cmd_execution_reboot.date_send_cmd DESC ";
        $page = new Pagination($SQL, 8);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();
    }
    else if(!empty($_POST['idatm']))
    {
        include "../languages/" . $_SESSION['lang'] . ".php";
        include("../pagination.php");
        $dated = $_POST['dated'] ;
        $datef = $_POST['datef'] ;
        $idatm = $_POST['idatm'] ;

        $SQL = "SELECT new_list_gab.id_terminal_xfs as id_terminal_xfs ,new_list_gab.nom_gab as nom_gab , atm_profile.description as description, new_list_gab.terminal as terminal,
                list_cmd_for_atm.description_cmd, hist_cmd_execution_reboot.date_send_cmd, hist_cmd_execution_reboot.date_after_exec_cmd
                FROM hist_cmd_execution_reboot,list_cmd_for_atm,`new_list_gab`,`atm_profile`,`list_atm_confirmed`
                WHERE list_atm_confirmed.id_atm = hist_cmd_execution_reboot.id_atm and  new_list_gab.id_profil= atm_profile.id_profile AND new_list_gab.id_terminal_xfs=list_atm_confirmed.id_atm and
                 hist_cmd_execution_reboot.id_cmd=  list_cmd_for_atm.id_command 
                 and new_list_gab.terminal = ".mysqli_real_escape_string($connexion,$idatm)."
                 and hist_cmd_execution_reboot.date_send_cmd 
				 BETWEEN  '".mysqli_real_escape_string($connexion,$dated)."' and '".mysqli_real_escape_string($connexion,$datef)."' ORDER BY hist_cmd_execution_reboot.date_send_cmd DESC 	";
        $page = new Pagination($SQL, 8);
        $total = $page->getCount($lang['aff_lign'].' %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();

    }

    else
    {
        include "../languages/" . $_SESSION['lang'] . ".php";
        include("../pagination.php");
        $dated = $_POST['dated'] ;
        $datef = $_POST['datef'] ;

        $SQL = "SELECT new_list_gab.id_terminal_xfs as id_terminal_xfs ,new_list_gab.nom_gab as nom_gab , atm_profile.description as description, new_list_gab.terminal as terminal,
                list_cmd_for_atm.description_cmd, hist_cmd_execution_reboot.date_send_cmd, hist_cmd_execution_reboot.date_after_exec_cmd
                FROM hist_cmd_execution_reboot,list_cmd_for_atm,`new_list_gab`,`atm_profile`,`list_atm_confirmed`
                WHERE list_atm_confirmed.id_atm = hist_cmd_execution_reboot.id_atm and  new_list_gab.id_profil= atm_profile.id_profile AND new_list_gab.id_terminal_xfs=list_atm_confirmed.id_atm and
                 hist_cmd_execution_reboot.id_cmd=  list_cmd_for_atm.id_command and hist_cmd_execution_reboot.date_send_cmd 
				 BETWEEN  '".mysqli_real_escape_string($connexion,$dated)."' and '".mysqli_real_escape_string($connexion,$datef)."' ORDER BY hist_cmd_execution_reboot.date_send_cmd DESC 	";
        $page = new Pagination($SQL, 8);
        $total = $page->getCount($lang['aff_lign'].' %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();

    }
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 155:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 155 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g =0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $dateSend = $row["date_send_cmd"];
                $dateAfter = $row["date_after_exec_cmd"];
                $typeCmd = $row["description_cmd"];

                if($dateSend=="0000-00-00 00:00:00")
                {
                    $dateSend="---";
                }
                if($dateAfter=="0000-00-00 00:00:00")
                {
                    $dateAfter="---";
                }


                echo '<tr> 
                    <td class="text-center">' . ($g + 1) . '</td>
                    
                    <td class="text-center">' . $row["terminal"] . '</td>
                    <td class="text-center">' . $row["nom_gab"] . '</td>
                    <td class="text-center">' . $row["description"] . '</td>
                    <td class="text-center">' . $dateSend . '</td>
                    <td class="text-center">' . $typeCmd . '</td>
                    
                    </tr>';
                $g++;
            }
            echo '<tr><td colspan="9" class="text-center">';
            echo   '<ul class="pagination justify-content-center">'.$lien.'</ul>';
            echo   '<div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>';
            echo'</td></tr>';
        }
        else
        {
            echo'
           <tr>
                <td colspan="8" align="center"></td>
		   </tr> ';
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_hist_monitor_server()
{
    include "languages/" . $_SESSION['lang'] . ".php";

    include("pagination.php");
	//include("../pagination.php");

    $conn=ma_db_connexion();
    if(!isset($_POST['dated']) or !isset($_POST['datef']))
    {
		$SQL2 = "SELECT *   from monitoring_server_execution order by monitoring_server_execution.id_exec DESC ";
    }
    else
    {
        include "../languages/" . $_SESSION['lang'] . ".php";
        include("../pagination.php");
        $dated = $_POST['dated'] ;
        $datef = $_POST['datef'] ;

		$SQL2 = "SELECT *   from monitoring_server_execution
		WHERE start_date BETWEEN  '".mysqli_real_escape_string($conn,$dated)."' and '".mysqli_real_escape_string($conn,$datef)."' 
		ORDER BY `monitoring_server_execution`.`id_exec` DESC 	 "; 
        

    }
	//echo "<br>".$SQL."<br>";
		$page = new Pagination($SQL2, 20);
        $total = $page->getCount($lang['aff_lign'].' %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL1 = $page->req();
	
	
	echo '
	 <table id="his_p_i_server" class="table table-responsive-sm table-hover table-outline mb-0">
        <thead class="thead-light">
            <th class="text-center">#</th>
            <th class="text-center">'.$lang["th_table_40"].'</th>
            <th class="text-center">'.$lang["th_table_41"].'</th>
            <th class="text-center">'.$lang["exc_numb"].'</th>
            <th class="text-center">'.$lang["dure"].'</th>
        </thead>
        <tbody id="tb_get_hist_server">
     ';

    $result=mysqli_query($conn,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 156:  ".$SQL1."  ".mysqli_error($conn));
        die('ERREUR QUERY 156 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g =0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $start_date = $row["start_date"];
                $end_date = $row["end_date"];
                $num_exec = $row["num_exec"];

                // $duration = $row["duration"];
                $duration ="---";
				
                if($end_date=="0000-00-00 00:00:00")
                {
                    $color="danger";
                }
				else
                {
                    $duration  = secondsToWords(abs(strtotime($end_date)-strtotime($start_date)));
					$color="success";
				}


                echo '<tr>
                    
                    <td   class="text-center">
                        <span class="badge badge-pill badge-'.$color.'">&nbsp; &nbsp; &nbsp;  </span>
                    </td>
                    <td class="text-center">' . $start_date . '</td>
                    <td class="text-center">' . $end_date . '</td>
                    <td class="text-center">' . $num_exec . '</td>
                    <td class="text-center">' . $duration. '</td>
                    </tr>';
                $g++;
            }
            echo '<tr><td colspan="9" class="text-center">';
            echo   '<ul class="pagination justify-content-center">'.$lien.'</ul>';
            echo   '<div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>';
            echo'</td></tr>';
        }
        else
        {
            echo'
           <tr>
                <td colspan="8" class="text-center">--- </td>
		   </tr> ';
        }
        mysqli_free_result($result);
    }
	echo '                   </tbody>
                            </table>
	';
	
	mysqli_close($conn);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_commande()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_command` ,`description_cmd` FROM `list_cmd_for_atm` ORDER BY `description_cmd` DESC";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 157:  ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 157 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'. $row["id_command"] .'">'. $row["description_cmd"] .'</option>';
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_commande_priv($idprivilege,$idev)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT   `id_command` ,`description_cmd`  FROM  `list_cmd_for_atm` ORDER BY `description_cmd` DESC";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 158:  ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 158 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g=1;
            if($idprivilege == 1)
            {
                while ($row = mysqli_fetch_assoc($result))
                {
                    $selectedOptions = explode(',', str_replace("'", "", $idev));
                    $selected = in_array($row["id_command"], $selectedOptions) ? 'selected' : '';
                    echo '<option ' . $selected . ' id="' . $g . '" value="'. $row["id_command"] .'">'. $row["description_cmd"] .'</option>';
                    $g++;
                }
            }
            else
            {
                while ($row = mysqli_fetch_assoc($result))
                {
                    if($row["description_cmd"]=="Ping" || $row["description_cmd"]=="Reboot ATM")
                    {
                        $selectedOptions = explode(',', str_replace("'", "", $idev));
                        $selected = in_array($row["id_command"], $selectedOptions) ? 'selected' : '';
                        echo '<option ' . $selected . ' id="' . $g . '" value="'. $row["id_command"] .'">'. $row["description_cmd"] .'</option>';
                    }
                    $g++;
                }
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function ajouterintervention($intervention,$categ,$note)
{
    $okMessage ="Intervention enregistrées";
    $errorMessage = "Intervention non enregistrées";
    $intervention = addslashes($intervention);
    $note = addslashes($note);
    $connexion=ma_db_connexion();
    $SQL = "INSERT INTO new_action_intervention (" .
        "  libelle_intevention, msg,id_categories,type_arret,degre" .
        ") VALUES (  " . "'" . mysqli_real_escape_string($connexion,$intervention) . "', 
		" . "'" . mysqli_real_escape_string($connexion,$note) . "',"."'".mysqli_real_escape_string($connexion,$categ)."',"."'".mysqli_real_escape_string($connexion,$categ)."',1) ;";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);

    if ($result)
    {
        $responseArray = array('type' => 'success', 'message' => $okMessage);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => $errorMessage." \n Erreur QUERY 159");
        error_log("Erreur SQL 159:  ".$SQL."  ".mysqli_error($connexion));

    }
    mysqli_close($connexion);
    $encoded = json_encode($responseArray);
    header('Content-Type: application/json');
    echo $encoded;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_categorie_intervention()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT   `id_categorie` ,`libelle`  FROM  `new_categorie_intervention` ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 160:  ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 160 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            echo '<option value=""></option>';
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'. $row["id_categorie"] .'">'. $row["libelle"] .'</option>';
            }
        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_categorie_intervention_action($id_intevention)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `new_categorie_intervention`.`libelle`,`new_action_intervention`.`id_intevention` FROM `new_categorie_intervention`,`new_action_intervention`
	WHERE `new_action_intervention`.`id_categories`=`new_categorie_intervention`.`id_categorie`
	AND `new_action_intervention`.`id_intevention` = '".mysqli_real_escape_string($connexion,$id_intevention)."' ORDER BY `new_action_intervention`.`id_intevention` DESC";
    $sql1 = "SELECT   `id_categorie` ,`libelle`  FROM  `new_categorie_intervention` ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 161:  ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 161 !');
    }
    if ($result)
    {
        $result1=mysqli_query($connexion,$sql1);
        if (!$result1)
        {
            error_log("Erreur SQL 162:  ".$sql1."  ".mysqli_error($connexion));
            die('ERREUR QUERY 162 !');
        }
        if ($result1)
        {
            if(mysqli_num_rows($result)>0 && mysqli_num_rows($result1)>0)
            {
                $row = mysqli_fetch_assoc($result);
                while ($row1 = mysqli_fetch_assoc($result1))
                {
                    if( $row["libelle"] == $row1["libelle"])
                    {
                        echo '<option  value="'. $row1["id_categorie"] .'" selected>'. $row["libelle"] .'</option>';
                    }
                    else
                    {
                        echo '<option  value="'. $row1["id_categorie"] .'">'. $row1["libelle"] .'</option>';
                    }
                }
            }
            mysqli_free_result($result1);
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_listes_interventions()
{
    $connexion=ma_db_connexion();
    $SQL = "SELECT  `libelle_intevention` ,  `msg`,`auto_mail`, `retrait_argent`, `depot_argent`, `depot_cheque`, `autre_transactions`,`id_intevention`  
	FROM  `new_action_intervention` ORDER BY id_intevention ASC ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 163:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 163 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g = 0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $libelle_intevention = $row["libelle_intevention"];
                $msg = $row["msg"];
                $auto_mail = $row["auto_mail"];
                $retrait_argent = $row["retrait_argent"];
                $depot_argent = $row["depot_argent"];
                $depot_cheque = $row["depot_cheque"];
                $autre_transactions = $row["autre_transactions"];
                $id_intevention = $row["id_intevention"];
                if($libelle_intevention=="")
                {
                    $libelle_intevention="----";
                }

                if($msg=="")
                {
                    $msg="----";
                }
                if($auto_mail==0)
                {
                    $auto_mail='<span class="fa fa-times" onclick="javascript:update_mail_auto(\'' . $auto_mail .'\',\'' . $id_intevention . '\')" style="color: #C9302C;" aria-hidden="false"></span>';
                }
                if($retrait_argent==0)
                {
                    $retrait_argent='<span class="fa fa-times" onclick="javascript:update_retrait_argent(\'' . $retrait_argent .'\',\'' . $id_intevention . '\')" style="color: #C9302C;" aria-hidden="false"></span>';
                }
                if($depot_argent==0)
                {

                    $depot_argent='<span class="fa fa-times" onclick="javascript:update_depot_argent(\'' . $depot_argent .'\',\'' . $id_intevention . '\')" style="color: #C9302C;" aria-hidden="false"></span>';
                }
                if($depot_cheque==0)
                {
                    $depot_cheque='<span class="fa fa-times" onclick="javascript:update_depot_cheque(\'' . $depot_cheque .'\',\'' . $id_intevention . '\')" style="color: #C9302C;" aria-hidden="false"></span>';
                }
                if($autre_transactions==0)
                {
                    $autre_transactions='<span class="fa fa-times" onclick="javascript:update_autre_transactions(\'' . $autre_transactions .'\',\'' . $id_intevention . '\')" style="color: #C9302C;" aria-hidden="false"></span>';
                }


                if($auto_mail==1)
                {
                    $auto_mail='<span  class="cil-check" onclick="javascript:update_mail_auto(\'' . $auto_mail .'\',\'' . $id_intevention . '\')" style="color: #33cc33;" aria-hidden="false"></span>';
                }
                if($retrait_argent==1)
                {
                    $retrait_argent='<span class="cil-check" onclick="javascript:update_retrait_argent(\'' . $retrait_argent .'\',\'' . $id_intevention . '\')" style="color: #33cc33;" aria-hidden="false"></span>';
                }
                if($depot_argent==1)
                {
                    $depot_argent='<span class="cil-check" onclick="javascript:update_depot_argent(\'' . $depot_argent .'\',\'' . $id_intevention . '\')" style="color: #33cc33;" aria-hidden="false"></span>';
                }
                if($depot_cheque==1)
                {
                    $depot_cheque='<span class="cil-check" onclick="javascript:update_depot_cheque(\'' . $depot_cheque .'\',\'' . $id_intevention . '\')" style="color: #33cc33;" aria-hidden="false"></span>';
                }
                if($autre_transactions==1)
                {
                    $autre_transactions='<span class="cil-check" onclick="javascript:update_autre_transactions(\'' . $autre_transactions .'\',\'' . $id_intevention . '\')" style="color: #33cc33;" aria-hidden="false"></span>';
                }

                echo '<tr style="padding: 3px">
	            <td scope="row" style="padding: 3px" align="center">' . ($g + 1) . '</td>
	            <td scope="row" style="padding: 3px" align="left">' . $libelle_intevention . '</td>
	      
	            <td scope="row" style="padding: 3px" align="left">' . $msg . '</td>
	            <td scope="row" style="padding: 3px" align="center"><div id = "' . $id_intevention . '1" >' . $auto_mail . '</div></td>
	            <td scope="row" style="padding: 3px" align="center"><div id = "' . $id_intevention . '2" >' . $retrait_argent . '</div></td>
	            <td scope="row" style="padding: 3px" align="center"><div id = "' . $id_intevention . '3" >' . $depot_argent . '</div></td>
	            <td scope="row" style="padding: 3px" align="center"><div id = "' . $id_intevention . '4" >' . $depot_cheque . '</div></td>
	            <td scope="row" style="padding: 3px" align="center"><div id = "' . $id_intevention . '5" >' . $autre_transactions . '</div></td>
				<td scope="row" style="padding: 3px" align="center">
                                                    <select class="selectpicker form-control" onchange="javascript:update_categorie_intervention(this,\''.$id_intevention.'\')">';
                get_categorie_intervention_action($id_intevention);
                echo'</select>
                                                </td>
                <td scope="row" style="padding: 3px" align="center"><span class="fa fa-minus" onclick="javascript:delete_intervention(\''.$id_intevention.'\')" style="color: #C9302C;" aria-hidden="false"></span></td>              
			    
				</tr>';
                $g++;
            }
            echo'

           <tr>
                <td colspan="10" align="center"></td>
		   </tr> ';

        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_mail_auto($mail_auto,$id_intevention)
{
    $connexion=ma_db_connexion();
    $SQL="";
    if($mail_auto==0)
    {
        $SQL= "UPDATE new_action_intervention SET `auto_mail` = 1 where `auto_mail` = 0 and id_intevention=".mysqli_real_escape_string($connexion,$id_intevention)." ";
    }
    else if($mail_auto==1)
    {
        $SQL= "UPDATE new_action_intervention SET `auto_mail` = 0 where `auto_mail` = 1 and id_intevention=".mysqli_real_escape_string($connexion,$id_intevention)." ";
    }
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 164:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 164 !');
    }

    if($result)
    {
        //todo: json retour
        echo"mise à jour effectuée";
    }
    mysqli_close($connexion);

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_retrait_argent($retrait_argent,$id_intevention)
{
    $connexion=ma_db_connexion();
    $SQL="";
    if($retrait_argent==0)
    {
        $SQL= "UPDATE new_action_intervention SET `retrait_argent` = 1 where `retrait_argent` = 0 and id_intevention=".mysqli_real_escape_string($connexion,$id_intevention)."";
    }
    else if($retrait_argent==1)
    {
        $SQL= "UPDATE new_action_intervention SET `retrait_argent` = 0 where `retrait_argent` = 1 and id_intevention=".mysqli_real_escape_string($connexion,$id_intevention)."";
    }
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 165:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 165 !');
    }
    if($result)
    {
        //todo: json retour
        echo"mise à jour effectuée";
    }

    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_depot_argent($depot_argent,$id_intevention)
{
    $connexion=ma_db_connexion();
    $SQL="";
    if($depot_argent==0)
    {
        $SQL= "UPDATE new_action_intervention SET `depot_argent` = 1 where `depot_argent` = 0 and id_intevention=".mysqli_real_escape_string($connexion,$id_intevention)."";
    }
    else if($depot_argent==1)
    {
        $SQL= "UPDATE new_action_intervention SET `depot_argent` = 0 where `depot_argent` = 1 and id_intevention=".mysqli_real_escape_string($connexion,$id_intevention)."";
    }
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 166:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 166 !');
    }
    if($result)
    {
        //todo: json retour
        echo"mise à jour effectuée";
    }
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_depot_cheque($depot_cheque,$id_intevention)
{
    $connexion=ma_db_connexion();
    $SQL="";
    if($depot_cheque==0)
    {
        $SQL= "UPDATE new_action_intervention SET `depot_cheque` = 1 where `depot_cheque` = 0 and id_intevention=".mysqli_real_escape_string($connexion,$id_intevention)."";
    }
    else if($depot_cheque==1)
    {
        $SQL= "UPDATE new_action_intervention SET `depot_cheque` = 0 where `depot_cheque` = 1 and id_intevention=".mysqli_real_escape_string($connexion,$id_intevention)."";
    }
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 167:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 167 !');
    }
    if($result)
    {
        //todo: json retour
        echo"mise à jour effectuée";
    }
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_autre_transactions($autre_transactions,$id_intevention)
{
    $connexion=ma_db_connexion();
    $SQL="";
    if($autre_transactions==0)
    {
        $SQL= "UPDATE new_action_intervention SET `autre_transactions` = 1 where `autre_transactions` = 0 and id_intevention=".mysqli_real_escape_string($connexion,$id_intevention)."";
    }
    else if($autre_transactions==1)
    {
        $SQL= "UPDATE new_action_intervention SET `autre_transactions` = 0 where `autre_transactions` = 1 and id_intevention=".mysqli_real_escape_string($connexion,$id_intevention)."";
    }
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 168:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 168 !');
    }
    if($result)
    {
        //todo: json retour
        echo"mise à jour effectuée";
    }
    mysqli_close($connexion);
}
/*********************************************/
function update_categorie_intervention($sel,$id_intevention)
{
    $connexion=ma_db_connexion();
    $SQL= "UPDATE new_action_intervention SET `id_categories` = $sel , `type_arret` =$sel  where id_intevention= ".mysqli_real_escape_string($connexion,$id_intevention)."";
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 169:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 169 !');
    }
    if($result)
    {
        //todo: json retour
        echo"mise à jour effectuée";
    }
    mysqli_close($connexion);
}
/******************************************************/
function delete_intervention($id_intevention)
{
    $connexion=ma_db_connexion();
    $SQL= "DELETE FROM `new_action_intervention` WHERE `id_intevention`= ".mysqli_real_escape_string($connexion,$id_intevention)." ";

    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 170:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 170 !');
    }
    if($result)
    {
        //todo: json retour
        echo"Supression effectuée";
    }

    mysqli_close($connexion);
}
/***************************************************************************/

function get_IdAtm_Terminal($terminal)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_atm`  FROM  `list_atm_confirmed` WHERE `terminal` = '".mysqli_real_escape_string($connexion,$terminal)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 171:  ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 171 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["id_atm"];
            }
        }
        else
        {
            return "";
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
function historique_ping($ipAtm,$if_success,$if_executed,$value_cmd)
{
    $connexion=ma_db_connexion();
    $IdATM = get_IdAtm_Terminal($ipAtm);
    $SQL= "INSERT INTO `hist_cmd_execution`(" .
    "id_atm,date_send_cmd,date_exec_cmd,id_cmd,if_executed,if_success,user_exec,date_after_exec_cmd,value_cmd".
    ") VALUES ('".mysqli_real_escape_string($connexion,$IdATM)."',  now() ,  now() 
    ,52,'".mysqli_real_escape_string($connexion,$if_executed)."','".mysqli_real_escape_string($connexion,$if_success)."'
    ,'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',  now() ,'".mysqli_real_escape_string($connexion,$value_cmd)."')";
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 172:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 172 !');
    }

    mysqli_close($connexion);
}  
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_scren_incident($id_atm, $terminalID)
{
    $val=get_name_terminal_gag($id_atm);
    include "../languages/" . $_SESSION['lang'] . ".php";
    $lang_ses = $_SESSION['lang'];
    echo '
    <div  class="modal-dialog modal-xl" role="document">
        <div  class="modal-content" style="background-color:#e9ecef;color:#2b3449;"">
        <!-- Modal Header -->
		<div class="modal-header">
			
			<h4 class="modal-title">'.$lang['hist_cap'].' '.$lang['terminal'].' : ';
            echo  $terminalID. " - ".$val[1];
            echo '</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            
		</div>	
		<div class="modal-footer">
            <button type="button"  class="btn btn-block btn-dark c-loading-button" onclick="javascript:reloadDiv_capture_incid(\''.$id_atm.'\');" >Reload <i id="btn_reload_cmd_ATM"></i></button>
        </div>
        
        <div class="modal-body">	
            <form class="form-horizontal" role="form">
                <div class="container col-md-12"">
                <div class="row">
                </div>
                </div>
                <div>
                    <table  id="tbl_hist_cmd_det" class="table table-responsive-sm table-bordered table-striped table-sm" >
                        <thead class="thead-light">
                            <tr>
                                <th class="text-center">'.$lang['date_env_cmd'].'</th>
                                <th class="text-center">'.$lang['stat_cmd'].'</th>
                                <th class="text-center">'.$lang['date_cmd'].'</th>
                                <th class="text-center">'.$lang['ret_cmd'].'</th>
                                <th class="text-center"></th>   
                            </tr>
                            
                        </thead>
                        ';


                    get_all_scren_incident($id_atm);
                    echo '
                    </table>					
                </div>		
            </form> 
        </div>																																																					
        <!-- Modal footer -->
            <div class="modal-footer">
                    
                    <button type="button" id="modal_button" onclick="javascript:get_modal_button(\''.$lang_ses.'\')" data-dismiss="modal" class="btn btn-info" >'.$lang['confir'].'</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">'.$lang['close'].'</button>
            </div>			
        
        </div>
    </div>
    ';

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getcommandeATM($id_atm, $terminalID,$idprivilege)
{
    include "../languages/" . $_SESSION['lang'] . ".php";
    $val=get_name_terminal_gag($id_atm);
    echo '
		
    <div  class="modal-dialog modal-xl" role="document" style="max-width: 1700px;">					
	    <div class="modal-content" style="background-color:#e9ecef;color:#2b3449;" >							
	        <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">'.$lang['atm_hist_cmd'].' : '.$terminalID.' - '.$val[1].' </h4>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-footer">
                <button type="button"  class="btn btn-block btn-dark c-loading-button"  onclick="javascript:reloadDiv_commande_ATM(\''.$id_atm.'\',\''.$idprivilege.'\');" >'.$lang['reload'].' <i id="btn_reload_cmd_ATM"></i> </button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">	
                <form class="form-horizontal" role="form">
                    <div class="container col-md-12"">
                        <div class="row">
                        </div>
                    </div>
                    <table  id="tbl_hist_cmd" class="table table-responsive-sm table-bordered table-striped table-sm" >
                        <thead>
                            <tr>
                                <th>'.$lang['date_env_cmd'].'</th>
                                <th>'.$lang['desc_cms'].'</th>
                                <th>'.$lang['stat_cmd'].'</th>
                                <th>'.$lang['date_cmd'].'</th>
                                <th>'.$lang['ret_cmd'].'</th>
                            </tr>
                        </thead>';
                        getallcommandATM($id_atm,$idprivilege);
                    echo '</table>						
                </form> 
            </div>																																																					
            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
            </div>																																		
        </div>
    </div>';
}


/********************************************************************************/
function getallcommandATM($id_atm,$idprivilege)
{
    include("../pagination.php");
    include "../languages/" . $_SESSION['lang'] . ".php";
    $connexion=ma_db_connexion();
    echo ' 	<tbody id="div_commande_ATM">';

    $description = 'description_en';
    if ($lang['lang']=="fr")
    {
        $description = 'description';
    }
    if ($idprivilege==1)
    {
        $SQL1 = "SELECT `date_send_cmd`,`date_exec_cmd`,`description_cmd`,`if_success`,`date_after_exec_cmd`, `value_cmd`,`type_cmd_execution`.".$description." as description
        FROM `hist_cmd_execution`,`list_cmd_for_atm`,`type_cmd_execution`
        WHERE `hist_cmd_execution`.`id_atm` = '" . mysqli_real_escape_string($connexion,$id_atm) . "' 
        AND `type_cmd_execution`.`id_type` = `hist_cmd_execution`.`if_executed`
        AND `hist_cmd_execution`.`id_cmd`= `list_cmd_for_atm`.`id_command` 
        ORDER BY `hist_cmd_execution`.`id_exec_cmd` DESC LIMIT 30";

        $SQL2 = "SELECT `date_send_cmd`,`date_exec_cmd`,`description_cmd`,`if_success`,`date_after_exec_cmd`,`type_cmd_execution`.".$description." as description
        FROM `hist_cmd_execution_reboot`,`list_cmd_for_atm`,`type_cmd_execution`
        WHERE `hist_cmd_execution_reboot`.`id_atm` = '" .  mysqli_real_escape_string($connexion,$id_atm) . "' 
        AND `type_cmd_execution`.`id_type` = `hist_cmd_execution_reboot`.`if_executed`
        AND `hist_cmd_execution_reboot`.`id_cmd`= `list_cmd_for_atm`.`id_command` 
        ORDER BY `hist_cmd_execution_reboot`.`id_exec_cmd` DESC LIMIT 30";
    }
    else
    {
        $SQL1 = "SELECT `date_send_cmd`,`date_exec_cmd`,`description_cmd`,`if_success`,`date_after_exec_cmd`, `value_cmd`,`type_cmd_execution`.".$description." as description
        FROM `hist_cmd_execution`,`list_cmd_for_atm`,`type_cmd_execution`
        WHERE `hist_cmd_execution`.`id_atm` = '" .  mysqli_real_escape_string($connexion,$id_atm) . "' 
        AND `type_cmd_execution`.`id_type` = `hist_cmd_execution`.`if_executed`
        AND `hist_cmd_execution`.`id_cmd`= `list_cmd_for_atm`.`id_command` 
        AND `hist_cmd_execution`.`id_cmd` IN (52,53)
        ORDER BY `hist_cmd_execution`.`id_exec_cmd` DESC LIMIT 30";

        $SQL2 = "SELECT `date_send_cmd`,`date_exec_cmd`,`description_cmd`,`if_success`,`date_after_exec_cmd`,`type_cmd_execution`.".$description." as description
        FROM `hist_cmd_execution_reboot`,`list_cmd_for_atm`,`type_cmd_execution`
        WHERE `hist_cmd_execution_reboot`.`id_atm` = '" .  mysqli_real_escape_string($connexion,$id_atm). "' 
        AND `type_cmd_execution`.`id_type` = `hist_cmd_execution_reboot`.`if_executed`
        AND `hist_cmd_execution_reboot`.`id_cmd`= `list_cmd_for_atm`.`id_command` 
        AND `hist_cmd_execution_reboot`.`id_cmd` IN (1)
        ORDER BY `hist_cmd_execution_reboot`.`id_exec_cmd` DESC LIMIT 30";
    }



    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    //
    $result=mysqli_query($connexion,$SQL1);
    $result1=mysqli_query($connexion,$SQL2);
    if (!$result)
    {
        error_log("Erreur SQL 173:  ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 173 !'.$SQL1);
    }
    if (!$result1)
    {
        error_log("Erreur SQL 174:  ".$SQL2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 174 !');
    }
    if($result || $result1)
    {
        if((mysqli_num_rows($result)>0)||(mysqli_num_rows($result1)>0))
        {
            
            $g=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $date_send_cmd=$row["date_send_cmd"];
                $date_exec_cmd=$row["date_exec_cmd"];
                $description_cmd=$row["description_cmd"];
                $if_success=$row["if_success"];
                $date_after_exec_cmd=$row["date_after_exec_cmd"];
                $value_cmd=$row["value_cmd"];
                $description=$row["description"];

                if ($date_send_cmd == "0000-00-00 00:00:00") {
                    $date_send_cmd = "---";
                }
                if ( $date_exec_cmd == "0000-00-00 00:00:00") {
                    $date_exec_cmd = "---";
                }
                if ( $description_cmd == "") {
                    $description_cmd = "---";
                }
                if ($if_success == "") {
                    $if_success = "---";
                }
                if ($date_after_exec_cmd == "0000-00-00 00:00:00") {
                    $date_after_exec_cmd = "---";
                }
                if ($value_cmd == "") {
                    $value_cmd = "---";
                }
                if ($description == "") {
                    $description = "---";
                }

                if ($if_success == "0" && $description_cmd == "Ping")
                {
                    echo '<tr style="background-color:#ffc6a9;">
                    
                    <td style="padding: 3px" align="center">' . $date_send_cmd . '</td>
                    
                    <td style="padding: 3px" align="center">' . $description_cmd . '</td>
                    <td style="padding: 3px" align="center">' . $description . ' <span class="fa fa-times" style="color: #ff4d4d;" aria-hidden="false"></span></td>
                    <td style="padding: 3px" align="center">' . $date_after_exec_cmd . ' </td>
                    <td style="padding: 3px" align="center">' . $value_cmd . ' </td>

                    </tr>';
                }
                else if ($date_after_exec_cmd == "---" && $description_cmd != "Ping"&& $description_cmd != "Capture écran" )
                {
                    echo '<tr style="background-color:#ff4d4d;">
                    
                    <td style="padding: 3px" align="center">' . $date_send_cmd . '</td>
                    
                    <td style="padding: 3px" align="center">' . $description_cmd . '</td>
                    <td style="padding: 3px" align="center">' . $description . ' <span class="fa fa-times" style="color: #ff4d4d;" aria-hidden="false"></span></td>
                    <td style="padding: 3px" align="center">' . $date_after_exec_cmd . ' </td>
                    <td style="padding: 3px" align="center">' . $value_cmd . ' </td>

                    </tr>';
                }
                else if($description_cmd == "Capture écran" && $date_after_exec_cmd != "---")
                {
                    echo '<tr>
                    
                    <td style="padding: 3px" align="center">' . $date_send_cmd . '</td>
                   
                    <td style="padding: 3px" align="center">' . $lang['screenshot'] . '</td>
                    <td style="padding: 3px" align="center">' . $description . ' <span class="cil-check" style="color: #5CB85C;" aria-hidden="false"></span></td>
                    <td style="padding: 3px" align="center">' . $date_after_exec_cmd . ' </td>
                    <td style="padding: 3px" align="center">
                    <a tabindex="-1"  data-toggle="modal" 
					    onClick="javascript:ShowScreenshotATM(\''.$id_atm.'\',\''.$value_cmd.'\')"   
					    data-target="#showScreenshotATM"><i class="fa fa-eye" title="'.$lang['screenshot'].'"></i>
                    </td>

                    </tr>';
                }
                else if($description_cmd == "Capture écran" && $date_after_exec_cmd == "---")
                {
                    echo '<tr>
                    <td style="padding: 3px" align="center">' . $date_send_cmd . '</td>
                   
                    <td style="padding: 3px" align="center">' . $lang['screenshot'] . '</td>
                    <td style="padding: 3px" align="center">' . $description . ' <span class="cil-check" style="color: #ffc6a9;" aria-hidden="false"></span></td>
                    <td style="padding: 3px" align="center">' . $date_after_exec_cmd . ' </td>
                    <td style="padding: 3px" align="center">
                    <a tabindex="-1"  data-toggle="modal"><i class="fa fa-eye-slash" title="'.$lang['screenshot'].'"></i>
                    </td>

                    </tr>';
                }
                else
                {
                    echo '<tr> 
           
                    <td style="padding: 3px" align="center">' . $date_send_cmd . '</td>
               
                    <td style="padding: 3px" align="center">' . $description_cmd . '</td>
                    <td style="padding: 3px" align="center">' . $description . ' <span class="cil-check" style="color: #5CB85C;" aria-hidden="false"></span></td>
                    <td style="padding: 3px" align="center">' . $date_after_exec_cmd . ' </td>
                    <td style="padding: 3px" align="center">' . $value_cmd . ' </td>

                    </tr>';
                }
                $g++;
            }
            while ($row = mysqli_fetch_assoc($result1))
            {
                $date_send_cmd1=$row["date_send_cmd"];
                $date_exec_cmd1=$row["date_exec_cmd"];
                $description_cmd1=$row["description_cmd"];
                $if_success1=$row["if_success"];
                $date_after_exec_cmd1=$row["date_after_exec_cmd"];
                $value_cmd1="";


                if ($date_send_cmd1 == "0000-00-00 00:00:00")
                {
                    $date_send_cmd1 = "---";
                }
                if ( $date_exec_cmd1 == "0000-00-00 00:00:00")
                {
                    $date_exec_cmd1 = "---";
                }
                if ( $description_cmd1 == "")
                {
                    $description_cmd1 = "---";
                }
                if ($if_success1 == "")
                {
                    $if_success1 = "---";
                }
                if ($if_success1 != "1") {

                    $value_cmd1 = $lang['cmd_non_exec'];
                }
                if ($if_success1 == "0")
                {
                    $value_cmd1 = $lang['rebot_ok'];
                }
                if ($date_after_exec_cmd1 == "0000-00-00 00:00:00")
                {
                    $value_cmd1 = $lang['cmd_non_exec'];
                    $date_after_exec_cmd1 = "---";
                }
                if ($value_cmd1 == "")
                {
                    $value_cmd1 = "---";
                }

                if ($row["if_success"] == "0" && $description_cmd1 == "Reboot ATM" && $date_after_exec_cmd1 != "---")
                {
                    echo '<tr >
                    
                    <td style="padding: 3px" align="center">' . $date_send_cmd1 . '</td>
              
                    <td style="padding: 3px" align="center">' . $description_cmd1 . '</td>
                    <td style="padding: 3px" align="center"><span class="cil-check " style="color: #5CB85C;" aria-hidden="false"></span></td>
                    <td style="padding: 3px" align="center">' . $date_after_exec_cmd1 . ' </td>
                    <td style="padding: 3px" align="center">' . $value_cmd1 . ' </td>

                    </tr>';
                }
                else
                {
                    echo '<tr> 
                  
                    <td style="padding: 3px" align="center">' . $date_send_cmd1 . '</td>
              
                    <td style="padding: 3px" align="center">' . $description_cmd1 . '</td>
                    <td style="padding: 3px" align="center"><span class="fa fa-times" style="color: #ff4d4d;" aria-hidden="false"></span></td>
                    <td style="padding: 3px" align="center">' . $date_after_exec_cmd1 . ' </td>
                    <td style="padding: 3px" align="center">' . $value_cmd1 . ' </td>

                    </tr>';
                }
                $g++;
            }
        }
        mysqli_free_result($result);
        mysqli_free_result($result1);
    }
mysqli_close($connexion);
    echo '
         </tbody>';
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_scren_incident($id_atm)
{
    include("../pagination.php");
    $connexion=ma_db_connexion();
    echo ' 	<tbody id="div_scren_incident">';


    $SQL = "SELECT `date_send_cmd`,`type_cmd_execution`.`description` as `description`,`date_after_exec_cmd`, `value_cmd`, `if_executed`
    FROM `hist_cmd_execution`,`list_cmd_for_atm`,`type_cmd_execution`
    WHERE `hist_cmd_execution`.`id_atm` = '" .  mysqli_real_escape_string($connexion,$id_atm) . "' 
    AND `hist_cmd_execution`.`id_cmd`= `list_cmd_for_atm`.`id_command` 
    AND `hist_cmd_execution`.`if_executed`= `type_cmd_execution`.`id_type`
    AND `hist_cmd_execution`.`id_cmd` = 53
    ORDER BY `hist_cmd_execution`.`id_exec_cmd` DESC LIMIT 10";
    // var_dump($SQL);die();

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    //
    $result=mysqli_query($connexion,$SQL);

    if (!$result)
    {
        error_log("Erreur SQL 000173:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 000173 !');
    }

    if($result)
    {
        if((mysqli_num_rows($result)>0))
        {

            $g=0;
            while ($row = mysqli_fetch_assoc($result))
            {

                $date_send_cmd=$row["date_send_cmd"];
                $description=$row["description"];
                $if_executed=$row["if_executed"];
                $date_after_exec_cmd=$row["date_after_exec_cmd"];
                $value_cmd=$row["value_cmd"];

                if ($date_send_cmd == "0000-00-00 00:00:00") {
                    $date_send_cmd = "---";
                }

                if ( $description == "") {
                    $description = "---";
                }

                if ($date_after_exec_cmd == "0000-00-00 00:00:00")
                {
                    $date_after_exec_cmd = "---";
                }
                if ($value_cmd == "")
                {
                    $value_cmd = "---";
                }
                $state_cap=get_scren_del($value_cmd);
                //var_dump("state_cap : ".$state_cap);
                if($date_after_exec_cmd != "---" && $state_cap === 1)
                {
                    echo '<tr>
                    
                    <td class="text-center">' . $date_send_cmd . '</td>
                    <td class="text-center">' . $description . ' <span class="cil-check" style="color: #5CB85C;" aria-hidden="false"></span></td>
                    <td class="text-center">' . $date_after_exec_cmd . ' </td>
                    <td class="text-center">
                    <a tabindex="-1"  data-toggle="modal" 
					    onClick="javascript:ShowScreenshotATM(\''.$id_atm.'\',\''.$value_cmd.'\')"   
					    data-target="#showScreenshotATM"><i class="fa fa-eye" title="Capture écran"></i>
                    </td>
                    <td>
                        <input type="radio" name="cheked_cmd" id="'.$value_cmd.'"  value="'.$value_cmd.'" >   
                    </td>
                    </tr>';
                }
                else if($date_after_exec_cmd == "---" || $state_cap === 0)
                {
                    echo '<tr>
                    
                    <td style="padding: 3px" align="center">' . $date_send_cmd . '</td>
                   
                    <td style="padding: 3px" align="center">' . $description . ' <span class="cil-check" style="color: #ffc6a9;" aria-hidden="false"></span></td>
                    <td style="padding: 3px" align="center">' . $date_after_exec_cmd . ' </td>
                    <td style="padding: 3px" align="center">
                    <a tabindex="-1"  data-toggle="modal"><i class="fa fa-eye-slash" title="Capture écran"></i>
                    </td>
                    <td>
                        <input disabled type="radio" name="cheked_cmd" id="'.$value_cmd.'" value="'.$value_cmd.'" >  
                    </td>
                    </tr>';
                }

                $g++;
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    echo '
         </tbody>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function ShowScreenshotATM($ATM,$value_cmd)
{
    include "../languages/" . $_SESSION['lang'] . ".php";
    //var_dump($lang);

    include("../pagination.php");
    $connexion=ma_db_connexion();
    echo '<div class="modal-dialog modal-lg" role="document" >
	<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
        <!-- Modal Header -->
        <div class="modal-header">
            <h4 class="modal-title"> '.$lang['screenshot'].' : '.$ATM.' - '.getLibelleATM($ATM).' </h4>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        </div>					
                                                                                            
        <!-- Modal body -->
        <div class="modal-body">';
    if ($value_cmd === "---")
    {
        echo '<div class="alert alert-danger" align="center"><strong>'.$lang['no_img'].'</strong></div>';
    }
    else
    {
        $SQL="SELECT `data`,`id_image`,`name_picture` from `screenshot_images` WHERE `id_image` IN (".$value_cmd.")";
        $page = new Pagination($SQL, 1);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $SQL1 = $page->req();

         mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
         $result=mysqli_query($connexion,$SQL1);
         if (!$result)
         {
             error_log("Erreur SQL 175:  ".$SQL1."  ".mysqli_error($connexion));
             die('ERREUR QUERY 175 !');
         }
         if ($result)
         {
             if (mysqli_num_rows($result) > 0)
             {
                 while ($row = mysqli_fetch_assoc($result))
                 {
                     $img_name = $row['name_picture'];
                     echo '<div class="img-block">
                            <!-- <pre><div style="user-select: none;display: inline;">Code image :</div></pre>-->
                            <img src="data:image/jpeg;base64,'.base64_encode( $row['data'] ).'" title="'.$img_name.'" height="50%" width="100%" /> 
                     </div>';
                 }
             }
             else
             {
                 echo '<div class="alert alert-danger" align="center"><strong>'.$lang['img_del'].'</strong></div>';

             }
             mysqli_free_result($result);
         }
         mysqli_close($connexion);


         echo ' <div align="center">
            <ul class="pagination justify-content-center"><li>'.$page->Paginate_modal_screen(5, '',$ATM,$value_cmd).' </li></ul>
            <div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>
        </div>';
     }

                    echo '</div>																										
                    <!-- Modal footer -->
                    <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
                    </div>
                                                                            
        </div>
    </div>';

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getDetail_cause_arret($libelleLogical,$id_atm,$terminal,$nomGAB,$idVacation,$idVac,$descservice,$lang)
{
    $idfwDevice="";
    $connexion=ma_db_connexion();
    $sql="SELECT fwDevice FROM vacations_".  mysqli_real_escape_string($connexion,$descservice)." 
          WHERE id_atm = ".  mysqli_real_escape_string($connexion,$id_atm)."
          AND id_vacation = ".  mysqli_real_escape_string($connexion,$idVac)." 
          AND id_global_vacation = ".  mysqli_real_escape_string($connexion,$idVacation)." ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 176:  ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 176 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $idfwDevice= $row["fwDevice"];
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
        echo "<a style='vertical-align:middle' data-toggle='modal' href='#myModalcause_arret".$terminal."'><span class='fa fa-eye fa-lg' title='".$lang["det_caus_arret"]."'></span></a>
		 <div class='modal fade' id='myModalcause_arret".$terminal."' role='dialog'>
			<div id='modal_d' class='modal-dialog' role='document'>
				<div class='modal-content'>
					<div class='modal-header'>
						<h4 class='modal-title' >".$nomGAB." - ".$terminal."</h4>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
					</div>  
					
					<div class='modal-body'> ";
                            getxfs_errors_service($libelleLogical,$descservice,$idfwDevice);
                            echo"</div>
					
					<div class='modal-footer'>
						
						<button type='button' class='btn btn-secondary' data-dismiss='modal'>".$lang['close']."</button>
						
					</div>
				</div>
			</div>
		 </div>
	";

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getxfs_errors_service($libelleLogical,$descservice,$idfwDevice)
{
    $msg='message';

    if ($_SESSION['lang']=='fr')
    {
        $msg='message_fr';
    }
    $connexion=ma_db_connexion();
    $sql="SELECT code_error,message,message_fr FROM xfs_errors_".  mysqli_real_escape_string($connexion,$descservice)." 
          WHERE category = 'fwDevice' 
          AND value = '".  mysqli_real_escape_string($connexion,$idfwDevice)."' ";
    //echo $sql;
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 177:  ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 177 !'.mysqli_error($connexion));
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<div class="card card-accent-info ">
                    <div class="card-header">'.$descservice.' : '.$row["code_error"].'</div>
                    <div class="card-body">
                        <ul class="list-group">
                            <li class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">'.$row[$msg].'</li>
                        </ul>
                    </div>
                </div>';

            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDetail_mnt_crit_att($libelleLogical,$id_atm,$terminal,$nomGAB,$descservice,$mtn_ctr,$generartion_date,$lang)
{

    $connexion=ma_db_connexion();
    $sql="SELECT 
         (`vacations_CDM_cash_unit_logical`.`ulValues`*`vacations_CDM_cash_unit_logical`.`ulCount`) as cassetes,
    
         `atm_logical_names`.`file_generation_date` as date_ajour,
         `atm_logical_names`.`logical_name` as logical_name,
          `atm_logical_names`.`critical_cash_amount`

          FROM `vacations_CDM_cash_unit_logical`,`vacations_CDM`,`atm_logical_names` 
          WHERE `vacations_CDM`.`id_atm` = ".  mysqli_real_escape_string($connexion,$id_atm)."
          AND `vacations_CDM_cash_unit_logical`.`id_vacation` = `vacations_CDM`.`id_vacation` 
          AND `atm_logical_names`.`id_logical_name`=`vacations_CDM`.`id_logical_name`
          AND `vacations_CDM_cash_unit_logical`.`usType` = 3 
          and  `atm_logical_names`.`id_logical_name` = '".  mysqli_real_escape_string($connexion,$libelleLogical)."'
          AND `vacations_CDM`.`if_last_vacation` = 1 
          AND `vacations_CDM`.`id_logical_name` = '".  mysqli_real_escape_string($connexion,$libelleLogical)."' ";

    $totoalcasseteacc=0;
    $logical_name="";
    $mtn_ctr=number_format($mtn_ctr,0,'',','). " MGA";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 178:  ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 178 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $logical_name=$row["logical_name"];
                $totoalcasseteacc=$totoalcasseteacc + $row["cassetes"];
                $critical_cash_amount=number_format($row["critical_cash_amount"],0,'',','). " MGA";
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

    echo "<a style='vertical-align:middle' data-toggle='modal' href='#myModalmnt_crit_att".$terminal."'><span class='fa fa-eye fa-lg' title='Détail   Montant Critique'></span></a>
		 <div class='modal fade' id='myModalmnt_crit_att".$terminal."' role='dialog'>
			<div id='modal_mnt_crit_att' class='modal-dialog' role='document'>
				<div class='modal-content'>
					<div class='modal-header'>
					    <h4>".$nomGAB." - ".$terminal."</h4>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
					</div>  
					
					<div class='modal-body'> ";
                            echo '<div class="card card-accent-info ">
                                <div class="card-header">Service '.$descservice.' : '.$logical_name.' </div>
                                <div class="card-body">
                                    <ul class="list-group">
                                        <li class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">'.$lang['mtn_crt_dfn'].': 
                                            <span>'.$critical_cash_amount.'</span>
                                        </li>
                                        <li class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">'.$lang['mtn_crt_rmnt'].':
                                            <span>'.$mtn_ctr.' </span>
                                        </li>   
                                        <li class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">'.$lang['act_amnt'].':
                                            <span>'.number_format($totoalcasseteacc,0,'',','). " MGA".'</span></li>
                                    </ul>
                                </div>
                            </div>';

                    echo"</div>
					
					<div class='modal-footer'>
						
						<button type='button' class='btn btn-secondary' data-dismiss='modal'>".$lang['close']."</button>
						
					</div>
				</div>
			</div>
		 </div>
	";
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDetail_Mode_superviseur($libelleLogical,$id_atm,$terminal,$nomGAB,$last_supervised_mode_entry)
{
    $connexion=ma_db_connexion();
    $sql="SELECT critical_supervisor_mode_value, last_supervised_mode_entry, last_supervised_mode_exit 
    FROM atm_logical_names WHERE id_atm=".  mysqli_real_escape_string($connexion,$id_atm)." LIMIT 1";
   // echo $sql;
    $critical_supervisor_mode_value="";
    $last_supervised_entry="";
    $last_supervised_mode_exit="";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 179:  ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 179 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $critical_supervisor_mode_value = $row["critical_supervisor_mode_value"];
                $last_supervised_entry = $row["last_supervised_mode_entry"];
                $last_supervised_mode_exit = $row["last_supervised_mode_exit"];
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    echo "<a style='vertical-align:middle' data-toggle='modal' href='#myModalMode_superviseur".$terminal."'><span class='fa fa-eye fa-lg' title='Détail   Mode superviseur'></span></a>";

echo"
<div class='modal fade' id='myModalMode_superviseur".$terminal."' role='dialog'>
			<div id='modal_Mode_superviseur' class='modal-dialog' role='document'>
				<div class='modal-content'>
					<div class='modal-header'>
						<h4 class='modal-title' >".$nomGAB." - ".$terminal." </h4>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
					</div>  
					
					<div class='modal-body'> ";

                        echo '<div class="card card-accent-info ">
                            <div class="card-header">Mode superviseur dépasse la durée permise </div>
                            <div class="card-body">
                                <ul class="list-group">
                                    <li class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">Durée critique définit pour mode superviseur : 
                                        <span>'.$critical_supervisor_mode_value.'</span>
                                    </li>
                                    <li class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">Dernière entrée en mode superviseur :
                                        <span>'.$last_supervised_mode_entry.'</span>
                                    </li>   
                                    <li class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">Dernière sortie en mode superviseur :
                                         <span>'.$last_supervised_mode_exit.'</span>';
                                        if(abs(strtotime($last_supervised_entry)-strtotime($last_supervised_mode_exit)) <= 0)
                                        {
                                            echo"<span class='fa fa-circle fa-lg' style='color: #C9302C;' aria-hidden='false'></span>";
                                        }
                                        else
                                        {
                                            echo"<span class='fa fa-circle fa-lg' style='color: #33cc33;' aria-hidden='false'></span>";
                                        }
                                    echo'</li>
                                </ul>
                            </div>
                        </div>';
                    echo"</div>
				
					<div class='modal-footer'>
						
						<button type='button' class='btn btn-secondary' data-dismiss='modal'>Fermer</button>
						
					</div>
				</div>
			</div>
		 </div>";
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDetail_Cartes_capturées_successivement($libelleLogical,$id_atm,$terminal,$nomGAB)
{

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function Transactions_annulées_successivement($libelleLogical,$id_atm,$terminal,$nomGAB,$last_rejected_transaction,$last_reject_reason,$lang)
{
    $connexion=ma_db_connexion();

    $sql="SELECT last_withrawel, last_reject_reason 
    FROM atm_logical_names WHERE id_atm=".  mysqli_real_escape_string($connexion,$id_atm)." LIMIT 1";

    $last_withrawel="";
    $last_reason="";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 180:  ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 180 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $last_withrawel = $row["last_withrawel"];
                $last_reason = $row["last_reject_reason"];

            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    echo "<a style='vertical-align:middle' data-toggle='modal' href='#myModalransactions_annulées".$terminal."'><span class='fa fa-eye fa-lg' title='".$lang['det_trans_ann_succ']."'></span></a>";

    echo"
    <div class='modal fade' id='myModalransactions_annulées".$terminal."' role='dialog'>
			<div id='modal_Mode_superviseur' class='modal-dialog' role='document'>
				<div class='modal-content'>
					<div class='modal-header'>
					    <h4>".$nomGAB." - ".$terminal."</h4>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
					</div>  
					
					<div class='modal-body'>
                        ";

                    echo '<div class="card card-accent-info ">
                            <div class="card-header">'.$lang["ann_trans_succ"].' </div>
                            <div class="card-body">
                                <ul class="list-group">
                                    <li class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">'.$lang["last_mot_rej"].'
                                        <span>'.$last_reject_reason.'</span>
                                    </li>
                                    <li class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">'.$lang["last_withrawel"].'
                                        <span>'.$last_withrawel.'</span>
                                    </li>   
                                    <li class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">'.$lang["last_rejected_transaction"].'
                                        <span>'.$last_rejected_transaction.'</span>';
                                           if((strtotime($last_withrawel)-strtotime($last_rejected_transaction)) <= 0)
                                            {
                                                echo"<span class='fa fa-circle fa-lg' style='color: #C9302C;' aria-hidden='false'></span>";
                                            }
                                            else
                                            {
                                                echo"<span class='fa fa-circle fa-lg' style='color: #33cc33;' aria-hidden='false'></span>";
                                            }
                                    echo '</li>
                                </ul>
                            </div>
                        </div>';
                echo"</div>
					
					<div class='modal-footer'>
						
						<button type='button' class='btn btn-secondary' data-dismiss='modal'>".$lang['close']."</button>
						
					</div>
				</div>
			</div>
		 </div>";
}
function get_Transaction_Passive($id_atm,$terminal,$nomGAB,$passive_value_withrawel,$last_withrawel)
{
    echo '<a style="vertical-align:middle" data-toggle="modal" href="#myModalTransaction_Passive'.$terminal.'"><span class="fa fa-eye fa-lg" title="Passive transaction detail"></span></a>';

    echo"<div class='modal fade' id='myModalTransaction_Passive".$terminal."' role='dialog'>
			<div id='modal_Transaction_Passive' class='modal-dialog' role='document'>
				<div class='modal-content'>
					<div class='modal-header'>
						<h4>".$nomGAB." - ".$terminal."</h4>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
					</div>  
					
					<div class='modal-body'>
                        <div class='row'>
                            <div class='col-12'>
                                <div class='c-callout c-callout-info'><small class='text-muted'>Last withdrawal date: </small>
                                    <div class='text-value-lg'>".$last_withrawel."</div>
                                </div>
                            </div>
                        </div> 
                        <div class='row'>
                            <div class='col-12'>
                                <div class='c-callout c-callout-info'><small class='text-muted'>Configured value :</small>
                                    <div class='text-value-lg'>".$passive_value_withrawel." min</div>
                                </div>
                            </div>
                        </div> 
				</div>
					
					<div class='modal-footer'>
						
						<button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
						
					</div>
				</div>
			</div>
		 </div>";
}
function get_depot_argent_Passive($id_atm,$terminal,$nomGAB,$passive_value_money_deposit,$last_money_deposit)
{
    echo '<a style="vertical-align:middle" data-toggle="modal" href="#myModaldepot_argent_Passive'.$terminal.'"><span class="fa fa-eye fa-lg" title="Money deposit detail"></span></a>';
    echo"
<div class='modal fade' id='myModaldepot_argent_Passive".$terminal."' role='dialog'>
			<div id='modal_depot_argent_Passive' class='modal-dialog' role='document'>
				<div class='modal-content'>
					<div class='modal-header'>
					    <h4 class='modal-title' >".$nomGAB." - ".$terminal."</h4>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
					</div>  
					
					<div class='modal-body'>
					    <div class='row'>
                            <div class='col-12'>
                              <div class='c-callout c-callout-info'><small class='text-muted'>Date of last money deposit:</small>
                                <div class='text-value-lg'>".$last_money_deposit."</div>
                              </div>
                            </div>
                        </div> 
                        <div class='row'>
                            <div class='col-12'>
                              <div class='c-callout c-callout-info'><small class='text-muted'>Configured value :</small>
                                <div class='text-value-lg'>".$passive_value_money_deposit." min</div>
                              </div>
                            </div>
                        </div>
				    </div>
					
					<div class='modal-footer'>
						
						<button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
						
					</div>
				</div>
			</div>
		 </div>";
}

function get_depot_cheque_Passive($id_atm,$terminal,$nomGAB,$passive_value_check_deposit,$last_check_deposit)
{
    //echo "passive_value_check_deposit : ".$passive_value_check_deposit;
    echo "<a style='vertical-align:middle' data-toggle='modal' href='#myModaldepot_cheque_Passive".$terminal."'><span class='fa fa-eye fa-lg' title='Check deposit detail'></span></a>";
    echo"<div class='modal fade' id='myModaldepot_cheque_Passive".$terminal."' role='dialog'>
			<div id='modal_depot_cheque_Passive' class='modal-dialog' role='document'>
				<div class='modal-content'>
					<div class='modal-header'>
						<h4 style='font-size:13pt;color: #3a1d19;' class='modal-title' >".$nomGAB." - ".$terminal."</h4>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
					</div>  
					
					<div class='modal-body'>
                        <div class='row'>
                            <div class='col-12'>
                              <div class='c-callout c-callout-info'><small class='text-muted'>Last check deposit date: </small>
                                <div class='text-value-lg'>".$last_check_deposit."</div>
                              </div>
                            </div>
                        </div> 
                        <div class='row'>
                            <div class='col-12'>
                              <div class='c-callout c-callout-info'><small class='text-muted'>Configured value :</small>
                                <div class='text-value-lg'>".$passive_value_check_deposit." min</div>
                              </div>
                            </div>
                        </div>
				    </div>
					
					<div class='modal-footer'>
						
						<button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
						
					</div>
				</div>
			</div>
		 </div>";
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nombre_incident_total()
{

    $conn=ma_db_connexion();
    $nombre_incident=0;
    $sql="SELECT atm_list_stopped_test.id_atm AS nbr_incident FROM `atm_list_stopped_test`";
    $result1=mysqli_query($conn,$sql);
    if (!$result1)
    {
        error_log("Erreur SQL 181:  ".$sql."  ".mysqli_error($conn));
        die('ERREUR QUERY 181 !');
    }
    if($result1)
    {
        $nombre_incident = mysqli_num_rows($result1);
    }
    mysqli_free_result($result1);
    mysqli_close($conn);
    return $nombre_incident;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nombre_incident_total_v2()
{

    $conn=ma_db_connexion();
    $nombre_incident=0;
    $sql="SELECT atm_list_stopped_test.id_atm AS nbr_incident FROM `atm_list_stopped_test`";
    $result1=mysqli_query($conn,$sql);
    if (!$result1)
    {
        error_log("Erreur SQL 181:  ".$sql."  ".mysqli_error($conn));
        die('ERREUR QUERY 181 !'.mysqli_error($conn));
    }
    if($result1)
    {
        $nombre_incident = mysqli_num_rows($result1);
    }
    mysqli_free_result($result1);
    mysqli_close($conn);
    return $nombre_incident;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nombre_incident_nodeclarer()
{
    $conn=ma_db_connexion();
    $incident_nodeclarer=0;
    $sql = "SELECT atm_list_stopped_test.id_atm
            FROM `list_atm_confirmed` , atm_list_stopped_test 
            WHERE list_atm_confirmed.id_atm= atm_list_stopped_test.id_atm
            AND list_atm_confirmed. state= 1
            AND list_atm_confirmed.terminal NOT IN (SELECT id_gab FROM new_incident_gab_ouvert)";
    $result2=mysqli_query($conn,$sql);
    if (!$result2)
    {
        error_log("Erreur SQL 182:  ".$sql."  ".mysqli_error($conn));
        die('ERREUR QUERY 0182 !');
    }
    if($result2)
    {
        $incident_nodeclarer = mysqli_num_rows($result2);
    }
    mysqli_free_result($result2);
    mysqli_close($conn);
   return $incident_nodeclarer;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nombre_incident_nodeclarer_v2()
{
    $conn=ma_db_connexion();
    $incident_nodeclarer=0;
    $sql = "SELECT atm_list_stopped_test.id_atm AS nbr_incident FROM `atm_list_stopped_test` WHERE if_declared=0";
    $result2=mysqli_query($conn,$sql);
    if (!$result2)
    {
        error_log("Erreur SQL 182:  ".$sql."  ".mysqli_error($conn));
        die('ERREUR QUERY 182 !'.mysqli_error($conn));
    }
    if($result2)
    {
        $incident_nodeclarer = mysqli_num_rows($result2);
    }
    mysqli_free_result($result2);
    mysqli_close($conn);
   return $incident_nodeclarer;

}
function date_raff_arret($result1,$result2)
{
    if ($_SESSION['lang']=='fr')
    {
        $date2 = date('d/m/Y à H:i:s');
        echo" Le ". $date2;
        echo", total de ".$result2."/".$result1."";
    }
    else
    {

        $date2 = date('m/d/Y \\a\\t H:i:s');
        echo" The ". $date2;
        echo", total of ".$result2."/".$result1."";
    }
   /* $conn=ma_db_connexion();
    //$selectDate="SELECT MAX(DATE_FORMAT(`date_up_atm`, '%d/%m/%Y à %H:%i:%s')) AS Max_Date FROM atm_logical_names ";
    $selectDate= "SELECT MAX(`date_up_atm`) AS Max_Date FROM atm_logical_names";

    $result=mysqli_query($conn,$selectDate);
    if (!$result)
    {
        error_log("Erreur SQL 183:  ".$selectDate."  ".mysqli_error($conn));
        die('ERREUR QUERY 183 !');
    }
    if($result)
    {
        if( mysqli_num_rows($result) > 0)
        {
            while ($myDate= mysqli_fetch_assoc($result))
            {
                $date1 = $myDate["Max_Date"];
                if ($_SESSION['lang']=='fr')
                {
                    $date2 = date_format(date_create($date1),'d/m/Y à H:i:s');
                    echo" Le ". $date2;
                    echo", total de ".$result2."/".$result1."";
                }
                else
                {
                    $date2 = date_format(date_create($date1),'d/m/Y \\a\\t H:i:s');
                    echo" The ". $date2;
                    echo", total of ".$result2."/".$result1."";
                }

                //echo date_format(date_create($date1), date('d-m-Y à H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y'))));echo". total de ".$result2."/".$result1."";
            }

        }
    }

    mysqli_free_result($result);
    mysqli_close($conn);*/
}
///////////////////////////////////////////////
function suivi_work_post()
{
    // session_start();
    echo '                   
			<div class="col-lg-12">	
                <div class="row">
                    <div class="table-responsive">	
                        <table class="table table-bordered table-hover table-striped">';
                            echo '<thead>											
                                <tr>
                                    <th colspan="5" style="background-color:#fabf8f;font-size:18px;color:#fff;line-height: 160%;text-align: center;" >Post-region 
                                        <a tabindex="-1" class="btn btn-info btn-circle" title="Ajouter post" data-toggle="modal" 
                                            onClick="javascript:get_modal_AjouterPost()"   
                                            data-target="#ajouter_Post"><span class="fa fa-plus"></span></a>													
                                    </th>
                                </tr>											             
                                <tr>
                                    <th>+</th>
                                    <th>Nom post</th>
                                    <th>Régions</th>
                                    <th>Modifier</th>
                                    <th>Suprimer</th>
                                </tr>
                            </thead>
                            <tbody>';
                                $connexion=ma_db_connexion();

                                $SQL2 = "SELECT `id_post`, `name_poste`, `id_filiale` FROM `work_post`  ORDER BY `id_post` DESC";
                                mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
                                $result2=mysqli_query($connexion,$SQL2);
                                if (!$result2)
                                {
                                    error_log("Erreur SQL 184:  ".$SQL2."  ".mysqli_error($connexion));
                                    die('ERREUR QUERY 184 !');
                                }
                                if($result2)
                                {
                                    if(mysqli_num_rows($result2)>0)
                                    {		$i=1;
                                        while ($row = mysqli_fetch_assoc($result2))
                                        {

                                            echo '<tr>
                                                    <td>'.$i.'</td>
                                                    <td>'.$row["name_poste"].'</td>
                                                    <td>';
                                                        getnameRegion($row["id_filiale"]);
                                                    echo'</td>
                                                    <td>
                                                       <a tabindex="-1" class="btn btn-success btn-circle" title="Modifier" data-toggle="modal"
                                                        onClick="javascript:get_modal_modifier_work_post(\''.$row["id_post"].'\')"
                                                         data-target="#Modifier_Post"><span class="fa fa-pencil-square-o" ></span></a>
                                                      
                                                    </td>
                                                    <td>
                                                          <a  class="btn btn-danger btn-circle" title="Supprimer" onClick="javascript:suppimer_work_post(\''.$row["id_post"].'\')"><span class="fa fa-times" ></span></a>
                                                    </td>
                                            </tr>';
                                            $i++;
                                        }
                                    }
                                    mysqli_free_result($result2);
                                }
                                mysqli_close($connexion);
                            echo '</tbody>
                        </table>
                    </div><!-- /.table-responsive -->
                </div>
            </div>';
}
function get_modal_AjouterPost()
{


    echo '
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title" id="Label_ajouter_Region">Ajouter Post </h4>
          </div>
          <div class="modal-body"> 
           <!-- Modal -->
           <div id="Lightbox_Label_ajouter_Post">
            <form class="form-horizontal" role="form">		
            		
                <div  class="form-group">				
                    <label for="post" class="col-sm-3 control-label">Nom Post :</label>
                    <div class="col-sm-9">
                        <input  id="post" name="post" type="text" class="form-control input-sm">	    
                    </div>
                </div>		
            </form>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
            <button type="button" class="btn btn-primary"  onClick="javascript:ajouterPost()" data-dismiss="modal">Ajouter</button>
          </div>
        </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->

    ';

}
function ajouterPost($post)
{
    $connexion=ma_db_connexion();

    $SQL = "INSERT INTO  `work_post`( `name_poste`, `id_filiale`) VALUES ( '".  mysqli_real_escape_string($connexion,$post)."', '');";

    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 185:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 185 !');
    }
    if($result)
    {
        //todo: json retour

    }


    mysqli_free_result($result);
    mysqli_close($connexion);
}
function suppimer_work_post($id_post)
{
    $connexion=ma_db_connexion();

    $SQL = "DELETE FROM `work_post` WHERE  `id_post` = '".  mysqli_real_escape_string($connexion,$id_post)."'";
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 186:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 186 !');
    }
    if($result)
    {
        //todo: json retour

    }


    mysqli_free_result($result);
    mysqli_close($connexion);
}
function get_modal_modifier_work_post($id_post)
{
    $name_poste="";
    $id_filiale="";
    $connexion=ma_db_connexion();

    $SQL = "SELECT `name_poste`, `id_filiale` FROM `work_post` WHERE `id_post` = ".  mysqli_real_escape_string($connexion,$id_post)." ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 187:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 187 !');
    }
    if($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $name_poste=$row["name_poste"];
                $id_filiale=$row["id_filiale"];
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    echo '
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title" id="Label_ajouter_Region">Modifier Post </h4>
          </div>
          <div class="modal-body"> 
           <!-- Modal -->
           <div id="Lightbox_Label_Modifier_Post">
            <form class="form-horizontal" role="form">				
                <div  class="form-group">				
                    <label for="post" class="col-sm-3 control-label">Nom Post :</label>
                    <div class="col-sm-9">
                        <input  id="post" name="post" type="text" class="form-control input-sm" value="'.$name_poste.'">	    
                    </div>
                </div>	
                 <div  class="form-group">				
                    <label for="region" class="col-sm-3 control-label">Region :</label>
                    <div class="col-md-9">
                          <select id="regionid[]"  class="selectpicker form-control" data-live-search="true" multiple data-done-button="true" data-hide-disabled="true" data-actions-box="true" data-selected-text-format="count > 6">
                            ';
                            getRegion($id_filiale);
                        echo '</select>
                </div>		
            </form>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
            <button type="button" class="btn btn-danger"  onClick="javascript:modifierPost(\''.$id_post.'\')" data-dismiss="modal">Modifier</button>
          </div>
        </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->

    ';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifierPost($id_post,$name_poste,$id_filiale)
{
    $id_filiale=substr($id_filiale,1);
    $connexion=ma_db_connexion();

    $SQL ="UPDATE `work_post`  SET `name_poste` ='".  mysqli_real_escape_string($connexion,$name_poste)."' ,
			`id_filiale` = '".$id_filiale."' 
			WHERE `id_post` = '".$id_post."' ";

    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 188:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 188 !');
    }
    if($result)
    {
        //todo: json retour

    }

    mysqli_free_result($result);
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getRegion($idRegion)
{
    $connexion=ma_db_connexion();

    $SQL = "SELECT `id_filiale` ,`nom_filiale`  FROM  `new_filiale` ORDER BY `nom_filiale` DESC ; ";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 189:  ".$SQL."  " .mysqli_error($connexion));
        die('ERREUR QUERY 189 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $selectedOptions = explode(',', str_replace("'", "", $idRegion));
                $selected = in_array($row["id_filiale"], $selectedOptions) ? 'selected' : '';
                echo '<option ' . $selected . ' id="' . $g . '" value="' . $row["id_filiale"] . '">' . $row["nom_filiale"] . '</option>';
                $g++;
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getnameRegion($idRegion)
{
    $name_regions="";
    $connexion=ma_db_connexion();
    $array =explode(",",$idRegion);

    foreach ($array as $item)
    {
        if($item != "")
        {

            $SQL = "SELECT `nom_filiale`  FROM  `new_filiale`  WHERE `id_filiale` = '".  mysqli_real_escape_string($connexion,$item)."' ; ";

            mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
            $result=mysqli_query($connexion,$SQL);
            if (!$result)
            {
                error_log("Erreur SQL 190:  ".$SQL."  " .mysqli_error($connexion));
                die('ERREUR QUERY 190 !');
            }
            if ($result)
            {
                if(mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {
                        $name_regions.="-".$row["nom_filiale"];
                    }

                }

            }
        }
    }
    echo substr($name_regions,1);
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getNamePost()
{
    $connexion=ma_db_connexion();

    $SQL = "SELECT `name_poste`   FROM  `work_post` ORDER BY `id_post` ASC ; ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");

    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 191:  ".$SQL."  " .mysqli_error($connexion));
        die('ERREUR QUERY 191 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $g=0;
            while ($row = mysqli_fetch_assoc($result))
            {
               // $name_poste=trim($row["name_poste"]);
                $name_poste=str_replace(CHR(32),'',$row["name_poste"]);
                echo '<option id="' . $g . '" value="' . $name_poste . '">' . $row["name_poste"] . '</option>';
                $g++;
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDashboardATM($id_atm)
{
    include "../languages/" . $_SESSION['lang'] . ".php";

    $val=get_name_terminal_gag($id_atm);
    echo '
		
<div  class="modal-dialog modal-xl" style="max-width: 1700px;">
									
	<div  class="modal-content" style="background-color:#e9ecef;color:#2b3449;">					
	
	<!-- Modal Header -->
        <div class="modal-header">
            <h4 class="modal-title"> '.$lang['dashboard'].' :  '.$id_atm.' - '.$val[0].' - '.$val[1].'</h4>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        </div>
	    <div class="modal-footer">
            <button type="button"  class="btn btn-pill btn-block btn-dark"   onclick="javascript:reloadDiv_Dashboard_ATM(\''.$id_atm.'\')" >'.$lang['reload'].' <i id="btn_reload_Dashboard_ATM" ></i></button> 
        </div>

												<!-- Modal body -->
												<div class="modal-body">	
													<form class="form-horizontal" role="form">
														<div class="container col-md-12">
														<div class="row">
                                                            <div class="col-sm-12 col-lg-12">
                                                                <div class="card text-white bg-secondary  mb-2" style="text-align: center;">
                                                                    <div class="text-value  c-icon-3xl text-white my-1 text-white">
                                                                        <h style="color: #4f5d73;"> '.$lang['dashboard'].' '.getLibelleATM($id_atm); echo'  '.getDateDashboard($id_atm);echo'</h>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
														  
                                                        </div>
                                                         <div class="row" id="Div_DashboardATM">
                                                            <div class="col-sm-3 col-md-4 ">
                                                                <div class="card col-12">
                                                                    <div class="card-header " align="center" style="font-size: 20px;font-family: Calibri">'.$lang['use_ram'].'</div>
                                                                    <div class="card-body">
                                                                        <div class="c-chart-wrapper">
                                                                            <canvas id="myChart1" ></canvas>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-3 col-md-4 ">
                                                                <div class="card col-12">
                                                                    <div class="card-header " align="center" style="font-size: 20px;font-family: Calibri">'.$lang['use_cpu'].'</div>
                                                                    <div class="card-body">
                                                                        <div class="c-chart-wrapper">
                                                                             <canvas id="myChart2"></canvas>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-3 col-md-4 ">
                                                                <div class="card col-12">
                                                                    <div class="card-header " align="center" style="font-size: 20px;font-family: Calibri">'.$lang['use_dis_lib'].'</div>
                                                                    <div class="card-body">
                                                                        <div class="c-chart-wrapper">
                                                                            <canvas id="myChart3"></canvas>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                        </div>
													</form> 
												</div>																																																					
					<!-- Modal footer -->
						<div class="modal-footer">
								<button type="button" class="btn btn-danger" data-dismiss="modal"> '.$lang['close'].'</button>
						</div>																																		
	</div>
</div>';
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getColorDashboard($id_atm)
{
    $connexion=ma_db_connexion();
    $SQL = "SELECT `cpu_load`,memory_load,(((`disk_available`-`disk_free`)*100)/`disk_available`) as `taux_disk` FROM `hist_connect`
	WHERE `id_atm` =".   mysqli_real_escape_string($connexion,$id_atm)." ORDER BY `id_con` DESC LIMIT 1 ";

    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 192:  ".$SQL."  " .mysqli_error($connexion));
        die('ERREUR QUERY 192 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {

            $row = mysqli_fetch_assoc($result);
            $cpu_load= $row["cpu_load"];
            $memory_load= $row["memory_load"];
            $taux_disk= $row["taux_disk"];

             if ($cpu_load == 0 && $memory_load == 0 )
            {
                return "#888683";
            }
             else if($cpu_load <= 80 && $memory_load <= 80 && $taux_disk <= 80)
            {
                return "#9ad887";

            }
            else
                {
                    return "#ff3d4a";
                }

        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDateDashboard($id_atm)
{
    $connexion=ma_db_connexion();
    $SQL = "SELECT `date_connect` FROM `hist_connect` WHERE `id_atm` = ".  mysqli_real_escape_string($connexion,$id_atm)." ORDER BY `id_con` DESC LIMIT 1 ";
    $date_connect="-----";
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 193:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 193 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {

            $row = mysqli_fetch_assoc($result);
            $date_connect= $row["date_connect"];
         //   return $date_connect;
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return $date_connect;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function checkAuthJWT($token,array $idhabilitation)
{
    include("../lib/JWT/jwt.php");
    $config2 = file_get_contents("../lib/auth/config.json");
    $config2 = json_decode($config2);
    $bool_return=false;

    $jwtPayload = [];


    if(isset($token) && isset($idhabilitation))
    {
        foreach ($idhabilitation as $valuehabilitation)
        {
            // echo "VALUE : " . $valuehabilitation;
            try
            {
                $payload2 = JWT::decode($token, $config2->jwt_secret, (array)$config2->jwt_signing_alg);
                if ($payload2->habilitation <> "")
                {
                    foreach ($payload2->habilitation as $value)
                    {
                        // echo "ID habilitation :   $value \n";
                        if ($value == $valuehabilitation)
                        {
                            $bool_return = true;
                            break;
                        }
                    }
                }
                else
                {
                    $bool_return = false;
                }
                header("Content-Type: application/json");
            }
            catch (Exception $e)
            {
                //if token is invalid, then return the error message
                $bool_return = false;
                //echo $e->getMessage();
            }
        }
    }
    else
    {
        $bool_return=false;
    }
    return $bool_return;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function gethardtokenind()
{
    $config = file_get_contents("../../lib/auth/config.json");
    $config = json_decode($config);
    $longueur = 10;
    $caracteres=$config->idlogin;
    $longueurMax = strlen($caracteres);
    $caractere1 = '';
    $caractere2 = '';
    $caractere3 = '';
    $caractere4 = '';
    $caractere5 = '';
    $caractere6 = '';
    $caractere7 = '';
    $caractere8 = '';
    $caractere9 = '';
    $caractere10 = '';

    for ($i = 0; $i < $longueur; $i++)
    {
        $caractere1= $caracteres[rand(0, $longueurMax - 1)];
        $caractere2= $caracteres[rand(0, $longueurMax - 1)];
        $caractere3= $caracteres[rand(0, $longueurMax - 1)];
        $caractere4= $caracteres[rand(0, $longueurMax - 1)];
        $caractere5= $caracteres[rand(0, $longueurMax - 1)];
        $caractere6= $caracteres[rand(0, $longueurMax - 1)];
        $caractere7= $caracteres[rand(0, $longueurMax - 1)];
        $caractere8= $caracteres[rand(0, $longueurMax - 1)];
        $caractere9= $caracteres[rand(0, $longueurMax - 1)];
        $caractere10= $caracteres[rand(0, $longueurMax - 1)];
    }
    $chaineAleatoire= $caractere1."". $caractere2."". $caractere3."". $caractere4."". $caractere5."". $caractere6."". $caractere7."". $caractere8."". $caractere9."". $caractere10;
     //echo "chaineAleatoire : ".$chaineAleatoire."<br>"; die();
    return $chaineAleatoire;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getall_upload_content($id_atm,$idprivilege)
{
    include("../pagination.php");
    $connexion=ma_db_connexion();
    echo ' 	<tbody id="div_pload_content"> ';
    if ($idprivilege==1)
    {
        $SQL = "SELECT `path_upload`,`date_after_upload`,`nbr_files`,`code_upload_content`
        ,`upload_execution`.`state_upload` as `state_upload`
        ,`state_upload`.`description` as `state_upload_desc`
        FROM `upload_execution`,`state_upload`
        WHERE `upload_execution`.`state_upload` = `state_upload`.`id_state`
        AND `id_atm` = '" . mysqli_real_escape_string($connexion,$id_atm) . "'
        ORDER BY `code_upload_content` DESC";
    }
   // var_dump($SQL);
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);

    if (!$result)
    {
        error_log("Erreur SQL 194:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 194 !');
    }
    if($result )
    {
       // echo mysqli_num_rows($result);
        if (mysqli_num_rows($result) > 0)
        {
            $g = 0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $path_upload = $row["path_upload"];
                $date_after_upload = $row["date_after_upload"];
                $nbr_files = $row["nbr_files"];
                $code_upload_content = $row["code_upload_content"];
                $state_upload = $row["state_upload"];
                $state_upload_desc = $row["state_upload_desc"];

                if ($state_upload=="1"|| $state_upload=="3"|| $state_upload=="4")
                {
                    echo '<tr style="background-color:#ffc6a9;">
                    <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                    <td style="padding: 3px" align="center">' . $path_upload . '</td>
                    <td style="padding: 3px" align="center">' . $date_after_upload . '</td>
                    <td style="padding: 3px" align="center">' . $nbr_files . ' </td>
                    <td style="padding: 3px" align="center">' . $code_upload_content . ' </td>
                    <td style="padding: 3px" align="center">' . $state_upload_desc . ' </td>
                     <td style="padding: 3px" align="center">
                        <a tabindex="-1"><i class="fa fa-eye-slash" title="Fichier Télécharger"></i></a>
                    </td>
                    </tr>';
                }
                else if ($state_upload=="10" || $state_upload=="2")
                {
                    echo '<tr>
                    <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                    <td style="padding: 3px" align="center">' . $path_upload . '</td>
                    <td style="padding: 3px" align="center">' . $date_after_upload . '</td>
                    <td style="padding: 3px" align="center">' . $nbr_files . ' </td>
                    <td style="padding: 3px" align="center">' . $code_upload_content . ' </td>
                    <td style="padding: 3px" align="center">' . $state_upload_desc . ' </td>
                    <td style="padding: 3px" align="center">
                    <a tabindex="-1"  data-toggle="modal" 
					    onClick="javascript:ShowFileUploadATM(\''.$id_atm.'\',\''.$code_upload_content.'\',\''.$state_upload.'\')"
					    data-target="#showFileUpload"><i class="fa fa-eye" title="Fichier Télécharger"></i>
					</a>
                    </td>
                    </tr>';
                }
                else
                {
                    echo '<tr style="background-color:#ff0000;">
                    <td scope="row" style="padding: 3px">' . ($g + 1) . '</td>
                    <td style="padding: 3px" align="center">' . $path_upload . '</td>
                    
                    <td style="padding: 3px" align="center">' . $date_after_upload . '</td>
                    <td style="padding: 3px" align="center">' . $nbr_files . ' </td>
                    <td style="padding: 3px" align="center">' . $code_upload_content . ' </td>
                    <td style="padding: 3px" align="center">' . $state_upload_desc . ' </td>
                     <td style="padding: 3px" align="center">
                    <a tabindex="-1"><i class="fa fa-eye-slash" title="Fichier Télécharger"></i></a>
                    </td>
                    </tr>';
                }

            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    echo '<tr>
            <td colspan="7" align="center"></td>
		  </tr> 
         </tbody>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function ShowFileUploadATM($ATM,$code_upload_content,$state_upload)
{
    include("../pagination.php");
    $connexion=ma_db_connexion();

    if(isset($code_upload_content))
    {

        $SQL="SELECT `id_content`,`data`,`hash_code`, `name_file`, `date_upload`,`state_approbation`, `size_file` FROM `upload_contents` 
        WHERE id_atm = '".mysqli_real_escape_string($connexion,$ATM)."' AND `code_upload_content` = '".mysqli_real_escape_string($connexion,$code_upload_content)."'";


    echo ' <div class="modal-dialog modal-xl modal-dialog-centered" style="transform: translate(0%, 50%);">
        <div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title"> File detail : '.$ATM.' - '.getLibelleATM($ATM).' </h4>
                    <button type="button" class="close" data-dismiss="modal" onclick="javascript:reloadDiv_upload_execution(\''.$ATM.'\',1)">&times;</button>
                </div>					
                                                                                                    
                <!-- Modal body -->
                <div class="modal-body">

        <table id="tbl_cnt_file" class="table table-responsive-sm table-hover table-outline mb-0"  width="100%">
            <thead class="thead-light">
                <tr>
                    <th>File Name</th>
                    <th>File Size</th>
                    <th>File upload date</th>
                    <th>Download File</th>
                   <!-- <th>View Fichier</th>-->
               </tr>
            </thead>
            <tbody id="tbl_cnt_file_tbody">';
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 195:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 195 !');
    }
    
    if ($result)
    {
        if (mysqli_num_rows($result) > 0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {

                $filedata = $row['data'];
                $filename = $row['name_file'];
                $id_content = $row['id_content'];

               // header("Content-length: ".strlen($filedata));
                //header("Content-disposition: download; filename=$filename");

                    echo '<tr> 
                    <td style="padding: 3px" align="center">' . $row['name_file'] . '</td>   
                    <td style="padding: 3px" align="center">' . $row['size_file']/1000 . ' ko</td>   
                    <td style="padding: 3px" align="center">' . $row['date_upload'] . '</td>   ';
                    if ($row['state_approbation']=="3")
                    {
                        echo' <td style="padding: 3px" align="center"><a href="data:file;base64,'.base64_encode( $filedata ).'"  download="' . $filename . '">Download</td>';
                    }
                    else
                    {
                        echo' <td style="padding: 3px" align="center"><a  tabindex="-1"  
                        onClick="javascript:DownloadFileATM(\''.$ATM.'\',\''.$id_content.'\')" data-dismiss="modal"> 
                        <i class="fa fa-cloud-download" title="Télécharger Fichier"></i></a></td>';
                    }
                echo'  <!--<td style="padding: 3px" align="center"><a target="_blank" href="data:file;base64,/\'//.base64_encode( $filedata )./\'"  >View</a></td>-->
               </tr>';


            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
        echo'<tr>
                <td colspan="4" align="center"></td>
            </tr>
        </tbody>
    </table>';


    echo '</div>																										
			<!-- Modal footer -->
            <div class="modal-footer">
                    <button type="button" onclick="javascript:reloadDiv_upload_execution(\''.$ATM.'\',1)" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
                                                                            
        </div>
    </div>';
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function DownFileUploadATM($ATM,$code_upload_content,$state_upload)
{
    include("../pagination.php");
    $connexion=ma_db_connexion();

    if(isset($code_upload_content))
    {

        $SQL="SELECT `id_content`,`data`,`hash_code`, `name_file`, `date_upload`, `size_file` FROM `upload_contents` 
        WHERE id_atm = '".mysqli_real_escape_string($connexion,$ATM)."' AND `code_upload_content` = '".mysqli_real_escape_string($connexion,$code_upload_content)."'";


    echo ' <div class="modal-dialog modal-lg">
        <div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title"> Détail fichier GAB : '.$ATM.' - '.getLibelleATM($ATM).' </h4>
                    <button type="button" onclick="javascript:reloadDiv_upload_execution(\''.$ATM.'\',1)" class="close" data-dismiss="modal">&times;</button>
                </div>					
                                                                                                    
                <!-- Modal body -->
                <div class="modal-body">

        <table id="tbl_cnt_file" class="table table-bordered table-hover table-striped"  width="100%">
            <thead class="text-warning">
           
            <th>Nom Fichier</th>
            <th>Size Fichier</th>
            <th>Date upload Fichier</th>
            <th>Download Fichier </th>
           <!-- <th>View Fichier</th>-->
            </thead>
            <tbody id="tbl_cnt_file_tbody">';
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 195:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 195 !');
    }

    if ($result)
    {
        if (mysqli_num_rows($result) > 0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {

                $id_content = $row['id_content'];

                    echo '<tr> 
                    <td style="padding: 3px" align="center">' . $row['name_file'] . '</td>   
                    <td style="padding: 3px" align="center">' . $row['size_file']/1000 . ' ko</td>   
                    <td style="padding: 3px" align="center">' . $row['date_upload'] . '</td>   
                     <td style="padding: 3px" align="center">
                    <input type="checkbox" class="checkbox" value="'. $row["id_content"] .'"   >

                    </td>
                    <!--<td style="padding: 3px" align="center"><a target="_blank" href="data:file;base64,/\'//.base64_encode( $filedata )./\'"  >View</a></td>-->
                </tr>';

            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
        echo'<tr>
                <td colspan="4" align="center"></td>
            </tr>
        </tbody>
    </table>';


    echo '</div>																										
			<!-- Modal footer -->
            <div class="modal-footer">
            <a class="btn btn-danger" tabindex="-1"  data-toggle="modal" 
					   onClick="javascript:DownloadFileATM(\''.$ATM.'\',\''.$id_content.'\')"
					   data-target="#showFileUpload">Download <i class="fa fa-cloud-download" title="Télécharger Fichier"></i></a>
                    <button type="button" onclick="javascript:reloadDiv_upload_execution(\''.$ATM.'\',1)" class="btn btn-danger" data-dismiss="modal">Close</button>
                    
            </div>
                                                                            
        </div>
    </div>';
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function detailler_email_consigne($id_mail)
{
    $message=get_information_email_consigne($id_mail);
    echo'
    <div class="panel-group" id="accordion">

        <div class="panel panel-default">
      <div class="panel-body">
          <table class="table table-striped">
             <tr>
                  <th>AA</th><th>:</th><th>'.$message[1].'</th>
       </tr>
             <tr>   
                  <th>CC</th><th>:</th><th>'.$message[2].'</th>
       </tr>

             <tr >            
                  <th COLSPAN=3><p class="text-center">Message</p></th>
       </tr>
             <tr>           
                  <th COLSPAN=3>'.nl2br($message[3]).'</th>
             </tr>
             <tr>           
                  <th COLSPAN=3></th>
             </tr>			 
        </table>
		
		
	
     <div class="form-group"   id="liste_mail_consigne">
    <label for="inputnamecost3" class="col-sm-2 control-label">Liste des Interventions</label>
    <div class="col-xs-8">
			<div class="input-group">
    <select class="form-control" id="id_intrevention" >';
    echo get_select_liste_intervention($id_mail);
    echo '</select>
        <span class="input-group-btn">
        <button  onClick="javascript:ajouter_intrevention_consigne(\''.$id_mail.'\')"   class="btn btn-success" type="button">+</button>
		</span> 
			</div>
          <div id="liste_mail_consigne2">';
    echo     get_id_mail_intervention($id_mail)	;
    echo '</div>      
	</div>
	
    </div>
	
	
	
      </div>
	  </div>
 </div>
</div>';
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_information_email_consigne($id_mail)
{
    $connexion=ma_db_connexion();
    $SQL="SELECT `id_mail`, `adresse_mail_aa`, `adresse_mail_cc`, `corps_messagerie`, `id_user`
	FROM `new_mail_messagerie` 
	WHERE `id_mail` = '".mysqli_real_escape_string($connexion,$id_mail)."'";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");

    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 33333335:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 33333335 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $name_poste= $row["id_user"]   ;
                $de=$row["id_mail"];
                $mail_aa=$row["adresse_mail_aa"];
                $mail_cc=$row["adresse_mail_cc"] ;
                $message=$row["corps_messagerie"];
                $id_user=$row["id_user"];
            }
            return  array($de,$mail_aa,$mail_cc,$message,$id_user);
        }
        else
        {
            return  array('','','','','');
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_liste_intervention($idmail)
{
    $connexion=ma_db_connexion();

    $SQL = "SELECT `id_intevention`,`libelle_intevention` FROM `new_action_intervention` 
	WHERE `id_intevention` 
	NOT IN ( SELECT `id_intevention` 
	FROM `new_mail_action_intevention`
	WHERE `id_mail` ='".mysqli_real_escape_string($connexion,$idmail)."')
	ORDER BY `id_intevention`";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 33333336:  ".$SQL."  " .mysqli_error($connexion));
        die('ERREUR QUERY 33333336 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["id_intevention"].'">'.$row["libelle_intevention"].'</option>';
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);




}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_mail_intervention($idmail)
{

    $connexion=ma_db_connexion();
    $SQL = "SELECT `id_intevention` FROM `new_mail_action_intevention` WHERE `id_mail`  = '".mysqli_real_escape_string($connexion,$idmail)."'";

    echo '<table class="table table-striped">
      <tr>
      <th>#</th>
      <th>Libelle Intervention</th>
      <th></th>
      
      </tr>';

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 33333337:  ".$SQL."  " .mysqli_error($connexion));
        die('ERREUR QUERY 33333337 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<tr>
                    <td>'.$idmail.'</td>
                    <td>'.get_lebelle_intervention($row["id_intevention"]).'</td>
                    <td>
                    <a href="javascript:suppimer_mail_consigne(\''.$idmail.'\',\''.$row["id_intevention"].'\')"><span class="fa fa-times"></a>
                    </td>
                </tr>  ';
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

    echo ' </table>';

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_lebelle_intervention($id_intevention)
{
    $libelle_intevention="";
    $connexion=ma_db_connexion();
    $SQL = "SELECT `libelle_intevention` FROM   `new_action_intervention`
    WHERE `id_intevention`=".mysqli_real_escape_string($connexion,$id_intevention)."";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 33333338:  ".$SQL."  " .mysqli_error($connexion));
        die('ERREUR QUERY 33333338 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $libelle_intevention=$row["libelle_intevention"];
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return $libelle_intevention;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function suppimer_mail_consigne($id_mail, $id_intrevention)
{
    $connexion=ma_db_connexion();
    $sql = "DELETE FROM `new_mail_action_intevention` WHERE `id_mail` = '".mysqli_real_escape_string($connexion,$id_mail)."' AND `id_intevention`  =  '".mysqli_real_escape_string($connexion,$id_intrevention)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 33333339:  ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 33333339 !');
    }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_mail_intervention2($id_mail)
{
    echo '
    <label for="inputnamecost3" class="col-sm-2 control-label">Liste des Interventions</label>
    <div class="col-xs-8">
			<div class="input-group">
    <select class="form-control" id="id_intrevention" >';
    echo get_select_liste_intervention($id_mail);
    echo '</select>
        <span class="input-group-btn">
        <button  onClick="javascript:ajouter_intrevention_consigne(\''.$id_mail.'\')"   class="btn btn-success" type="button">+</button>
		</span> 
			</div>
          <div id="liste_mail_consigne2">';
    echo     get_id_mail_intervention($id_mail)	;
    echo '</div>      
	</div>';
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function ajouter_intrevention_consigne($id_intervention, $id_mail)
{
    $connexion=ma_db_connexion();
    $SQL = "SELECT `id_intevention`,`id_mail` FROM `new_mail_action_intevention` 
	WHERE `id_intevention`  =  '".mysqli_real_escape_string($connexion,$id_intervention)."'
	AND `id_mail` = '".mysqli_real_escape_string($connexion,$id_mail)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 33333340:  ".$SQL."  " .mysqli_error($connexion));
        die('ERREUR QUERY 33333340 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)==0)
        {
            $sql_isert = "INSERT INTO `new_mail_action_intevention` (`id_aim` ,`id_intevention` ,`id_mail`)
			VALUES ('', '".mysqli_real_escape_string($connexion,$id_intervention)."',  '".mysqli_real_escape_string($connexion,$id_mail)."');";
            $result_isert=mysqli_query($connexion,$sql_isert);
            if (!$result_isert)
            {
                error_log("Erreur SQL 33333341:  ".$sql_isert."  ".mysqli_error($connexion));
                die('ERREUR QUERY 33333341 !');
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_libelle_groupe2($id)
{
    $connexion=ma_db_connexion();
    $code_group="";
    $SQL = "SELECT  `code_group` FROM  `new_list_gab` 	WHERE   `new_list_gab`.`terminal`  LIKE '".mysqli_real_escape_string($connexion,$id)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 33333342:  ".$SQL."  " .mysqli_error($connexion));
        die('ERREUR QUERY 33333342 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)==0)
        {
            $row = mysqli_fetch_assoc($result);
            $code_group=TRIM($row["code_group"]);
        }
    }
 return $code_group;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_mail_prestataire_declarer($id_gab,$motif,$date_arret,$id_intervention)
{

    if(get_id_gestionnaire($id_gab)==9)// verifer AGENCE/GF BCC
    {
        if ($motif<>6)
        {
            get_email_incident_gab1($id_gab,$motif,$date_arret,$id_intervention,get_libelle_prestataire_gab(1));
        }//Manque de fond
        get_email_incident_gab($id_gab,$motif,$date_arret,$id_intervention,get_libelle_prestataire_gab(2));
    }
    else
    {
        //var_dump("id gab :$id_gab");
//if(get_libelle_prestataire_gab(get_id_gestionnaire($id_gab))=='AGENCE')//AGENCE
        $gestionnaire=get_libelle_prestataire_gab(get_id_gestionnaire($id_gab));
        get_email_incident_gab($id_gab,$motif,$date_arret,$id_intervention,$gestionnaire);
    }
    //EURAFRIC INFORMATION  7
    echo "<br>";
   // get_mail_nouveau_appel7($id_gab,$motif,$date_prise,$id_intervention,get_gestionnaire_gab2(7));
    // DMG  8
   // get_mail_nouveau_appel8($id_gab,$motif,$date_prise,$id_intervention,get_gestionnaire_gab2(8));

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_email_incident_gab1($id_gab,$motif,$date_intervention,$id_intervention,$gestionnaire)
{
    $codeAgence=get_cd_agence($id_gab);
	
    $astreinteGAB=getContactGABAstreinte($codeAgence,$gestionnaire);
    $astreinteGAB2=getContactGABAstreinte2($codeAgence,$gestionnaire);
    $mail=get_verif_mail_incident_gab($id_intervention,$id_gab,$gestionnaire);
    echo '
<form class="form-horizontal" role="form">
<table class="table  table-striped" style="border-left: 2px solid #cecece;;border-right: 2px solid #cecece;;border-top: 2px solid #cecece;border-bottom: 2px solid #cecece;font-family:  Calibri, serif;font-size:14px;font-weight:bold;">
<tr><th colspan="2">
<strong>';
    echo $gestionnaire;
    echo'</strong>
</th>
</tr>
<tr><th colspan="2">
<strong>
<p style="margin-left: 30px;"> AA :  '; if($gestionnaire<>"AGENCE"){echo get_aa_email_gab($id_gab);}else{echo get_aa_email_gab1($id_gab);}echo '</p>
<p style="margin-left: 30px;"> CC :  '; if($gestionnaire<>"AGENCE"){echo get_cc_email_gab($id_gab);}else{echo get_cc_email_gab1($id_gab);}echo '</p>
<p style="margin-left: 310px;"> GAB : '. get_return_nom_gab_declarer($id_gab).'</p>
</strong>
<div id="code11">
<strong>';
    $selec='Selected';
    $genr_mail='Generate mail';
    if($_SESSION['lang']=='fr')
    {
        $selec='Sélectionné';
        $genr_mail='Générer mail';
    }
    $message=str_replace("num_terminal",$id_gab,$mail[2]);
    $message=str_replace("nom_terminal",get_return_nom_gab_declarer($id_gab),$message);
    $message=str_replace("num_banque",get_return_nom_banque_abi2($id_gab),$message);
    $message=str_replace("nom_filiale",get_nom_filiale(get_id_code_filiale($id_gab)),$message);
    $message=str_replace("date_iertvention",$date_intervention,$message);
    $message=str_replace("num_serie",get_return_num_serie($id_gab),$message);
    $message=str_replace("responsableGAB",$astreinteGAB2,$message);
    $message=str_replace("remarque","",$message);
// $message=str_replace("date_iertvention",date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))),$message);
    $message=str_replace("motif_iertvention",get_lebelle_declaration($motif),$message);
    echo '
<p style="margin-left: 20px;">'.nl2br($message).'</p>
';
    echo '
</strong>
</th>
</tr><tr>
<th><a onClick="javascript:Select_code(\'code11\');" class="btn btn-info btn-xs btn-block"> '.$selec.'</a></th>
<th>';
//get_return_id_prestataire($id_incident)
    $message=html_entity_decode_outlouk($message);
    if($gestionnaire<>"AGENCE")// verifer AGENCE/GF BCC
    {
        $a_mail=get_aa_email_gab($id_gab);
        $cc_mail=get_cc_email_gab($id_gab);
    }
    else
    {
        $a_mail=get_aa_email_gab1($id_gab);
        $cc_mail=get_cc_email_gab1($id_gab);
    }
    $de_mail="Supervision.GAB@bmcebank.co.ma";


    $bcc="";

    $obj=str_replace("num_terminal",$id_gab,$mail[3]);
    $obj=str_replace("nom_filiale",get_nom_filiale(get_id_code_filiale($id_gab)),$obj);
    $obj=str_replace("nom_terminal",get_return_nom_gab_declarer($id_gab),$obj)." ".get_return_libelle_groupe($id_gab)." ".get_return_libelle_groupe2($id_gab);
    $obj=str_replace("responsable_gab",$astreinteGAB,$obj);

    ?>
    <a  class="btn btn-success btn-xs btn-block" href="mailto:<?php echo $a_mail;?>
				 ?From=<?php echo $de_mail;?>
				 &cc=<?php echo $cc_mail;?><?php echo $bcc;?>
				 &subject=<?php echo $obj?>
				 &body=<?php echo  ($message);?>">
        <?php echo $genr_mail;?></a>
    <?php
    echo '</th>
</tr>
</table>
</form>
';
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_email_incident_gab($id_gab,$motif,$date_intervention,$id_intervention,$gestionnaire)
{
    $codeAgence=get_cd_agence($id_gab);
    $astreinteGAB=getContactGABAstreinte($codeAgence,$gestionnaire);
    $astreinteGAB2=getContactGABAstreinte2($codeAgence,$gestionnaire);
    $mail=get_verif_mail_incident_gab($id_intervention,$id_gab,$gestionnaire);

	if ($motif == '425' || $motif == '427' ||$motif == '424' ||$motif == '426' ||$motif == '375' ||$motif == '374' )
    {
        $id_intervention = 9 ;
    }
	else if ($motif == '434' || $motif == '436' || $motif == '438' || $motif == '448')
    {
        $id_intervention = 10 ;
    }
    else
    {
        $id_intervention = 2 ;
    }
    $message=str_replace("num_terminal",$id_gab,$mail[2]);
    $message=str_replace("nom_terminal",get_return_nom_gab_declarer($id_gab),$message);
    $message=str_replace("num_banque",get_return_nom_banque_abi2($id_gab),$message);
    $message=str_replace("nom_filiale",get_nom_filiale(get_id_code_filiale($id_gab)),$message);
    $message=str_replace("date_iertvention",$date_intervention,$message);
    $message=str_replace("num_serie",get_return_num_serie($id_gab),$message);
    $message=str_replace("responsableGAB",$astreinteGAB2,$message);
    $message=str_replace("remarque","",$message);
// $message=str_replace("date_iertvention",date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))),$message);
    $message=str_replace("motif_iertvention",get_lebelle_declaration($motif),$message);

    $selec='Selected';
    $genr_mail='Generate mail';
    if($_SESSION['lang']=='fr')
    {
        $selec='Sélectionné';
        $genr_mail='Générer mail';
    }
    echo '<form class="form-horizontal" role="form">
		<div class="form-group">
		    <div class="card" style="background-color:#e9ecef;color:#2b3449;">
                <div class="card-header">
                 <span class="c-icon cil-envelope-open float-right"></span>
                    <p> AA :  '; if($gestionnaire<>"AGENCE"){echo get_aa_email_gab($id_intervention);}else{echo get_aa_email_gab($id_intervention);}echo '</p>
                    <p> CC :  '; if($gestionnaire<>"AGENCE"){echo get_cc_email_gab2($id_intervention);}else{echoget_cc_email_gab2($id_intervention);}echo '</p>
                    <p> GAB : '. get_return_nom_gab_declarer($id_gab).'</p>
                    <p> OBJET : '.get_return_nom_gab_declarer($id_gab).' - '.$id_gab.'</p>
  
                </div>
                <div class="card-body">
                <div id="code1">
                <p style="margin-left: 14px;font-family: Calibri;font-size: small;font-weight:normal;">'.nl2br($message).'</p>
                </div>
              
                </div>
                <div class="card-footer">
                <a onClick="javascript:Select_code(\'code1\');" class="btn btn-info btn-xs btn-block"> '.$selec.'</a>';
                $message=html_entity_decode_outlouk($message);
                if($gestionnaire<>"AGENCE")// verifer AGENCE/GF BCC
                {
                    $a_mail=get_aa_email_gab($id_intervention);;
                    $cc_mail=get_cc_email_gab2($id_intervention);
                }
                else
                {
                    $a_mail=get_aa_email_gab($id_intervention);;
                    $cc_mail=get_cc_email_gab2($id_intervention);
                }
                $de_mail="Supervision.GAB@bmcebank.co.ma";


                $bcc="";

                $obj=str_replace("num_terminal",$id_gab,$mail[3]);
                $obj=str_replace("nom_filiale",get_nom_filiale(get_id_code_filiale($id_gab)),$obj);
                $obj=str_replace("nom_terminal",get_return_nom_gab_declarer($id_gab),$obj)." ".get_return_libelle_groupe($id_gab)." ".get_return_libelle_groupe2($id_gab);
                $obj=str_replace("responsable_gab",$astreinteGAB,$obj);
                ?>
                <a  class="btn btn-success btn-xs btn-block" href="mailto:<?php echo $a_mail;?>
				 ?From=<?php echo $de_mail;?>
				 &cc=<?php echo $cc_mail;?><?php echo $bcc;?>
				 &subject=<?php echo $obj?>

				 &body=<?php echo  ($message);?>">
                <?php echo $genr_mail;?></a>
                <?php
                echo '</div>
            </div>
        </div>
	</form>';
                
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getdeatil_per($id_tam)
{
    include "languages/" . $_SESSION['lang'] . ".php";
    $connexion=ma_db_connexion();
    $sqlG = "SELECT list_atm_confirmed.`id_atm`
    FROM `list_atm_confirmed` 
    WHERE list_atm_confirmed.state=1 AND list_atm_confirmed.`terminal` = '".$id_tam."'";

    $resultG=mysqli_query($connexion,$sqlG);
    if (!$resultG)
    {
        error_log("Erreur SQL 9999:  ".$sqlG."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 9999 !');
    }
    if ($resultG)
    {
        if(mysqli_num_rows($resultG)>0)
        {
            while ($rowG = mysqli_fetch_assoc($resultG))
            {
                //////***************************************************************************************************/////
                //////***********************************Vacation*********************************************//////
                $sql = "SELECT `id_vacation_ALM`, `id_vacation_BCR`, `id_vacation_CAM`, `id_vacation_CDM`, 
                `id_vacation_CEU`, `id_vacation_CHK`, `id_vacation_CIM`, `id_vacation_CRD`, 
                `id_vacation_DEP`, `id_vacation_IDC`, `id_vacation_IPM`, `id_vacation_PIN`, 
                `id_vacation_PTR`, `id_vacation_SIU`, `id_vacation_TTU`, `id_vacation_VDM`, `vacation_date`, `name_file`						
                FROM  `hist_vacations`	WHERE `hist_vacations`.`id_atm` ='".mysqli_real_escape_string($connexion,$rowG["id_atm"])."'  
                AND if_load=1
                ORDER BY `id_global_vacation` DESC
                LIMIT 1";


                $result=mysqli_query($connexion,$sql);
                if (!$result)
                {
                    error_log("Erreur SQL 99991:  ".$sql."  " .mysqli_error($connexion));
                    die(' ERREUR QUERY 99991 !');
                }
                if ($result)
                {

                    if (mysqli_num_rows($result)>0)
                    {
                        while ($row = mysqli_fetch_assoc($result))
                        {
                            $state_btn = 'btn-warning';
                            if(get_device_status($rowG["id_atm"],$row["vacation_date"]))
                            {
                                $state_btn = 'btn-info';
                            }
                                /*******************Statut périphérique**************************************************************************************/

                                echo '
                        <div class="btn-group" > 
                            <button class="btn '.$state_btn.' dropdown-toggle" id="btnGroupVerticalDrop1" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="cil-airplay"></i>
                            </button>
                           <ul class="dropdown-menu">
                                <li >
                                    <div class="btn-group"> ';
                            $idprivilege = 0;
                            $paramettre = 1;
                            $date_debut="";
                            $date_fin="";
                            $historique_vacation="";
                            $service = 4;
                            //if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CDM"],'vacations_CDM','xfs_errors_CDM','CDM',$row["vacation_date"],'WFS_INF_CDM_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                            }
                            $service = 7;
                            //if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CIM"],'vacations_CIM','xfs_errors_CIM','CIM',$row["vacation_date"],'WFS_INF_CIM_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                            }
                            $service = 12;
                            //if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_PIN"],'vacations_PIN','xfs_errors_PIN','PIN',$row["vacation_date"],'WFS_INF_PIN_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                            }
                            $service = 13;
                            //if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_PTR"],'vacations_PTR','xfs_errors_PTR','PTR',$row["vacation_date"],'WFS_INF_PTR_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                            }
                            $service = 10;
                            //if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_IDC"],'vacations_IDC','xfs_errors_IDC','IDC',$row["vacation_date"],'WFS_INF_IDC_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                            }

                            /*******************************DASHBOARD*********************************/
                            $varcolor=getColorDashboard($rowG["id_atm"]) ;
                            if($varcolor != "#888683")
                            {
                                echo '<a class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                    onClick="javascript:getDashboardATM(\''.$rowG["id_atm"].'\')" 
                                    data-target="#moduleDashboardATM"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-2x" title="CPU,RAM"></i></strong></a> ';
                            }
                            else
                            {
                                echo '<a class="text-center dropdown-item " tabindex="-1"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-2x" title="CPU,RAM"></i></strong></a>';
                            }

                            /*******************************Journal*********************************/

                            echo '<a class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                    onClick="javascript:getjournalATM(\'' . $rowG["id_atm"] . '\',\'' . $id_tam . '\')"    
                                    data-target="#detailjournalATM"> <strong style="color:#52c322" ><i class="fa fa-newspaper-o fa-2x" title="E-J "> </i></strong></a>';

                            /*******************************Historique CMD*********************************/

                            echo '<a  tabindex="-1" class="text-center dropdown-item " data-toggle="modal"  title="'.$lang["cmd_hist"].'"
                                    onClick="javascript:getcommandeATM(\'' . $rowG["id_atm"] . '\',\'' . $id_tam . '\',\''.$idprivilege.'\')"
                                    data-target="#detailcommandeATM"> <strong style="color:#52c322" >
                                    <svg class="icon x128" height="30" width="30" >
                                        <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-monitor"></use>
                                    </svg>
                                  </strong>
                            </a>';


                            /*******************************Redémarrer*********************************/
                            $paramettre=1;
                            $date_debut="";
                            $date_fin="";
                            $historique_vacation="";
                            $idprivilege=0;
                            echo '<a class="text-center dropdown-item " title="'.$lang["reboot"].'" tabindex="-1"  data-toggle="modal"
                             onclick="javascript:getRedemarrerATM(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')" 
                             data-target="#detailRedemarrerATM" aria-pressed="true">
                              <svg class="icon x128" height="30" width="30" style="color:#52c322">
                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-power-standby"></use>
                            </svg>
                            </a>';

                            /*******************************Capture écran *********************************/

                            echo '<a tabindex="-1" class="text-center dropdown-item" title="'.$lang["screenshot"].'" data-toggle="modal"
                            onclick="javascript:getScreenshotATM(\''.$rowG["id_atm"].'\')"
                            data-target="#detailScreenshotATM"><strong style="color:#52c322">
                            
                            <svg class="icon x128" height="30" width="30">
                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-camera"></use>
                            </svg>
                                
                          </strong></a>';

                            /*******************************Déconnexion*********************************/

                            echo '<a class="text-center dropdown-item " title="'.$lang["det_con_gab"].'" tabindex="-1" data-toggle="modal" 
                                    onClick="javascript:getdeconATM(\'' . $rowG["id_atm"] . '\')"    
                                    data-target="#detaildeconATM"> <strong style="color:#52c322;">
                                    <svg class="icon x128" height="30" width="30">
                                        <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-link"></use>
                                    </svg>
                                 </strong></a>';
                                    
                            /*******************************Historique vacations*********************************/
                            echo '<a title="'.$lang['dev_stat_hist'].'" class="text-center dropdown-item " href="detailVacation.php?idATM=' . $rowG["id_atm"] . '&amp;date_vacation=" target="_blank"> <strong style="color:#52c322;">
                           <svg class="icon x128" height="30" width="30">
                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-devices"></use>
                            </svg>
                            
                            </strong></a>
                            
                            

                            </div>
                                </li>
                            </ul>
                        </div>';


                        }
                    }
                }
            }
        }
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_update_id_facturation2($id_facturation,$id)
{
    $connexion=ma_db_connexion();
    $sql1 = "UPDATE `new_incident_gab` SET `id_facturable`='".mysqli_real_escape_string($connexion,$id_facturation)."' WHERE `new_incident_gab`.`id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
   //var_dump($sql1);
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql1);
    if (!$result)
    {
        error_log("Erreur SQL F_T_000001:  ".$sql1."  ".mysqli_error($connexion));
        die('ERREUR QUERY F_T_000001 !');
    }

    $sql2 = "UPDATE `new_incident_gab_ouvert` SET `id_facturable`='".mysqli_real_escape_string($connexion,$id_facturation)."' WHERE `new_incident_gab_ouvert`.`id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
    //var_dump($sql2);

    $result1=mysqli_query($connexion,$sql2);
    if (!$result1)
    {
        error_log("Erreur SQL F_T_000002:  ".$sql2."  ".mysqli_error($connexion));
        die('ERREUR QUERY F_T_000002 !');
    }
    mysqli_close($connexion);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_moyen_dispo_gab($dated,$datef)
{
    include("pagination.php");
    $connexion=ma_db_connexion();
    $SQL="SELECT `id_terminal_xfs`,`terminal`,`nom_gab` FROM `new_list_gab` where `id_terminal_xfs` IS NOT NULL ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");

    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        die("Erreur SQL 000001:  ".$SQL."  " .mysqli_error($connexion));
    }
    if ($result)
    {

        $id_atm =array();

        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_atm[]=[$row["id_terminal_xfs"],$row["terminal"],$row["nom_gab"]];

            }
        }
        mysqli_free_result($result);
    }
    $g =0;
    foreach ($id_atm as $item)
    {
        $g++;
        echo '<tr style="padding: 3px">';
        echo '<td class="text-center">' . $g . '</td>';
        echo '<td class="text-center">' . $item[1] . ' </td>';
        echo '<td class="text-center">' . $item[2] . ' </td>';
        echo '<td class="text-center">' . get_moyen_dispo_gab_retraite($item[0],1,$dated,$datef). '</td>';
        echo '<td class="text-center">' . get_moyen_dispo_gab_retraite($item[0],2,$dated,$datef) . '</td>';
        echo '<td class="text-center">' . get_moyen_dispo_gab_retraite($item[0],3,$dated,$datef) . '</td>';
        echo '</td>';

    }

    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_moyen_dispo_gab_retraite($id_atm,$type_transaction,$dated,$datef)
{
    if(empty($dated))
    {
        $dated=date('Y-m-d');
    }
    if(empty($datef))
    {
        $datef=date('Y-m-d');
    }

    $connexion=ma_db_connexion();
    $date_today = date('Y-m-d');
    $SQL1 ="SELECT `dateligne` FROM `journal_contents_ncr`
    WHERE `type_transaction` = '".mysqli_real_escape_string($connexion,$type_transaction)."' AND `id_atm` = '".mysqli_real_escape_string($connexion,$id_atm)."' AND `dateligne` between '".mysqli_real_escape_string($connexion,$dated)."%' and '".mysqli_real_escape_string($connexion,$datef)."%'";

    //var_dump($SQL1."<br>");
    $result1=mysqli_query($connexion,$SQL1);
    if (!$result1)
    {
        die("Erreur SQL 000002:  ".$SQL1."  " .mysqli_error($connexion));
    }
    if ($result1)
    {
        $i=0;
        $somdiffe=0;
        $moyen=0;
        //var_dump(mysqli_num_rows($result1));
        if(mysqli_num_rows($result1)>0)
        {

            while ($data = mysqli_fetch_assoc($result1))
            {

                $first_date = strtotime($data['dateligne']);
                if ($i<>0)
                {
                    $first_date = strtotime($data['dateligne']);
                    $diffe = abs($first_date_2 - $first_date);
                    $second = $diffe % 60;
                    //var_dump("Date def -- ".$second ."<br> ");
                    $diffe = floor( ($diffe - $second) /60 );

                    //$minute = $diffe % 60;
                    //var_dump("Date def -- ".$minute ."<br> ");
                    //echo"id_atm : ".$item." -- dateligne : ".$data["dateligne"] ." -- Date def MIN : ".$diffe ."<br> ";
                    $somdiffe=$somdiffe+$diffe;
                }

                $first_date_2=$first_date;
                $i++;
            }
        }
        mysqli_free_result($result1);
    }
    if($somdiffe<>0 && $i <> 0)
    {
        //echo"nombre de ligne : ".$i."<br>";
        $i=$i-1;
        $moyen=($somdiffe/$i);
        $moyen = number_format($moyen, 2, ',', ' ');
    }
    mysqli_close($connexion);
    return $moyen;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_state_incident($id_incident)
{
    $connexion=ma_db_connexion();
    $SQL="UPDATE `screenshot_images` SET `state_incident`= 1 
    WHERE `id_image` in (".mysqli_real_escape_string($connexion,$id_incident).") ";
    //var_dump($SQL);die();
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur sql 00000005:  ".$SQL."   ".mysqli_error($connexion));
        die('ERREUR QUERY 00000005 !');
    }
    mysqli_close($connexion);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_screen_incident($id_atm,$id_incident)
{
    $state=0;
    $connexion=ma_db_connexion();
    $SQL="SELECT `id_image`, `id_atm` FROM `screenshot_images`
    WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$id_atm)."'
    AND `id_image` in (".mysqli_real_escape_string($connexion,$id_incident).")";

    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur sql 00000006:  ".$SQL."   ".mysqli_error($connexion));
        die('ERREUR QUERY 00000006 !');
    }
    if($result)
    {
        if(mysqli_num_rows($result)==0)
        {
            $state=1;
        }
        else
        {
            $state=0;
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return $state;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_scren_del($value_cmd)
{
    $connexion=ma_db_connexion();

    $stat=0;
    $SQL = "SELECT `id_image` FROM `screenshot_images` WHERE `id_image` IN ('".$value_cmd."')";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 0000175:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 0000175 !');
    }
    if ($result)
    {
        if (mysqli_num_rows($result) > 0)
        {
            $stat=1;
        }
        else
        {
            $stat=0;
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return $stat;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_last_con_atm($id_atm)
{
    $connexion=ma_db_connexion();
    $last_connexion="";
    $SQL="SELECT TIMESTAMPDIFF(SECOND ,last_connexion,now()) as last_connexion FROM list_atm_confirmed WHERE id_atm = '".mysqli_real_escape_string($connexion,$id_atm)."' ";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 0000176:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 0000176 !');
    }
    if ($result)
    {
        if (mysqli_num_rows($result) > 0)
        {
            while ($data = mysqli_fetch_assoc($result))
            {
                $last_connexion = $data['last_connexion'];
            }
        }

        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    $desconnected_time=secondsToWords($last_connexion);
    return $desconnected_time;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getdeconATM($id_atm)
{
    include "../languages/" . $_SESSION['lang'] . ".php";

    $last_con_atm=get_last_con_atm($id_atm);
    $val=get_name_terminal_gag($id_atm);
    echo '<div class="modal-dialog modal-lg" role="document">
									
	<div  class="modal-content" style="background-color:#e9ecef;color:#2b3449;">					
	
	<!-- Modal Header -->
	
        <div class="modal-header">
            <h4 class="modal-title">'.$lang['det_con_gab'].' : '.$val[0].'  - '.$val[1].' </h4>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        </div>
        	<!-- Modal body -->
		<div class="modal-body">	
		    <form class="form-horizontal" role="form">
		    <div class="container col-md-12">
			
            <div class="table-responsive">				
                <table class="table table-bordered table-hover table-striped">
                    <thead class="thead-light">
                        <th>#</th>
                        <th>'.$lang['dat_con'].' </th>
                    </thead>';
                        getallconatm($id_atm);
                echo '</table>					
            </div>
				</div>	
		   </form> 
		</div>																																																					
		<!-- Modal footer -->
        <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
        </div>																																		
	</div>
</div>';

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function Affect_Incid($id_insert,$idMotifTraiter)
{
    $okMessage ="Mise à jour effectuée";
    $errorMessage = "Aucune mise à jour effectuée";

    $connexion=ma_db_connexion();
    $SQL = "UPDATE `atm_list_stopped_test` SET `id_incident` = '".mysqli_real_escape_string($connexion,$idMotifTraiter)."',
    `if_declared` = 1
    WHERE `id_insert`= '".mysqli_real_escape_string($connexion,$id_insert)."'";
    //var_dump($SQL);
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
	//$result=true;
    if ($result)
    {
        $responseArray = array('type' => 'success', 'message' => $okMessage);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => $errorMessage." \n Erreur QUERY 10050090");
        error_log("Erreur SQL 10050090:  ".$SQL."  ".mysqli_error($connexion));
    }
    mysqli_close($connexion);
    $encoded = json_encode($responseArray);
    header('Content-Type: application/json');
    echo $encoded;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getAffectIncid_gab_ouv($terminal,$id_insert,$id_atm)
{
    $val=get_name_terminal_gag($id_atm);
    echo '<div class="modal-dialog modal-lg">
	    <div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">	
		    <!-- Modal Header -->
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Affecter Incident GAB : '.$id_atm.' - '.$terminal.' - '.$val[1].' </h4>
            </div>
			<!-- Modal body -->
			<div class="modal-body">
			<div id="div_Affect_Incid">
                <form id="frm_Affect_Incid" class="form-horizontal" role="form">';
                $connexion=ma_db_connexion();
                $SQL="SELECT `new_incident_gab_ouvert`.`id_incident`,`new_action_intervention`.`libelle_intevention` FROM `new_incident_gab_ouvert`,`new_action_intervention`
                WHERE `new_incident_gab_ouvert`.`id_action_fonctionelle` = `new_action_intervention`.`id_intevention` 
                AND `new_incident_gab_ouvert`.`id_gab` = '".mysqli_real_escape_string($connexion,$terminal)."'";
                mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
                $result=mysqli_query($connexion,$SQL);
                if (!$result)
                {
                    error_log("Erreur SQL 014014013:  ".$SQL."  " .mysqli_error($connexion));
                    die('ERREUR QUERY 014014013 !');
                }

                $i=0;
                if ($result)
                {
                    if(mysqli_num_rows($result)>0)
                    {
                        while ($row = mysqli_fetch_assoc($result))
                        {
                            $tt= $i+1;
                            echo'
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="motifAffectIncid'.$id_atm.'"  id="motifAffectIncid'.$tt.''.$id_atm.'"  
                                    value="'. $row['id_incident'].'">
                                <label class="form-check-label" for="exampleRadios1">
                                '. $row['libelle_intevention'].' - '. $row['id_incident'].'
                                </label>	
                            </div>';
                            $i++;
                        }
                    }
                    mysqli_free_result($result);
                }
                mysqli_close($connexion);


                echo'								
                </form>
                </div>
			</div>
            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                <button id="btn_affec" type="button" onclick="javascript:Affect_Incid(\''.$id_atm.'\',\''.$id_insert.'\')" class="btn btn-default" >Valider</button>
            </div>
		</div>	
	</div>';
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getallconatm($id_atm)
{
    $connexion=ma_db_connexion();

    $SQL="SELECT `date_connect` FROM hist_connect WHERE id_atm = '".mysqli_real_escape_string($connexion,$id_atm)."' ORDER BY `id_con` DESC LIMIT 10 ";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 0000177:  ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 0000177 !');
    }
    if ($result)
    {
        if (mysqli_num_rows($result) > 0)
        {
            $g=1;
            while ($data = mysqli_fetch_assoc($result))
            {
                echo '<tr>
                    <td scope="row" style="padding: 3px">' . $g++ . '</td>       
                    <td scope="row" style="padding: 3px">' . $data['date_connect'] . '</td>       
                </tr>';
            }

        }

        mysqli_free_result($result);
    }
    mysqli_close($connexion);


}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

?>