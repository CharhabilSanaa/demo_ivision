<?php
include("connexion.php");
ma_db_connexion();
error_reporting(E_ALL);
ini_set('display_errors', '1');

$date_7= date("Y-m-d 00:00:00", strtotime("-7 day"));
$date_30= date("Y-m-d 00:00:00", strtotime("-30 day"));
$connexion=ma_db_connexion();
$SQL="DELETE FROM  `screenshot_images` WHERE `state_incident` = 0 and `date_insert` <= '".mysqli_real_escape_string($connexion,$date_7)."'";
$SQL2="DELETE FROM  `screenshot_images` WHERE `date_insert` <= '".mysqli_real_escape_string($connexion,$date_30)."'";

$result1=mysqli_query($connexion,$SQL);
if (!$result1)
{
    error_log("Erreur SQL TRT_00001:  ".$SQL."  ".mysqli_error($connexion));
    die('ERREUR QUERY TRT_00001 !');
}
if ($result1)
{
    echo "<strong >---> Suppression des captures D'une Semaine  </strong> <br>";
}

$result2=mysqli_query($connexion,$SQL2);
if (!$result2)
{
    error_log("Erreur SQL TRT_00002:  ".$SQL2."  ".mysqli_error($connexion));
    die('ERREUR QUERY TRT_00002 !');
}
if ($result2)
{
    echo "<strong >---> Suppression des captures D'un Mois  </strong> <br>";
}

mysqli_close($connexion);