<?php
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////////////////
function getVacationATM($id_atm,$paramettre,$idprivilege,$date_debut,$date_fin,$vacation_date)
{

													if((empty($date_debut))&&(empty($date_fin)))
													{$date_debut=$vacation_date;$date_fin=$vacation_date;}
													else{$date_debut=$date_debut;$date_fin=$date_fin;}
// id_atm,paramettre,idprivilege,date_debut,date_fin,vacation_date
	echo '
		
<div class="modal-dialog modal-lg " >
									 
	<div  class="modal-content" style="background-color:#e9ecef;color:#2b3449;">					
	
	<!-- Modal Header -->
		<div class="modal-header" style="background-color:#e7722c;font-size:18px;color:#fff;line-height: 80%;">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title">Historique vacation </h4>
		</div>	
										
																																				
												<!-- Modal body -->
												<div class="modal-body">	
													<form class="form-horizontal" role="form">
																			<div class="container col-md-12"">
																			  <div class="row">
																				<div class="col-md-6">
																					<div class="panel-group">
																						<div class="input-group date" id="datetimepicker6">
																							<input type="text"  id="datedebut'.$id_atm.'"  value="'.$date_debut.'"  class="form-control" placeholder="Date début" />
																							<span class="input-group-addon">
																								<span class="glyphicon glyphicon-calendar"></span>
																							</span>
																						</div>
																					</div>
																				</div>
																				<div class="col-md-6">
																					<div class="panel-group">
																						<div class="input-group date" id="datetimepicker7">
																							<input type="text"  id="datefin'.$id_atm.'"  value="'.$date_fin.'"  class="form-control" placeholder="Date fin" />
																							<span class="input-group-addon">
																								<span class="glyphicon glyphicon-calendar"></span>
																							</span>
																						</div>
																					</div>
																				 
																				</div>
																					<div class="modal-footer">														   																				
																						<button type="button" onClick="javascript:getVacationATM2(\''.$id_atm.'\',\''.$paramettre.'\',
																						\''.$idprivilege.'\',\''.$vacation_date.'\')" data-target="#detailVacationATM" class="btn btn-danger" >Recherche</button>
																					</div>
																			  </div>
																		</div>
															<div>';

																			getHistoriqueEtatParcATM($id_atm,1,1,$date_debut,$date_fin);
																			// getHistoriqueEtatParcATM($id_atm,$paramettre,$idprivilege,$date_debut,$date_fin,$vacation_date);
																			
																			echo'</div>
													</form> 
												</div>	
												<div id="detail_historique_vacation">
												</div>	
																			
																																																
																									<!-- Modal footer -->
						<div class="modal-footer">
								<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
						</div>													
																									
	</div>
</div>';
				
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function boolHistoriqueVacationGAB($service,$atm,$table,$cmd,$stat_verif,$categorie)
{


	$V=0;
	$V2=0;	


																foreach ($stat_verif as $id =>  $Etat)
																	{	
																	
																			// echo '<br>'.$Etat;																			
																if(is_array($Etat))
																			{
																				
																			$value_category="";
																			$category="";
																			}
																		else{  
																	// list($category1, $Etat_category) = explode('|',  $Etat);		
																	list($category, $value_category) = explode('-',  $Etat);
																	         }	
												
																// if (($category=='fwDevice') && 	($value_category==0) && (!empty($value_category))){$V2++;} //echo $category .'   -     '.$value_category.'<br>';	
																if (($category=='fwDevice') && 	($value_category==0) && ($value_category<>"")){$V2++;} //echo $category .'   -     '.$value_category.'<br>';	
																if (($category=='fwDevice') && 	($value_category<>0) && ($value_category<>"")){$V++;} 												
																			}
														

return 	array($V,$V2);			
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// $paramettre,$idprivilege,$id_atm,$id_vacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,1,$category,$code_error,$logical_name,$paramAffichage,$id_service,$id_logical_name
function getDetailHistotiquePeripheralStatus($paramettre,$idprivilege,$ATM,$ArrayEtatPeripheral,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage,$service,$id_logical_name)
	{
	

														foreach($ArrayEtatPeripheral as $cle2 => $valeur2) 
														{	 		 echo $ArrayEtatPeripheral."gggg";
															list($category1, $Etat_category) = explode('|',  $valeur2);		
															list($category, $value_category) = explode('-',  $Etat_category);	
														   // if ($category=="id_service")
														   {
															// $tableau_logical_autorise2=getListStatusLogicalNameATM($ATM,$value_category,$logical_name);															
															echo $ArrayEtatPeripheral." ============== ".$value_category.' -- '.$ATM.'<br>';
														   }
														}
	
	}

?>