<?php

DEFINE('HOST', '192.168.0.171');
DEFINE('USER', 'user_wallet');
DEFINE('PSWD', 'wallet!22@');
DEFINE('PORT', '4045');

DEFINE('DATABASE', 'demo_db_ivision_v2');
DEFINE('DATABASE_USER', 'iprc_authentification_boa');

/****/

  
?>