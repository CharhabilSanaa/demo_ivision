<?php
include("connexion.php");
ma_db_connexion();
/*error_reporting(E_ALL);
ini_set('display_errors', '1');*/
include("detailDeclarer.php");
include 'statusPeripheral.php';
include 'historiqueVacation.php';
include 'histDetailVacation.php';
include 'lib_backoffice.php';
include 'libAchraf.php';
include 'libKamar.php';

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_ip()
{
    if ( isset ( $_SERVER['HTTP_X_FORWARDED_FOR'] ) )
    {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    elseif ( isset ( $_SERVER['HTTP_CLIENT_IP'] ) )
    {
        $ip  = $_SERVER['HTTP_CLIENT_IP'];
    }
    else
    {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return htmlspecialchars(mysqli_real_escape_string(ma_db_connexion(),$ip));
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nouveau_appel_gab_erreur($incident,$incOpen)
{
    get_detail_nouveau_appel_gab($incident);
    $id_intervention=get_max_id_action_intervention($incident);
    $id_gab=get_id_gab_incident($incident);
    $motif=get_id_motif_incident($id_intervention);
    $act=get_array_information_action_intervention(($id_intervention));
    $gestionnaire=get_gestionnaire_gab2(get_id_gestionnaire_incident($id_gab));
    $type_gab=get_fournisseur(get_id_type_gab_incident($id_gab));
    $date_prise=gmdate("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y")));
    echo ' <div class="alert alert-danger" >
        <strong style="color:#b70101" >Attention!: Un incident est déjà ouvert pour ce Gab sous le numéro de dossier '.$incOpen.'</strong> 
    </div>

    <form class="form-horizontal" role="form">
	    <input  id="degre_declaration"  name="degre_declaration" type="hidden"   value="'.get_return_max_id_degre_appel($incident).'" class="form-control input-sm">
        <div  class="form-group">
        <label <for="input_terminal" style="text-align:left" class="col-sm-3 control-label">Motif</label>
		<div class="col-sm-9">';
    echo '<select style="font-size:10pt;font-weight:bold;color:#000;" '.enabling_button($incident,0).' 	class="form-control" id="id_motif_arret" required name="id_motif_arret" >';
    //get_select_return_motif_arret2($idcausearret);
    get_select_intervention_id($motif);
    get_all_select_return_motif_arret2();
    echo '</select>';

    echo '</div>
	</div>	';
    echo '<input  align="center"  id="txtnumaffectation" name="txtnumaffectation" type="hidden"   value="'.get_numero_affectation($incident).'"    class="form-control input-sm">';
    echo '

				
<div  class="form-group">
<label for="input_terminal" style="text-align:left" class="col-sm-3 control-label">Affectation</label>
				<div class="col-sm-9">';
    echo '<select  '.enabling_button($incident,0).' class="form-control" id="id_affectation"  name="id_affectation">';
    get_libelle_type_contact($act[3]);
    get_select_affectation($id_gab);
    // get_libelle_type_contact2();
    echo ' </select>		';
    echo '</div>
				</div>

<div  class="form-group">
<label for="input_id_etat" style="text-align:left" class="col-sm-3 control-label">Etat contact</label>
				<div class="col-sm-9">';
    echo '<select '.enabling_button($incident,0).' class="form-control" id="id_etat"  name="id_etat">';
    get_libelle_etat_contact($act[4]);
    get_libelle_etat_contact2();
    echo ' </select>		';
    echo '</div>
				</div>
				
<div  class="form-group">
<label for="input_terminal" style="text-align:left" class="col-sm-3 control-label">Date Prise en charge</label>
				<div class="col-sm-9">';
    echo '<input  '.enabling_button($incident,0).' align="center"  id="date_prise" name="date_prise" type="text"   value="'.$date_prise.'"    class="form-control input-sm">';
    echo '</div>
				</div>


<div  class="form-group">
<label for="input_terminal" style="text-align:left" class="col-sm-3 control-label">Durée Rappel</label>
				<div class="col-sm-9">';
    echo '    			<select '.enabling_button($incident,0).' class="form-control" id="id_rappel" required name="rappel" >';
    echo '    <option value='.get_return_durue_rappel_sla($act[3]).'>'.get_return_libelle_durue_rappel_sla($act[3]).'</option>';
    echo '  
											<option value="3600">1h</option>
										    <option value="5400">1h30</option>
											<option value="7200">2h</option>
											<option value="14400">4h</option>
											<option value="JO7">Jour ouvrable</option>
											<option value="86400">24h (1Jour)</option>
											<option value="172800">48h (2Jours)</option>
											<option value="259200">72h (3Jours)</option>					
											<option value="345600">96h (4Jours)</option>	
			    </select> ';


    // if (enabling_button($incident,0)=='disabled'){$etatActivation='disabled';}else $etatActivation='';


    echo '</div>
				</div>

				
<div  class="form-group">				
<label for="name_agence" class="col-sm-3 control-label"></label>
				<div class="col-sm-9">
				<button type="button" '.enabling_button($incident,0).' class="btn btn-info btn-xs btn-block" id="btn_nouv_appel" style="background-color:#3276b1" onClick="javascript:ajouter_nouvelle_appel2(\''.$incident.'\')"   >Nouveau Appel</button>
		  </div>
		</div>';

    if(get_id_gestionnaire($id_gab)==9)// verifer AGENCE/GF BCC
    {

        get_mail_nouveau_appel1($id_gab,$motif,$date_prise,$id_intervention,get_libelle_prestataire_gab(1));

        get_mail_nouveau_appel($id_gab,$motif,$date_prise,$id_intervention,get_libelle_prestataire_gab(2));

        get_mail_nouveau_appel2($id_gab,$motif,$date_prise,$id_intervention,$type_gab);

    }
    else
    {
        get_mail_nouveau_appel($id_gab,$motif,$date_prise,$id_intervention,$gestionnaire);
        get_mail_nouveau_appel1($id_gab,$motif,$date_prise,$id_intervention,$type_gab);
    }
    //EURAFRIC INFORMATION  7
    echo "<br>";
    get_mail_nouveau_appel7($id_gab,$motif,$date_prise,$id_intervention,get_gestionnaire_gab2(7));
    // DMG  8
    get_mail_nouveau_appel8($id_gab,$motif,$date_prise,$id_intervention,get_gestionnaire_gab2(8));


    echo '</form>				
';
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function antixss($input)
{
    $new=strip_tags($input);
    $new1 = htmlspecialchars($new, ENT_QUOTES);
    $new = mysqli_real_escape_string(ma_db_connexion(),$new1);
    return $new;
}

function getlenght($keyword)
{
    return strlen($keyword);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function verif_habilitation($habilitation, $id_habilitation)
{
    if ($habilitation<>"")
    {
        for ($i=0; $i < count($habilitation) ; $i++)
        {
            if ($habilitation[$i]==$id_habilitation)
            {
                return true;
            }
        }
    }
    else
    {
        return false;
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function date_transaction($date_transac)
{
    $date_alerte=str_replace("   "," ",$date_transac);
    $date_alerte=str_replace("  "," ",$date_transac);
    list($date, $hour) = explode(' ', $date_alerte);
    $pos = stripos($date, "/");
    if ($pos !== false)
    {
        list($hh, $mn, $ss) = explode(':', $hour);
        list($jj, $mm, $aa) = explode('/', $date);
        return  date("Y-m-d H:i:s", mktime($hh, $mn, $ss,$mm,$jj,$aa));
    }
    else
    {
        return $date_transac;
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getReturnEtatPeripheral($tableVacation,$idATM,$peripheral,$idVacation,$histDateVacation,$histNameFile)
{
    $link = ma_db_connexion();
    $EtatVacation = array();
    SWITCH ($peripheral)
    {

        CASE 'ALM':

            $sql = "SELECT `date_vacation`, `vacations_ALM`.`fwDevice` AS Device, `vacations_ALM`.`bAlarmSet` AS AlarmSet, `vacations_ALM`.`wAntiFraudModule` AS AntiFraudModule, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name` 
					FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";
            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 200:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 200 !');
            }

            if ($result)
            {
                if (mysqli_num_rows($result)>0)
                {	$j=0;
                    while ($row = mysqli_fetch_assoc($result))
                    {
                        $EtatVacation[$j] =  array("date_vacation-".$row["date_vacation"],
                            "fwDevice-".$row["Device"],"bAlarmSet-".$row["AlarmSet"],
                            "wAntiFraudModule-".$row["AntiFraudModule"],"logical_name-".$row["logical_name"]);
                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] =  array("date_vacation-","fwDevice-","bAlarmSet-","wAntiFraudModule-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link,$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;

            BREAK;

        CASE 'BCR':

            $sql = "SELECT `date_vacation`, `vacations_BCR`.`fwDevice` as Device, `vacations_BCR`.`fwBCRScanner` as BCRScanner, `vacations_BCR`.`dwGuidLights` as GuidLights, `vacations_BCR`.`dwGuidLights_WFS_BCR_GUIDANCE_BCR` as GuidLights_WFS_BCR_GUIDANCE_BCR,
							`vacations_BCR`.`wDevicePosition` as DevicePosition, `vacations_BCR`.`usPowerSaveRecoveryTime` as PowerSaveRecoveryTime, `vacations_BCR`.`wAntiFraudModule` as  AntiFraudModule, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name` 
							FROM `".mysqli_real_escape_string($link,$tableVacation)."`,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";
            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 201:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 201 !');
            }

            if ($result)
            {		$j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {

                        $EtatVacation[$j] =  array("date_vacation-".$row["date_vacation"],
                            "fwDevice-".$row["Device"],"fwBCRScanner-".$row["BCRScanner"],
                            "dwGuidLights-".$row["GuidLights"],"dwGuidLights_WFS_BCR_GUIDANCE_BCR-".$row["GuidLights_WFS_BCR_GUIDANCE_BCR"],
                            "wDevicePosition-".$row["DevicePosition"],
                            "usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTime"],"wAntiFraudModule-".$row["AntiFraudModule"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] =    array("date_vacation-","fwDevice-","fwBCRScanner-",
                        "dwGuidLights-","dwGuidLights_WFS_BCR_GUIDANCE_BCR-","wDevicePosition-",
                        "usPowerSaveRecoveryTime-","wAntiFraudModule-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link,$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;

            BREAK;

        CASE 'CAM':

            $sql = "SELECT `date_vacation`, `vacations_CAM`.`fwDevice` as Device, `vacations_CAM`.`fwMedia_WFS_CAM_ROOM` as Media_WFS_CAM_ROOM, `vacations_CAM`.`fwMedia_WFS_CAM_PERSON` as Media_WFS_CAM_PERSON, 
            `vacations_CAM`.`fwMedia_WFS_CAM_EXITSLOT` as Media_WFS_CAM_EXITSLOT, `vacations_CAM`.`usPictures` as Pictures, `vacations_CAM`.`wAntiFraudModule` as AntiFraudModule, `vacations_CAM`.`fwCameras_WFS_CAM_ROOM` as Cameras_WFS_CAM_ROOM, 
            `vacations_CAM`.`fwCameras_WFS_CAM_PERSON` as Cameras_WFS_CAM_PERSON, `vacations_CAM`.`fwCameras_WFS_CAM_EXITSLOT` as Cameras_WFS_CAM_EXITSLOT, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name` 
            FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
            
            WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
            AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
            AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
            AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
            AND `atm_logical_names`.`state` = 1";
            // if ($_SESSION['id_utilisateur']==46){echo $sql;}
            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 203:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 203 !');
            }

            if ($result)
            {		$j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {

                        $EtatVacation[$j] =  array("date_vacation-".$row["date_vacation"],"fwDevice-".$row["Device"],"fwMedia_WFS_CAM_ROOM-".$row["Media_WFS_CAM_ROOM"],
                            "fwMedia_WFS_CAM_PERSON-".$row["Media_WFS_CAM_PERSON"],"fwMedia_WFS_CAM_EXITSLOT-".$row["Media_WFS_CAM_EXITSLOT"],"usPictures-".$row["Pictures"],
                            "wAntiFraudModule-".$row["AntiFraudModule"],"fwCameras_WFS_CAM_ROOM-".$row["Cameras_WFS_CAM_ROOM"],"fwCameras_WFS_CAM_PERSON-".$row["Cameras_WFS_CAM_PERSON"],
                            "fwCameras_WFS_CAM_EXITSLOT-".$row["Cameras_WFS_CAM_EXITSLOT"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);
                        $j++;

                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] =  array("date_vacation-","fwDevice-","fwMedia_WFS_CAM_ROOM-",
                        "fwMedia_WFS_CAM_PERSON-","fwMedia_WFS_CAM_EXITSLOT-","usPictures-",
                        "wAntiFraudModule-","fwCameras_WFS_CAM_ROOM-","fwCameras_WFS_CAM_PERSON-",
                        "fwCameras_WFS_CAM_EXITSLOT-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link,$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;

            BREAK;

        CASE 'CDM':

            $sql = "SELECT `date_vacation` , `vacations_CDM`.`fwDevice` AS DeviceCDM, `vacations_CDM`.`fwSafeDoor` AS SafeDoorCDM, `vacations_CDM`.`fwDispenser` AS DispenserCDM,
                    `vacations_CDM`.`fwIntermediateStacker` AS IntermediateStackerCDM, `vacations_CDM`.`fwPosition` AS PositionCDM, `vacations_CDM`.`fwPositionStatus` AS PositionStatusCDM, 
                    `vacations_CDM`.`fwShutter` AS ShutterCDM, `vacations_CDM`.`fwTransport` AS TransportCDM, `vacations_CDM`.`fwTransportStatus` AS TransportStatusCDM, 
                    `vacations_CDM`.`fwJammedShutterPosition` AS JammedShutterPositionCDM, `vacations_CDM`.`dwGuidLights` AS GuidLightsCDM,
                    `vacations_CDM`.`wDevicePosition` AS DevicePositionCDM, `vacations_CDM`.`usPowerSaveRecoveryTime` AS PowerSaveRecoveryTimeCDM, `vacations_CDM`.`id_vacation` AS vacationCDM, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name` 
                    FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";

           // echo $sql;
            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 204:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 204 !');
            }
            if ($result)
            {		$j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {

                        $EtatVacation[$j] =  array("date_vacation-".$row["date_vacation"],"fwDevice-".$row["DeviceCDM"],"fwSafeDoor-".$row["SafeDoorCDM"],
                            "fwDispenser-".$row["DispenserCDM"],"fwIntermediateStacker-".$row["IntermediateStackerCDM"],
                            "fwPosition-".$row["PositionCDM"],
                            "fwPositionStatus -".$row["PositionStatusCDM"],"fwShutter-".$row["ShutterCDM"],
                            "fwTransport -".$row["TransportCDM"],"fwTransportStatus-".$row["TransportStatusCDM"],
                            "fwJammedShutterPosition -".$row["JammedShutterPositionCDM"],"dwGuidLights-".$row["GuidLightsCDM"],
                            "wDevicePosition -".$row["DevicePositionCDM"],"usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTimeCDM"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] = array("date_vacation-","fwDevice-","fwSafeDoor-",
                        "fwDispenser-","fwIntermediateStacker-",
                        "fwPosition-",
                        "fwPositionStatus -","fwShutter-",
                        "fwTransport -","fwTransportStatus-",
                        "fwJammedShutterPosition -","dwGuidLights-",
                        "wDevicePosition -","usPowerSaveRecoveryTime-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link,$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;
            BREAK;

        CASE 'CDM2':

            $sql = "SELECT `id_vacation_logical`, `jLoop`, `usNumber`, `usType`, `cUnitID`, `cCurrencyID`, `ulValues`,`ulValues`*`ulCount` as montant,
								`ulInitialCount`, `ulCount`, `ulRejectCount`, `ulMinimum`, `bAppLock`, `usStatus`, `ulDispensedCount`, `ulPresentedCount`, `ulRetractedCount`,
								`usNumPhysicalCUs`,`vacations_CDM`.`fwDevice`
								FROM `vacations_CDM_cash_unit_logical` ,vacations_CDM,`atm_logical_names` 
								
								WHERE `atm_logical_names`.`id_logical_name` = `vacations_CDM`.`id_logical_name`
								AND vacations_CDM_cash_unit_logical.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
								AND vacations_CDM_cash_unit_logical.id_vacation= vacations_CDM.id_vacation
								AND `usType`=3 
								AND `atm_logical_names`.`state` = 1
								AND `vacations_CDM`.`fwDevice` <>3";

            //var_dump($sql);die();
            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 205:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 205 !');
            }

            if ($result)
            {		$j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {


                        $EtatVacation[$j] = array("fwDevice-".$row["fwDevice"],"jLoop-".$row["jLoop"],"usNumber-".$row["usNumber"],
                            "cUnitID-".$row["cUnitID"],
                            "cCurrencyID-".$row["cCurrencyID"],"ulValues-".$row["ulValues"],
                            "ulInitialCount-".$row["ulInitialCount"],"ulCount-".$row["ulCount"],
                            "Reject Count|ulRejectCount-".$row["ulRejectCount"],"ulMinimum-".$row["ulMinimum"],
                            "bAppLock-".$row["bAppLock"],"usStatus-".$row["usStatus"],
                            "ulDispensedCount-".$row["ulDispensedCount"],"ulPresentedCount-".$row["ulPresentedCount"],
                            "ulRetractedCount-".$row["ulRetractedCount"],"usNumPhysicalCUs-".$row["usNumPhysicalCUs"],
                            "montant-".$row["montant"],"id_service-4");

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] = array("jLoop-","usNumber-",
                        "cUnitID-",
                        "cCurrencyID-","ulValues-",
                        "ulInitialCount-","ulCount-",
                        "Reject Count|ulRejectCount-","ulMinimum-",
                        "bAppLock-","usStatus-",
                        "ulDispensedCount-","ulPresentedCount-",
                        "ulRetractedCount-","usNumPhysicalCUs-",
                        "montant-","id_service-4");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link,$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;
            BREAK;

        CASE 'CEU':

            $sql = "SELECT `date_vacation`, `vacations_CEU`.`fwDevice` as Device, `vacations_CEU`.`fwMedia` as Media, `vacations_CEU`.`fwRetainBin` as RetainBin,
						`vacations_CEU`.`fwOutputBin` as OutputBin, `vacations_CEU`.`fwInputBin` as InputBin, `vacations_CEU`.`usTotalCards` as TotalCards, `vacations_CEU`.`usOutputCards` as OutputCards, `vacations_CEU`.`usRetainCards` as RetainCards,
						`vacations_CEU`.`wDevicePosition` as DevicePosition, `vacations_CEU`.`usPowerSaveRecoveryTime` as PowerSaveRecoveryTime, `vacations_CEU`.`wToner` as Toner, 
						`vacations_CEU`.`wAntiFraudModule` as AntiFraudModule, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name` 
							FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";

            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 206:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 206 !');
            }

            if ($result)
            {		$j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {

                        $EtatVacation[$j] =   array("date_vacation-".$row["date_vacation"],"fwDevice-".$row["Device"],"fwMedia-".$row["Media"],
                            "fwRetainBin-".$row["RetainBin"],"fwOutputBin-".$row["OutputBin"],"fwInputBin-".$row["InputBin"],
                            "usTotalCards-".$row["TotalCards"],"usOutputCards-".$row["OutputCards"],"usRetainCards-".$row["RetainCards"],
                            "wDevicePosition-".$row["DevicePosition"],"usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTime"],"wToner-".$row["Toner"],"wAntiFraudModule-".$row["AntiFraudModule"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] =   array("date_vacation-","fwDevice-","fwMedia-",
                        "fwRetainBin-","fwOutputBin-","fwInputBin-",
                        "usTotalCards-","usOutputCards-","usRetainCards-",
                        "wDevicePosition-","usPowerSaveRecoveryTime-","wToner-","wAntiFraudModule-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link(),$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;
            BREAK;

        CASE 'CHK':

            $sql = "SELECT `date_vacation`, `fwDevice` AS DeviceCHK , `fwMedia` AS MediaCHK , 
					       `fwInk` AS InkCHK , `dwGuidLights` AS GuidLightsCHK , `dwGuidLights_WFS_CHK_GUIDANCE_CHECKUNIT` AS GuidLights_WFS_CHK_GUIDANCE_CHECKUNITCHK , 
						   `usPowerSaveRecoveryTime` AS PowerSaveRecoveryTimeCHK , `wAntiFraudModule`  AS AntiFraudModuleCHK, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name` 
							FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";

            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 207:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 207 !');
            }
            if ($result)
            {		$j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {

                        $EtatVacation[$j] =    array("date_vacation-".$row["date_vacation"],"fwDevice-".$row["DeviceCHK"],"fwMedia-".$row["MediaCHK"],
                            "fwInk-".$row["InkCHK"],"dwGuidLights-".$row["GuidLightsCHK"],"dwGuidLights_WFS_CHK_GUIDANCE_CHECKUNIT-".$row["GuidLights_WFS_CHK_GUIDANCE_CHECKUNITCHK"],
                            "usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTimeCHK"],"wAntiFraudModule-".$row["AntiFraudModuleCHK"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] =    array("date_vacation-","fwDevice-","fwMedia-",
                        "fwInk-","dwGuidLights-","dwGuidLights_WFS_CHK_GUIDANCE_CHECKUNIT-",
                        "usPowerSaveRecoveryTime-","wAntiFraudModule-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link(),$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;
            BREAK;

        CASE 'CIM':

            $sql = "SELECT `vacations_CIM`.`date_vacation` , `vacations_CIM`.`fwDevice` as DeviceCIM, `vacations_CIM`.`fwSafeDoor` as SafeDoorCIM, `vacations_CIM`.`fwAcceptor` as AcceptorCIM, `vacations_CIM`.`fwIntermediateStacker` as IntermediateStackerCIM, 
							`vacations_CIM`.`fwStackerItems` as StackerItemsCIM, `vacations_CIM`.`fwBanknoteReader` as BanknoteReaderCIM, `vacations_CIM`.`bDropBox` as DropBoxCIM, `vacations_CIM`.`fwPosition` as PositionCIM,
							 `vacations_CIM`.`fwShutter` as ShutterCIM, `vacations_CIM`.`fwPositionStatus` as PositionStatusCIM, `vacations_CIM`.`fwTransport` as TransportCIM, `vacations_CIM`.`fwTransportStatus` as TransportStatusCIM, 
							 `vacations_CIM`.`fwJammedShutterPosition` as JammedShutterPositionCIM, `vacations_CIM`.`dwGuidLights` as GuidLightsCIM, `vacations_CIM`.`wDevicePosition` as DevicePositionCIM, 
							 `vacations_CIM`.`usPowerSaveRecoveryTime` as PowerSaveRecoveryTimeCIM, `wMixedMode` as MixedModeCIM, `vacations_CIM`.`wAntiFraudModule`  as AntiFraudModuleCIM, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name` 
							FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";
            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 208:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 208 !');
            }
            if ($result)
            {		$j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {

                        $EtatVacation[$j] =    array("date_vacation-".$row["date_vacation"],"fwDevice-".$row["DeviceCIM"],"fwSafeDoor-".$row["SafeDoorCIM"],
                            "fwAcceptor-".$row["AcceptorCIM"],"fwIntermediateStacker-".$row["IntermediateStackerCIM"],"fwStackerItems-".$row["StackerItemsCIM"],
                            "fwBanknoteReader-".$row["BanknoteReaderCIM"],"bDropBox-".$row["DropBoxCIM"],"fwPosition-".$row["PositionCIM"],
                            "fwShutter-".$row["ShutterCIM"],"fwPositionStatus-".$row["PositionStatusCIM"],"fwTransport-".$row["TransportCIM"],"fwTransportStatus-".$row["TransportStatusCIM"],
                            "fwJammedShutterPosition-".$row["JammedShutterPositionCIM"],"dwGuidLights-".$row["GuidLightsCIM"],"wDevicePosition-".$row["DevicePositionCIM"],
                            "usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTimeCIM"],"wMixedMode-".$row["MixedModeCIM"],"wAntiFraudModule-".$row["AntiFraudModuleCIM"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] =    array("date_vacation-","fwDevice-","fwSafeDoor-",
                        "fwAcceptor-","fwIntermediateStacker-","fwStackerItems-",
                        "fwBanknoteReader-","bDropBox-","fwPosition-",
                        "fwShutter-","fwPositionStatus-","fwTransport-","fwTransportStatus-",
                        "fwJammedShutterPosition-","dwGuidLights-","wDevicePosition-",
                        "usPowerSaveRecoveryTime-","wMixedMode-","wAntiFraudModule-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link(),$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;
            BREAK;

        CASE 'CIM2':


            $sql = "SELECT  `id_vacation_logical`, vacations_CIM_cash_unit_logical.`id_vacation`, `jLoop`, `usNumber`, vacations_CIM_cash_unit_logical.`fwType`, `fwItemType`, `cUnitID`, 
																		`cCurrencyID`, `ulValues`, `ulCashInCount`, `ulInitialCount`, `ulCount`, `ulMaximum`, `ulRejectCount`, `ulMinimum`, 
																		`bAppLock`, `usStatus`, `usCDMType`, `ulDispensedCount`, `ulPresentedCount`, `ulRetractedCount`, `usNumPhysicalCUs`, 
																		`lppPhysical`, `detailsPhysicalUnits`  ,`vacations_CIM`.`fwDevice`
																		FROM `vacations_CIM_cash_unit_logical`,`vacations_CIM` , `atm_logical_names`
																		WHERE `atm_logical_names`.`id_logical_name` = `vacations_CIM`.`id_logical_name` 
																		AND vacations_CIM_cash_unit_logical.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
																		AND vacations_CIM_cash_unit_logical.id_vacation = vacations_CIM.id_vacation
																		AND `vacations_CIM`.`fwDevice` <>3
																		AND `atm_logical_names`.`state` = 1";



            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 209:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 209 !'.mysqli_error($link));
            }

            if ($result)
            {		$j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {


                        $EtatVacation[$j] = array("fwDevice-".$row["fwDevice"],"jLoop-".$row["jLoop"],"usNumber-".$row["usNumber"],
                            "fwType-".$row["fwType"],"fwItemType-".$row["fwItemType"],
                            "cUnitID-".$row["cUnitID"],
                            "cCurrencyID-".$row["cCurrencyID"],"ulValues-".$row["ulValues"],
                            "ulCashInCount-".$row["ulCashInCount"],"ulInitialCount-".$row["ulInitialCount"],
                            "ulCount-".$row["ulCount"],"ulMaximum-".$row["ulMaximum"],
                            "ulRejectCount-".$row["ulRejectCount"],"ulMinimum-".$row["ulMinimum"],
                            "bAppLock-".$row["bAppLock"],"usStatus-".$row["usStatus"],
                            "usCDMType-".$row["usCDMType"],
                            "ulDispensedCount-".$row["ulDispensedCount"],"ulPresentedCount-".$row["ulPresentedCount"],
                            "ulRetractedCount-".$row["ulRetractedCount"],"usNumPhysicalCUs-".$row["usNumPhysicalCUs"],
                            "lppPhysical-".$row["lppPhysical"],"detailsPhysicalUnits-".$row["detailsPhysicalUnits"],"id_service-7");

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] = array("jLoop-","usNumber-",
                        "fwType-","fwItemType-",
                        "cUnitID-",
                        "cCurrencyID-","ulValues-",
                        "ulCashInCount-","ulInitialCount-",
                        "ulCount-","ulMaximum-",
                        "ulRejectCount-","ulMinimum-",
                        "bAppLock-","usStatus-",
                        "usCDMType-",
                        "ulDispensedCount-","ulPresentedCount-",
                        "ulRetractedCount-","usNumPhysicalCUs-",
                        "lppPhysical-","detailsPhysicalUnits-","id_service-7");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link(),$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;
            BREAK;

        CASE 'CRD':

            $sql = "SELECT `date_vacation`, `vacations_CRD`.`fwDevice` as DeviceCRD, `vacations_CRD`.`fwDispenser` as DispenserCRD, `logical_name`,
							`vacations_CRD`.`fwTransport` as TransportCRD, `vacations_CRD`.`fwMedia` as MediaCRD, `vacations_CRD`.`fwShutter` as ShutterCRD, 
							`vacations_CRD`.`dwGuidLights` as GuidLightsCRD, `vacations_CRD`.`dwGuidLights_WFS_CRD_GUIDANCE_CARDDISP` as GuidLights_WFS_CRD_GUIDANCE_CARDDISPCRD, `vacations_CRD`.`wDevicePosition` as DevicePositionCRD,
							`vacations_CRD`.`usPowerSaveRecoveryTime` as PowerSaveRecoveryTimeCRD, `vacations_CRD`.`wAntiFraudModule` as  AntiFraudModuleCRD, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name`  
							FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";
            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 210:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 210 !');
            }

            if ($result)
            {
                $j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {

                        $EtatVacation[$j] =   array("date_vacation-".$row["date_vacation"],"fwDevice-".$row["DeviceCRD"],"fwDispenser-".$row["DispenserCRD"],
                            "fwTransport-".$row["TransportCRD"],"fwMedia-".$row["MediaCRD"],"fwShutter-".$row["ShutterCRD"],
                            "dwGuidLights-".$row["GuidLightsCRD"],"dwGuidLights_WFS_CRD_GUIDANCE_CARDDISP-".$row["GuidLights_WFS_CRD_GUIDANCE_CARDDISPCRD"],"wDevicePosition-".$row["DevicePositionCRD"],
                            "usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTimeCRD"],"wAntiFraudModule-".$row["AntiFraudModuleCRD"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] =   array("date_vacation-","fwDevice-","fwDispenser-",
                        "fwTransport-","fwMedia-","fwShutter-",
                        "dwGuidLights-","dwGuidLights_WFS_CRD_GUIDANCE_CARDDISP-","wDevicePosition-",
                        "usPowerSaveRecoveryTime-","wAntiFraudModule-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link(),$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;
            BREAK;

        CASE 'DEP':

            $sql = "SELECT `date_vacation`, `vacations_DEP`.`fwDevice` AS DeviceDEP, `vacations_DEP`.`fwDepContainer` AS DepContainerDEP, 
							`vacations_DEP`.`fwDepTransport` AS DepTransportDEP, `vacations_DEP`.`fwEnvSupply` AS EnvSupplyDEP, `vacations_DEP`.`fwEnvDispenser` AS EnvDispenserDEP, 
							`vacations_DEP`.`fwShutter` AS ShutterDEP, `vacations_DEP`.`wNumOfDeposits` AS NumOfDepositsDEP, `vacations_DEP`.`dwGuidLights` AS GuidLightsDEP, 
							`vacations_DEP`.`dwGuidLights_WFS_DEP_GUIDANCE_ENVDEPOSITORY` AS GuidLights_WFS_DEP_GUIDANCE_ENVDEPOSITORYDEP, `vacations_DEP`.`dwGuidLights_WFS_DEP_GUIDANCE_ENVDISPENSER`  AS GuidLights_WFS_DEP_GUIDANCE_ENVDISPENSERDEP, `vacations_DEP`.`fwDepositLocation`  AS DepositLocationDEP, 
							`vacations_DEP`.`wDevicePosition`  AS DevicePositionDEP, `vacations_DEP`.`usPowerSaveRecoveryTime`  AS PowerSaveRecoveryTimeDEP, `vacations_DEP`.`wAntiFraudModule`  AS AntiFraudModuleDEP, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name`   
							FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";

            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 211:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 211 !');
            }

            if ($result)
            {		$j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {


                        $EtatVacation[$j] =   array("date_vacation-".$row["date_vacation"],"fwDevice-".$row["DeviceDEP"],"fwDepContainer-".$row["DepContainerDEP"],
                            "fwDepTransport-".$row["DepTransportDEP"],"fwEnvSupply-".$row["EnvSupplyDEP"],"fwEnvDispenser-".$row["EnvDispenserDEP"],
                            "fwShutter-".$row["ShutterDEP"],"wNumOfDeposits-".$row["NumOfDepositsDEP"],"dwGuidLights-".$row["GuidLightsDEP"],
                            "dwGuidLights_WFS_DEP_GUIDANCE_ENVDEPOSITORY-".$row["GuidLights_WFS_DEP_GUIDANCE_ENVDEPOSITORYDEP"],"dwGuidLights_WFS_DEP_GUIDANCE_ENVDISPENSER-".$row["GuidLights_WFS_DEP_GUIDANCE_ENVDISPENSERDEP"],"fwDepositLocation-".$row["DepositLocationDEP"],
                            "wDevicePosition-".$row["DevicePositionDEP"],"usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTimeDEP"],"wAntiFraudModule-".$row["AntiFraudModuleDEP"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] =   array("date_vacation-","fwDevice-","fwDepContainer-",
                        "fwDepTransport-","fwEnvSupply-","fwEnvDispenser-",
                        "fwShutter-","wNumOfDeposits-","dwGuidLights-",
                        "dwGuidLights_WFS_DEP_GUIDANCE_ENVDEPOSITORY-","dwGuidLights_WFS_DEP_GUIDANCE_ENVDISPENSER-","fwDepositLocation-",
                        "wDevicePosition-","usPowerSaveRecoveryTime-","wAntiFraudModule-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link(),$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;
            BREAK;



        CASE 'IDC':

            $sql = "SELECT `date_vacation` , `vacations_IDC`.`fwDevice` as DeviceIDC, `vacations_IDC`.`fwMedia` as MediaIDC,  `vacations_IDC`.`fwRetainBin` as RetainBinIDC,  `vacations_IDC`.`fwSecurity` as SecurityIDC, 
								`vacations_IDC`.`usCards` as CardsIDC, `vacations_IDC`.`fwChipPower` as ChipPowerIDC,  `vacations_IDC`.`dwGuidLights` as GuidLightsIDC,  `vacations_IDC`.`dwGuidLights_WFS_IDC_GUIDANCE_CARDUNIT` as GuidLights_WFS_IDC, 
								`vacations_IDC`.`fwChipModule` as ChipModuleIDC, `vacations_IDC`.`fwMagReadModule` as MagReadModuleIDC,  `vacations_IDC`.`fwMagWriteModule` as MagWriteModuleIDC,  `vacations_IDC`.`fwFrontImageModule` as FrontImageModuleIDC, 
								`vacations_IDC`.`fwBackImageModule` as BackImageModuleIDC, `vacations_IDC`.`wDevicePosition` as DevicePositionIDC,  `vacations_IDC`.`usPowerSaveRecoveryTime` as PowerSaveRecoveryTimeIDC,  `vacations_IDC`.`wAntiFraudModule` as AntiFraudModuleIDC, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name` 
							FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";

            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 212:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 212 !');
            }

            if ($result)
            {
                $j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {

                        $EtatVacation[$j] =    array("date_vacation-".$row["date_vacation"],"fwDevice-".$row["DeviceIDC"],"fwMedia-".$row["MediaIDC"],
                            "fwRetainBin-".$row["RetainBinIDC"],"fwSecurity-".$row["SecurityIDC"],
                            "usCards-".$row["CardsIDC"],"fwChipPower-".$row["ChipPowerIDC"],
                            "dwGuidLights-".$row["GuidLightsIDC"],"dwGuidLights_WFS_IDC_GUIDANCE_CARDUNIT-".$row["GuidLights_WFS_IDC"],
                            "fwChipModule-".$row["ChipModuleIDC"],"fwMagReadModule-".$row["MagReadModuleIDC"],
                            "fwMagWriteModule-".$row["MagWriteModuleIDC"],"fwFrontImageModule-".$row["FrontImageModuleIDC"],
                            "fwBackImageModule-".$row["BackImageModuleIDC"],"wDevicePosition-".$row["DevicePositionIDC"],
                            "usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTimeIDC"],"wAntiFraudModule-".$row["AntiFraudModuleIDC"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] =  array("date_vacation-","fwDevice-","fwMedia-",
                        "fwRetainBin-","fwSecurity-",
                        "usCards-","fwChipPower-",
                        "dwGuidLights-","dwGuidLights_WFS_IDC_GUIDANCE_CARDUNIT-",
                        "fwChipModule-","fwMagReadModule-",
                        "fwMagWriteModule-","fwFrontImageModule-",
                        "fwBackImageModule-","wDevicePosition-",
                        "usPowerSaveRecoveryTime-","wAntiFraudModule-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link(),$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;

            BREAK;


        CASE 'IPM':

            $sql = "SELECT `date_vacation`, `vacations_IPM`.`fwDevice` AS DeviceIPM, `vacations_IPM`.`wAcceptor` AS AcceptorIPM, 
							`vacations_IPM`.`wMedia` AS MediaIPM, `vacations_IPM`.`wToner` AS TonerIPM, `vacations_IPM`.`wInk` AS InkIPM, 
							`vacations_IPM`.`wFrontImageScanner` AS FrontImageScannerIPM, `vacations_IPM`.`wBackImageScanner` AS BackImageScannerIPM, `vacations_IPM`.`wMICRReader` AS MICRReaderIPM, 
							`vacations_IPM`.`wStacker` AS StackerIPM, `vacations_IPM`.`wReBuncher` AS ReBuncherIPM, `vacations_IPM`.`wMediaFeeder` AS MediaFeederIPM, `vacations_IPM`.`dwGuidLights` AS GuidLightsIPM, 
							`vacations_IPM`.`dwGuidLights_WFS_IPM_GUIDANCE_MEDIAIN` AS GuidLights_WFS_IPM_GUIDANCE_MEDIAINIPM, `vacations_IPM`.`dwGuidLights_WFS_IPM_GUIDANCE_MEDIAOUT` AS GuidLights_WFS_IPM_GUIDANCE_MEDIAOUTIPM, 
							`vacations_IPM`.`dwGuidLights_WFS_IPM_GUIDANCE_MEDIAREFUSED` AS GuidLights_WFS_IPM_GUIDANCE_MEDIAREFUSEDIPM, `vacations_IPM`.`wDevicePosition` AS DevicePositionIPM, 
							`vacations_IPM`.`wMixedMode` AS MixedModeIPM, `vacations_IPM`.`wAntiFraudModule` AS AntiFraudModuleIPM, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name` 
							FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";
            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 213:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 213 !');
            }

            if ($result)
            {		$j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {

                        $EtatVacation[$j] =  array("date_vacation-".$row["date_vacation"],"fwDevice-".$row["DeviceIPM"],"wAcceptor-".$row["AcceptorIPM"],
                            "wMedia-".$row["MediaIPM"],"wToner-".$row["TonerIPM"],"wInk-".$row["InkIPM"],
                            "wFrontImageScanner-".$row["FrontImageScannerIPM"],"wBackImageScanner-".$row["BackImageScannerIPM"],"wMICRReader-".$row["MICRReaderIPM"],
                            "wStacker-".$row["StackerIPM"],"wReBuncher-".$row["ReBuncherIPM"],"wMediaFeeder-".$row["MediaFeederIPM"],"dwGuidLights-".$row["GuidLightsIPM"],
                            "dwGuidLights_WFS_IPM_GUIDANCE_MEDIAIN-".$row["GuidLights_WFS_IPM_GUIDANCE_MEDIAINIPM"],"dwGuidLights_WFS_IPM_GUIDANCE_MEDIAOUT-".$row["GuidLights_WFS_IPM_GUIDANCE_MEDIAOUTIPM"],
                            "dwGuidLights_WFS_IPM_GUIDANCE_MEDIAREFUSED-".$row["GuidLights_WFS_IPM_GUIDANCE_MEDIAREFUSEDIPM"],"wDevicePosition-".$row["DevicePositionIPM"],
                            "wMixedMode-".$row["MixedModeIPM"],"wAntiFraudModule-".$row["AntiFraudModuleIPM"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0]  = array("date_vacation-","fwDevice-","wAcceptor-",
                        "wMedia-","wToner-","wInk-",
                        "wFrontImageScanner-","wBackImageScanner-","wMICRReader-",
                        "wStacker-","wReBuncher-","wMediaFeeder-","dwGuidLights-",
                        "dwGuidLights_WFS_IPM_GUIDANCE_MEDIAIN-","dwGuidLights_WFS_IPM_GUIDANCE_MEDIAOUT-",
                        "dwGuidLights_WFS_IPM_GUIDANCE_MEDIAREFUSED-","wDevicePosition-",
                        "wMixedMode-","wAntiFraudModule-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link(),$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;

            BREAK;

        CASE 'PTR':

            $sql = "SELECT `date_vacation` , `vacations_PTR`.`fwDevice` as DevicePTR, `vacations_PTR`.`fwMedia` as MediaPTR,  `vacations_PTR`.`usRetractCount` as RetractCountPTR,  `vacations_PTR`.`wRetractBin` as RetractBinPTR, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name` 
							FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";
            //var_dump($sql);
            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 214:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 214 !');
            }

            if ($result)
            {		$j=0;
                //var_dump(mysqli_num_rows($result));
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {


                        $EtatVacation[$j] =   array("date_vacation-".$row["date_vacation"],"fwDevice-".$row["DevicePTR"],"fwMedia-".$row["MediaPTR"],
                            "usRetractCount-".$row["RetractCountPTR"],"wRetractBin-".$row["RetractBinPTR"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] = array("date_vacation-","fwDevice-","fwMedia-","usRetractCount-","wRetractBin-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link(),$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))

            //var_dump($EtatVacation);
            return	 $EtatVacation;
            BREAK;

        CASE 'PIN':

            $sql = "SELECT `date_vacation` , `vacations_PIN`.`fwDevice` as DevicePIN, `vacations_PIN`.`fwEncStat` as EncStaPIN,  `vacations_PIN`.`dwGuidLights` as GuidLightsPIN,  `vacations_PIN`.`fwAutoBeepMode` as AutoBeepModePIN,
								`vacations_PIN`.`dwCertificateState` as CertificateStatePIN, `vacations_PIN`.`wDevicePosition` as DevicePositionPIN,  `vacations_PIN`.`usPowerSaveRecoveryTime` as PowerSaveRecoveryTimePIN,  `vacations_PIN`.`wAntiFraudModule` as AntiFraudModulePIN, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name` 
							FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";

            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 215:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 215 !');
            }

            if ($result)
            {		$j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {

                        $EtatVacation[$j] =   array("date_vacation-".$row["date_vacation"],"fwDevice-".$row["DevicePIN"],"fwEncStat-".$row["EncStaPIN"],
                            "dwGuidLights-".$row["GuidLightsPIN"],"fwAutoBeepMode-".$row["AutoBeepModePIN"],
                            "dwCertificateState-".$row["CertificateStatePIN"],"wDevicePosition-".$row["DevicePositionPIN"],
                            "usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTimePIN"],"wAntiFraudModule-".$row["AntiFraudModulePIN"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);
                        $j++;

                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] = array("date_vacation-","fwDevice-","fwEncStat-",
                        "dwGuidLights-","fwAutoBeepMode-",
                        "dwCertificateState-","wDevicePosition-",
                        "usPowerSaveRecoveryTime-","wAntiFraudModule-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link(),$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;
            BREAK;


        CASE 'SIU':

            $sql = "SELECT    `date_vacation` , `vacations_SIU`.`fwDevice` as DeviceSIU, `vacations_SIU`.`fwSensors_WFS_SIU_OPERATORSWITCH` as Sensors_WFS_SIU_OPERATORSWITCHSIU, 
							`vacations_SIU`.`fwSensors_WFS_SIU_TAMPER` as Sensors_WFS_SIU_TAMPERSIU, 
							`vacations_SIU`.`fwSensors_WFS_SIU_INTTAMPER` as Sensors_WFS_SIU_INTTAMPERSIU, `vacations_SIU`.`fwSensors_WFS_SIU_SEISMIC` as Sensors_WFS_SIU_SEISMICSIU, 
							`vacations_SIU`.`fwSensors_WFS_SIU_HEAT`  as Sensors_WFS_SIU_HEATSIU, `vacations_SIU`.`fwSensors_WFS_SIU_PROXIMITY` as Sensors_WFS_SIU_PROXIMITYSIU, 
							`vacations_SIU`.`fwSensors_WFS_SIU_AMBLIGHT`  as Sensors_WFS_SIU_AMBLIGHTSIU, `vacations_SIU`.`fwSensors_WFS_SIU_ENHANCEDAUDIO`  as Sensors_WFS_SIU_ENHANCEDAUDIOSIU, 
							`vacations_SIU`.`fwSensors_WFS_SIU_BOOT_SWITCH`  as Sensors_WFS_SIU_BOOT_SWITCHSIU, 
							`vacations_SIU`.`fwSensors_WFS_SIU_CONSUMER_DISPLAY`  as Sensors_WFS_SIU_CONSUMER_DISPLAYSIU, `vacations_SIU`.`fwSensors_WFS_SIU_OPERATOR_CALL_BUTTON`  as Sensors_WFS_SIU_OPERATOR_CALL_BUTTONSIU,
							`vacations_SIU`.`fwSensors_WFS_SIU_HANDSETSENSOR`  as Sensors_WFS_SIU_HANDSETSENSORSIU, 
							`vacations_SIU`.`fwSensors_WFS_SIU_GENERALINPUTPORT`  as Sensors_WFS_SIU_GENERALINPUTPORTSIU, `vacations_SIU`.`fwSensors_WFS_SIU_HEADSETMICROPHONE` as Sensors_WFS_SIU_HEADSETMICROPHONESIU, 
							`vacations_SIU`.`fwSensors_WFS_SIU_FASCIAMICROPHONE` as Sensors_WFS_SIU_FASCIAMICROPHONESIU, 
							`vacations_SIU`.`fwDoors_WFS_SIU_CABINET`  as Doors_WFS_SIU_CABINETSIU, `vacations_SIU`.`fwDoors_WFS_SIU_SAFE`  as Doors_WFS_SIU_SAFESIU, `vacations_SIU`.`fwDoors_WFS_SIU_VANDALSHIELD` as Doors_WFS_SIU_VANDALSHIELDSIU, 
							`vacations_SIU`.`fwDoors_WFS_SIU_CABINET_FRONT` as Doors_WFS_SIU_CABINET_FRONTSIU, 
							`vacations_SIU`.`fwDoors_WFS_SIU_CABINET_REAR`  as Doors_WFS_SIU_CABINET_REARSIU, `vacations_SIU`.`fwDoors_WFS_SIU_CABINET_LEFT`  as Doors_WFS_SIU_CABINET_LEFTSIU, 
							`vacations_SIU`.`fwDoors_WFS_SIU_CABINET_RIGHT` as Doors_WFS_SIU_CABINET_RIGHTSIU, 
							`vacations_SIU`.`fwIndicators_WFS_SIU_OPENCLOSE` as Indicators_WFS_SIU_OPENCLOSESIU, `vacations_SIU`.`fwIndicators_WFS_SIU_FASCIALIGHT` as Indicators_WFS_SIU_FASCIALIGHTSIU, 
							`vacations_SIU`.`fwIndicators_WFS_SIU_AUDIO`  as Indicators_WFS_SIU_AUDIOSIU, 
							`vacations_SIU`.`fwIndicators_WFS_SIU_HEATING` as Indicators_WFS_SIU_HEATINGSIU,  `vacations_SIU`.`fwIndicators_WFS_SIU_CONSUMER_DISPLAY_BACKLIGHT` as Indicators_WFS_SIU_CONSUMER_DISPLAY_BACKLIGHTSIU, 
							`vacations_SIU`.`fwIndicators_WFS_SIU_SIGNAGEDISPLAY` as Indicators_WFS_SIU_SIGNAGEDISPLAYSIU, 
							`vacations_SIU`.`fwIndicators_WFS_SIU_TRANSINDICATOR` as Indicators_WFS_SIU_TRANSINDICATORSIU,  `vacations_SIU`.`fwIndicators_WFS_SIU_GENERALOUTPUTPORT` as Indicators_WFS_SIU_GENERALOUTPUTPORTSIU, 
							`vacations_SIU`.`fwAuxiliaries_WFS_SIU_VOLUME` as Auxiliaries_WFS_SIU_VOLUMESIU, 
							`vacations_SIU`.`fwAuxiliaries_WFS_SIU_UPS` as Auxiliaries_WFS_SIU_UPSSIU,  `vacations_SIU`.`fwAuxiliaries_WFS_SIU_REMOTE_STATUS_MONITOR` as Auxiliaries_WFS_SIU_REMOTE_STATUS_MONITORSIU, 
							`vacations_SIU`.`fwAuxiliaries_WFS_SIU_AUDIBLE_ALARM` as Auxiliaries_WFS_SIU_AUDIBLE_ALARMSIU, 
							`vacations_SIU`.`fwAuxiliaries_WFS_SIU_ENHANCEDAUDIOCONTROL` as Auxiliaries_WFS_SIU_ENHANCEDAUDIOCONTROLSIU,  `vacations_SIU`.`fwAuxiliaries_WFS_SIU_ENHANCEDMICROPHONECONTROL` as Auxiliaries_WFS_SIU_ENHANCEDMICROPHONECONTROLSIU, 
							`vacations_SIU`.`fwAuxiliaries_WFS_SIU_MICROPHONEVOLUME` as Auxiliaries_WFS_SIU_MICROPHONEVOLUMESIU, `vacations_SIU`.`fwGuidLights_WFS_SIU_CARDUNIT` as GuidLights_WFS_SIU_CARDUNITSIU,  
							`vacations_SIU`.`fwGuidLights_WFS_SIU_PINPAD` as GuidLights_WFS_SIU_PINPADSIU,  
							`vacations_SIU`.`fwGuidLights_WFS_SIU_NOTESDISPENSER` as GuidLights_WFS_SIU_NOTESDISPENSERSIU,  `vacations_SIU`.`fwGuidLights_WFS_SIU_COINDISPENSER` as GuidLights_WFS_SIU_COINDISPENSERSIU,  
							`vacations_SIU`.`fwGuidLights_WFS_SIU_RECEIPTPRINTER` as GuidLights_WFS_SIU_RECEIPTPRINTERSIU,  
							`vacations_SIU`.`fwGuidLights_WFS_SIU_PASSBOOKPRINTER` as GuidLights_WFS_SIU_PASSBOOKPRINTERSIU,  `vacations_SIU`.`fwGuidLights_WFS_SIU_ENVDEPOSITORY` as GuidLights_WFS_SIU_ENVDEPOSITORYSIU,  
							`vacations_SIU`.`fwGuidLights_WFS_SIU_CHEQUEUNIT` as GuidLights_WFS_SIU_CHEQUEUNITSIU,
							`vacations_SIU`.`fwGuidLights_WFS_SIU_BILLACCEPTOR` as GuidLights_WFS_SIU_BILLACCEPTORSIU,  `vacations_SIU`.`fwGuidLights_WFS_SIU_ENVDISPENSER` as GuidLights_WFS_SIU_ENVDISPENSERSIU,
							`vacations_SIU`.`fwGuidLights_WFS_SIU_DOCUMENTPRINTER` as GuidLights_WFS_SIU_DOCUMENTPRINTERSIU,
							`vacations_SIU`.`fwGuidLights_WFS_SIU_COINACCEPTOR`as GuidLights_WFS_SIU_COINACCEPTORSIU, `vacations_SIU`.`fwGuidLights_WFS_SIU_SCANNER` as GuidLights_WFS_SIU_SCANNERSIU,
							`vacations_SIU`.`usPowerSaveRecoveryTime`  as PowerSaveRecoveryTimeSIU  , `vacations_SIU`.`wAntiFraudModule` as AntiFraudModuleSIU, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name`  
							FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";

            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 216:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 216 !');
            }

            if ($result)
            {		$j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {

                        $EtatVacation[$j] =   array("date_vacation-".$row["date_vacation"],"fwDevice-".$row["DeviceSIU"],"fwSensors_WFS_SIU_OPERATORSWITCH-".$row["Sensors_WFS_SIU_OPERATORSWITCHSIU"],
                            "fwSensors_WFS_SIU_TAMPER-".$row["Sensors_WFS_SIU_TAMPERSIU"],
                            "fwSensors_WFS_SIU_INTTAMPER-".$row["Sensors_WFS_SIU_INTTAMPERSIU"],"fwSensors_WFS_SIU_SEISMIC-".$row["Sensors_WFS_SIU_SEISMICSIU"],
                            "fwSensors_WFS_SIU_HEAT-".$row["Sensors_WFS_SIU_HEATSIU"],"fwSensors_WFS_SIU_PROXIMITY-".$row["Sensors_WFS_SIU_PROXIMITYSIU"],
                            "fwSensors_WFS_SIU_AMBLIGHT-".$row["Sensors_WFS_SIU_AMBLIGHTSIU"],"fwSensors_WFS_SIU_ENHANCEDAUDIO-".$row["Sensors_WFS_SIU_ENHANCEDAUDIOSIU"],
                            "fwSensors_WFS_SIU_BOOT_SWITCH-".$row["Sensors_WFS_SIU_BOOT_SWITCHSIU"],
                            "fwSensors_WFS_SIU_CONSUMER_DISPLAY-".$row["Sensors_WFS_SIU_CONSUMER_DISPLAYSIU"],"fwSensors_WFS_SIU_OPERATOR_CALL_BUTTON-".$row["Sensors_WFS_SIU_OPERATOR_CALL_BUTTONSIU"],
                            "fwSensors_WFS_SIU_HANDSETSENSOR-".$row["Sensors_WFS_SIU_HANDSETSENSORSIU"],
                            "fwSensors_WFS_SIU_GENERALINPUTPORT-".$row["Sensors_WFS_SIU_GENERALINPUTPORTSIU"],"fwSensors_WFS_SIU_HEADSETMICROPHONE-".$row["Sensors_WFS_SIU_HEADSETMICROPHONESIU"],
                            "fwSensors_WFS_SIU_FASCIAMICROPHONE-".$row["Sensors_WFS_SIU_FASCIAMICROPHONESIU"],
                            "fwDoors_WFS_SIU_CABINET-".$row["Doors_WFS_SIU_CABINETSIU"],"fwDoors_WFS_SIU_SAFE-".$row["Doors_WFS_SIU_SAFESIU"],"fwDoors_WFS_SIU_VANDALSHIELD-".$row["Doors_WFS_SIU_VANDALSHIELDSIU"],
                            "fwDoors_WFS_SIU_CABINET_FRONT-".$row["Doors_WFS_SIU_CABINET_FRONTSIU"],
                            "fwDoors_WFS_SIU_CABINET_REAR-".$row["Doors_WFS_SIU_CABINET_REARSIU"],"fwDoors_WFS_SIU_CABINET_LEFT-".$row["Doors_WFS_SIU_CABINET_LEFTSIU"],
                            "fwDoors_WFS_SIU_CABINET_RIGHT-".$row["Doors_WFS_SIU_CABINET_RIGHTSIU"],
                            "fwIndicators_WFS_SIU_OPENCLOSE-".$row["Indicators_WFS_SIU_OPENCLOSESIU"],"fwIndicators_WFS_SIU_FASCIALIGHT-".$row["Indicators_WFS_SIU_FASCIALIGHTSIU"],
                            "fwIndicators_WFS_SIU_AUDIO-".$row["Indicators_WFS_SIU_AUDIOSIU"],
                            "fwIndicators_WFS_SIU_HEATING-".$row["Indicators_WFS_SIU_HEATINGSIU"],"fwIndicators_WFS_SIU_CONSUMER_DISPLAY_BACKLIGHT-".$row["Indicators_WFS_SIU_CONSUMER_DISPLAY_BACKLIGHTSIU"],
                            "fwIndicators_WFS_SIU_SIGNAGEDISPLAY-".$row["Indicators_WFS_SIU_SIGNAGEDISPLAYSIU"],
                            "fwIndicators_WFS_SIU_TRANSINDICATOR-".$row["Indicators_WFS_SIU_TRANSINDICATORSIU"],"fwIndicators_WFS_SIU_GENERALOUTPUTPORT-".$row["Indicators_WFS_SIU_GENERALOUTPUTPORTSIU"],
                            "fwAuxiliaries_WFS_SIU_VOLUME-".$row["Auxiliaries_WFS_SIU_VOLUMESIU"],
                            "fwAuxiliaries_WFS_SIU_UPS-".$row["Auxiliaries_WFS_SIU_UPSSIU"],"fwAuxiliaries_WFS_SIU_REMOTE_STATUS_MONITOR-".$row["Auxiliaries_WFS_SIU_REMOTE_STATUS_MONITORSIU"],
                            "fwAuxiliaries_WFS_SIU_AUDIBLE_ALARM-".$row["Auxiliaries_WFS_SIU_AUDIBLE_ALARMSIU"],
                            "fwAuxiliaries_WFS_SIU_ENHANCEDAUDIOCONTROL-".$row["Auxiliaries_WFS_SIU_ENHANCEDAUDIOCONTROLSIU"],"fwAuxiliaries_WFS_SIU_ENHANCEDMICROPHONECONTROL-".$row["Auxiliaries_WFS_SIU_ENHANCEDMICROPHONECONTROLSIU"],
                            "fwAuxiliaries_WFS_SIU_MICROPHONEVOLUME-".$row["Auxiliaries_WFS_SIU_MICROPHONEVOLUMESIU"],"fwGuidLights_WFS_SIU_CARDUNIT-".$row["GuidLights_WFS_SIU_CARDUNITSIU"],
                            "fwGuidLights_WFS_SIU_PINPAD-".$row["GuidLights_WFS_SIU_PINPADSIU"],
                            "fwGuidLights_WFS_SIU_NOTESDISPENSER-".$row["GuidLights_WFS_SIU_NOTESDISPENSERSIU"],"fwGuidLights_WFS_SIU_COINDISPENSER-".$row["GuidLights_WFS_SIU_COINDISPENSERSIU"],
                            "fwGuidLights_WFS_SIU_RECEIPTPRINTER-".$row["GuidLights_WFS_SIU_RECEIPTPRINTERSIU"],
                            "fwGuidLights_WFS_SIU_PASSBOOKPRINTER-".$row["GuidLights_WFS_SIU_PASSBOOKPRINTERSIU"],"fwGuidLights_WFS_SIU_ENVDEPOSITORY-".$row["GuidLights_WFS_SIU_ENVDEPOSITORYSIU"],
                            "fwGuidLights_WFS_SIU_CHEQUEUNIT-".$row["GuidLights_WFS_SIU_CHEQUEUNITSIU"],
                            "fwGuidLights_WFS_SIU_BILLACCEPTOR-".$row["GuidLights_WFS_SIU_BILLACCEPTORSIU"],"fwGuidLights_WFS_SIU_ENVDISPENSER-".$row["GuidLights_WFS_SIU_ENVDISPENSERSIU"],
                            "fwGuidLights_WFS_SIU_DOCUMENTPRINTER-".$row["GuidLights_WFS_SIU_DOCUMENTPRINTERSIU"],
                            "fwGuidLights_WFS_SIU_COINACCEPTOR-".$row["GuidLights_WFS_SIU_COINACCEPTORSIU"],"fwGuidLights_WFS_SIU_SCANNER-".$row["GuidLights_WFS_SIU_SCANNERSIU"],
                            "usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTimeSIU"],"wAntiFraudModule-".$row["AntiFraudModuleSIU"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] =   array("date_vacation-","fwDevice-","fwSensors_WFS_SIU_OPERATORSWITCH-",
                        "fwSensors_WFS_SIU_TAMPER-",
                        "fwSensors_WFS_SIU_INTTAMPER-","fwSensors_WFS_SIU_SEISMIC-",
                        "fwSensors_WFS_SIU_HEAT-","fwSensors_WFS_SIU_PROXIMITY-",
                        "fwSensors_WFS_SIU_AMBLIGHT-","fwSensors_WFS_SIU_ENHANCEDAUDIO-",
                        "fwSensors_WFS_SIU_BOOT_SWITCH-",
                        "fwSensors_WFS_SIU_CONSUMER_DISPLAY-","fwSensors_WFS_SIU_OPERATOR_CALL_BUTTON-",
                        "fwSensors_WFS_SIU_HANDSETSENSOR-",
                        "fwSensors_WFS_SIU_GENERALINPUTPORT-","fwSensors_WFS_SIU_HEADSETMICROPHONE-",
                        "fwSensors_WFS_SIU_FASCIAMICROPHONE-",
                        "fwDoors_WFS_SIU_CABINET-","fwDoors_WFS_SIU_SAFE-","fwDoors_WFS_SIU_VANDALSHIELD-",
                        "fwDoors_WFS_SIU_CABINET_FRONT-",
                        "fwDoors_WFS_SIU_CABINET_REAR-","fwDoors_WFS_SIU_CABINET_LEFT-",
                        "fwDoors_WFS_SIU_CABINET_RIGHT-",
                        "fwIndicators_WFS_SIU_OPENCLOSE-","fwIndicators_WFS_SIU_FASCIALIGHT-",
                        "fwIndicators_WFS_SIU_AUDIO-",
                        "fwIndicators_WFS_SIU_HEATING-","fwIndicators_WFS_SIU_CONSUMER_DISPLAY_BACKLIGHT-",
                        "fwIndicators_WFS_SIU_SIGNAGEDISPLAY-",
                        "fwIndicators_WFS_SIU_TRANSINDICATOR-","fwIndicators_WFS_SIU_GENERALOUTPUTPORT-",
                        "fwAuxiliaries_WFS_SIU_VOLUME-",
                        "fwAuxiliaries_WFS_SIU_UPS-","fwAuxiliaries_WFS_SIU_REMOTE_STATUS_MONITOR-",
                        "fwAuxiliaries_WFS_SIU_AUDIBLE_ALARM-",
                        "fwAuxiliaries_WFS_SIU_ENHANCEDAUDIOCONTROL-","fwAuxiliaries_WFS_SIU_ENHANCEDMICROPHONECONTROL-",
                        "fwAuxiliaries_WFS_SIU_MICROPHONEVOLUME-","fwGuidLights_WFS_SIU_CARDUNIT-",
                        "fwGuidLights_WFS_SIU_PINPAD-",
                        "fwGuidLights_WFS_SIU_NOTESDISPENSER-","fwGuidLights_WFS_SIU_COINDISPENSER-",
                        "fwGuidLights_WFS_SIU_RECEIPTPRINTER-",
                        "fwGuidLights_WFS_SIU_PASSBOOKPRINTER-","fwGuidLights_WFS_SIU_ENVDEPOSITORY-",
                        "fwGuidLights_WFS_SIU_CHEQUEUNIT-",
                        "fwGuidLights_WFS_SIU_BILLACCEPTOR-","fwGuidLights_WFS_SIU_ENVDISPENSER-",
                        "fwGuidLights_WFS_SIU_DOCUMENTPRINTER-",
                        "fwGuidLights_WFS_SIU_COINACCEPTOR-","fwGuidLights_WFS_SIU_SCANNER-",
                        "usPowerSaveRecoveryTime-","wAntiFraudModule-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link(),$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;
            BREAK;



        CASE 'TTU':

            $sql = "SELECT `date_vacation`, `vacations_TTU`.`fwDevice` AS DeviceTTU, `vacations_TTU`.`wKeyboard` AS KeyboardIPM, `vacations_TTU`.`wKeylock` AS KeylockTTU, 
							`vacations_TTU`.`wLEDs` AS LEDsTTU, `vacations_TTU`.`wDisplaySizeX` AS DisplaySizeXTTU, `vacations_TTU`.`wDisplaySizeY` AS DisplaySizeYTTU, 
							`vacations_TTU`.`wDevicePosition` AS DevicePositionTTU, `vacations_TTU`.`usPowerSaveRecoveryTime` AS PowerSaveRecoveryTimeTTU, `vacations_TTU`.`wAntiFraudModule` AS AntiFraudModuleTTU, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name`  
							FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";

            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 217:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 217 !');
            }

            if ($result)
            {		$j=0;
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {

                        $EtatVacation[$j] =   array("date_vacation-".$row["date_vacation"],"fwDevice-".$row["DeviceTTU"],"wKeyboard-".$row["KeyboardIPM"],"wKeylock-".$row["KeylockTTU"],
                            "wLEDs-".$row["LEDsTTU"],"wDisplaySizeX-".$row["DisplaySizeXTTU"],"wDisplaySizeY-".$row["DisplaySizeYTTU"],
                            "wDevicePosition-".$row["DevicePositionTTU"],"usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTimeTTU"],"wAntiFraudModule-".$row["AntiFraudModuleTTU"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);
                        $j++;

                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] =   array("date_vacation-","fwDevice-","wKeyboard-","wKeylock-",
                        "wLEDs-","wDisplaySizeX-","wDisplaySizeY-",
                        "wDevicePosition-","usPowerSaveRecoveryTime-","wAntiFraudModule-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link(),$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;
            BREAK;


        CASE 'VDM':

            $sql = "SELECT `date_vacation`, `vacations_VDM`.`wDevice` AS DeviceVDM, `vacations_VDM`.`wService` AS ServiceVDM, `".mysqli_real_escape_string($link,$tableVacation)."`.`logical_name` 
							FROM `".mysqli_real_escape_string($link,$tableVacation)."` ,`atm_logical_names` 
                    
                    WHERE `atm_logical_names`.`id_logical_name` = `".mysqli_real_escape_string($link,$tableVacation)."`.`id_logical_name` 
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_atm` ='".mysqli_real_escape_string($link,$idATM)."'
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`id_vacation` IN(".mysqli_real_escape_string($link,$idVacation).")
                    AND `".mysqli_real_escape_string($link,$tableVacation)."`.`fwDevice` <> 3 
                    AND `atm_logical_names`.`state` = 1";
            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 218:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 218 !');
            }

            if ($result)
            {
                if (mysqli_num_rows($result)>0)
                {	$j=0;
                    while ($row = mysqli_fetch_assoc($result))
                    {


                        $EtatVacation[$j] =   array("date_vacation-".$row["date_vacation"],"wDevice-".$row["DeviceVDM"],"wService-".$row["ServiceVDM"],
                            "histDateVacation-".$histDateVacation,"histNameFile-".$histNameFile,"logical_name-".$row["logical_name"]);

                        $j++;
                    }//while ($row = mysqli_fetch_assoc($result))
                }//if (mysqli_num_rows($result)>0)
                else
                {
                    $EtatVacation[0] =   array("date_vacation-","wDevice-","wService-","histDateVacation-","histNameFile-","logical_name-");
                }
                mysqli_free_result($result);
            }	// if ($result=mysqli_query($link(),$sql) or die('Erreur   getReturnEtatPeripheral !<br>'.$sql.'<br>'.mysqli_error()))
            return	 $EtatVacation;

            BREAK;

    }
    mysqli_close($link);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




function countXFSErreur($erreur,$nameTable)
{
    $connexion=ma_db_connexion();
  $sql = "SELECT count(`id_error`) as nb_error FROM `".mysqli_real_escape_string($connexion,$nameTable)."`";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 219:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 219 !');
    }

    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return " ( ".$row["nb_error"]." : errors  ) ";		
					}
			}	
		else
			{
				return 0;
			}
mysqli_free_result($result);	
	}					
				mysqli_close($connexion);
					
}
///////////////////////////////////////////////	
function suiviIncidents($incident)
{
    $connexion=ma_db_connexion();

    if($incident=="")
			{
            $SQL = "SELECT `id_incident`, `id_terminal`, `vacation`, `xfs_error`, `xfs_status`, `category`, `code_error`, `date_vacation` FROM `declarer_incident` 
                    ORDER BY `id_incident` DESC";      
				$page = new Pagination($SQL, 12);
                $total = $page->getCount('Affichage des lignes  %d - %d  ( total  : %d )');
                $lien = $page->liens(5);
                $SQL1 = $page->req();
			}
			else
			{
            $SQL1 = "SELECT  `id_incident`, `id_terminal`, `vacation`, `xfs_error`, `xfs_status`, `category`, `code_error`, `date_vacation`
			FROM `declarer_incident` 
            WHERE   (		
                      trim(`id_incident`) like '".mysqli_real_escape_string($connexion,$incident)."' 	
					  OR  trim(`id_terminal`) like '".mysqli_real_escape_string($connexion,$incident)."' 	
					  OR  trim(`xfs_error`) like '".mysqli_real_escape_string($connexion,$incident)."' 	
					  OR UPPER(`code_error`) like '".mysqli_real_escape_string($connexion,$incident)."'
					)
                    
            ORDER BY `id_incident` DESC";    
// echo 	  $SQL1 ;		
  			
			}

    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 219:  ".$SQL1."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 219 !');
    }

    if ($result)
	{			
	echo '                   
			<div class="col-lg-12">	
			<!-- /.panel -->
                    <div class="panel panel-info">
                        <div class="panel-heading" style="background-color:#e7722c;font-size:18px;color:#fff;line-height: 80%;">
                            <i class="fa fa-refresh"></i> Suivi incidents
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
										
                                        <table class="table table-bordered table-hover table-striped">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Dossier</th>
                                                    <th>ATM</th>
                                                    <th>Vacation</th>
                                                    <th>xfs error</th>
                                                    <th>xfs status</th>
                                                    <th>Category</th>
                                                    <th>Code error</th>
                                                    <th>Date vacation</th>
                                                </tr>
                                            </thead>
                                            <tbody>';
									
									if(mysqli_num_rows($result)>0)
										{
										    $i = 1;
										while ($row = mysqli_fetch_assoc($result)) 
												{										
                                                     echo '   <tr>
                                                    <td>'.$i.'</td>
                                                    <td>'; echo $row["id_incident"];echo '</td>
                                                    <td>'; echo $row["id_terminal"];echo '</td>
                                                    <td>'; echo $row["vacation"];echo '</td>
                                                    <td>'; echo $row["xfs_error"];echo '</td>
                                                    <td>'; echo $row["xfs_status"];echo '</td>
                                                    <td>'; echo $row["category"];echo '</td>
                                                    <td>'; echo $row["code_error"];echo '</td>
                                                    <td>'; echo $row["date_vacation"];echo '</td>                                                    
													';
													// <td></td> 
													// <td>'.returnDateCloture(mysql_result($result,$i,'date_cloture')).'</td>
													// getActionReliser(mysql_result($result,$i,'id_alerte'));
													// <td>'.get_etat_type_blocage(mysql_result($result,$i,'id_type_blocage')).'</td>
													echo '                                                   
                                                    
                                                    <td>';
													if (verif_habilitation($_SESSION['habilitation_action'],3)==true){
													// echo ' <a  class="btn btn-danger btn-circle" title="Supprimer" href="javascript:suppimerAlerte(\''.mysql_result($result,$i,'id_alerte').'\')"><i class="fa fa-times" ></i></a>';
													}

													echo '</td>
                                                </tr>';
													$i++;
											}
										}
											
											
								if(($incident=="") )
													{  
													  
											echo'<tr><td colspan="11" align="center">';  
											 echo   '<ul class="pagination"><li>'.$lien.' </li></ul>';
											 echo   '<div class="alert" style="background-color:#fabf8f;font-size:18px;color:#fff;line-height: 80%;"><strong>'.$total.'</strong></div>';
														echo'</td></tr> ';
													}											
											
                                        echo '   </tbody>
                                        </table>											
											
											
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.col-lg-4 (nested) -->
                                <div class="col-lg-8">
                                    <div id="morris-bar-chart"></div>
                                </div>
                                <!-- /.col-lg-8 (nested) -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-8 -->

				';	
mysqli_free_result($result);	
	}
mysqli_close($connexion);
}
/***********************************************************************************************************************************************************************/
function XFSErreur($nbr,$erreur,$nameTable)
{
    $connexion=ma_db_connexion();
	echo '											 <div class="card z-depth-0 bordered">
													<div class="card-header" id="heading'.$erreur.'" style="background-color:#e7722c;">
													  <h5 class="mb-0">
														<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse'.$erreur.'"
														  aria-expanded="true" aria-controls="collapse'.$erreur.'" >
														  <strong style="font-size:14px;font-weight:bold;color:#FFFFFF;text-decoration:none" >'.$nbr.') xfs errors '.$erreur.' '.countXFSErreur($erreur,$nameTable).' </strong>
														  </button>
													  </h5>
													</div>
													<div id="collapse'.$erreur.'" class="collapse" aria-labelledby="heading'.$erreur.'" data-parent="#accordionExample275">
															<div class="card-body" style="padding-left: 50px;background-color:#f8f8f8;" >';
  

																		echo ' <div class="table-responsive">										
																					<table class="table table-bordered table-hover table-striped">
																						<thead>
																							<tr>
																								<th>#</th>
																								<th>CMD</th>
																								<th>CATEGORY</th>
																								<th>CODE ERROR</th>
																								<th>MESSAGE</th>
																							</tr>
																						</thead>
																						<tbody>';
																						
																	$sql = "SELECT `id_error`, `cmd`, `category`, `code_error`, `value`, `supervised`, `value_dec`, `message`, `stat_verif` FROM `".mysqli_real_escape_string($connexion,$nameTable)."`
																	ORDER BY `cmd`,`category` ASC";
                                                                            $result=mysqli_query($connexion,$sql);
                                                                            if (!$result)
                                                                            {
                                                                                error_log("Erreur SQL 220:  ".$sql."  " .mysqli_error($connexion));
                                                                                die(' ERREUR QUERY 220 !');
                                                                            }

                                                                            if ($result)
																			{	
																				if(mysqli_num_rows($result)>0)
																					{
                                                                                        $i = 1;
																					while ($row = mysqli_fetch_assoc($result)) 
																						{											
																					echo '   <tr>
																								<td>'.$i.'</td>
																								<td>'.$row["cmd"].'</td>
																								<td>'.$row["category"].'</td>
																								<td>'.$row["code_error"].'</td>
																								<td>'.substr($row["message"], 0, 30).' ...</td>
																							</tr>';
																					$i++;
																						}
																					}
																						mysqli_free_result($result);	
																				}
																		mysqli_close($connexion);
																					echo '</tbody>
																					</table>
																				</div>
													
															</div>
														</div>											
													</div>';		
		

}
///////////////////////////////////////////////
function suiviXFSErreur($erreur)
{				
echo '<div class="accordion" id="accordionExample275">';  
  XFSErreur(1,'ALM','xfs_errors_ALM');	
  XFSErreur(2,'BCR','xfs_errors_BCR');	
  XFSErreur(3,'CAM','xfs_errors_CAM');	
  XFSErreur(4,'CDM','xfs_errors_CDM');	
  XFSErreur(5,'CEU','xfs_errors_CEU');	
  XFSErreur(6,'CHK','xfs_errors_CHK');	
  XFSErreur(7,'CIM','xfs_errors_CIM');	
  XFSErreur(8,'CRD','xfs_errors_CRD');	
  XFSErreur(9,'DEP','xfs_errors_DEP');	
  XFSErreur(10,'IDC','xfs_errors_IDC');	
  XFSErreur(11,'IPM','xfs_errors_IPM');	
  XFSErreur(12,'PIN','xfs_errors_PIN');	
  XFSErreur(13,'PTR','xfs_errors_PTR');	
  XFSErreur(14,'SIU','xfs_errors_SIU');	
  XFSErreur(15,'TTU','xfs_errors_TTU');	
  XFSErreur(16,'VDM','xfs_errors_VDM');	
echo '</div>';
}
///////////////////////////////////////////////	
function suiviService($alerte)
{
    $connexion=ma_db_connexion();

    if($alerte=="")
			{
            $SQL = "SELECT `id_service`, `service` FROM `list_service` ORDER BY `service` DESC";      
				$page = new Pagination($SQL, 12);
                $total = $page->getCount('Affichage des lignes  %d - %d  ( total  : %d )');
                $lien = $page->liens(5);
                $SQL1 = $page->req();
 
			}
			else
			{
            $SQL1 = "SELECT `id_service`, `service` FROM `list_service`
            WHERE  trim(`service`) like '".mysqli_real_escape_string($connexion,$alerte)."'";
			// echo 	  $SQL1 ;		
 			
			}


    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 221:  ".$SQL1."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 221 !');
    }

    if ($result)
	{				
	echo '                   
			<div class="col-lg-12">	
			<!-- /.panel -->
                    <div class="panel panel-info">
                        <div class="panel-heading" style="background-color:#e7722c;font-size:18px;color:#fff;line-height: 80%;">
                            <i class="fa  fa-retweet"></i> Suivi service
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
										
                                        <table class="table table-bordered table-hover table-striped">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Service</th>
                                                </tr>
                                            </thead>
                                            <tbody>';
									if(mysqli_num_rows($result)>0)
									{
									    $i=1;
										while ($row = mysqli_fetch_assoc($result)) 
                                        {
                                            echo '<tr>
                                                <td>'.$i.'</td>
                                                <td>'.$row["service"].'</td>
                                            </tr>';
                                            $i++;
                                        }
									}
											
											
								if(($alerte=="") )
								{
								    echo'<tr><td colspan="2" align="center">';
								    echo   '<ul class="pagination"><li>'.$lien.' </li></ul>';
								    echo   '<div class="alert" style="background-color:#fabf8f;font-size:18px;color:#fff;line-height: 80%;"><strong>'.$total.'</strong></div>';
								    echo'</td></tr> ';
								}
											
                                        echo '   </tbody>
                                        </table>											
											
											
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.col-lg-4 (nested) -->
                                <div class="col-lg-8">
                                    <div id="morris-bar-chart"></div>
                                </div>
                                <!-- /.col-lg-8 (nested) -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-8 -->

				';	

    mysqli_free_result($result);
	}
mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_etat_parc_atm($terminal,$paramettre,$idprivilege,$date_debut,$date_fin,$historique_vacation,$lang)
{

    include("pagination.php");
    include("../pagination.php");
    include "../languages/" . $_SESSION['lang'] . ".php";
    //
    //echo "<pre>";print_r($lang);echo "</pre>";die();

    $link = ma_db_connexion();

    $sqlG = "SELECT `id_atm`, `terminal`, `state` , `state_confirm`,`ip_adress`,
    TIMESTAMPDIFF(SECOND ,last_connexion,now()) as `desconnected_time`			
    FROM `list_atm_confirmed` ";

    if(($idprivilege==0))
    {
        $sqlG = $sqlG." WHERE ";
    }

    if(($paramettre==0) && ($idprivilege==0))
    {
        $sqlG = $sqlG." state_confirm=1 ";
    }
    if(($paramettre==1) && ($idprivilege==0))
    {
        $sqlG = $sqlG." state=1  ";
    }

    $sqlG = $sqlG." ORDER BY `id_atm` ASC";

    $page = new Pagination($sqlG, 12);
    $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
    $lien = $page->liens(5);
    $SQL = $page->req();

    $resultG=mysqli_query($link,$SQL);
    if (!$resultG)
    {
        error_log("Erreur SQL 222:  ".$SQL."  " .mysqli_error($link));
        die(' ERREUR QUERY 222 !');
    }


    if ($resultG)
    {
        echo '<div>';
        echo '  <table class="table table-responsive-sm table-hover table-outline mb-0">
        <thead class="thead-light">
            <tr>
                <th class="text-center">ID</th>';
                if(($paramettre==1) && ($idprivilege==1)){ echo '<th class="text-center">'.$lang['status'].'</th>';}
                echo'<th class="text-center">'.$lang['atm_id'].'</th>
                <th class="text-center">'.$lang['atm_name'].'</th>
                <th class="text-center">IP</th>
                <th class="text-center">'.$lang['date_add'].'</th>
                <th class="text-center">'.$lang['date_vacation'].'</th>
                <th class="text-center">'.$lang['last_conn'].'</th>
                <th class="text-center">'.$lang['dev_stat'].' </th>
                <th class="text-center">Actions</th>
                <th class="text-center">'.$lang['declar_i'].'</th>
            </tr>
        </thead>
        <tbody>';
        if (mysqli_num_rows($resultG)>0)
        {
            $o=0;
            $l=0;
            $tableService = array();
            while ($rowG = mysqli_fetch_assoc($resultG))
            {

                $o++;
                $idfilial=getfilialATM($rowG["id_atm"]);
                list($id_poste_affecter, $name_poste_affecter) = explode('---', get_post_affect_ATM($idfilial));
                $name_poste_affecter=str_replace(CHR(32),'',$name_poste_affecter);
                list($terminalID, $ipAdresseGAB, $nomGAB, $dateAjout) = explode('---', getinfoATM($rowG["id_atm"]));
                $sql = "SELECT `id_vacation_ALM`, `id_vacation_BCR`, `id_vacation_CAM`, `id_vacation_CDM`, 
                `id_vacation_CEU`, `id_vacation_CHK`, `id_vacation_CIM`, `id_vacation_CRD`, 
                `id_vacation_DEP`, `id_vacation_IDC`, `id_vacation_IPM`, `id_vacation_PIN`, 
                `id_vacation_PTR`, `id_vacation_SIU`, `id_vacation_TTU`, `id_vacation_VDM`, `vacation_date`, `name_file`						
                FROM  `hist_vacations`	WHERE `hist_vacations`.`id_atm` ='".mysqli_real_escape_string($link,$rowG["id_atm"])."'  AND if_load=1
                AND if_last_vacation=1";
                //var_dump($sql);echo "<br>";
                $result=mysqli_query($link,$sql);
                if (!$result)
                {
                    error_log("Erreur SQL 223:  ".$sql."  " .mysqli_error($link));
                    die(' ERREUR QUERY 223 !');
                }
                if($result)
                {
                    $k=0;
                    // Verifications Services autorisé.
                    $serviceATMAutorise = explode(',', get_list_service_atm($rowG["id_atm"]));
                    foreach($serviceATMAutorise as $service)
                    {
                        $tableService[] = $service;
                    }
                    if (mysqli_num_rows($result)>0)
                    {
                        while ($row = mysqli_fetch_assoc($result))
                        {
                            $state_btn = 'btn-warning';
                            if(get_device_status($rowG["id_atm"],$row["vacation_date"]))
                            {
                                $state_btn = 'btn-info';
                            }
                            $l++;
                            $k++;
                            echo '<tr id="tr_'.$rowG["id_atm"].'">';
                            echo'<td class="text-center">';
                            echo $rowG["id_atm"];

                            get_date_up_atm(get_last_vacation_date($rowG["id_atm"]));
                            echo '</td>';
                            if(($paramettre==1) && ($idprivilege==1) )
                            {
                                if($rowG["state"] == 0 && $rowG["state_confirm"] == 1)
                                {
                                    echo' <td class="text-center" id="div1'.$rowG['id_atm'].'">'.$lang['att_confirmation'].'</td>';
                                }
                                else
                                {
                                    echo '<td class="text-center" id="div1'.$rowG['id_atm'].'">'.getStatEtatGAB($rowG["state"]).'</td>';
                                }
                            }
                            echo'<td class="text-center" id="div0'.$rowG["id_atm"].'" >'.$terminalID.'</td>';

                            echo '<td class="text-center">'. $nomGAB. '</td>';
                            echo'<td class="text-center">'. $ipAdresseGAB. '</td>';
                            echo'<td class="text-center">'.$dateAjout.'</td>';
                            echo'<td class="text-center">'.$row["vacation_date"].'</td>';

                                /****Durée de déconnection*****/
                            $desconnected_time=secondsToWords($rowG["desconnected_time"]);
                            if($rowG["desconnected_time"]>600)
                            {
                                echo'<td class="text-center" >
                                <span class="badge badge-pill badge-danger">
                                        '.$desconnected_time .'
                                    </span>
                                </td>';
                            }
                            else
                            {
                                echo'<td class="text-center">
                                <span class="badge badge-pill badge-secondary">
                                        '.$desconnected_time .'
                                    </span>
                                </td>';
                            }

                            echo'<td class="text-center">';
                            echo'<div class="span4" align="center">
                            <div class="btn-group"> 
                            <button class="btn '.$state_btn.' dropdown-toggle" id="btnGroupVerticalDrop1" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="cil-airplay"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li>
                                    <div class="btn-group"> ';
                            $service = 4;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CDM"],'vacations_CDM','xfs_errors_CDM','CDM',$row["vacation_date"],'WFS_INF_CDM_STATUS',mysqli_real_escape_string($link,$row["name_file"]));
                            }
                            $service = 7;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CIM"],'vacations_CIM','xfs_errors_CIM','CIM',$row["vacation_date"],'WFS_INF_CIM_STATUS',mysqli_real_escape_string($link,$row["name_file"]));
                            }
                            $service = 12;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_PIN"],'vacations_PIN','xfs_errors_PIN','PIN',$row["vacation_date"],'WFS_INF_PIN_STATUS',mysqli_real_escape_string($link,$row["name_file"]));
                            }
                            $service = 13;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_PTR"],'vacations_PTR','xfs_errors_PTR','PTR',$row["vacation_date"],'WFS_INF_PTR_STATUS',mysqli_real_escape_string($link,$row["name_file"]));
                            }
                            $service = 10;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_IDC"],'vacations_IDC','xfs_errors_IDC','IDC',$row["vacation_date"],'WFS_INF_IDC_STATUS',mysqli_real_escape_string($link,$row["name_file"]));
                            }
                            /*$service = 14;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_SIU"],'vacations_SIU','xfs_errors_SIU','SIU',$row["vacation_date"],'WFS_INF_SIU_STATUS',mysqli_real_escape_string($link,$row["name_file"]));
                            }*/

                            $varcolor=getColorDashboard($rowG["id_atm"]) ;
                            if($varcolor != "#888683")
                            {
                                echo '<a class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                onClick="javascript:getDashboardATM(\''.$rowG["id_atm"].'\')" 
                                data-target="#moduleDashboardATM"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-2x" title="CPU,RAM"></i></strong></a> ';
                            }
                            else
                            {
                                echo '<a class="text-center dropdown-item " tabindex="-1"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-2x" title="CPU,RAM"></i></strong></a>';
                            }
                            echo '<a class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                            onClick="javascript:getjournalATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\')"    
                            data-target="#detailjournalATM"> <strong style="color:#52c322" ><i class="fa fa-newspaper-o fa-2x" title="E-J"> </i></strong></a>';

                            echo '<a class="text-center dropdown-item "  title="'.$lang['cmd_hist'].'" tabindex="-1" data-toggle="modal"
                            onClick="javascript:getcommandeATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
                            data-target="#detailcommandeATM"> <strong style="color:#52c322" >
                                <svg class="icon x128" height="30" width="30">
                                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-monitor"></use>
                                </svg>
                                </strong>
                                    </a>';

                            echo '<a class="text-center dropdown-item " title="'.$lang["det_con_gab"].'" tabindex="-1" data-toggle="modal" 
                                    onClick="javascript:getdeconATM(\'' . $rowG["id_atm"] . '\')"    
                                    data-target="#detaildeconATM"> <strong style="color:#52c322;">
                                    <svg class="icon x128" height="30" width="30">
                                        <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-link"></use>
                                    </svg>
                                    </strong>
                                    </a>';
                            echo '</div>
                                </li>
                            </ul>
                        </div>
                    </div>';
                     echo '</td>';
                            echo '<td class="text-center">';

                            echo ' <div class="btn-group">
                                        <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span class="cil-transfer"></span> </button>
                                <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 34px, 0px); top: 0px; left: 0px; will-change: transform;">';
                            /**********************Config Admin********************/
                            if ($idprivilege==1)
                            {

                                echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal" 
                                    onClick="javascript:getConfigServiceATM(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
                                    data-target="#detailConfigServiceATM"><strong style="color:#FF0040" ><i class="cil-clipboard" title="Service"></i></strong>&nbsp; Service</a>';


                                echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal" 
                                    onClick="javascript:getConfigStatusXFSName(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
                                    data-target="#detailConfigStatusXFSNameATM"><strong style="color:#FF0040" ><i class="cil-check" title="'.$lang['activ_serv'].' XFS erreurs "></i></strong>&nbsp; '.$lang['activ_serv'].'</a>';

                            }

                            if ($idprivilege==1)
                            {
                                if($rowG["state"]==0)
                                {
                                    echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal" 
                                        onClick="javascript:declarerNouveauGAB(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
                                        data-target="#moduledeclarerNouveauGAB"> <strong style="color:#FF0040" ><i class="fa  fa-gg" title="'.$lang['new_atm'].'"></i></strong>&nbsp; '.$lang['new_atm'].'</a>';
                                }
                            }
                            /*********************************************************/
                            /**********************Redémarrer********************/

                            echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal" 
                                    onClick="javascript:getRedemarrerATM(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
                                    data-target="#detailRedemarrerATM"  aria-pressed="true"><i style="color:#FF0040"  class="cil-pregnant" title="'.$lang['reboot'].'"></i>&nbsp; '.$lang['reboot'].' </a>';


                            /*********************************************************
                            /**********************Ping********************/
                            /*echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal"
                            onClick="javascript:getPingATM(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$rowG["id_atm"].'\',\''.$rowG["terminal"].'\',\''.$rowG["ip_adress"].'\')"   
                            data-target="#detailPingATM"  aria-pressed="true"><i style="color:#FF0040"  class="cil-transfer" title="Ping"></i>&nbsp; Ping </a>';*/
                            /*********************************************************
                            /********************** Capture écran ATM********************/

                            echo' <a tabindex="-1" class="dropdown-item"  data-toggle="modal" 
                                    onClick="javascript:getScreenshotATM(\''.$rowG["id_atm"].'\')"   
                                    data-target="#detailScreenshotATM"><strong style="color:#FF0040" ><i class="cil-camera" title="'.$lang['screenshot'].'"></i></strong>&nbsp; '.$lang['screenshot'].' </a>';



                            /**********************Historique CMD********************/

                            echo '<a tabindex="-1" class="dropdown-item"  data-toggle="modal" 
                                    onClick="javascript:getcommandeATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
                                    data-target="#detailcommandeATM"> <strong style="color:#FF0040" ><i class="cil-mood-bad" title="'.$lang['cmd_hist'].'"> </i></strong>&nbsp; '.$lang['cmd_hist'].'</a>';





                            /**********************Config Admin Upload image********************/
                            if ($idprivilege == 1)
                            {
                                echo '<a tabindex="-1" class="dropdown-item" href="selectimagepofil.php" target="_blank"> 
                                <strong style="color:#FF0040" ><i class="cil-cloud-upload" title="'.$lang['uplo_img'].'"></i></strong>&nbsp; '.$lang['uplo_img'].'</a>';
                            }
                            /**********************Config Admin Modifier GAB<********************/
                            if ($idprivilege == 1)
                            {
                                echo'<a tabindex="-1" class="dropdown-item" data-toggle="modal" 
                                    onClick="javascript:getModifierATMConfirmed(\''.$terminalID.'\')" 
                                    data-target="#moduleModifierATMConfirmed"><strong style="color:#FF0040" ><i class="cil-people" title="'.$lang['edit_atm'].'"></i></strong>&nbsp; '.$lang['edit_atm'].'</a>
                                     ';
                            }
                            /******************************Download File in GAB************************************/
                            if ($idprivilege == 1)
                            {
                                echo'<a tabindex="-1" data-toggle="modal" class="dropdown-item"
                                    onClick="javascript:getDownloadFileGAB(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
                                    data-target="#moduleDownloadFileGAB"><strong style="color:#FF0040" ><i class="cil-cloud-download" title="'.$lang['down_file'].'"></i></strong>&nbsp; '.$lang['down_file'].'</a>';
                            }
                            /************************Historique vacations*********************/
                            echo "<a class='dropdown-item' tabindex='-1'  href='detailVacation.php?idATM=".$rowG["id_atm"]."&date_vacation=".$row["vacation_date"] . "' target='_blank'><i style='color:#FF0040' class='cil-devices' title='".$lang['dev_stat_hist']."'></i>&nbsp; ".$lang['dev_stat_hist']."</a>";



                            echo ' </div>';
                            echo '  </div>  
                                      </td>';
                            /**********************Fin Button ********************/
                            /***** Déclaration **/
                            echo'<td id="div'.$rowG["id_atm"].'" align="center">';
                            if(($rowG["terminal"]<>0) && ($rowG["state_confirm"]==0) && ($rowG["state"]==1))
                            {
                                echo "<a name='declarer' href='declarer.php?terminal=".$rowG["terminal"]."&dateArret=".date("Y-m-d H:i:s")."&id_motif=227' target='_blank'><strong style='color:#FF0040' ><i class='fa fa-plus-square' title='".$lang['declar_i']."'></i></strong></a>";
                            }
                            if ($idprivilege==1)
                            {
                                if($rowG["state"]==0 && $rowG["state_confirm"]==1)
                                {
                                    echo '<a tabindex="-1"  data-toggle="modal" 
                                            onClick="javascript:declarerNouveauGAB(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
                                            data-target="#moduledeclarerNouveauGAB"> <strong style="color:#FF0040" ><i class="fa fa-gg" title="'.$lang["new_atm"].'"></i></strong></a>';
                                }
                                if($rowG["state"]==0 && $rowG["state_confirm"]==0)
                                {
                                    echo '<a tabindex="-1" 
                                            onClick="javascript:change_state(\''.$rowG["id_atm"].'\')" >
                                            <strong style="color:#FF0040"> <i class="cil-color-border" title="'.$lang["activ_atm"].'"></i></strong></a>';
                                }
                            }
                            echo'</td>';
                            /***** FIN Déclaration **/
                           echo '</tr>';
											
                        }//while ($row = mysqli_fetch_assoc($result))
                    }//If VACATION§§§§ //  if (mysql_num_rows($result)>0)
								   
                    /******************************************************PARTIE ?????????????????*******************************************************/
                    else
					{
					    echo '<tr class="text-center"  id="tr_'.$rowG["id_atm"].'">';
					    echo'<td class="text-center">'.$rowG["id_atm"].'</td>';
					    if(($paramettre==1) && ($idprivilege==1) )
					    {
                            if($rowG["state"] == 0 && $rowG["state_confirm"] == 1)
                            {
                                echo' <td class="text-center" id="div1'.$rowG['id_atm'].'">'.$lang["wait_confir"].'</td>';
                            }
                            else
                            {
                                echo '<td class="text-center" id="div1'.$rowG['id_atm'].'">'.getStatEtatGAB($rowG["state"]).'</td>';
                            }
                        }
					    echo'<td class="text-center" id="div0'.$rowG["id_atm"].'">'.$terminalID.'</td>';
                        echo'<td class="text-center">'.$nomGAB.'</td>';
                        echo'<td class="text-center">'. $ipAdresseGAB.'</td>';
                        echo'<td class="text-center">'.$dateAjout.'</td>											
                        <td class="text-center"><span class="badge badge-secondary">---</span></td>		
                        <td class="text-center"><span class="badge badge-secondary">---</span></td>
						<td class="text-center"><span class="badge badge-secondary">---</span></td>';

                        echo '<td class="text-center">';

                        echo ' <div class="btn-group">
                                        <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span class="cil-transfer"></span> </button>
                                <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 34px, 0px); top: 0px; left: 0px; will-change: transform;">';
                        /**********************Config Admin********************/
                        if ($idprivilege==1)
                        {

                            echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal" 
                                    onClick="javascript:getConfigServiceATM(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
                                    data-target="#detailConfigServiceATM"><strong style="color:#FF0040" ><i class="cil-clipboard" title="Service"></i></strong>&nbsp; Service</a>';


                            echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal" 
                                    onClick="javascript:getConfigStatusXFSName(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
                                    data-target="#detailConfigStatusXFSNameATM"><strong style="color:#FF0040" ><i class="cil-check" title="'.$lang['activ_serv'].' XFS erreurs "></i></strong>&nbsp; '.$lang['activ_serv'].'</a>';

                        }

                        if ($idprivilege==1)
                        {

                            if($rowG["state"]==0)
                            {
                                echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal" 
                                        onClick="javascript:declarerNouveauGAB(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
                                        data-target="#moduledeclarerNouveauGAB"> <strong style="color:#FF0040" ><i class="fa  fa-gg" title="'.$lang['new_atm'].'"></i></strong>&nbsp; '.$lang['new_atm'].'</a>';
                            }

                        }
                        /*********************************************************/
                        /**********************Redémarrer********************/

                        echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal" 
                                    onClick="javascript:getRedemarrerATM(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
                                    data-target="#detailRedemarrerATM"  aria-pressed="true"><i style="color:#FF0040"  class="cil-pregnant" title="'.$lang['reboot'].'"></i>&nbsp; '.$lang['reboot'].' </a>';


                        /*********************************************************
                        /**********************Ping********************/
                        /*echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal"
                            onClick="javascript:getPingATM(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$rowG["id_atm"].'\',\''.$rowG["terminal"].'\',\''.$rowG["ip_adress"].'\')"   
                            data-target="#detailPingATM"  aria-pressed="true"><i style="color:#FF0040"  class="cil-transfer" title="Ping"></i>&nbsp; Ping </a>';*/
                        /*********************************************************
                        /********************** Capture écran ATM********************/

                        echo' <a tabindex="-1" class="dropdown-item"  data-toggle="modal" 
                                    onClick="javascript:getScreenshotATM(\''.$rowG["id_atm"].'\')"   
                                    data-target="#detailScreenshotATM"><strong style="color:#FF0040" ><i class="cil-camera" title="'.$lang['screenshot'].'"></i></strong>&nbsp; '.$lang['screenshot'].' </a>';



                        /**********************Historique CMD********************/

                        echo '<a tabindex="-1" class="dropdown-item"  data-toggle="modal" 
                                    onClick="javascript:getcommandeATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
                                    data-target="#detailcommandeATM"> <strong style="color:#FF0040" ><i class="cil-mood-bad" title="'.$lang['cmd_hist'].'"> </i></strong>&nbsp; '.$lang['cmd_hist'].'</a>';





                        /**********************Config Admin Upload image********************/
                        if ($idprivilege == 1)
                        {
                            echo '<a tabindex="-1" class="dropdown-item" href="selectimagepofil.php" target="_blank"> 
                                <strong style="color:#FF0040" ><i class="cil-cloud-upload" title="'.$lang['uplo_img'].'"></i></strong>&nbsp; '.$lang['uplo_img'].'</a>';
                        }
                        /**********************Config Admin Modifier GAB<********************/
                        if ($idprivilege == 1)
                        {
                            echo'<a tabindex="-1" class="dropdown-item" data-toggle="modal" 
                                    onClick="javascript:getModifierATMConfirmed(\''.$terminalID.'\')" 
                                    data-target="#moduleModifierATMConfirmed"><strong style="color:#FF0040" ><i class="cil-people" title="'.$lang['edit_atm'].'"></i></strong>&nbsp; '.$lang['edit_atm'].'</a>
                                     ';
                        }
                        /******************************Download File in GAB************************************/
                        if ($idprivilege == 1)
                        {
                            echo'<a tabindex="-1" data-toggle="modal" class="dropdown-item"
                                    onClick="javascript:getDownloadFileGAB(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
                                    data-target="#moduleDownloadFileGAB"><strong style="color:#FF0040" ><i class="cil-cloud-download" title="'.$lang['down_file'].'"></i></strong>&nbsp; '.$lang['down_file'].'</a>';
                        }

                        /************************Historique vacations*********************/
                       // echo "<a class='dropdown-item' tabindex='-1'  href='detailVacation.php?idATM=".$rowG["id_atm"]."&date_vacation=".$row["vacation_date"] . "' target='_blank'><i style='color:#FF0040' class='fa fa-newspaper-o' title='".$lang['dev_stat_hist']."'></i>&nbsp; ".$lang['dev_stat_hist']."</a>";
                        
                        echo ' </div>';
                        echo '  </div>  
                                      </td>';
                        /**********************Fin Button ********************/
                        /***** Déclaration **/

                        echo'<td class="text-center">';

                        if ($idprivilege==1)
                        {
                            if($rowG["state"]==0)
                            {
                                echo '<a tabindex="-1"  data-toggle="modal" 
                                    onClick="javascript:declarerNouveauGAB(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
                                    data-target="#moduledeclarerNouveauGAB"> <strong style="color:#FF0040" ><i class="fa  fa-gg" title="'.$lang['new_atm'].'"></i></strong></a>';
                            }
                            else
                            {
                                echo '<span class="badge badge-secondary">---</span>';
                            }
                        }
                        else
                        {
                            echo '<span class="badge badge-secondary">---</span>';
                        }
                        echo'</td>';
                        /*****FIN Déclaration **/
                        echo '</tr>';
					}
                    mysqli_free_result($result);
                }//if($result = mysqli_query(l(),$sql) or die('Erreur SQL 11111 !<br>'.$sql.'<br>'.mysqli_error()))
            } //while ($row = mysqli_fetch_assoc($resultG))
        }//if (mysqli_num_rows($resultG)>0)

        mysqli_free_result($resultG);
        echo '<tr><td colspan="11" class="text-center">';
        echo   '<ul class="pagination justify-content-center">'.$lien.'</ul>';
        echo   '<div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>';
        echo'</td></tr>';
        echo '  </tbody>
		</table>								
		</div>';
    }//if($resultG = mysqli_query($link(),$sqlG) or die('Erreur SQL 11111 !<br>'.$sqlG.'<br>'.mysqli_error()))
    mysqli_close($link);
}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getArray_Id_logicalNames($id_atm)
{
    $arrayLogicalNames= array();
    /*******Initialisation********/
    for ($g=0; $g <9  ; $g++)
    {
        $arrayLogicalNames[$g][0][0]='---';//ID logical name
        $arrayLogicalNames[$g][1][0]='---';// Libelle SERVICE
        $arrayLogicalNames[$g][2][0]='---';// Valeur fwDevice
        $arrayLogicalNames[$g][3][0]='--';// Libelle fwDevice
			
        $arrayLogicalNames[$g][4][0]='--';// Valeur fwDispencer

        $arrayLogicalNames[$g][5][0]='--';// Etat cassette 1
        $arrayLogicalNames[$g][5][1]='--';// Montant cassette 1
        $arrayLogicalNames[$g][5][2]='--';// TYPE cassette 1

        $arrayLogicalNames[$g][6][0]='--';// Etat cassette 2
        $arrayLogicalNames[$g][6][1]='--';// Montant cassette 2
        $arrayLogicalNames[$g][6][2]='--';// TYPE cassette 2

        $arrayLogicalNames[$g][7][0]='--';// Etat cassette 3
        $arrayLogicalNames[$g][7][1]='--';// Montant cassette 3
        $arrayLogicalNames[$g][7][2]='--';// TYPE cassette 3
			
        $arrayLogicalNames[$g][8][0]='--';// Etat cassette 4
        $arrayLogicalNames[$g][8][1]='--';// Montant cassette 4
        $arrayLogicalNames[$g][8][2]='--';// TYPE cassette 4
			
        $arrayLogicalNames[$g][9][0]='--';// Etat Cassette rejet
			
        $arrayLogicalNames[$g][10][0]='--';// Libelle logical name
    }
    $connexion=ma_db_connexion();
    /****************************/
    $SQL = "SELECT id_logical_name,logical_name , `list_service`.`service` as service  
	FROM atm_logical_names, list_service
	WHERE list_service.id_service= atm_logical_names.id_service AND id_atm=".mysqli_real_escape_string($connexion,$id_atm)." ";
	// var_dump($SQL);

    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 224:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 224 !');
    }
    if($result)
	{
        if (mysqli_num_rows($result) > 0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $idLog = $row["id_logical_name"];
                $libelle =$row["logical_name"];
                $idService =$row["service"];
                switch ($libelle)
                {
                    case 'CurrencyDispenser1':
                    $arrayLogicalNames[0][0][0]=$idLog;
                    $arrayLogicalNames[0][1][0]=$idService;
                    $arrayLogicalNames[0][10][0]=$libelle;
                    break;

                    case 'CurrencyDispenser2':
                    $arrayLogicalNames[1][0][0]=$idLog;
                    $arrayLogicalNames[1][1][0]=$idService;
                    $arrayLogicalNames[1][10][0]=$libelle;
                    break;

                    case 'CoinDispenser1':
                    $arrayLogicalNames[2][0][0]=$idLog;
                    $arrayLogicalNames[2][1][0]=$idService;
                    $arrayLogicalNames[2][10][0]=$libelle;
                    break;

                    case 'CashInModule1':
                    $arrayLogicalNames[3][0][0]=$idLog;
                    $arrayLogicalNames[3][1][0]=$idService;
                    $arrayLogicalNames[3][10][0]=$libelle;
                    break;

                    case 'Pinpad1':
                    $arrayLogicalNames[4][0][0]=$idLog;
                    $arrayLogicalNames[4][1][0]=$idService;
                    $arrayLogicalNames[4][10][0]=$libelle;
                    break;

                    case 'ChequeProcessor1':
                    $arrayLogicalNames[5][0][0]=$idLog;
                    $arrayLogicalNames[5][1][0]=$idService;
                    $arrayLogicalNames[5][10][0]=$libelle;
                    break;

                    case 'ReceiptPrinter1':
                    $arrayLogicalNames[6][0][0]=$idLog;
                    $arrayLogicalNames[6][1][0]=$idService;
                    $arrayLogicalNames[6][10][0]=$libelle;
                    break;

                    case 'JournalPrinter1':
                    $arrayLogicalNames[7][0][0]=$idLog;
                    $arrayLogicalNames[7][1][0]=$idService;
                    $arrayLogicalNames[7][10][0]=$libelle;
                    break;

                    case 'IDCardUnit1':
                    $arrayLogicalNames[8][0][0]=$idLog;
                    $arrayLogicalNames[8][1][0]=$idService;
                    $arrayLogicalNames[8][10][0]=$libelle;
                    break;

                }
            }
        }
        mysqli_free_result($result);
	}
	mysqli_close($connexion);
   // echo '<pre>'.print_r($arrayLogicalNames).'</pre>';
	return $arrayLogicalNames;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getColor_for_peripherals_details($device,$element)
{
	$color="";
	if($device=="Inéxistant")
	{
		$color= "";
	}
	else
	{
	    if($element=="Minimum" OR $element=="Presque pleine(s)" )
		{
			$color= "color:#F39C12;";
		}
		else if($element=="Hors ligne" OR $element=="Non connecté" OR  $element=="Pb hardware" OR $element=="Pb utilisation" 
		OR $element=="Fraud détectée" OR  $element=="Pb hard ou caisses pleines" 
		OR  $element=="Vide" OR   $element=="Pleine" OR  $element=="Pb values" OR  $element=="Pb manipulation" OR   $element=="Pb config" 
		OR  $element=="Manquante" )
		{
			$color= "color:#E74C3C;";
		}
	}
	//echo "color: ".$color;
	return $color;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getValues_statuts_logical_names_by_id_vacation($idAtm,array $arrayLogicalNames,$idVacation)
{
    $connexion=ma_db_connexion();
    /***************GET LAST VACATION*******************/
    if($idVacation=="")
    {
        //$queryGlobalVaction="   AND if_last_vacation=1  ";
        $Sql1 = "SELECT  file_generation_date, vacation_date, date_treatment_server,
		id_vacation_ALM,id_vacation_BCR,id_vacation_CAM,id_vacation_CDM, id_vacation_CEU, id_vacation_CHK, id_vacation_CIM, 
		id_vacation_CRD, id_vacation_DEP, id_vacation_IDC, id_vacation_IPM, id_vacation_PIN, id_vacation_PTR, id_vacation_SIU,
		id_vacation_TTU, id_vacation_VDM
		FROM  hist_vacations WHERE  id_atm='".mysqli_real_escape_string($connexion,$idAtm)."'  
		AND if_load=1 ORDER BY `hist_vacations`.`id_global_vacation` DESC LIMIT 1";

    }
    /***************GET A SPECIDFIED VACATION*******************/
    else
    {
        // $queryGlobalVaction="   AND  id_global_vacation= ".mysqli_real_escape_string($connexion,$idVacation) ."  ";
        $Sql1 = "SELECT  file_generation_date, vacation_date, date_treatment_server,
        id_vacation_ALM,id_vacation_BCR,id_vacation_CAM,id_vacation_CDM, id_vacation_CEU, id_vacation_CHK, id_vacation_CIM, 
        id_vacation_CRD, id_vacation_DEP, id_vacation_IDC, id_vacation_IPM, id_vacation_PIN, id_vacation_PTR, id_vacation_SIU,
        id_vacation_TTU, id_vacation_VDM
        FROM  hist_vacations
        WHERE  id_atm='".mysqli_real_escape_string($connexion,$idAtm)."'  
        AND if_load=1
        AND id_global_vacation ='".mysqli_real_escape_string($connexion,$idVacation)."'";
    }
    /**********************************/
    //var_dump($Sql1."<br>");
    $result1=mysqli_query($connexion,$Sql1);
    if (!$result1)
    {
        error_log("Erreur SQL 225:  ".$Sql1."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 225 !');
    }

    if ($result1)
    {
        if (mysqli_num_rows($result1) > 0)
        {
            while ($row = mysqli_fetch_assoc($result1))
            {
                foreach ($arrayLogicalNames as $key=>$value )
                {
                    /**CDM**/
                    $fwDispenser='---';
                    $rejet='---';
                    $c1='---'; $m1='---'; $s1='---';
                    $c2='---'; $m2='---'; $s2='---';
                    $c3='---'; $m3='---'; $s3='---';
                    $c4='---'; $m4='---'; $s4='---';
                    /**CIM**/
                    $fwAcceptor='---';
                    $rejetCim='---';
                    $nbr1_cim='---'; $s1_cim='---';
                    $nbr2_cim='---'; $s2_cim='---';
                    $nbr3_cim='---'; $s3_cim='---';

					$string1= 'id_vacation_'.$arrayLogicalNames[$key][1][0];
                    if ($arrayLogicalNames[$key][1][0]=='CDM' && $row[$string1])
                    {
                        $string= 'id_vacation_'.$arrayLogicalNames[$key][1][0];
                        $str= $row[$string];

                        $SQLCDM = "SELECT  vacations_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0])." .fwDispenser as fwDispenser ,
                            xfs_errors_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0]).".message_short as message,
                            vacations_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0]).".id_vacation as id_vacation
                            FROM vacations_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0])." , xfs_errors_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0])."
                            WHERE  id_logical_name=".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][0][0])."  
                            AND category LIKE 'fwDispenser' 
                            AND   vacations_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0]).".id_vacation IN (".mysqli_real_escape_string($connexion,$str).")
                            AND xfs_errors_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0]).".value=vacations_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0]).".fwDispenser";
                        $resultCDM=mysqli_query($connexion,$SQLCDM);
                        if (!$resultCDM)
                        {
                            error_log("Erreur SQL 226:  ".$SQLCDM."  " .mysqli_error($connexion));
							
                            die(' ERREUR QUERY 226 !');
                        }
                        if ($resultCDM)
                        {
                            if (mysqli_num_rows($resultCDM) > 0)
                            {
                                while ($rowCDM = mysqli_fetch_assoc($resultCDM))
                                {
                                    $fwDispenser=$rowCDM["message"];
                                    // echo "fwDispenser: ".$fwDispenser;
                                    $idVacationCassettes= $rowCDM["id_vacation"];
                                    // echo "<br>idVacationCassettes cdm: ".$idVacationCassettes."<br>";
                                    /**********************Cassettes***********************/
                                    $SQLCDM_cassettes = "SELECT   xfs_errors_CDM.message_short as message,
                                        vacations_CDM_cash_unit_logical.usType, vacations_CDM_cash_unit_logical.usNumber,
                                        vacations_CDM_cash_unit_logical.ulCount , vacations_CDM_cash_unit_logical.ulValues
                                        FROM vacations_CDM_cash_unit_logical , xfs_errors_CDM
                                        WHERE  xfs_errors_CDM.category LIKE 'usStatus' 
                                        AND xfs_errors_CDM.cmd LIKE 'WFS_INF_CDM_CASH_UNIT_INFO'
                                        AND   vacations_CDM_cash_unit_logical.id_vacation IN (".mysqli_real_escape_string($connexion,$idVacationCassettes).")
                                        AND xfs_errors_CDM.value=vacations_CDM_cash_unit_logical.usStatus";
                                    $resultCDM_assettes=mysqli_query($connexion,$SQLCDM_cassettes);
                                    if (!$resultCDM_assettes)
                                    {
                                        error_log("Erreur SQL 227:  ".$SQLCDM_cassettes."  " .mysqli_error($connexion));
                                        die(' ERREUR QUERY 227 !');
                                    }

                                    if ($resultCDM_assettes)
                                    {
                                        if (mysqli_num_rows($resultCDM_assettes) > 0)
                                        {
                                            while ($rowCDM_assettes = mysqli_fetch_assoc($resultCDM_assettes))
                                            {
                                                // echo "<br>SQLCDM_cassettes cdm:".mysql_result($resultCDM_assettes,$j,'usNumber')." <br>";
                                                $usType=$rowCDM_assettes["usType"];

                                                // if($arrayLogicalNames[$key][10][0]=='CoinDispenser1')
                                                // {
                                                // echo "<br>SQLCDM_cassettes cdm:".mysql_result($resultCDM_assettes,$j,'usNumber')." <br>";
                                                // echo "<br>usType:".mysql_result($resultCDM_assettes,$j,'usType')." <br>";
                                                // echo "<br>ulValues:".mysql_result($resultCDM_assettes,$j,'ulValues')." <br>";
                                                // }
                                                /***********Cassette Reject***********/
                                                if($usType==2)
                                                {
                                                    // echo "usType reject ";
                                                    $rejet=$rowCDM_assettes["message"];

                                                }
                                                /***********Cassette Cash***********/
                                                else if($usType==3 OR $usType==4)
                                                {
                                                    switch ($rowCDM_assettes["usNumber"])
                                                    {
                                                        case 1:
                                                            //echo "usType Cash1 ";
                                                            $c1=$rowCDM_assettes["ulValues"];
                                                            $m1=$rowCDM_assettes["ulValues"]*$rowCDM_assettes["ulCount"];
                                                            $s1=$rowCDM_assettes["message"];
                                                            break;
                                                        case 2:
                                                            //echo "usType Cash2 ";

                                                            $c2=$rowCDM_assettes["ulValues"];
                                                            $m2=$rowCDM_assettes["ulValues"]*$rowCDM_assettes["ulCount"];
                                                            $s2=$rowCDM_assettes["message"];
                                                            break;

                                                        case 3:
                                                            //echo "usType Cash3 ";
                                                            $c3=$rowCDM_assettes["ulValues"];
                                                            $m3=$rowCDM_assettes["ulValues"]*$rowCDM_assettes["ulCount"];
                                                            $s3=$rowCDM_assettes["message"];
                                                            break;

                                                        case 4:
                                                            // echo "usType Cash 4";
                                                            $c4=$rowCDM_assettes["ulValues"];
                                                            $m4=$rowCDM_assettes["ulValues"]*$rowCDM_assettes["ulCount"];
                                                            $s4=$rowCDM_assettes["message"];
                                                            break;
                                                    }
                                                }
                                            }//while ($rowCDM_assettes = mysqli_fetch_assoc($resultCDM_assettes))
                                            mysqli_free_result($resultCDM_assettes);
                                        }//	if ($resultCDM_assettes = mysqli_query($connexion,$SQLCDM_cassettes) or die('Erreur SQLCDM_cassettes getValues_statuts_logical_names_by_id_vacation !<br>' . $SQLCDM_cassettes .'<br>'. mysqli_error()))
                                    }
                                }//while ($rowCDM = mysqli_fetch_assoc($resultCDM))
                            } // if (mysql_num_rows($resultCDM) > 0)
                            mysqli_free_result($resultCDM);
                        }//			if ($resultCDM=mysqli_query($connexion(),$SQLCDM) or die('Erreur SQLCDM getValues_statuts_logical_names_by_id_vacation !<br>' . $SQLCDM .'<br>'. mysqli_error()))
                    }
                    else if ($arrayLogicalNames[$key][1][0]=='CIM' && $row["id_vacation_CIM"])
                    {
                        $str= $row["id_vacation_CIM"];
                        $SQLCIM = "SELECT vacations_CIM.fwAcceptor as fwAcceptor, vacations_CIM.id_vacation,
                            xfs_errors_CIM.message_short as message	
                            FROM vacations_CIM, xfs_errors_CIM
                            WHERE   category LIKE 'fwAcceptor' 
                            AND   vacations_CIM.id_vacation IN (".mysqli_real_escape_string($connexion,$str).")
                            AND xfs_errors_CIM.value=vacations_CIM.fwAcceptor";
                        $resultCIM=mysqli_query($connexion,$SQLCIM);
                        if (!$resultCIM)
                        {
                            error_log("Erreur SQL 228:  ".$SQLCIM."  " .mysqli_error($connexion));
                            die(' ERREUR QUERY 228 !');
                        }
                        if($resultCIM)
                        {
                            if (mysqli_num_rows($resultCIM) > 0)
                            {
                                while ($rowCIM = mysqli_fetch_assoc($resultCIM))
                                {
                                    $idVacationCassettes= $rowCIM["id_vacation"];
                                    $fwAcceptor=$rowCIM["message"];
                                    // echo "<br>idVacationCassettes cim: ".$idVacationCassettes."<br>";
                                    /**********************Cassettes cim***********************/
                                    $SQLCIM_cassettes = "SELECT   xfs_errors_CIM.message_short as message,
                                        vacations_CIM_cash_unit_logical.fwType, vacations_CIM_cash_unit_logical.usNumber,
                                        vacations_CIM_cash_unit_logical.ulCount , vacations_CIM_cash_unit_logical.ulValues
                                        FROM vacations_CIM_cash_unit_logical , xfs_errors_CIM
                                        WHERE  xfs_errors_CIM.category LIKE 'usStatus' 
                                        AND xfs_errors_CIM.cmd LIKE 'WFS_INF_CIM_CASH_UNIT_INFO'
                                        AND   vacations_CIM_cash_unit_logical.id_vacation IN (".mysqli_real_escape_string($connexion,$idVacationCassettes).")
                                        AND xfs_errors_CIM.value=vacations_CIM_cash_unit_logical.usStatus";
                                    $resultCIM_assettes=mysqli_query($connexion,$SQLCIM_cassettes);
                                    if (!$resultCIM_assettes)
                                    {
                                        error_log("Erreur SQL 229:  ".$SQLCIM_cassettes."  " .mysqli_error($connexion));
                                        die(' ERREUR QUERY 229 !');
                                    }
                                    if($resultCIM_assettes)
                                    {
                                        if (mysqli_num_rows($resultCIM_assettes) > 0)
                                        {
                                            //echo "ciiim*********";
                                            while ($rowCIM_assettes = mysqli_fetch_assoc($resultCIM_assettes))
                                            {
                                                $fwType=$rowCIM_assettes["fwType"];
                                                /***********Cash In***********/
                                                // if($fwType==4)
                                                // {
                                                // $rejetCim=mysql_result($resultCIM_assettes,$j,'message');
                                                // echo "<br>rejetCim cim: ".$rejetCim."<br>";

                                                // }
                                                /***********Cash reject***********/
                                                if($fwType==2 OR $fwType==4 )
                                                {
                                                    switch ($rowCIM_assettes["usNumber"])
                                                    {
                                                        case 1:
                                                            $nbr1_cim=$rowCIM_assettes["ulCount"];
                                                            $s1_cim= $rowCIM_assettes["message"];
                                                            // echo "<br>nbr1_cim cim: ".$nbr1_cim."<br>";
                                                            break;

                                                        case 2:
                                                            $nbr2_cim= $rowCIM_assettes["ulCount"];
                                                            $s2_cim= $rowCIM_assettes["message"];
                                                            // echo "<br>nbr2_cim cim: ".$nbr2_cim."<br>";
                                                            break;

                                                        case 3:
                                                            $nbr3_cim= $rowCIM_assettes["ulCount"];
                                                            $s3_cim= $rowCIM_assettes["message"];
                                                            // echo "<br>nbr3_cim cim: ".$nbr3_cim."<br>";
                                                            break;

                                                    }
                                                }
                                            }

                                        }//if (mysqli_num_rows($resultCIM_assettes) > 0)
                                        mysqli_free_result($resultCIM_assettes);
                                    }//if($resultCIM_assettes = mysqli_query($connexion(),$SQLCIM_cassettes) or die('Erreur SQLCIM_cassettes getValues_statuts_logical_names_by_id_vacation !<br>' . $SQLCIM_cassettes .'<br>'. mysqli_error()))
                                }//while ($rowCIM = mysqli_fetch_assoc($resultCIM))
                            } //if (mysqli_num_rows($resultCIM) > 0)
                            mysqli_free_result($resultCIM);
                        }//if($resultCIM = mysqli_query($SQLCIM) or die('Erreur SQLCIM getValues_statuts_logical_names_by_id_vacation !<br>' . $SQLCIM .'<br>'. mysqli_error()))
                    }
                    if ($arrayLogicalNames[$key][1][0] <> '---' && ($row['id_vacation_'.$arrayLogicalNames[$key][1][0]])<>'')
                    {
                        $string= 'id_vacation_'.$arrayLogicalNames[$key][1][0];
                        $str= $row[$string];
                        // echo "<br>string: ".$string."<br>";
                        //var_dump($str);echo"<br><br>";
                        //echo " <br>id_vacation_CDM : ".mysql_result($result1, 0,'id_vacation_CDM');
                        // echo "<br>string: ".$str."<br>";
                        $SQL = "SELECT  vacations_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0])." .fwDevice as fwDevice ,
                            xfs_errors_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0]).".message_short as message
                            FROM vacations_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0])." , xfs_errors_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0])."
                            WHERE  id_logical_name=".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][0][0])."  
                            AND category LIKE 'fwDevice' 
                            AND   vacations_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0]).".id_vacation IN (".mysqli_real_escape_string($connexion,$str).")
                            AND xfs_errors_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0]).".value=vacations_".mysqli_real_escape_string($connexion,$arrayLogicalNames[$key][1][0]).".fwDevice";
                        $result=mysqli_query($connexion,$SQL);
                        if (!$result)
                        {
                            error_log("Erreur SQL 230:  ".$SQL."  " .mysqli_error($connexion));
                            die(' ERREUR QUERY 230 !');
                        }
                        if($result)
                        {
                            if (mysqli_num_rows($result) > 0)
                            {
                                while ($row2 = mysqli_fetch_assoc($result))
                                {
                                    switch ($arrayLogicalNames[$key][10][0])
                                    {
                                        case 'CurrencyDispenser1':
                                            $arrayLogicalNames[$key][2][0]=$row2["message"];

                                            $arrayLogicalNames[$key][4][0]=$fwDispenser;
                                            // echo "fwDispenser1: ".$arrayLogicalNames[0][4][0];
                                            $arrayLogicalNames[$key][9][0]=$rejet;
                                            /***/
                                            $arrayLogicalNames[$key][5][0]=$s1;
                                            $arrayLogicalNames[$key][5][1]=$m1;
                                            $arrayLogicalNames[$key][5][2]=$c1;

                                            $arrayLogicalNames[$key][6][0]=$s2;
                                            $arrayLogicalNames[$key][6][1]=$m2;
                                            $arrayLogicalNames[$key][6][2]=$c2;

                                            $arrayLogicalNames[$key][7][0]=$s3;
                                            $arrayLogicalNames[$key][7][1]=$m3;
                                            $arrayLogicalNames[$key][7][2]=$c3;

                                            $arrayLogicalNames[$key][8][0]=$s4;
                                            $arrayLogicalNames[$key][8][1]=$m4;
                                            $arrayLogicalNames[$key][8][2]=$c4;
                                            /***/
                                            break;

                                        case 'CurrencyDispenser2':
                                            $arrayLogicalNames[$key][2][0]=$row2["message"];
                                            $arrayLogicalNames[$key][4][0]=$fwDispenser;
                                            // echo "fwDispenser2: ".$fwDispenser;
                                            $arrayLogicalNames[$key][9][0]=$rejet;
                                            /***/
                                            $arrayLogicalNames[$key][5][0]=$s1;
                                            $arrayLogicalNames[$key][5][1]=$m1;
                                            $arrayLogicalNames[$key][5][2]=$c1;

                                            $arrayLogicalNames[$key][6][0]=$s2;
                                            $arrayLogicalNames[$key][6][1]=$m2;
                                            $arrayLogicalNames[$key][6][2]=$c2;

                                            $arrayLogicalNames[$key][7][0]=$s3;
                                            $arrayLogicalNames[$key][7][1]=$m3;
                                            $arrayLogicalNames[$key][7][2]=$c3;

                                            $arrayLogicalNames[$key][8][0]=$s4;
                                            $arrayLogicalNames[$key][8][1]=$m4;
                                            $arrayLogicalNames[$key][8][2]=$c4;
                                            /***/
                                            break;

                                        case 'CoinDispenser1':
                                            $arrayLogicalNames[$key][2][0]=$row2["message"];
                                            $arrayLogicalNames[$key][4][0]=$fwDispenser;
                                            // echo "fwDispenser3: ".$fwDispenser;
                                            /***/
                                            $arrayLogicalNames[$key][5][0]=$s1;
                                            $arrayLogicalNames[$key][5][1]=$m1;
                                            $arrayLogicalNames[$key][5][2]=$c1;

                                            $arrayLogicalNames[$key][6][0]=$s2;
                                            $arrayLogicalNames[$key][6][1]=$m2;
                                            $arrayLogicalNames[$key][6][2]=$c2;


                                            $arrayLogicalNames[$key][7][0]=$s3;
                                            $arrayLogicalNames[$key][7][1]=$m3;
                                            $arrayLogicalNames[$key][7][2]=$c3;

                                            $arrayLogicalNames[$key][8][0]=$s4;
                                            $arrayLogicalNames[$key][8][1]=$m4;
                                            $arrayLogicalNames[$key][8][2]=$c4;
                                            /***/
                                            break;

                                        case 'CashInModule1':

                                            $arrayLogicalNames[$key][2][0]=$row2["message"];
                                            $arrayLogicalNames[$key][4][0]=$fwAcceptor;
                                            $arrayLogicalNames[$key][9][0]=$rejetCim;
                                            /***/
                                            $arrayLogicalNames[$key][5][0]=$s1_cim;
                                            $arrayLogicalNames[$key][5][1]=$nbr1_cim;

                                            $arrayLogicalNames[$key][6][0]=$s2_cim;
                                            $arrayLogicalNames[$key][6][1]=$nbr2_cim;

                                            $arrayLogicalNames[$key][7][0]=$s3_cim;
                                            $arrayLogicalNames[$key][7][1]=$nbr3_cim;

                                            /***/
                                            break;

                                        case 'Pinpad1':
                                            $arrayLogicalNames[$key][2][0]=$row2["message"];
                                            break;

                                        case 'ChequeProcessor1':
                                            $arrayLogicalNames[$key][2][0]=$row2["message"];
                                            break;

                                        case 'ReceiptPrinter1':
                                            $arrayLogicalNames[$key][2][0]=$row2["message"];
                                            break;

                                        case 'JournalPrinter1':
                                            $arrayLogicalNames[$key][2][0]=$row2["message"];
                                            break;

                                        case 'IDCardUnit1':
                                            $arrayLogicalNames[$key][2][0]=$row2["message"];
                                            break;

                                    }//switch ($arrayLogicalNames[$key][10][0])
                                }	//while ($row2 = mysqli_fetch_assoc($result))
                            }	//if (mysqli_num_rows($result) > 0)
                            mysqli_free_result($result);
                        }//if($result = mysqli_query($SQL) or die('Erreur SQL getValues_statuts_logical_names_by_id_vacation !<br>' . $SQL . '<br>' . mysqli_error()))
                    }
                }//foreach ($arrayLogicalNames as $key=>$value ){
            }//while ($row = mysqli_fetch_assoc($result1))
        }//if (mysqli_num_rows($result1) > 0)
        mysqli_free_result($result1);
    }//if ($result1=mysqli_query($connexion(),$sql) or die('Erreur    !<br>'.$sql.'<br>'.mysqli_error()))

    mysqli_close($connexion);
    return $arrayLogicalNames;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDetail_Peripheral_arret($idAtm,$terminal,$nomGab,$idVacation)
{

	$arrayIdLogicalNames=getArray_Id_logicalNames($idAtm);
	$arrayValuesArret= getValues_statuts_logical_names_by_id_vacation($idAtm,$arrayIdLogicalNames,$idVacation);
	$arrayValuesActuel= getValues_statuts_logical_names_by_id_vacation($idAtm,$arrayIdLogicalNames,"");
	// print_r($arrayValuesArret);
    echo "<a style='vertical-align:middle' data-toggle='modal' href='#myModal".$terminal."'><span class='fa fa-search' title='Statuts Périphériques Arrêt'></span></a>";

echo"    <div class='modal fade' id='myModal".$terminal."'  tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
			<div id='modal_d' class='modal-dialog modal-lg'>
				<div class='modal-content '>
					<div class='modal-header' >
					    <h4 class='modal-title' >Statuts Périphériques Arrêt</h4>
                        <button class='close' type='button' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>×</span></button>	
					</div>";
?>


    <div class='modal-body' >

                        <div class="row">
                            <div class="col">
                                <div class="card"  style="border: 0px;">
                                    <div class="card-header"> Détail Arrêt : <small><?php echo $nomGab ."($terminal)" ?></small></div>
                                    <div class="card-body" >

                                        <div class="nav-tabs-boxed">
                                            <ul class="nav nav-tabs" id="myTab1" role="tablist">
                                                <li class="nav-item"><a class="nav-link active" id="currency_dispenser-tab<?php echo "_".$terminal ?>" data-toggle="tab" href="#currency_dispenser<?php echo "_".$terminal ?>" role="tab" aria-controls="currency_dispenser<?php echo "_".$terminal ?>" aria-selected="true">Currency dispenser</a></li>
                                                <li class="nav-item"><a class="nav-link" id="coin_dispenser-tab<?php echo "_".$terminal ?>" data-toggle="tab" href="#coin_dispenser<?php echo "_".$terminal ?>" role="tab" aria-controls="coin_dispenser<?php echo "_".$terminal ?>" aria-selected="false">Coin dispenser</a></li>
                                                <li class="nav-item"><a class="nav-link" id="cash_in_module-tab<?php echo "_".$terminal ?>" data-toggle="tab" href="#cash_in_module<?php echo "_".$terminal ?>" role="tab" aria-controls="cash_in_module<?php echo "_".$terminal ?>" aria-selected="false">Cash in module</a></li>
                                                <li class="nav-item"><a class="nav-link" id="autres-tab<?php echo "_".$terminal ?>" data-toggle="tab" href="#autres<?php echo "_".$terminal ?>" role="tab" aria-controls="autres<?php echo "_".$terminal ?>" aria-selected="false">Autres périphèriques</a></li>
                                            </ul>

                                            <div class="tab-content" id="myTab1Content">
                                                <div class="tab-pane fade show active" id="currency_dispenser<?php echo "_".$terminal ?>" role="tabpanel" aria-labelledby="currency_dispenser-tab<?php echo "_".$terminal ?>">

                                                    <div class="row">
                                                        <div class="col-sm-6 col-md-6">
                                                            <div class="card card-accent-info ">
                                                                <div class="card-header">Currency dispenser 1 <span class="badge badge-danger float-right">Arrêt</span></div>

                                                                <div class="card-body">
                                                                    <ul class="list-group">
                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[0][2][0],$arrayValuesArret[0][5][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C1
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][5][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][5][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][5][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[0][2][0],$arrayValuesArret[0][6][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C2
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][6][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][6][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][6][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[0][2][0],$arrayValuesArret[0][7][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C3
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][7][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][7][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][7][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[0][2][0],$arrayValuesArret[0][8][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C4
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][8][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][8][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][8][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[0][2][0],$arrayValuesArret[0][9][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Cassette rejet:
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][9][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[0][2][0],$arrayValuesArret[0][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Distributeur:
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[0][2][0],$arrayValuesArret[0][4][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Etat alimentation:
                                                                            <span class="badge "><?php  echo $arrayValuesArret[0][4][0];?>
                                                                            (<?php echo intval($arrayValuesArret[0][5][1])+intval($arrayValuesArret[0][6][1])+intval($arrayValuesArret[0][7][1])+intval($arrayValuesArret[0][8][1]); ?>)</span>
                                                                        </li>

                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /.col-->
                                                        <div class="col-sm-6 col-md-6">
                                                            <div class="card card-accent-info">
                                                                <div class="card-header">Currency dispenser 1 <span class="badge badge-info float-right">Actuel</span>
                                                                </div>

                                                                <div class="card-body">
                                                                    <ul class="list-group">
                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][5][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C1
                                                                            <span class="badge "><?php echo $arrayValuesActuel[0][5][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[0][5][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][5][1]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][6][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C2
                                                                            <span class="badge "><?php echo $arrayValuesActuel[0][6][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[0][6][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][6][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][7][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C3
                                                                            <span class="badge "><?php echo $arrayValuesActuel[0][7][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[0][7][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][7][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][8][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C4
                                                                            <span class="badge "><?php echo $arrayValuesActuel[0][8][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[0][8][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[0][8][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][9][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Cassette rejet:
                                                                            <span class="badge "><?php echo $arrayValuesActuel[0][9][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Distributeur:
                                                                            <span class="badge "><?php echo $arrayValuesActuel[0][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][4][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Etat alimentation:
                                                                            <span class="badge "><?php  echo $arrayValuesActuel[0][4][0];?>
                                                                            (<?php echo intval($arrayValuesActuel[0][5][1])+intval($arrayValuesActuel[0][6][1])+intval($arrayValuesActuel[0][7][1])+intval($arrayValuesArret[0][8][1]); ?>)</span>
                                                                        </li>

                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /.col-->
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-6 col-md-6">
                                                            <div class="card card-accent-info">
                                                                <div class="card-header">Currency dispenser 2 <span class="badge badge-danger float-right">Arrêt</span></div>

                                                                <div class="card-body">
                                                                    <ul class="list-group">
                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[1][2][0],$arrayValuesArret[1][5][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C1
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][5][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][5][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][5][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[1][2][0],$arrayValuesArret[1][6][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C2
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][6][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][6][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][6][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[1][2][0],$arrayValuesArret[1][7][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C3
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][7][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][7][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][7][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[1][2][0],$arrayValuesArret[1][8][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C4
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][8][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][8][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][8][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[1][2][0],$arrayValuesArret[1][9][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Cassette rejet:
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][9][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[1][2][0],$arrayValuesArret[1][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Distributeur:
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[1][2][0],$arrayValuesArret[1][4][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Etat alimentation:
                                                                            <span class="badge "><?php  echo $arrayValuesArret[1][4][0];?>
                                                                            (<?php echo intval($arrayValuesArret[1][5][1])+intval($arrayValuesArret[1][6][1])+intval($arrayValuesArret[1][7][1])+intval($arrayValuesArret[1][8][1]); ?>)</span>
                                                                        </li>

                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /.col-->
                                                        <div class="col-sm-6 col-md-6">
                                                            <div class="card card-accent-info">
                                                                <div class="card-header">Currency dispenser 2 <span class="badge badge-info float-right">Actuel</span>
                                                                </div>

                                                                <div class="card-body">
                                                                    <ul class="list-group">
                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][5][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C1
                                                                            <span class="badge "><?php echo $arrayValuesActuel[1][5][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[1][5][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][5][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][6][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C2
                                                                            <span class="badge "><?php echo $arrayValuesActuel[1][6][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[1][6][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][6][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][7][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C3
                                                                            <span class="badge "><?php echo $arrayValuesActuel[1][7][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[1][7][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][7][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][8][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C4
                                                                            <span class="badge "><?php echo $arrayValuesActuel[1][8][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[1][8][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[1][8][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][9][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Cassette rejet:
                                                                            <span class="badge "><?php echo $arrayValuesActuel[1][9][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Distributeur:
                                                                            <span class="badge "><?php echo $arrayValuesActuel[1][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][4][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Etat alimentation:
                                                                            <span class="badge "><?php  echo $arrayValuesActuel[1][4][0];?>
                                                                            (<?php echo intval($arrayValuesActuel[1][5][1])+intval($arrayValuesActuel[1][6][1])+intval($arrayValuesActuel[1][7][1])+intval($arrayValuesActuel[1][8][1]); ?>)</span>
                                                                        </li>

                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /.col-->
                                                    </div>
                                                </div>
                                                <div class="tab-pane fade" id="coin_dispenser<?php echo "_".$terminal ?>" role="tabpanel" aria-labelledby="coin_dispenser-tab<?php echo "_".$terminal ?>">
                                                    <div class="row">
                                                        <div class="col-sm-6 col-md-6">
                                                            <div class="card card-accent-success">
                                                                <div class="card-header">Coin dispenser <span class="badge badge-danger float-right">Arrêt</span></div>

                                                                <div class="card-body">
                                                                    <ul class="list-group">
                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[2][2][0],$arrayValuesArret[2][5][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C1
                                                                            <span class="badge "><?php echo $arrayValuesArret[2][5][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[2][5][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[2][5][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[2][2][0],$arrayValuesArret[2][5][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C2
                                                                            <span class="badge "><?php echo $arrayValuesArret[2][6][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[2][6][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[2][6][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[2][2][0],$arrayValuesArret[2][5][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C3
                                                                            <span class="badge "><?php echo $arrayValuesArret[2][7][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[2][7][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[2][7][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[2][2][0],$arrayValuesArret[2][5][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C4
                                                                            <span class="badge "><?php echo $arrayValuesArret[2][8][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[2][8][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[2][8][2]; ?></span>
                                                                        </li>


                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[2][2][0],$arrayValuesArret[2][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Distributeur:
                                                                            <span class="badge "><?php echo $arrayValuesArret[2][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[2][2][0],$arrayValuesArret[2][4][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Etat alimentation:
                                                                            <span class="badge "><?php  echo $arrayValuesArret[2][4][0];?>
                                                                            (<?php echo intval($arrayValuesArret[2][5][1])+intval($arrayValuesArret[2][6][1])+intval($arrayValuesArret[2][7][1])+intval($arrayValuesArret[2][8][1]); ?>)</span>
                                                                        </li>

                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /.col-->
                                                        <div class="col-sm-6 col-md-6">
                                                            <div class="card card-accent-success">
                                                                <div class="card-header">Coin dispenser <span class="badge badge-info float-right">Actuel</span>
                                                                </div>

                                                                <div class="card-body">
                                                                    <ul class="list-group">
                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][5][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C1
                                                                            <span class="badge "><?php echo $arrayValuesActuel[2][5][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[2][5][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[2][5][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][6][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C2
                                                                            <span class="badge "><?php echo $arrayValuesActuel[2][6][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[2][6][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[2][6][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][7][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C3
                                                                            <span class="badge "><?php echo $arrayValuesActuel[2][7][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[2][7][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[2][7][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][8][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C4
                                                                            <span class="badge "><?php echo $arrayValuesActuel[2][8][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[2][8][0]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesActuel[2][8][2]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Distributeur:
                                                                            <span class="badge "><?php echo $arrayValuesActuel[2][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][4][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Etat alimentation:
                                                                            <span class="badge "><?php  echo $arrayValuesActuel[2][4][0];?>
                                                                            (<?php echo intval($arrayValuesActuel[2][5][1])+intval($arrayValuesActuel[2][6][1])+intval($arrayValuesActuel[2][7][1])+intval($arrayValuesActuel[2][8][1]); ?>)</span>
                                                                        </li>

                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /.col-->
                                                    </div>
                                                </div>
                                                <div class="tab-pane fade" id="cash_in_module<?php echo "_".$terminal ?>" role="tabpanel" aria-labelledby="cash_in_module-tab<?php echo "_".$terminal ?>">
                                                    <div class="row">
                                                        <div class="col-sm-6 col-md-6">
                                                            <div class="card card-accent-secondary">
                                                                <div class="card-header">Cash in module <span class="badge badge-danger float-right">Arrêt</span></div>

                                                                <div class="card-body">
                                                                    <ul class="list-group">
                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[3][2][0],$arrayValuesArret[3][5][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C1
                                                                            <span class="badge "><?php echo $arrayValuesArret[3][5][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[3][5][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[3][2][0],$arrayValuesArret[3][6][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C2
                                                                            <span class="badge "><?php echo $arrayValuesArret[3][6][1]; ?></span>
                                                                            <span class="badge "><?php echo $arrayValuesArret[3][6][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[3][2][0],$arrayValuesArret[3][7][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C3
                                                                            <span class="badge "><?php  echo $arrayValuesArret[3][7][1]; ?></span>
                                                                            <span class="badge "><?php  echo $arrayValuesArret[3][7][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[3][2][0],$arrayValuesArret[3][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Device:
                                                                            <span class="badge "><?php echo $arrayValuesArret[3][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[3][2][0],$arrayValuesArret[3][4][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Acceptor:
                                                                            <span class="badge "><?php  echo $arrayValuesArret[3][4][0];?></span>
                                                                        </li>

                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /.col-->
                                                        <div class="col-sm-6 col-md-6">
                                                            <div class="card card-accent-secondary">
                                                                <div class="card-header">Cash in module <span class="badge badge-info float-right">Actuel</span>
                                                                </div>

                                                                <div class="card-body">
                                                                    <ul class="list-group">
                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[3][2][0],$arrayValuesActuel[3][5][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C1
                                                                            <span class="badge "><?php  echo $arrayValuesActuel[3][5][1]; ?></span>
                                                                            <span class="badge "><?php  echo $arrayValuesActuel[3][5][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[3][2][0],$arrayValuesActuel[3][6][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C2
                                                                            <span class="badge "><?php  echo $arrayValuesActuel[3][6][1]; ?></span>
                                                                            <span class="badge "><?php  echo $arrayValuesActuel[3][6][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][7][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            C3
                                                                            <span class="badge "><?php  echo $arrayValuesActuel[3][7][1]; ?></span>
                                                                            <span class="badge "><?php  echo $arrayValuesActuel[3][7][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[3][2][0],$arrayValuesActuel[3][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Device:
                                                                            <span class="badge "><?php echo $arrayValuesActuel[3][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[3][2][0],$arrayValuesActuel[3][4][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Acceptor:
                                                                            <span class="badge "><?php  echo $arrayValuesActuel[3][4][0];?></span>
                                                                        </li>

                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /.col-->
                                                    </div>
                                                </div>
                                                <div class="tab-pane fade" id="autres<?php echo "_".$terminal ?>" role="tabpanel" aria-labelledby="autres-tab<?php echo "_".$terminal ?>">
                                                    <div class="row">
                                                        <div class="col-sm-6 col-md-6">
                                                            <div class="card card-accent-warning">
                                                                <div class="card-header">Autres périphèriques <span class="badge badge-danger float-right">Arrêt</span></div>

                                                                <div class="card-body">
                                                                    <ul class="list-group">
                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[8][2][0],$arrayValuesArret[8][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Lecteur de carte:
                                                                            <span class="badge "><?php echo $arrayValuesArret[8][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[4][2][0],$arrayValuesArret[4][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Pinpad:
                                                                            <span class="badge "><?php echo $arrayValuesArret[4][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[5][2][0],$arrayValuesArret[5][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Cheque processor
                                                                            <span class="badge "><?php echo $arrayValuesArret[5][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[6][2][0],$arrayValuesArret[6][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Imprimante ticket:
                                                                            <span class="badge "><?php echo $arrayValuesArret[6][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesArret[7][2][0],$arrayValuesArret[7][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Imprimante journal:
                                                                            <span class="badge "><?php echo $arrayValuesArret[7][2][0]; ?></span>
                                                                        </li>

                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /.col-->
                                                        <div class="col-sm-6 col-md-6">
                                                            <div class="card card-accent-warning">
                                                                <div class="card-header">Autres périphèriques <span class="badge badge-info float-right">Actuel</span>
                                                                </div>

                                                                <div class="card-body">
                                                                    <ul class="list-group">
                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[8][2][0],$arrayValuesActuel[8][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Lecteur de carte:
                                                                            <span class="badge "><?php echo $arrayValuesActuel[8][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[3][2][0],$arrayValuesActuel[3][6][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Pinpad:
                                                                            <span class="badge "><?php echo $arrayValuesActuel[4][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][7][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Cheque processor:
                                                                            <span class="badge "><?php echo $arrayValuesActuel[5][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[6][2][0],$arrayValuesActuel[6][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Imprimante ticket:
                                                                            <span class="badge "><?php echo $arrayValuesActuel[6][2][0]; ?></span>
                                                                        </li>

                                                                        <li style ="<?php echo getColor_for_peripherals_details($arrayValuesActuel[7][2][0],$arrayValuesActuel[7][2][0]); ?>"  class="list-group-item d-flex list-group-item-action justify-content-between align-items-center">
                                                                            Imprimante journal:
                                                                            <span class="badge "><?php echo $arrayValuesActuel[7][2][0]; ?></span>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /.col-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>






					</div>
					<div class='modal-footer'>
						
						<button type='button' class='btn btn-secondary' data-dismiss='modal'>Fermer</button>
						
					</div>
			</div>
     </div>
    </div>
	
<?php	
echo "
	";
	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDetail_Peripheral_gab($idAtm,$terminal,$nomGab,$idVacation)
{

    $arrayIdLogicalNames=getArray_Id_logicalNames($idAtm);
    $arrayValuesArret= getValues_statuts_logical_names_by_id_vacation($idAtm,$arrayIdLogicalNames,$idVacation);
    $arrayValuesActuel= getValues_statuts_logical_names_by_id_vacation($idAtm,$arrayIdLogicalNames,"");
    // print_r($arrayValuesArret);
    echo "<a style='vertical-align:middle' data-toggle='modal' href='#myModal".$terminal."'><span class='fa fa-search' title='Statuts Périphériques'></span></a>";
    echo"
		 <div class='modal fade' id='myModal".$terminal."' role='dialog'>
			<div id='modal_d' class='modal-dialog'>
				<div class='modal-content'>
					<div class='modal-header'>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
						<div style='font-size:13pt;color: #3a1d19;' class='modal-title' >Détail GAB: ".$nomGab." (".$terminal.")<br></div>
					</div>
	";
    ?>

    <div class='modal-body' style='padding:20px 20px;'>
        <div class='row'>

            <div class="col-sm-12">
                <div class='panel panel-default'>
                    <div class='panel-heading' style='background-color:#e7722c;font-size:13pt;color:#fff;'>Currency dispenser 1 (Actuel)</div>

                    <div style='margin-left: 2px' class='panel-body'>


                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][5][0]); ?>'>
                            <div class='col-sm-2'>
                                <label>C1</label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[0][5][1]; ?></label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[0][5][0]; ?></label>
                            </div>
                            <div class='col-sm-2'>
                                <label><?php echo $arrayValuesArret[0][5][2]; ?></label>
                            </div>

                        </div>
                        <div style='background-color:#f9f9f9;<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][6][0]); ?>' class='row'>
                            <div class='col-sm-2'>
                                <label>C2</label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[0][6][1]; ?></label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[0][6][0]; ?></label>
                            </div>
                            <div class='col-sm-2'>
                                <label><?php echo $arrayValuesArret[0][6][2]; ?></label>
                            </div>
                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][7][0]); ?>'>
                            <div class='col-sm-2'>
                                <label>C3</label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php  echo $arrayValuesActuel[0][7][1]; ?></label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo  $arrayValuesActuel[0][7][0]; ?></label>
                            </div>
                            <div class='col-sm-2'>
                                <label><?php echo $arrayValuesArret[0][7][2]; ?></label>
                            </div>
                        </div>
                        <div style='background-color:#f9f9f9;<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][8][0]); ?>' class='row'>
                            <div class='col-sm-2'>
                                <label>C4</label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php  echo $arrayValuesActuel[0][8][1]; ?></label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[0][8][0]; ?></label>
                            </div>
                            <div class='col-sm-2'>
                                <label><?php echo $arrayValuesArret[0][8][2]; ?></label>
                            </div>
                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][9][0]); ?>'>
                            <div class='col-sm-4'>
                                <label>Cassette rejet</label>
                            </div>

                            <div class='col-sm-8'>
                                <label><?php echo $arrayValuesActuel[0][9][0]; ?></label>
                            </div>

                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][2][0]); ?>'>
                            <div class='col-sm-4'>
                                <label>Distributeur: </label>
                            </div>

                            <div class='col-sm-8'>
                                <label><?php echo $arrayValuesActuel[0][2][0]; ?></label>
                            </div>

                        </div>
                        <div class='row'  style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[0][2][0],$arrayValuesActuel[0][4][0]); ?>'>
                            <div class='col-sm-4'>
                                <label>Etat alimentation: </label>
                            </div>

                            <div class='col-sm-8'>
                                <label><?php  echo $arrayValuesActuel[0][4][0];?>
                                    (<?php echo intval($arrayValuesActuel[0][5][1])+intval($arrayValuesActuel[0][6][1])+intval($arrayValuesActuel[0][7][1])+intval($arrayValuesActuel[0][8][1]); ?>)
                                </label>
                            </div>
                        </div>


                    </div>

                    <div class='panel-heading' style='background-color:#e7722c;font-size:13pt;color:#fff;'>Currency dispenser 2 (Actuel)</div>
                    <div style='margin-left: 2px' class='panel-body'>


                        <div class='row'  style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][5][0]); ?>'>
                            <div class='col-sm-2'>
                                <label>C1</label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[1][5][1]; ?></label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[1][5][0]; ?></label>
                            </div>
                            <div class='col-sm-2'>
                                <label><?php echo $arrayValuesArret[1][5][2]; ?></label>
                            </div>
                        </div>
                        <div style='background-color:#f9f9f9;<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][6][0]); ?>' class='row'>
                            <div class='col-sm-2'>
                                <label>C2</label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[1][6][1]; ?></label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[1][6][0]; ?></label>
                            </div>
                            <div class='col-sm-2'>
                                <label><?php echo $arrayValuesArret[1][6][2]; ?></label>
                            </div>
                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][7][0]); ?>'>
                            <div class='col-sm-2'>
                                <label>C3</label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[1][7][1]; ?></label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[1][7][0]; ?></label>
                            </div>
                            <div class='col-sm-2'>
                                <label><?php echo $arrayValuesArret[1][7][2]; ?></label>
                            </div>
                        </div>
                        <div style='background-color:#f9f9f9;<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][8][0]); ?>' class='row'>
                            <div class='col-sm-2'>
                                <label>C4</label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[1][8][1]; ?></label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[1][8][0]; ?></label>
                            </div>
                            <div class='col-sm-2'>
                                <label><?php echo $arrayValuesArret[1][8][2]; ?></label>
                            </div>
                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][9][0]); ?>' >
                            <div class='col-sm-4'>
                                <label>Cassette rejet</label>
                            </div>

                            <div class='col-sm-8'>
                                <label><?php echo $arrayValuesActuel[1][9][0]; ?></label>
                            </div>

                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][2][0]); ?>'>
                            <div class='col-sm-4'>
                                <label>Distributeur: </label>
                            </div>

                            <div class='col-sm-8'>
                                <label><?php echo $arrayValuesActuel[1][2][0]; ?></label>
                            </div>

                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[1][2][0],$arrayValuesActuel[1][4][0]); ?>'>
                            <div class='col-sm-4'>
                                <label>Etat alimentation: </label>
                            </div>

                            <div class='col-sm-8'>
                                <label><?php  echo $arrayValuesActuel[1][4][0];?>
                                    (<?php echo intval($arrayValuesActuel[1][5][1])+intval($arrayValuesActuel[1][6][1])+intval($arrayValuesActuel[1][7][1])+intval($arrayValuesActuel[1][8][1]); ?>)
                                </label>
                            </div>
                        </div>

                    </div>

                    <div class='panel-heading' style='background-color:#e7722c;font-size:13pt;color:#fff;'>Coin dispenser  (Actuel)</div>
                    <div style='margin-left: 2px' class='panel-body'>


                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][5][0]); ?>'>
                            <div class='col-sm-2'>
                                <label>C1</label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[2][5][1]; ?></label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[2][5][0]; ?></label>
                            </div>
                            <div class='col-sm-2'>
                                <label><?php echo $arrayValuesActuel[2][5][2]; ?></label>
                            </div>

                        </div>
                        <div style='background-color:#f9f9f9;<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][6][0]); ?>' class='row'>
                            <div class='col-sm-2'>
                                <label>C2</label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[2][6][1]; ?></label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[2][6][0]; ?></label>
                            </div>
                            <div class='col-sm-2'>
                                <label><?php echo $arrayValuesActuel[2][6][2]; ?></label>
                            </div>
                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][7][0]); ?>'>
                            <div class='col-sm-2'>
                                <label>C3</label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[2][7][1]; ?></label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[2][7][0]; ?></label>
                            </div>
                            <div class='col-sm-2'>
                                <label><?php echo $arrayValuesActuel[2][7][2]; ?></label>
                            </div>
                        </div>
                        <div style='background-color:#f9f9f9;<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][8][0]); ?>' class='row'>
                            <div class='col-sm-2'>
                                <label>C4</label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[2][8][1]; ?></label>
                            </div>

                            <div class='col-sm-4'>
                                <label><?php echo $arrayValuesActuel[2][8][0]; ?></label>
                            </div>
                            <div class='col-sm-2'>
                                <label><?php echo $arrayValuesActuel[2][8][2]; ?></label>
                            </div>
                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][2][0]); ?>'>
                            <div class='col-sm-4'>
                                <label>Distributeur: </label>
                            </div>

                            <div class='col-sm-8'>
                                <label><?php echo $arrayValuesActuel[2][2][0]; ?></label>
                            </div>

                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[2][2][0],$arrayValuesActuel[2][4][0]); ?>'>
                            <div class='col-sm-4'>
                                <label>Etat alimentation: </label>
                            </div>

                            <div class='col-sm-8'>
                                <label><?php  echo $arrayValuesActuel[2][4][0];?>
                                    (<?php echo intval($arrayValuesActuel[2][5][1])+intval($arrayValuesActuel[2][6][1])+intval($arrayValuesActuel[2][7][1])+intval($arrayValuesActuel[2][8][1]); ?>)
                                </label>
                            </div>
                        </div>


                    </div>

                    <div class='panel-heading' style='background-color:#e7722c;font-size:13pt;color:#fff;'>Cash in module  (Actuel)</div>
                    <div style='margin-left: 2px' class='panel-body'>


                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[3][2][0],$arrayValuesActuel[3][5][0]); ?>'>
                            <div class='col-sm-2'>
                                <label>C1</label>
                            </div>

                            <div class='col-sm-5'>
                                <label><?php  echo $arrayValuesActuel[3][5][1]; ?></label>
                            </div>

                            <div class='col-sm-5'>
                                <label><?php  echo $arrayValuesActuel[3][5][0]; ?></label>
                            </div>

                        </div>
                        <div style='background-color:#f9f9f9;<?php echo getColor_for_peripherals_details($arrayValuesActuel[3][2][0],$arrayValuesActuel[3][6][0]); ?>' class='row'>
                            <div class='col-sm-2'>
                                <label>C2</label>
                            </div>

                            <div class='col-sm-5'>
                                <label><?php  echo $arrayValuesActuel[3][6][1]; ?></label>
                            </div>

                            <div class='col-sm-5'>
                                <label><?php  echo $arrayValuesActuel[3][6][0]; ?></label>
                            </div>
                        </div>
                        <div style='background-color:#f9f9f9;<?php echo getColor_for_peripherals_details($arrayValuesActuel[3][2][0],$arrayValuesActuel[3][7][0]); ?>' class='row'>
                            <div class='col-sm-2'>
                                <label>C3</label>
                            </div>

                            <div class='col-sm-5'>
                                <label><?php  echo $arrayValuesActuel[3][7][1]; ?></label>
                            </div>

                            <div class='col-sm-5'>
                                <label><?php  echo $arrayValuesActuel[3][7][0]; ?></label>
                            </div>
                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[3][2][0],$arrayValuesActuel[3][2][0]); ?>'>
                            <div class='col-sm-4'>
                                <label>Device: </label>
                            </div>

                            <div class='col-sm-8'>
                                <label><?php echo $arrayValuesActuel[3][2][0]; ?></label>
                            </div>

                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[3][2][0],$arrayValuesActuel[3][4][0]); ?>'>
                            <div class='col-sm-4'>
                                <label>Acceptor: </label>
                            </div>

                            <div class='col-sm-8'>
                                <label><?php  echo $arrayValuesActuel[3][4][0];?></label>
                            </div>
                        </div>


                    </div>

                    <div class='panel-heading' style='background-color:#e7722c;font-size:13pt;color:#fff;'>Autres périphèriques (Actuel)</div>
                    <div style='margin-left: 2px' class='panel-body'>

                        <div style='background-color:#f9f9f9;<?php echo getColor_for_peripherals_details($arrayValuesActuel[8][2][0],$arrayValuesActuel[8][2][0]); ?>' class='row'>
                            <div class='col-sm-4'>
                                <label>Lecteur de carte</label>
                            </div>
                            <div class='col-sm-8'>
                                <label><?php echo $arrayValuesActuel[8][2][0]; ?></label>
                            </div>
                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[4][2][0],$arrayValuesActuel[4][2][0]); ?>'>
                            <div class='col-sm-4'>
                                <label>Pinpad</label>
                            </div>
                            <div class='col-sm-8'>
                                <label><?php echo $arrayValuesActuel[4][2][0]; ?></label>
                            </div>
                        </div>
                        <div style='background-color:#f9f9f9;<?php echo getColor_for_peripherals_details($arrayValuesActuel[5][2][0],$arrayValuesActuel[5][2][0]); ?>' class='row'>
                            <div class='col-sm-4'>
                                <label>Cheque processor</label>
                            </div>
                            <div class='col-sm-8'>
                                <label><?php echo $arrayValuesActuel[5][2][0]; ?></label>
                            </div>
                        </div>
                        <div class='row' style='<?php echo getColor_for_peripherals_details($arrayValuesActuel[6][2][0],$arrayValuesActuel[6][2][0]); ?>'>
                            <div class='col-sm-4'>
                                <label>Imprimante ticket</label>
                            </div>
                            <div class='col-sm-8'>
                                <label><?php echo $arrayValuesActuel[6][2][0]; ?></label>
                            </div>
                        </div>
                        <div style='background-color:#f9f9f9;<?php echo getColor_for_peripherals_details($arrayValuesActuel[7][2][0],$arrayValuesActuel[7][2][0]); ?>' class='row'>
                            <div class='col-sm-4'>
                                <label>Imprimante journal</label>
                            </div>
                            <div class='col-sm-8'>
                                <label><?php echo $arrayValuesActuel[7][2][0]; ?></label>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
    <div class='modal-footer'>

        <button type='button' class='btn btn-default' data-dismiss='modal'>Fermer</button>

    </div>
    </div>
    </div>
    </div>

    <?php
    echo "
	";

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_gab_hors_service_v2($terminal,$paramettre,$idprivilege,$date_debut,$date_fin,$historique_vacation,$lang)
{



//echo "<pre>";print_r($lang);echo "</pre>";
    $conn=ma_db_connexion();
          //table table-responsive-sm table-bordered table-striped table-sm
    echo '<table class="table table-responsive-sm table-hover table-outline mb-0" >
        <thead class="thead-light">
            <tr>
                <th class="text-center">ID</th>
                <!--<th class="text-center" title="Statut périphérique">S_P</th>-->
                <th class="text-center">'.$lang['atm_id'].'</th>
                <th class="text-center">'.$lang['atm_name'].'</th>
                <th class="text-center">IP</th>
                <th class="text-center">'.$lang['region'].'</th>
                <th class="text-center">'.$lang['stop_date'].'</th>    
                <th class="text-center">'.$lang['cause_default'].'</th>
                <th class="text-center"  >'.$lang['last_cnx'].'</th>
                <th class="text-center">'.$lang['dev_stat'].'</th>
                <th class="text-center">Actions</th>
                <th class="text-center">'.$lang['declar_i'].'</th>
                <th class="text-center">'.$lang['trait'].'</th>
            </tr>
        </thead>
    <tbody>';
    if($_SESSION['lang']==='fr')
    {
        $description='description';
    }
    else
    {
        $description='description_eng';
    }

    //TIMESTAMPDIFF(SECOND ,`last_connexion`,now()) as `desconnected_time`
    $sqlG = "SELECT list_atm_confirmed.`id_atm`, list_atm_confirmed.`terminal`, list_atm_confirmed.`state` ,
    list_atm_confirmed.`state_confirm`,list_atm_confirmed.`ip_adress`,
    atm_list_stopped_test.generartion_date as dateArret, 
    cause_default.".$description." as causeArret, 
    atm_list_stopped_test.id_global_vacation as idVacation,
    `atm_list_stopped_test`.`cause_default` as cause_def,
    atm_list_stopped_test.id_vacation as idVac,
    `list_service`.`service` as descservice,
    `atm_list_stopped_test`.`critical_cash_amount` as mtn_ctr,
    `atm_list_stopped_test`.`generartion_date` as generartion_date,
    `atm_list_stopped_test`.`last_supervised_mode_entry`,
    `atm_list_stopped_test`.`last_rejected_transaction`,
    `atm_list_stopped_test`.`last_reject_reason`,
    `atm_list_stopped_test`.`notificate_in_service_atm`,
    `atm_list_stopped_test`.`stop_date`,
    `list_atm_confirmed`.`last_connexion`  as date_up_atm,
     `atm_list_stopped_test`.`id_logical_name`,
     `atm_list_stopped_test`.`id_insert` as id_arret,
    `atm_list_stopped_test`.`if_checked` as if_checked,
    `atm_list_stopped_test`.`check_cause` as check_cause,
    `cause_default`.`id_default` as id_default,
    TIMESTAMPDIFF(SECOND ,stop_date,now()) as `incident_time`,
    TIMESTAMPDIFF(SECOND ,last_connexion,now()) as `desconnected_time`
     
    FROM `list_atm_confirmed` , atm_list_stopped_test  ,cause_default,list_service
    WHERE `atm_list_stopped_test`.`cause_default` = cause_default.id_default
    AND list_atm_confirmed.id_atm= atm_list_stopped_test.id_atm
    AND `list_service`.`id_service` =  `atm_list_stopped_test`.`id_service`
    AND atm_list_stopped_test.if_declared=0
    AND list_atm_confirmed. state= 1 ORDER BY atm_list_stopped_test.id_insert DESC";

    //echo $sqlG;


    $resultG=mysqli_query($conn,$sqlG);
    if (!$resultG)
    {
        error_log("Erreur SQL 231:  ".$sqlG."  " .mysqli_error($conn));
        die(' ERREUR QUERY 231 !');
    }
	if ($resultG)
	{
		if(mysqli_num_rows($resultG)>0)
		{
		    $o=0;
		    $tableService = array();
		    while ($rowG = mysqli_fetch_assoc($resultG))
            {
                $o++;
                $idfilial=getfilialATM($rowG["id_atm"]);
                list($id_poste_affecter, $name_poste_affecter) = explode('---', get_post_affect_ATM($idfilial));
                $name_poste_affecter=str_replace(CHR(32),'',$name_poste_affecter);
                list($terminalID, $ipAdresseGAB, $nomGAB, $dateAjout,$ville) = explode('---', getinfoATM($rowG["id_atm"]));

                $sql = "SELECT `id_vacation_ALM`, `id_vacation_BCR`, `id_vacation_CAM`, `id_vacation_CDM`, 
                `id_vacation_CEU`, `id_vacation_CHK`, `id_vacation_CIM`, `id_vacation_CRD`, 
                `id_vacation_DEP`, `id_vacation_IDC`, `id_vacation_IPM`, `id_vacation_PIN`, 
                `id_vacation_PTR`, `id_vacation_SIU`, `id_vacation_TTU`, `id_vacation_VDM`, `vacation_date`, `name_file`						
                FROM  `hist_vacations`	WHERE `hist_vacations`.`id_atm` ='".mysqli_real_escape_string($conn,$rowG["id_atm"])."'  
                AND if_load=1 ORDER BY `id_global_vacation` DESC LIMIT 1";
                $k=0;
                $result=mysqli_query($conn,$sql);
                if (!$result)
                {
                    error_log("Erreur SQL 232:  ".$sql."  " .mysqli_error($conn));
                    die(' ERREUR QUERY 232 !');
                }
				if ($result)
                {
                    if (mysqli_num_rows($result)>0)
                    {
                        while ($row = mysqli_fetch_assoc($result))
                        {
                            $state_btn = 'btn-warning';
                            if(get_device_status($rowG["id_atm"],$row["vacation_date"]))
                            {
                                $state_btn = 'btn-info';
                            }
                            $k++;
                            // Verifications Services autorisé.
                            $serviceATMAutorise = explode(',', get_list_service_atm($rowG["id_atm"]));
                            foreach($serviceATMAutorise as $service)
                            {
                                $tableService[] = $service;
                            }

                            echo "<tr id='div_list_gab_hors_serv".$rowG["id_arret"]."'>";

                            /**********************Button Actions********************/

                            /*********************ID ATM********************/
                            echo ' <td class="text-center">'.$rowG["id_atm"].'</td>';

                            /*********************Detail_Peripheral_arret********************/
                            /*echo '<td class="text-center">';

                                getDetail_Peripheral_arret($rowG["id_atm"],$rowG["terminal"],$nomGAB,$rowG["idVacation"]);

                               $diff = strtotime(date("Y-m-d H:i:s")) - strtotime($row["vacation_date"]);

                                get_date_up_atm($diff);

                            echo '</td>';*/

                            /*********************Code GAB ********************/
                            echo ' <td class="text-center" id="div0'.$rowG["id_atm"].'">'.$terminalID.'</td>';

                            if(($paramettre==1) && ($idprivilege==1) ) {echo '<td class="text-center">'.getStatEtatGAB($rowG["state"]).'</td>';}
                            /********************Nom GAB*************************/
                            echo '<td class="text-center">'.$nomGAB.'</td>';

                            /********************Adresse IP*************************/
                            echo '<td class="text-center">'.$ipAdresseGAB.'</td>';

                            /*******************Date Ajout*************************/
                            echo ' <td class="text-center">'.$ville.'</td>';

                            /*******************Date Arret*************************/
                            echo ' <td class="text-center">'.$rowG["stop_date"].'</td>';

                            /*******************Cause Arret*************************/
                            $logical_name=get_Logical_name_By_ID($rowG["id_logical_name"]);
                            echo' <td class="text-center">';
                            if($rowG["cause_def"]==1)
                            {
                                echo ' '.$rowG["causeArret"].' - '.$rowG["descservice"].' ';
                                getDetail_cause_arret($logical_name,$rowG["id_atm"],$rowG["terminal"],$nomGAB,$rowG["idVacation"],$rowG["idVac"],$rowG["descservice"],$lang);
                            }
                            else if($rowG["cause_def"]==3 && $rowG["descservice"]=="CDM")
                            {
                                echo ' '.$rowG["causeArret"].' - '.$rowG["descservice"].' ';
                                getDetail_mnt_crit_att($rowG["id_logical_name"],$rowG["id_atm"],$rowG["terminal"],$nomGAB,$rowG["descservice"],$rowG["mtn_ctr"],$rowG["generartion_date"],$lang);
                            }
                            else if($rowG["cause_def"]==4)
                            {
                                echo ' '.$rowG["causeArret"].' - ';
                                getDetail_Mode_superviseur($logical_name,$rowG["id_atm"],$rowG["terminal"],$nomGAB,$rowG["last_supervised_mode_entry"]);
                            }
                            else if($rowG["cause_def"]==5)
                            {
                                echo ' '.$rowG["causeArret"];
                                //getDetail_Cartes_capturées_successivement($logical_name,$rowG["id_atm"],$rowG["terminal"],$nomGAB);
                            }
                            else if($rowG["cause_def"]==6)
                            {
                                echo ' '.$rowG["causeArret"].' - ';
                                Transactions_annulées_successivement($logical_name,$rowG["id_atm"],$rowG["terminal"],$nomGAB,$rowG["last_rejected_transaction"],$rowG["last_reject_reason"],$lang);
                            }
                            else
                            {
                                echo ' '.$rowG["causeArret"].'  ';
                            }
                            echo' </td>';

                            // /*******************Derniere Connexion au serveur*************************/
                            //echo ' <td>'.getLastConnexionATM_toServer($rowG["id_atm"]).'</td>';

                            /****Durée de déconnection*****/

                            $desconnected_time=secondsToWords($rowG["desconnected_time"]);
                            if($rowG["desconnected_time"]>600)
                            {
                                echo'<td class="text-center">
                                    <span class="badge badge-pill badge-danger">
                                         '.$desconnected_time .' 
                                    </span>
                                </td>';
                            }
                            else
                            {
                                echo'<td class="text-center" >
                                <span class="badge badge-pill badge-secondary">
                                     '.$desconnected_time .'
                                </span>
                                </td>';
                            }

                                    /*******************Statut périphérique**************************************************************************************/
                                    echo '
                                    
                <td> 
                    <div class="span4" align="center">
                        <div class="btn-group"> 
                            <button class="btn '.$state_btn.' dropdown-toggle" id="btnGroupVerticalDrop1" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="cil-airplay"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li >
                                    <div class="btn-group"> ';
                            $service = 4;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CDM"],'vacations_CDM','xfs_errors_CDM','CDM',$row["vacation_date"],'WFS_INF_CDM_STATUS',mysqli_real_escape_string($conn,$row["name_file"]));
                            }
                            $service = 7;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CIM"],'vacations_CIM','xfs_errors_CIM','CIM',$row["vacation_date"],'WFS_INF_CIM_STATUS',mysqli_real_escape_string($conn,$row["name_file"]));
                            }
                            $service = 12;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_PIN"],'vacations_PIN','xfs_errors_PIN','PIN',$row["vacation_date"],'WFS_INF_PIN_STATUS',mysqli_real_escape_string($conn,$row["name_file"]));
                            }
                            $service = 13;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_PTR"],'vacations_PTR','xfs_errors_PTR','PTR',$row["vacation_date"],'WFS_INF_PTR_STATUS',mysqli_real_escape_string($conn,$row["name_file"]));
                            }
                            $service = 10;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_IDC"],'vacations_IDC','xfs_errors_IDC','IDC',$row["vacation_date"],'WFS_INF_IDC_STATUS',mysqli_real_escape_string($conn,$row["name_file"]));
                            }
                            /*$service = 14;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_SIU"],'vacations_SIU','xfs_errors_SIU','SIU',$row["vacation_date"],'WFS_INF_SIU_STATUS',mysqli_real_escape_string($conn,$row["name_file"]));
                            }*/

                            $varcolor=getColorDashboard($rowG["id_atm"]) ;
                            if($varcolor != "#888683")
                            {
                                echo '<a class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                    onClick="javascript:getDashboardATM(\''.$rowG["id_atm"].'\')" 
                                    data-target="#moduleDashboardATM"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-2x" title="CPU,RAM"></i></strong></a> ';
                            }
                            else
                            {
                                echo '<a class="text-center dropdown-item " tabindex="-1"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-2x" title="CPU,RAM"></i></strong></a>';
                            }
                            echo '<a class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                    onClick="javascript:getjournalATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\')"    
                                    data-target="#detailjournalATM"> <strong style="color:#52c322" ><i class="fa fa-newspaper-o fa-2x" title="E-J"> </i></strong></a>';

                            echo '<a  title="'.$lang['cmd_hist'].'" class="text-center dropdown-item " tabindex="-1" data-toggle="modal"
                                    onClick="javascript:getcommandeATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
                                    data-target="#detailcommandeATM"> <strong style="color:#52c322" >
                                    <svg class="icon x128" height="30" width="30">
                                        <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-monitor"></use>
                                    </svg>
                                    </strong></a>';

                            echo '<a title="'.$lang["det_con_gab"].'" class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                    onClick="javascript:getdeconATM(\'' . $rowG["id_atm"] . '\')"    
                                    data-target="#detaildeconATM"> <strong style="color:#52c322;">
                                    <svg class="icon x128" height="30" width="30">
                                        <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-link"></use>
                                    </svg>
                                 </strong></a>';
                            echo '</div>
                                </li>
                            </ul>
                        </div>
                    </div>';

                echo '</td>		';
                            echo '<td class="text-center">';

                            echo ' <div class="btn-group">
                                        <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span class="cil-transfer"></span> </button>
                                <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 34px, 0px); top: 0px; left: 0px; will-change: transform;">';

                            /**********************Redémarrer********************/

                            echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal" 
                                    onClick="javascript:getRedemarrerATM(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
                                    data-target="#detailRedemarrerATM"  aria-pressed="true"><i style="color:#FF0040"  class="cil-pregnant" title="'.$lang["reboot"].'"></i>&nbsp; '.$lang["reboot"].' </a>';
                            /**********************Ping********************/
                            /*echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal"
                            onClick="javascript:getPingATM(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$rowG["id_atm"].'\',\''.$rowG["terminal"].'\',\''.$rowG["ip_adress"].'\')"   
                            data-target="#detailPingATM"  aria-pressed="true"><i style="color:#FF0040"  class="cil-transfer" title="Ping"></i>&nbsp; Ping </a>';*/
                            /********************** Capture écran ATM********************/

                            echo' <a tabindex="-1" class="dropdown-item"  data-toggle="modal" 
                                    onClick="javascript:getScreenshotATM(\''.$rowG["id_atm"].'\')"   
                                    data-target="#detailScreenshotATM"><strong style="color:#FF0040" ><i class="cil-camera" title="'.$lang["screenshot"].'"></i></strong>&nbsp; '.$lang["screenshot"].' </a>';


                            /**********************Historique CMD********************/

                            echo '<a tabindex="-1" class="dropdown-item"  data-toggle="modal" 
                                    onClick="javascript:getcommandeATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
                                    data-target="#detailcommandeATM"> <strong style="color:#FF0040" ><i class="cil-mood-bad" title="'.$lang["cmd_hist"].'"> </i></strong>&nbsp; '.$lang["cmd_hist"].'</a>';



                            /************************Historique vacations*********************/
                            echo "<a class='dropdown-item' tabindex='-1'  href='detailVacation.php?idATM=".$rowG["id_atm"]."&date_vacation=".$row["vacation_date"] . "' target='_blank'><i style='color:#FF0040' class='cil-devices'></i>&nbsp; ".$lang['dev_stat_hist']."</a>";



                            echo ' </div>';
                            echo '  </div>  
                            </td>';
                                /**********************Fin Button ********************/



                                /**********************Déclarer GAB********************/
                                echo ' <td class="text-center">';

                                if(($rowG["terminal"]<>0)  && ($rowG["state"]==1))
                                {
                                        echo "<a name='declarer' href='declarer.php?terminal=".$rowG["terminal"]."&dateArret=".$rowG["stop_date"]."&id_motif=227&id_arret=".$rowG["id_arret"]."'  target='_blank'><strong style='color:#FF0040' ><i class='fa fa-plus-square' title='".$lang['declar_i']."'></i></strong></a>";
                                }

                                echo '</td >';
                                /*********Traité GAB ***********************/
                                check_arret($rowG["terminal"],$rowG["id_atm"],$rowG["if_checked"],$rowG["check_cause"],$rowG["id_arret"],$nomGAB);

                                /*******************************************/

                               get_notification_in_service_atm($rowG["notificate_in_service_atm"]);

                                echo'</tr>';
                        }
                    } //if (mysqli_num_rows($result)>0)
                    mysqli_free_result($result);
                }//if ($result=mysqli_query($conn(),$sql) or die('Erreur   verif_user !<br>'.$sql.'<br>'.mysqli_error()))
            } //if num rows list_atm_confirmed
		}
		mysqli_free_result($resultG);
	} //if ($resultG=mysqli_query($conn(),$sqlG) or die('Erreur   verif_user !<br>'.$sqlG.'<br>'.mysqli_error()))

    echo '</tbody></table></div>';mysqli_close($conn);
}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nbr_incid_gab_ouv($terminal)
{
    $bool_nbr_incid=false;
    $connexion=ma_db_connexion();
    $SQL="SELECT COUNT(1) AS 'nbr_incid' FROM `new_incident_gab_ouvert` WHERE `id_gab` = '".mysqli_real_escape_string($connexion,$terminal)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 01010207:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 01010207 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            if($row["nbr_incid"]>0)
            {
                $bool_nbr_incid=true;
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return $bool_nbr_incid;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function filter_check()
{
		$connexion=ma_db_connexion();
	
	$list="SELECT `id_check`, `cause` FROM `check_incidents_causes` WHERE id_check<>2";
	
	$result=mysqli_query($connexion,$list);
      if (!$result)
      {
          error_log("Erreur SQL 1101: ".$list."  ".mysqli_error($connexion));
          die('ERREUR QUERY 1101 !');
      }
	
	if ($result)
      {
          $i=0;
          while ($row = mysqli_fetch_assoc($result))
          {
              $tt= $i+1;
              // echo $tt;
              // echo"<option value='". $row["id_check"]."'>". $row["cause"]."</option>";
              echo'<option value='. $row["id_check"].'>'. $row["cause"].'</option>';
              $i++;
          }
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function filter_cause_arret()
{
		$connexion=ma_db_connexion();

	$list="SELECT `id_default`, `description` FROM `cause_default` ";

	$result=mysqli_query($connexion,$list);
      if (!$result)
      {
          error_log("Erreur SQL 1101: ".$list."  ".mysqli_error($connexion));
          die('ERREUR QUERY 1101 !');
      }

	if ($result)
      {
          $i=0;
          while ($row = mysqli_fetch_assoc($result))
          {
              $tt= $i+1;

              // echo $tt;
              // echo"<option value='". $row["id_check"]."'>". $row["cause"]."</option>";
              echo'<option value='. $row["id_default"].' >'. $row["description"].'</option>';
              $i++;
          }
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function check_arret($terminal,$id_atm,$traitement,$motif_traiter,$id_arret,$nameATM)
{
	$connexion=ma_db_connexion();
    if($_SESSION['lang']==='fr')
    {
        $cause='cause';
        $close='Fermer';
        $valider='valider';
    }
    else
    {
        $cause='cause_eng';
        $close='Close';
        $valider='validated';
    }
	$list='SELECT `id_check`, '.$cause.' as cause FROM `check_incidents_causes`';
	
	$result=mysqli_query($connexion,$list);
      if (!$result)
      {
          error_log("Erreur SQL 1100: ".$list."  ".mysqli_error($connexion));
          die('ERREUR QUERY 1100 !');
      }
	
	if ($result)
	{
	if($traitement==0)
	{
	    echo "<td data-search='0' id='".$id_arret."'  style='text-align:center'><a data-toggle='modal'  href='#myModalTraiter".$id_arret."'><span class='fa fa-hand-pointer-o'  style='color:red;text-align:center;'></span></a>";
	    echo"<div class='modal fade' id='myModalTraiter".$id_arret."' role='dialog'>
            <div id='modal_d2' class='modal-dialog modal-lg' role='document'>
                <div class='modal-content' style='background-color:#e9ecef;color:#2b3449;'>
				    <div class='modal-header'>
					    <div style='font-size:13pt;color: #43231e;text-align:center;' class='modal-title'   >".$nameATM." - ".$terminal." </div>
						    <button type='button' class='close' data-dismiss='modal'>&times;</button>
                    </div>
                    <div class='modal-body' >
                        <div class='container' >
                            <div class='col-sm-6' >
							    <div  style='text-align:left'>";
	    $i=0;
	    while ($row = mysqli_fetch_assoc($result))
        {
            $tt= $i+1;
            // echo $tt;
            echo"<div class='form-group row'>
                    <input class='form-check-input col-sm-1' type='radio' name='motifTraiterInput".$id_arret."'  id='motifTraiterInput".$tt."".$id_arret."'  value='". $row["id_check"]."'>
                    <label class='form-check-label' for='exampleRadios1'>   ". $row["cause"]."  </label>	
				</div>  ";
            $i++;
        }

        echo "</form>																		
		    </div>								
		</div>
		</div>
										
										</div>
										<div class='modal-footer'>
											<button type='button' class='btn btn-secondary' data-dismiss='modal'>".$close."</button>
											<button type='button' onclick= 'javascript:traiter_arret(".$terminal.",".$traitement.",".$id_arret.")' class='btn btn-primary active' data-dismiss='modal'>".$valider."</button>
										</div>
									</div>	
								</div>
							</div>
						</td>";
	}
	else if ($traitement==1)
	{
	    echo "<td data-search='".$motif_traiter."' id='".$id_arret."'  style='text-align:center' >".getMotifTraiter_ById($motif_traiter)." ";
	    echo"<a data-toggle='modal'  href='#myModalTraiter".$id_arret."'><span class='fa fa-hand-pointer-o'  style='color:green' ></span></a>
		    <div class='modal fade' id='myModalTraiter".$id_arret."' role='dialog'>
			    <div id='modal_d2' class='modal-dialog modal-lg' role='document'>
				    <div class='modal-content' style='background-color:#e9ecef;color:#2b3449;'>
                        <div class='modal-header'>
                            <div style='font-size:13pt;color: #43231e;text-align:center;' class='modal-title'   > ".$nameATM." - ".$terminal." </div>
                            <button type='button' class='close' data-dismiss='modal'>&times;</button>
                        </div>
										<div class='modal-body' >
										<div class='container' >
											<div class='col-sm-6' >
												  
													<div   style='text-align:left'>
													
														";
														$i=0;
                                                        while ($row = mysqli_fetch_assoc($result))
                                                        {
                                                                $tt= $i+1;
                                                                // echo $tt;
                                                            echo"
                                                            <div class='form-group row'>
                                                                <input class='fform-check-input col-sm-1' type='radio' name='motifTraiterInput".$id_arret."'  id='motifTraiterInput".$tt."".$id_arret."'  value='". $row["id_check"]."'>
                                                                    <label class='form-check-label' for='exampleRadios1'>
                                                                ". $row["cause"]."
                                                            
                                                                    </label>	
                                                             </div>
                                                            ";
                                                            $i++;
                                                        }
														
												echo
												"	</form>
											
											</div>
											
										</div>

										</div>
										
										</div>
										<div class='modal-footer'>
											<button type='button' class='btn btn-secondary' data-dismiss='modal'>".$close."</button>
											<button type='button' onclick= 'javascript:traiter_arret(".$terminal.",".$traitement.",".$id_arret.")' class='btn btn-primary active' data-dismiss='modal'>".$valider."</button>
										</div>
									</div>	
								</div>
							</div>";

		echo "</td>";			
	}
		mysqli_free_result($result);	
	}
	mysqli_close($connexion);

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_state_check($id_arret,$terminal,$id_motif)
{
	$conn=ma_db_connexion();
	
	 $resultBool=false;

	$sql = "UPDATE atm_list_stopped_test SET if_checked=1 , check_date=now(),check_user= ".$_SESSION['id_utilisateur']." , 
	check_cause=".mysqli_real_escape_string($conn,$id_motif)."   WHERE id_insert=".mysqli_real_escape_string($conn,$id_arret)." ";
	
    $result=mysqli_query($conn,$sql);
    if (!$result)
		
    {
      // echo" Erreur SQL 2889:  ".$sql."  " .mysqli_error($conn);
	   error_log("Erreur SQL 2890:  ".$sql."  " .mysqli_error($conn));
        die(' ERREUR QUERY 2890 !');
    }
    if ($result)
    {
         $resultBool=true;
		 mysqli_free_result($result);
	}
	mysqli_close($conn);
	return $resultBool;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function delete_checked_in_service_arret($id_arret)
{
	$conn=ma_db_connexion();
	 $resultBool=false;

	$sql = "SELECT `id_insert`, `id_atm`, if_declared,
	`terminal`, `date_insert`, `id_vacation`, `id_service`, `date_vacation`, `generartion_date`, 
	`id_global_vacation`, `cause_default`, `stop_date`, `critical_cash_amount`, `last_withrawel`, 
	`last_money_deposit`, `last_check_deposit`, `last_rejected_transaction`, `last_reject_reason`, 
	`last_supervised_mode_entry`, `last_supervised_mode_exit`, `last_connexion_server`, `last_connexion_client`, 
	`last_in_service`, `last_out_of_service`, `notificate_in_service_atm`, `notification_date`, `if_checked`, `check_date`, 
	`check_user`, `check_cause` FROM `atm_list_stopped_test` WHERE id_insert=".mysqli_real_escape_string($conn,$id_arret)." ";
	
    $result=mysqli_query($conn,$sql);
    if (!$result)
    {
      // echo" Erreur SQL 2889:  ".$sql."  " .mysqli_error($conn);
	   error_log("Erreur SQL 2892:  ".$sql."  " .mysqli_error($conn));
        die(' ERREUR QUERY 2892 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {		
            while ($row = mysqli_fetch_assoc($result))
            {
				$cause=$row["cause"];
				/*********INSERT HISTORY***********/
				if($row["critical_cash_amount"]=="")
				{
					$row["critical_cash_amount"]= 'NULL';	
				}
				
				$sql2 = "INSERT INTO `history_atm_list_stopped`( `id_user_deleted`,  `id_atm`, 
								 `date_insert`, `id_vacation`, `id_service`, `date_vacation`, `generartion_date`, 
								`id_global_vacation`, `cause_default`, `stop_date`, `critical_cash_amount`, `last_withrawel`, 
								`last_money_deposit`, `last_check_deposit`, `last_rejected_transaction`, `last_reject_reason`,
								`last_supervised_mode_entry`, `last_supervised_mode_exit`, `last_connexion_server`, `last_connexion_client`, 
								`last_in_service`, `last_out_of_service`, `notificate_in_service_atm`, `notification_date`, `if_checked`, 
								`check_date`, `check_user`, `check_cause`,if_declared) 
								VALUES (0,".$row["id_atm"].",
								now(),".$row["id_vacation"].",".$row["id_service"].",'".$row["date_vacation"]."','".$row["generartion_date"]."',
								".$row["id_global_vacation"].",".$row["cause_default"].",'".$row["stop_date"]."',
								".$row["critical_cash_amount"].",'".$row["last_withrawel"]."','".$row["last_money_deposit"]."',
								'".$row["last_check_deposit"]."','".$row["last_rejected_transaction"]."','".$row["last_reject_reason"]."',
								'".$row["last_supervised_mode_entry"]."','".$row["last_supervised_mode_exit"]."','".$row["last_connexion_server"]."',
								'".$row["last_connexion_client"]."','".$row["last_in_service"]."','".$row["last_out_of_service"]."',
								'".$row["notificate_in_service_atm"]."','".$row["notification_date"]."','".$row["if_checked"]."',
								'".$row["check_date"]."','".$row["check_user"]."','".$row["check_cause"]."' ,'".$row["if_declared"]."'  )
								";
				$result2=mysqli_query($conn,$sql2);
					if (!$result2)
					{
					  echo" Erreur SQL 2883:  ".$sql2."  " .mysqli_error($conn);
					   error_log("Erreur SQL 2893:  ".$sql2."  " .mysqli_error($conn));
						die(' ERREUR QUERY 2893 !');
					}
					if ($result2)
					{
						/*****************DELETE INCIDENT *************/
						$sqlDelete="DELETE FROM atm_list_stopped_test WHERE  id_insert=".mysqli_real_escape_string($conn,$id_arret)." ";
						$result3=mysqli_query($conn,$sqlDelete);
							if (!$result3)
							{
							  // echo" Erreur SQL 2889:  ".$sql."  " .mysqli_error($conn);
							   error_log("Erreur SQL 2894:  ".$sqlDelete."  " .mysqli_error($conn));
								die(' ERREUR QUERY 2894 !');
							}
							if ($result3)
							{
								$resultBool=true;
							}
						mysqli_free_result($result2);
					}

			}
		}
		mysqli_free_result($result);
	}
	mysqli_close($conn);
	return $resultBool;
	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getMotifTraiter_ById($id)
{
    if($_SESSION['lang']==='fr')
    {
        $causse='cause';
    }
    else
    {
        $causse='cause_eng';
    }
    $conn=ma_db_connexion();
    $cause="";

	$sql = "SELECT `id_check`, ".$causse." as cause FROM check_incidents_causes WHERE id_check=".mysqli_real_escape_string($conn,$id)." ";
	
    $result=mysqli_query($conn,$sql);
    if (!$result)
		
    {
       echo" Erreur SQL 2889:  ".$sql."  " .mysqli_error($conn);
	   error_log("Erreur SQL 2889:  ".$sql."  " .mysqli_error($conn));
        die(' ERREUR QUERY 2889 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {		
            while ($row = mysqli_fetch_assoc($result))
            {
				$cause=$row["cause"];
			}
		}
		mysqli_free_result($result);
	}
	mysqli_close($conn);
	return $cause;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_Logical_name_By_ID($id)
{
	$conn=ma_db_connexion();
	 $logicalName="";

	$sql = "SELECT logical_name
	FROM atm_logical_names WHERE id_logical_name=".mysqli_real_escape_string($conn,$id)." ";
	
    $result=mysqli_query($conn,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 2888:  ".$sql."  " .mysqli_error($conn));
        die(' ERREUR QUERY 2888 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {		
            while ($row = mysqli_fetch_assoc($result))
            {
				$logicalName=$row["logical_name"];
			}
		}
	}
	mysqli_close($conn);
	return $logicalName;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_notification_in_service_atm($state)
{
    $val_stat='ATMs in service';

    if ($_SESSION['lang']=='fr')
    {
        $val_stat='Gab en service';
    }
if ($state==1){echo" <span class='cil-check' style='color:green' title='".$val_stat."'></span>";}

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_up_atm($date_up_atm)
{
    $val_stat='Non-updated statutes';

    if ($_SESSION['lang']=='fr')
    {
        $val_stat='Statuts non actualisés';
    }
    if ($date_up_atm >= 900){ echo" - <span class='cil-watch' style='color:red' title='".$val_stat."'></span>";}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function dureeArretWarning($dateAR){

    $totalDate = date('d-m-Y  H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y')));

    $datetime1 = new DateTime($totalDate);

    $datetime2 = new DateTime($dateAR);

    $difference = $datetime1->diff($datetime2);

    $years = $difference->y;
    $months = $difference->m;
    $days = $difference->d;
    $hours = $difference->h;
    $min = $difference->i;
    $sec = $difference->s;



    $totalMin=($months*30*24*60)+($days*24*60)+($hours*60)+($min);
    if($totalMin > 60){echo "<td align='center' style='padding: 6px;background:#d9534f;'></td>";}
    else if($totalMin > 30){echo "<td align='center' style='padding: 6px;background:#ff915f;'></td>";}
    else{echo "<td align='center' style='padding: 6px;background:#33cc33;'></td>";}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*******************************************************************************************************************************************/
function get_supprimer_incident($idATM)
{
	
	//echo"<td id='suprimer".$idATM."'>";
//<span class='fa fa-times-circle'></span>Supprimer Incident</a>

						 echo"
							<div class='modal-dialog' id='myModalSuprimerGAB".$idATM."' role='dialog'>
								<div id='modal_d2' class='modal-dialog'>
									<div class='modal-content'>
										<div class='modal-header'>
											<button type='button' class='close' data-dismiss='modal'>&times;</button>
											<div style='font-size:13pt;color: #43231e;' class='modal-title' >Suprimer incident ATM</div>
										</div>
										<div class='modal-body'  id='bodyModalEventSuprimer".$idATM."'  style='padding:0px 0px;font-size:10pt;'>
										<div class='container' >";
											echo'
											<div class="row"><label></label></div>
															<div class="row" >
																<div class="col-xs-5">
																		<label>Êtes-vous sûr de vouloir supprimer cet incident ?</label>
																</div>
																<div class="col-xs-1"><label>  </label></div>
															</div>
																';
										echo "						
										</div>

										</div>
										<div class='modal-footer'>
											<button type='button' class='btn btn-default' data-dismiss='modal'>NON</button>
											<button type='button' onclick= 'javascript:suprimerGabHorsService(".$idATM.",".$_SESSION['id_utilisateur'].");' class='btn btn-default'  data-dismiss='modal' >OUI</button>
										</div>
									</div>	
								</div>
							</div>";
							//</div>";
						//echo"</td>";
	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function suprimerGabHorsServ($idAtm,$user)
{
	$conn=ma_db_connexion();

	$sql = "SELECT `date_insert`, `id_vacation`, `id_service`, `date_vacation`, 
	`generartion_date`, `id_global_vacation`, `cause_default`, `stop_date`, `critical_cash_amount`,
	`last_withrawel`, `last_money_deposit`, `last_check_deposit`, `last_rejected_transaction`, `last_reject_reason`, 
	`last_supervised_mode_entry`, `last_supervised_mode_exit`, `last_connexion_server`, `last_connexion_client`,
	`last_in_service`, `last_out_of_service`, `notificate_in_service_atm`, `notification_date`
	FROM atm_list_stopped_test WHERE id_atm=".mysqli_real_escape_string($conn,$idAtm)." ";
	
    mysqli_query($conn,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($conn,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 233:  ".$sql."  " .mysqli_error($conn));
        die(' ERREUR QUERY 233 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
			 $critical_cash_amount=0;
			/*****************GET DATA DELETED**************/
            while ($row = mysqli_fetch_assoc($result))
            {
				
                $date_insert=$row["date_insert"] ;
                $id_vacation=$row["id_vacation"] ;
                $id_service=$row["id_service"] ;
                $date_vacation=$row["date_vacation"] ;
                $generartion_date=$row["generartion_date"] ;
                $id_global_vacation=$row["id_global_vacation"] ;
                $cause_default=$row["cause_default"] ;
                $stop_date=$row["stop_date"] ;
                $critical_cash_amount=$row["critical_cash_amount"] ;
                $last_withrawel=$row["last_withrawel"] ;
                $last_money_deposit=$row["last_money_deposit"] ;
                $last_check_deposit=$row["last_check_deposit"] ;
                $last_rejected_transaction=$row["last_rejected_transaction"] ;
                $last_reject_reason=$row["last_reject_reason"] ;
                $last_supervised_mode_entry=$row["last_supervised_mode_entry"] ;
                $last_supervised_mode_exit=$row["last_supervised_mode_exit"] ;
                $last_connexion_server=$row["last_connexion_server"] ;
                $last_connexion_client=$row["last_connexion_client"] ;
                $last_in_service=$row["last_in_service"] ;
                $last_out_of_service=$row["last_out_of_service"] ;
                $notificate_in_service_atm=$row["notificate_in_service_atm"] ;
                $notification_date=$row["notification_date"] ;
            }
			if($critical_cash_amount)
			{
				
			} else {$critical_cash_amount=0;}
			/*****************INSERT HISTORY**************/
					$sqlInsert = "INSERT INTO history_atm_list_stopped (id_user_deleted,date_delete,id_atm,`date_insert`, `id_vacation`, `id_service`, `date_vacation`, 
					`generartion_date`, `id_global_vacation`, `cause_default`, `stop_date`, `critical_cash_amount`,
					`last_withrawel`, `last_money_deposit`, `last_check_deposit`, `last_rejected_transaction`, `last_reject_reason`, 
					`last_supervised_mode_entry`, `last_supervised_mode_exit`, `last_connexion_server`, `last_connexion_client`,
					`last_in_service`, `last_out_of_service`, `notificate_in_service_atm`, `notification_date`) 
					VALUES ( ".mysqli_real_escape_string($conn,$_SESSION['id_utilisateur']).",now(),'".mysqli_real_escape_string($conn,$idAtm)."','".mysqli_real_escape_string($conn,$date_insert)."',
					'".mysqli_real_escape_string($conn,$id_vacation)."','".mysqli_real_escape_string($conn,$id_service)."','".mysqli_real_escape_string($conn,$date_vacation)."',
					'".mysqli_real_escape_string($conn,$generartion_date)."','".mysqli_real_escape_string($conn,$id_global_vacation)."','".mysqli_real_escape_string($conn,$cause_default)."',
					'".mysqli_real_escape_string($conn,$stop_date)."','".mysqli_real_escape_string($conn,$critical_cash_amount)."','".mysqli_real_escape_string($conn,$last_withrawel)."',
					'".mysqli_real_escape_string($conn,$last_money_deposit)."','".mysqli_real_escape_string($conn,$last_check_deposit)."','".mysqli_real_escape_string($conn,$last_rejected_transaction)."',
					'".mysqli_real_escape_string($conn,$last_reject_reason)."','".mysqli_real_escape_string($conn,$last_supervised_mode_entry)."',
					'".mysqli_real_escape_string($conn,$last_supervised_mode_exit)."','".mysqli_real_escape_string($conn,$last_connexion_server)."','".mysqli_real_escape_string($conn,$last_connexion_client)."',
					'".mysqli_real_escape_string($conn,$last_in_service)."','".mysqli_real_escape_string($conn,$last_out_of_service)."',
					'".mysqli_real_escape_string($conn,$notificate_in_service_atm)."','".mysqli_real_escape_string($conn,$notification_date)."')
					";
					
					mysqli_query($conn,"SET CHARACTER SET 'utf8'");
                    $resultInsert=mysqli_query($conn,$sqlInsert);
                    if (!$resultInsert)
                    {
                        error_log("Erreur SQL 234:  ".$sqlInsert."  " .mysqli_error($conn));
                        die(' ERREUR QUERY 234 !');
                    }
                    if ($resultInsert)
					{

					    $sqlDelete="DELETE FROM atm_list_stopped_test WHERE id_atm='".mysqli_real_escape_string($conn,$idAtm)."' ";
                        $resultDelete=mysqli_query($conn,$sqlDelete);
                        if (!$resultDelete)
                        {
                            error_log("Erreur SQL 235:  ".$sqlDelete."  " .mysqli_error($conn));
                            die(' ERREUR QUERY 235 !');
                        }

					}
					mysqli_free_result($resultInsert);
			
			
        }	
    }
	mysqli_free_result($result);
	mysqli_close($conn);

	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function secondsToWords($seconds)
{
    $ret = "";

    /*** get the days ***/
    $days = intval(intval($seconds) / (3600*24));
    if($days> 0)
    {
        if($_SESSION['lang']==='fr')
        {
            $ret .= $days." j ";
        }
        else
        {
            $ret .= $days." Day ";
        }


    }

    /*** get the hours ***/
    $hours = (intval($seconds) / 3600) % 24;
    if($hours > 0)
    {
        $ret .= $hours."h:";
    }

    /*** get the minutes ***/
    $minutes = (intval($seconds) / 60) % 60;
    //if($minutes > 0)
    {
        $ret .= $minutes."m";
    }

    /*** get the seconds ***/
    $seconds = intval($seconds) % 60;
    if ($seconds > 0)
    {
        $ret .= ":".$seconds."s";
    }

    return $ret;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_gab_deconnecte($terminal,$paramettre,$idprivilege,$date_debut,$date_fin,$historique_vacation,$lang)
{

    echo '<div>
            <table  class="table table-responsive-sm table-hover table-outline mb-0">
                <thead class="thead-light">
                    <tr>
                        <th class="text-center">ID</th>
                        <th class="text-center">'.$lang['atm_id'].'</th>
                        <th class="text-center">'.$lang['atm_name'].'</th>
                        <th class="text-center">IP</th>
                        <th class="text-center">'.$lang['region'].'</th>
                        <th class="text-center">'.$lang['logout_date'].'</th>    
                        <th class="text-center">'.$lang['last_conn'].'</th>
                       <!-- <th class="text-center">S_P</th>-->
                        <th class="text-center">'.$lang['dev_stat'].' </th>
                        <th class="text-center">Actions</th>
                        <th class="text-center">'.$lang['declar_i'].'</th>
                        
                    </tr>
                </thead>
            <tbody>';

    //////***********************************Info ATM*********************************************//////
    $connexion=ma_db_connexion();
    $sqlG = "SELECT list_atm_confirmed.`id_atm`, list_atm_confirmed.`terminal`, list_atm_confirmed.`state` ,
    list_atm_confirmed.`state_confirm`,list_atm_confirmed.`ip_adress`,
    atm_logical_names.last_connexion_client as dateArret, TIMESTAMPDIFF(SECOND ,atm_logical_names.last_connexion_client,now()) as desconnected_time
    FROM `list_atm_confirmed` , atm_logical_names  
    WHERE list_atm_confirmed.id_atm= atm_logical_names.id_atm
    AND list_atm_confirmed.state=1
    AND list_atm_confirmed.terminal NOT IN (SELECT id_gab FROM new_incident_gab_ouvert WHERE id_action_fonctionelle in ('419','380','381'))
    AND TIMESTAMPDIFF(SECOND ,atm_logical_names.last_connexion_client,now()) >= 900 GROUP BY atm_logical_names.`id_atm`";
    $resultG=mysqli_query($connexion,$sqlG);
    if (!$resultG)
    {
        error_log("Erreur SQL 236:  ".$sqlG."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 236 !');
    }
    if ($resultG)
    {
        if(mysqli_num_rows($resultG)>0)
        {
            $o=0;
            $tableService = array();
            while ($rowG = mysqli_fetch_assoc($resultG))
            {
                $o++;
                $idfilial=getfilialATM($rowG["id_atm"]);
                list($id_poste_affecter, $name_poste_affecter) = explode('---', get_post_affect_ATM($idfilial));
                $name_poste_affecter=str_replace(CHR(32),'',$name_poste_affecter);
                list($terminalID, $ipAdresseGAB, $nomGAB, $dateAjout,$ville) = explode('---', getinfoATM($rowG["id_atm"]));
                //////***************************************************************************************************/////
                //////***********************************Vacation*********************************************//////
                $sql = "SELECT `id_vacation_ALM`, `id_vacation_BCR`, `id_vacation_CAM`, `id_vacation_CDM`, 
                `id_vacation_CEU`, `id_vacation_CHK`, `id_vacation_CIM`, `id_vacation_CRD`, 
                `id_vacation_DEP`, `id_vacation_IDC`, `id_vacation_IPM`, `id_vacation_PIN`, 
                `id_vacation_PTR`, `id_vacation_SIU`, `id_vacation_TTU`, `id_vacation_VDM`, `vacation_date`, `name_file`						
                FROM  `hist_vacations`	WHERE `hist_vacations`.`id_atm` ='".mysqli_real_escape_string($connexion,$rowG["id_atm"])."'  
                AND if_load=1
                ORDER BY `id_global_vacation` DESC
                LIMIT 1";

                $k=0;
                $result=mysqli_query($connexion,$sql);
                if (!$result)
                {
                    error_log("Erreur SQL 237:  ".$sql."  " .mysqli_error($connexion));
                    die(' ERREUR QUERY 237 !');
                }
                if ($result)
                {
                    if (mysqli_num_rows($result)>0)
                    {
                        while ($row = mysqli_fetch_assoc($result))
                        {
                            $state_btn = 'btn-warning';
                            if(get_device_status($rowG["id_atm"],$row["vacation_date"]))
                            {
                                $state_btn = 'btn-info';
                            }
                            $k++;

                            // Verifications Services autorisé.
                            $serviceATMAutorise = explode(',', get_list_service_atm($rowG["id_atm"]));
                            foreach($serviceATMAutorise as $service)
                            {
                                $tableService[] = $service;
                            }

                            echo '<tr>';



                            /*********************ID ATM********************/
                            echo '<td class="text-center">'.$rowG["id_atm"].'</td>';

                            /*********************Code GAB ********************/
                            echo ' <td class="text-center" id="div0'.$rowG["id_atm"].'" >'.$terminalID.'</td>';




                            if(($paramettre==1) && ($idprivilege==1) ) {echo '<td>'.getStatEtatGAB($rowG["state"]).'</td>';}
                            /********************Nom GAB*************************/
                            echo '<td class="text-center">'.$nomGAB.'</td>';

                            /********************Adresse IP*************************/
                            echo '<td class="text-center ">'. $ipAdresseGAB .'</td>	';

                            /*******************Ville*************************/
                            echo ' <td class="text-center">'.$ville.'</td>';

                            // /*******************Date Vacation*************************/
                            // echo ' <td>'.$row["vacation_date"].'</td>';

                            /*******************Date Arret*************************/
                            echo ' <td class="text-center">'.$rowG["dateArret"].'</td>';

                            // /*******************Time Arret*************************/

                            if($rowG["desconnected_time"]>60)
                            {
                                $desconnected_time=secondsToWords($rowG["desconnected_time"]);
                            }
                            else
                            {
                                $desconnected_time = $rowG["desconnected_time"]."Sec";
                            }
                            echo'<td class="text-center">
                                <span class="badge badge-pill badge-secondary">
                                    '.$desconnected_time .'
                                </span>
                            </td>';

                            // /*******************Derniere Connexion au serveur*************************/


                           /* echo '<td class="text-center">';
                            $Detail_Peripheral=get_value_Peripheral_arret($terminalID);
                             getDetail_Peripheral_arret($Detail_Peripheral[0],$Detail_Peripheral[1],$nomGAB,$Detail_Peripheral[2]);
                            //getDetail_Peripheral_gab($Detail_Peripheral[0],$Detail_Peripheral[1],$nomGAB,$Detail_Peripheral[2]);
                            get_date_up_atm($Detail_Peripheral[3]);
                            echo'</td>';*/
                            /*******************Statut périphérique**************************************************************************************/
                            echo '<td >
                           <div class="span4" align="center">
                        <div class="btn-group"> 
                            <button class="btn '.$state_btn.' dropdown-toggle" id="btnGroupVerticalDrop1" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="cil-airplay"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li >
                                    <div class="btn-group"> ';
                            $service = 4;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CDM"],'vacations_CDM','xfs_errors_CDM','CDM',$row["vacation_date"],'WFS_INF_CDM_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                            }
                            $service = 7;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CIM"],'vacations_CIM','xfs_errors_CIM','CIM',$row["vacation_date"],'WFS_INF_CIM_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                            }
                            $service = 12;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_PIN"],'vacations_PIN','xfs_errors_PIN','PIN',$row["vacation_date"],'WFS_INF_PIN_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                            }
                            $service = 13;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_PTR"],'vacations_PTR','xfs_errors_PTR','PTR',$row["vacation_date"],'WFS_INF_PTR_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                            }
                            $service = 10;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_IDC"],'vacations_IDC','xfs_errors_IDC','IDC',$row["vacation_date"],'WFS_INF_IDC_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                            }
                            /*$service = 14;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_SIU"],'vacations_SIU','xfs_errors_SIU','SIU',$row["vacation_date"],'WFS_INF_SIU_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                            }*/

                            $varcolor=getColorDashboard($rowG["id_atm"]) ;
                            if($varcolor != "#888683")
                            {
                                echo '<a class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                    onClick="javascript:getDashboardATM(\''.$rowG["id_atm"].'\')" 
                                    data-target="#moduleDashboardATM"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-2x" title="CPU,RAM"></i></strong></a> ';
                            }
                            else
                            {
                                echo '<a class="text-center dropdown-item " tabindex="-1"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-2x" title="CPU,RAM"></i></strong></a>';
                            }
                            echo '<a class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                    onClick="javascript:getjournalATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\')"    
                                    data-target="#detailjournalATM"> <strong style="color:#52c322" ><i class="fa fa-newspaper-o fa-2x" title="E-J"> </i></strong></a>';

                            echo '<a class="text-center dropdown-item "  title="'.$lang['cmd_hist'].'" tabindex="-1" data-toggle="modal"
                                    onClick="javascript:getcommandeATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
                                    data-target="#detailcommandeATM"> <strong style="color:#52c322" >
                                    <svg class="icon x128" height="30" width="30">
                                        <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-monitor"></use>
                                    </svg>
                                   </strong></a>';

                            echo '<a title="'.$lang["det_con_gab"].'" class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                    onClick="javascript:getdeconATM(\'' . $rowG["id_atm"] . '\')"    
                                    data-target="#detaildeconATM"> <strong style="color:#52c322;">
                                   <svg class="icon x128" height="30" width="30">
                                        <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-link"></use>
                                    </svg>
                                    </strong></a>';
                            echo '</div>
                                </li>
                            </ul>
                        </div>
                    </div>';

                            echo '</td>	';

							/**********************Button Actions********************/
                            echo '<td class="text-center">';

                            echo ' <div class="btn-group">
                                        <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span class="cil-transfer"></span> </button>
                                <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 34px, 0px); top: 0px; left: 0px; will-change: transform;">';
                            /**********************Config Admin********************/

                            /*********************************************************/
                            /**********************Redémarrer********************/

                            echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal" 
                                    onClick="javascript:getRedemarrerATM(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
                                    data-target="#detailRedemarrerATM"  aria-pressed="true"><i style="color:#FF0040"  class="cil-pregnant" title="'.$lang['reboot'].' "></i>&nbsp; '.$lang["reboot"].'  </a>';

                            /*********************************************************
                            /**********************Ping********************/
                            /*echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal"
                            onClick="javascript:getPingATM(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$rowG["id_atm"].'\',\''.$rowG["terminal"].'\',\''.$rowG["ip_adress"].'\')"   
                            data-target="#detailPingATM"  aria-pressed="true"><i style="color:#FF0040"  class="cil-transfer" title="Ping"></i>&nbsp; Ping </a>';*/
                            /*********************************************************
                            /********************** Capture écran ATM********************/

                            echo' <a tabindex="-1" class="dropdown-item"  data-toggle="modal" 
                                    onClick="javascript:getScreenshotATM(\''.$rowG["id_atm"].'\')"   
                                    data-target="#detailScreenshotATM"><strong style="color:#FF0040" ><i class="cil-camera" title="'.$lang["screenshot"].'"></i></strong>&nbsp;  '.$lang["screenshot"].'     </a>';

                            /**********************Historique CMD********************/

                            echo '<a tabindex="-1" class="dropdown-item"  data-toggle="modal" 
                                    onClick="javascript:getcommandeATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
                                    data-target="#detailcommandeATM"> <strong style="color:#FF0040" ><i class="cil-mood-bad" title="'.$lang["cmd_hist"].'" > </i></strong>&nbsp; '.$lang["cmd_hist"].'  </a>';



                            /************************Historique vacations*********************/
                            echo "<a class='dropdown-item' tabindex='-1'  href='detailVacation.php?idATM=".$rowG["id_atm"]."&date_vacation=".$row["vacation_date"] . "' target='_blank'><i style='color:#FF0040' class='cil-devices'></i>&nbsp; ".$lang['dev_stat_hist']."</a>";



                            echo ' </div>';
                            echo '  </div>  
                                      </td>';
                            /**********************Fin Button ********************/
                            /**********************Déclarer GAB********************/
                            echo ' <td class="text-center">';
                            // if (($_SESSION['id_utilisateur']==46) || ($_SESSION['id_utilisateur']==185))
                            {
                                if(($rowG["terminal"]<>0) && ($rowG["state"]==1))
                                {
                                    echo "<a name='declarer' href='declarer.php?terminal=".$rowG["terminal"]."&dateArret=".$rowG["dateArret"]."&id_motif=227' target='_blank'><strong style='color:#FF0040' ><i class='fa fa-plus-square' title='".$lang['declar_i']."'></i></strong></a>";
                                }
                                /**********************Si Nouveau GAB********************/

                            }
                            echo '</td>
                            
							</tr>';

                        }

                    } //if (mysqli_num_rows($result)>0)
                    mysqli_free_result($result);
                }//if ($result=mysqli_query($connexion,$sql) or die('Erreur   verif_user !<br>'.$sql.'<br>'.mysqli_error()))
            }
        }

        mysqli_free_result($resultG);
    } //if ($resultG=mysqli_query($connexion,$sqlG) or die('Erreur   verif_user !<br>'.$sqlG.'<br>'.mysqli_error()))
mysqli_close($connexion);


          echo '  </tbody>
        </table>
    </div>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///
function get_gab_deconnecte_2h($terminal,$paramettre,$idprivilege,$date_debut,$date_fin,$historique_vacation)
{

    echo '<div>
   <div id="table-filter"  class="col-md-2" style="display:none">
                            <select id="regionid[]"  class="selectpicker form-control" data-live-search="false"  data-hide-disabled="true" data-actions-box="true" >
                            <option value="">All</option>';
    getNamePost();
    echo '</select>
                     </div>

            <table id="table_gab_deconnecte_2h" class="display table table-bordered" style="font-size:11px;font-weight:bold;text-align: center;width:100%;border-color: #FFFFFF;" >
                <thead class="text-warning">
                    <tr>
                        <th style="text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;" >ID ATM</th>
                        <th style="text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;" >Terminal</th>
                        <th style="text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;" >Libellé GAB</th>
                        <th style="text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;" >IP</th>
                        <th style="text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;" >Region</th>
                        <th style="text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;" >Date déconnexion</th>    
                        <th style="text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;" >Dernière connexion</th>
                        <th style="text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;"  >S_P </th>
                        <th style="text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;"  >Détails périphériques </th>
                        <th style="text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;" >Actions</th>
                        <th style="text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;" >Déclarer</th>
                        <th style="text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;display:none;"  >Post affecté </th>
                    </tr>
                </thead>
            <tbody>';

    //////***********************************Info ATM*********************************************//////
    $connexion=ma_db_connexion();
    $sqlG = "SELECT list_atm_confirmed.`id_atm`, list_atm_confirmed.`terminal`, list_atm_confirmed.`state` ,
    list_atm_confirmed.`state_confirm`,list_atm_confirmed.`ip_adress`,
    atm_logical_names.last_connexion_client as dateArret, TIMESTAMPDIFF(SECOND ,atm_logical_names.last_connexion_client,now()) as desconnected_time
    FROM `list_atm_confirmed` , atm_logical_names  
    WHERE list_atm_confirmed.id_atm= atm_logical_names.id_atm
    AND list_atm_confirmed.state=1
    AND list_atm_confirmed.terminal NOT IN (SELECT id_gab FROM new_incident_gab_ouvert WHERE id_action_fonctionelle in ('419','380','381'))
    AND TIMESTAMPDIFF(SECOND ,atm_logical_names.last_connexion_client,now()) >= 900 
    AND TIMESTAMPDIFF(SECOND ,atm_logical_names.last_connexion_client,now()) <= 7200 
    GROUP BY atm_logical_names.`id_atm`";
    $resultG=mysqli_query($connexion,$sqlG);
    if (!$resultG)
    {
        error_log("Erreur SQL 236:  ".$sqlG."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 236 !');
    }
    if ($resultG)
    {
        if(mysqli_num_rows($resultG)>0)
        {
            $o=0;
            $tableService = array();
            while ($rowG = mysqli_fetch_assoc($resultG))
            {
                $o++;
                $idfilial=getfilialATM($rowG["id_atm"]);
                list($id_poste_affecter, $name_poste_affecter) = explode('---', get_post_affect_ATM($idfilial));
                $name_poste_affecter=str_replace(CHR(32),'',$name_poste_affecter);
                list($terminalID, $ipAdresseGAB, $nomGAB, $dateAjout,$ville) = explode('---', getinfoATM($rowG["id_atm"]));
                //////***************************************************************************************************/////
                //////***********************************Vacation*********************************************//////
                $sql = "SELECT `id_vacation_ALM`, `id_vacation_BCR`, `id_vacation_CAM`, `id_vacation_CDM`, 
								`id_vacation_CEU`, `id_vacation_CHK`, `id_vacation_CIM`, `id_vacation_CRD`, 
								`id_vacation_DEP`, `id_vacation_IDC`, `id_vacation_IPM`, `id_vacation_PIN`, 
								`id_vacation_PTR`, `id_vacation_SIU`, `id_vacation_TTU`, `id_vacation_VDM`, `vacation_date`, `name_file`						
								FROM  `hist_vacations`	WHERE `hist_vacations`.`id_atm` ='".mysqli_real_escape_string($connexion,$rowG["id_atm"])."'  
								AND if_load=1
								ORDER BY `id_global_vacation` DESC
								LIMIT 1";

                $k=0;
                $result=mysqli_query($connexion,$sql);
                if (!$result)
                {
                    error_log("Erreur SQL 237:  ".$sql."  " .mysqli_error($connexion));
                    die(' ERREUR QUERY 237 !');
                }
                if ($result)
                {
                    if (mysqli_num_rows($result)>0)
                    {
                        while ($row = mysqli_fetch_assoc($result))
                        {
                            $k++;

                            // Verifications Services autorisé.
                            $serviceATMAutorise = explode(',', get_list_service_atm($rowG["id_atm"]));
                            foreach($serviceATMAutorise as $service)
                            {
                                $tableService[] = $service;
                            }

                            echo '<tr>';



                            /*********************ID ATM********************/
                            echo '<td>'.$rowG["id_atm"].'</td>';

                            /*********************Code GAB ********************/
                            echo ' <td id="div0'.$rowG["id_atm"].'" scope="row">'.$terminalID.'</td>';

                            if(($paramettre==1) && ($idprivilege==1) ) {echo '<td>'.getStatEtatGAB($rowG["state"]).'</td>';}
                            /********************Nom GAB*************************/
                            echo '<td>'.$nomGAB.'</td>';

                            /********************Adresse IP*************************/
                            echo '<td>';
							echo $ipAdresseGAB;
                            /*if ($ipAdresseGAB==$rowG["ip_adress"]){echo $ipAdresseGAB;}
                            else{echo $rowG["ip_adress"];}*/
                            echo '</td>	';

                            /*******************Ville*************************/
                            echo ' <td>'.$ville.'</td>';

                            // /*******************Date Vacation*************************/
                            // echo ' <td>'.$row["vacation_date"].'</td>';

                            /*******************Date Arret*************************/
                            echo ' <td>'.$rowG["dateArret"].'</td>';

                            // /*******************Time Arret*************************/

                            if($rowG["desconnected_time"]>60)
                            {
                                $desconnected_time=secondsToWords($rowG["desconnected_time"]);
                            }
                            else
                            {
                                $desconnected_time = $rowG["desconnected_time"]."Sec";
                            }
                            echo'<td data-sort="'.$rowG["desconnected_time"].'">'.$desconnected_time .'</td>';



                            // /*******************Derniere Connexion au serveur*************************/


                            echo '<td>';
                            $Detail_Peripheral=get_value_Peripheral_arret($terminalID);
                            getDetail_Peripheral_arret($Detail_Peripheral[0],$Detail_Peripheral[1],$nomGAB,$Detail_Peripheral[2]);
                            //getDetail_Peripheral_gab($Detail_Peripheral[0],$Detail_Peripheral[1],$nomGAB,$Detail_Peripheral[2]);
                            get_date_up_atm($Detail_Peripheral[3]);
                            echo'</td>';
                            /*******************Statut périphérique**************************************************************************************/
                            echo '<td>';
                            echo'<table style="width: 100%"><tr>';
                            /*******************************STATUS ALM *********************************/
                            /*$service = 1;


                            if (in_array($service, $tableService))//Verifications Services autorisation services
								{
                                    echo'<td style="padding-left: 0px; padding-right: 5px;">';
									getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_ALM"],'vacations_ALM','xfs_errors_ALM','ALM',$row["vacation_date"],'WFS_INF_ALM_STATUS',$row["name_file"]);
                                    echo'</td>';
								}*/
                            /*******************************STATUS BCR *********************************/
                            /*$service = 2;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
								{
                                    echo'<td style="padding-left: 0px; padding-right: 5px;">';
									getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_BCR"],'vacations_BCR','xfs_errors_BCR','BCR',$row["vacation_date"],'WFS_INF_BCR_STATUS',$row["name_file"]);
                                    echo'</td>';
								}*/
                            /*******************************STATUS CAM*********************************/
                            /*$service = 3;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
								{
                                    echo'<td style="padding-left: 0px; padding-right: 5px;">';
									getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CAM"],'vacations_CAM','xfs_errors_CAM','CAM',$row["vacation_date"],'WFS_INF_CAM_STATUS',$row["name_file"]);
                                    echo'</td>';
								}*/
                            /*******************************STATUS CDM*********************************/
                           /* $service = 4;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                echo'<td style="padding-left: 0px; padding-right: 5px;">';
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CDM"],'vacations_CDM','xfs_errors_CDM','CDM',$row["vacation_date"],'WFS_INF_CDM_STATUS',$row["name_file"]);
                                echo'</td>';
                            }*/
                            /*******************************STATUS CDM Cassettes *********************************/
                            $service = 4;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                echo'<td style="padding-left: 0px; padding-right: 5px;">';
                                getStatus2Vacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CDM"],'vacations_CDM','xfs_errors_CDM','CDM2',$row["vacation_date"],'WFS_INF_CDM_CASH_UNIT_INFO',$row["name_file"],'CASH','CDM');
                                echo'</td>';
                            }
                            /*******************************STATUS CEU *********************************/

                            /*******************************STATUS CHK*********************************/
                            /*$service = 6;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
								{
                                    echo'<td style="padding-left: 0px; padding-right: 5px;">';
									getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CHK"],'vacations_CHK','xfs_errors_CHK','CHK',$row["vacation_date"],'WFS_INF_CHK_STATUS',$row["name_file"]);
                                    echo'</td>';
								}*/
                            /*******************************STATUS CIM*********************************/
                            $service = 7;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                echo'<td style="padding-left: 0px; padding-right: 5px;">';
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CIM"],'vacations_CIM','xfs_errors_CIM','CIM',$row["vacation_date"],'WFS_INF_CIM_STATUS',$row["name_file"]);
                                echo'</td>';
                            }
                            /*******************************STATUS CIM logical*********************************/
                                /*$service = 7;
                                if (in_array($service, $tableService))//Verifications Services autorisation services
                                {
                                    echo'<td style="padding-left: 0px; padding-right: 5px;">';
                                    getStatus2Vacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CIM"],'vacations_CIM','xfs_errors_CIM','CIM2',$row["vacation_date"],'WFS_INF_CIM_CASH_UNIT_INFO',$row["name_file"],'CASH','CDM');
                                    echo'</td>';
                                }*/

                            /*******************************STATUS CRD *********************************/

                            /*******************************STATUS DEP *********************************/

                            /*******************************STATUS IPM*********************************/

                            /*******************************STATUS PIN*********************************/
                            $service = 12;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                echo'<td style="padding-left: 0px; padding-right: 5px;">';
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_PIN"],'vacations_PIN','xfs_errors_PIN','PIN',$row["vacation_date"],'WFS_INF_PIN_STATUS',$row["name_file"]);
                                echo'</td>';
                            }
                            /*******************************STATUS PTR*********************************/
                            $service = 13;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                echo'<td style="padding-left: 0px; padding-right: 5px;">';
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_PTR"],'vacations_PTR','xfs_errors_PTR','PTR',$row["vacation_date"],'WFS_INF_PTR_STATUS',$row["name_file"]);
                                echo'</td>';
                            }
                            /*******************************STATUS IDC*********************************/
                            $service = 10;
                            if (in_array($service, $tableService))//Verifications Services autorisation services
                            {
                                echo'<td style="padding-left: 0px; padding-right: 5px;">';
                                getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_IDC"],'vacations_IDC','xfs_errors_IDC','IDC',$row["vacation_date"],'WFS_INF_IDC_STATUS',$row["name_file"]);
                                echo'</td>';
                            }
                            /*******************************STATUS SIU*********************************/
                            /* $service = 14;
                             if (in_array($service, $tableService))//Verifications Services autorisation services
                             {
                                 echo'<td style="padding-left: 0px; padding-right: 5px;">';
                                 getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_SIU"],'vacations_SIU','xfs_errors_SIU','SIU',$row["vacation_date"],'WFS_INF_SIU_STATUS',$row["name_file"]);
                                 echo'</td>';
                             }*/
                            /*******************************STATUS TTU*********************************/


                            /*******************************STATUS VDM*********************************/
                            /*******************************DASHBOARD*********************************/
                            $varcolor=getColorDashboard($rowG["id_atm"]) ;
                            if($varcolor != "#888683")
                            {
                                echo '<td style="padding-left: 0px; padding-right: 5px;">
                                            <a tabindex="-1" data-toggle="modal" 
                                            onClick="javascript:getDashboardATM(\''.$rowG["id_atm"].'\')" 
											data-target="#moduleDashboardATM"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-3x" title="CPU,RAM"></i></strong></a>
                                            </td>';
                            }
                            else
                            {
                                echo '<td style="padding-left: 0px; padding-right: 5px;">
                                            <a tabindex="-1"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-3x" title="CPU,RAM"></i></strong></a>
                                            </td>';
                            }

                            /*******************************DASHBOARD*********************************/

                            echo '<td style="padding-left: 0px; padding-right: 5px;">';
                            echo '<a tabindex="-1" data-toggle="modal" 
                            onClick="javascript:getjournalATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\')"    
                            data-target="#detailjournalATM"> <strong style="color:#52c322" ><i class="fa fa-newspaper-o fa-3x" title="Journal "> </i></strong></a>';
                            echo '</td>	';

                            /*******************************Historique CMD*********************************/

                            echo '<td style="padding-left: 0px; padding-right: 5px;">';
                            echo '<a tabindex="-1" data-toggle="modal"
                                        onClick="javascript:getcommandeATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
                                        data-target="#detailcommandeATM"> <strong style="color:#52c322" ><i class="fa fa-desktop  fa-2x" title="Historique CMD "> </i></strong></a>';
                            echo '</td>	';

                            /*******************************Déconnexion*********************************/

                            echo '<td style="padding-left: 0px; padding-right: 5px;">';
                            echo '<a tabindex="-1" data-toggle="modal" 
                                onClick="javascript:getdeconATM(\'' . $rowG["id_atm"] . '\')"    
                                data-target="#detaildeconATM"> <strong style="color:#52c322;"><i class="fa fa-link fa-2x" title="Déconnexion"></i></strong></a>';
                            echo '</td>	';

                            echo' </tr></table>';
                            echo '</td>	';

                            /**********************Button Actions********************/
                            echo '<td align="center">';
                            echo ' <div class="dropdown clearfix">
												<button class="btn btn-danger" data-toggle="dropdown"> <span class="fa fa-hand-pointer-o"></span> </button>
												
										<ul  style="z-index: 1;" class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" >';
                            /**********************Config Admin********************/
                            if ($idprivilege==1)
                            {
                                echo ' <li>';echo '<a tabindex="-1"  data-toggle="modal" 
																	onClick="javascript:getConfigServiceATM(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
																	data-target="#detailConfigServiceATM"><strong style="color:#FF0040" ><i class="fa  fa-dot-circle-o" title="Service"></i></strong> Service</a>';echo'</li> 
																	 
																	 <li>';echo '<a tabindex="-1"  data-toggle="modal" 
																	onClick="javascript:getConfigLogicalNameService(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
																	data-target="#detailConfigLogicalNameServiceATM"><strong style="color:#FF0040" ><i class="fa  fa-gear" title="Logical Name"></i></strong> Logical Name</a>';echo'</li> 
																	 
																	 <li>';echo '<a tabindex="-1"  data-toggle="modal" 
																	onClick="javascript:getConfigStatusLogicalName(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
																	data-target="#detailConfigStatusLogicalNameATM"><strong style="color:#FF0040" ><i class="fa fa-cogs" title="Status XFS erreurs"></i></strong> XFS erreurs</a>';echo'</li>';

                                echo '	 <li>';echo '<a tabindex="-1"  data-toggle="modal" 
																	onClick="javascript:getConfigStatusXFSName(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
																	data-target="#detailConfigStatusXFSNameATM"><strong style="color:#FF0040" ><i class="fa fa-tags" title="Activer toutes  les services et les status  XFS erreurs "></i></strong> Activer services</a>';echo'</li>';

                            }

                            if ($idprivilege==1)
                            {
                                echo '   <li>';
                                if($rowG["state"]==0)
                                {
                                    echo '<a tabindex="-1"  data-toggle="modal" 
																			onClick="javascript:declarerNouveauGAB(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
																			data-target="#moduledeclarerNouveauGAB"> <strong style="color:#FF0040" ><i class="fa  fa-gg" title="Nouveau GAB"></i></strong>  Nouveau GAB</a>';
                                }
                                echo '</li> ';
                            }
                            /*********************************************************/

                            /**********************Redémarrer********************/
                            echo ' <li>';
                            echo '<a tabindex="-1"  data-toggle="modal" 
																onClick="javascript:getRedemarrerATM(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
																data-target="#detailRedemarrerATM"><strong style="color:#FF0040" ><i class="fa fa-power-off" title="Redémarrer"></i></strong> Redémarrer </a>';
                            echo'</li>';

                            /**********************Ping ATM********************/
                            echo' <li><a tabindex="-1"  data-toggle="modal" 
                                             onClick="javascript:getPingATM(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$rowG["id_atm"].'\',\''.$rowG["terminal"].'\',\''.$rowG["ip_adress"].'\')"
											data-target="#detailPingATM"><strong style="color:#FF0040" ><i class="fa fa-spinner fa-spin" title="Ping"></i></strong> Ping </a></li>';

                            /**********************Capture écran ATM********************/

                            echo' <li><a tabindex="-1"  data-toggle="modal" 
											onClick="javascript:getScreenshotATM(\''.$rowG["id_atm"].'\')"   
											data-target="#detailScreenshotATM"><strong style="color:#FF0040" ><i class="fa fa-crosshairs" title="Capture écran"></i></strong> Capture écran </a></li>';

                            /**********************Journal ATM********************/
                            echo'	<li>';
                            echo '<a tabindex="-1" data-toggle="modal" 
																onClick="javascript:getjournalATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\')"    
																data-target="#detailjournalATM"> <strong style="color:#FF0040" ><i class="fa fa-newspaper-o" title="journal "> </i></strong> Evenement journal</a>';
                            echo '</li>	';

                            /**********************Historique CMD********************/
                            echo' <li>';
                            echo '<a tabindex="-1" data-toggle="modal"
											onClick="javascript:getcommandeATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
											data-target="#detailcommandeATM"> <strong style="color:#FF0040" ><i class="fa fa-desktop" title="commande "> </i></strong>Historique CMD</a>';
                            echo '</li>';

                            /**********************Config Admin Upload image********************/
                            if ($idprivilege == 1) {
                                echo '   <li>';
                                // if($rowG["state_confirm"]==0)
                                {
                                    echo '<a tabindex="-1" href="selectimagepofil.php" target="_blank"> 
															<strong style="color:#FF0040" ><i class="fa fa-upload" title="upload Picture"></i></strong>  Upload image</a>';
                                }
                                echo '</li> ';
                            }
                            /**********************Config Admin Modifier GAB<********************/
                            if ($idprivilege == 1)
                            {
                                echo'<li>
                                                                      
                                            <a tabindex="-1" data-toggle="modal" 
                                            onClick="javascript:getModifierATMConfirmed(\''.$terminalID.'\')" 
											data-target="#moduleModifierATMConfirmed"><strong style="color:#FF0040" ><i class="fa fa-edit" title="Modifier ATM"></i></strong>  Modifier ATM</a>
                                            </li> ';
                            }
                            /**********************Download file in GAB*******************************/

                            if ($idprivilege == 1)
                            {
                                echo'<li>
                                            <a tabindex="-1" data-toggle="modal" 
                                            onClick="javascript:getDownloadFileGAB(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
											data-target="#moduleDownloadFileGAB"><strong style="color:#FF0040" ><i class="fa fa-download" title="Download  file"></i></strong>  Download  file</a>
                                            </li> ';
                            }
                            /************************Historique vacations*********************/
                            echo "<li><a  href='detailVacation.php?idATM=".$rowG["id_atm"]."&date_vacation=".$row["vacation_date"]."' target='_blank'><strong style='color:#FF0040' ><i class='fa fa-newspaper-o' title='historique Vacations'></i></strong> Historique vacations</a></li>";



                            echo ' </ul>';
                            echo '  </div>	
										      </td>';
                            /**********************Fin Button ********************/
                            /**********************Déclarer GAB********************/
                            echo ' <td align="center">';
                            // if (($_SESSION['id_utilisateur']==46) || ($_SESSION['id_utilisateur']==185))
                            {


                                if(($rowG["terminal"]<>0) && ($rowG["state"]==1))
                                {
                                    echo "<a name='declarer' href='declarer.php?terminal=".$rowG["terminal"]."&dateArret=".$rowG["dateArret"]."&id_motif=227' target='_blank'><strong style='color:#FF0040' ><i class='fa fa-plus-square' title='Déclarer'></i></strong></a>";
                                }
                                /**********************Si Nouveau GAB********************/
                                if ($idprivilege==1)
                                {
                                    if($rowG["state"]==0)
                                    {
                                        echo '<a tabindex="-1"  data-toggle="modal" 
																onClick="javascript:declarerNouveauGAB(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
																data-target="#moduledeclarerNouveauGAB"> <strong style="color:#FF0040" ><i class="fa  fa-gg" title="Nouveau GAB"></i></strong></a>';
                                    }
                                }

                            }
                            echo '</td>
                            <td style="display:none;">'.$name_poste_affecter.'</td>
							</tr>';

                        }

                    } //if (mysqli_num_rows($result)>0)
                    mysqli_free_result($result);
                }//if ($result=mysqli_query($connexion,$sql) or die('Erreur   verif_user !<br>'.$sql.'<br>'.mysqli_error()))
            }
        }

        mysqli_free_result($resultG);
    } //if ($resultG=mysqli_query($connexion,$sqlG) or die('Erreur   verif_user !<br>'.$sqlG.'<br>'.mysqli_error()))
    mysqli_close($connexion);


    echo '  </tbody>
        </table>
    </div>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_gab_passive($terminal,$paramettre,$idprivilege,$date_debut,$date_fin,$historique_vacation,$lang)
{
	$link = ma_db_connexion();
    echo '<div>
            <table class="table table-responsive-sm table-hover table-outline mb-0" >
                <thead class="thead-light">
                    <tr>
                        <th class="text-center" >ID</th>
                        <th class="text-center" >'.$lang['atm_id'].'</th>
                        <th class="text-center" >'.$lang['atm_name'].'</th>
                        <th class="text-center" >IP</th>
                        <th class="text-center" >'.$lang['region'].'</th>
                        <th class="text-center" >'.$lang['passiv_with'].'</th>    
                        <th class="text-center" >'.$lang['passiv_da'].'</th>
                        <th class="text-center" >'.$lang['passiv_dc'].' </th>
                        <!--<th class="text-center" >S_P </th>-->
                        <th class="text-center" >'.$lang['dev_stat'].' </th>
                        <th class="text-center" >Actions</th>
                        <th class="text-center" >'.$lang['declar_i'].'</th>
                    </tr>
                </thead>
            <tbody>';

    //////***********************************Info ATM*********************************************//////


    //atm_logical_names.start_date_day_passive_value=$datetimeBegin;
    //atm_logical_names.end_date_day_passive_value=$datetimeEnd;


    $sqlG = "SELECT list_atm_confirmed.`id_atm`, list_atm_confirmed.`terminal`, list_atm_confirmed.`state` ,
    list_atm_confirmed.`state_confirm`,list_atm_confirmed.`ip_adress`,
    `atm_logical_names`.`passive_value_withrawel`,`atm_logical_names`.`passive_value_money_deposit`,`atm_logical_names`.`passive_value_check_deposit`,
    `atm_logical_names`.`start_date_day_passive_value` as datetimeBegin,`atm_logical_names`.`end_date_day_passive_value` as datetimeEnd,
    `atm_logical_names`.`passive_value_withrawel_out_schedule`,`atm_logical_names`.`passive_value_money_deposit_out_schedule`,`atm_logical_names`.`passive_value_check_deposit_out_schedule`,
    TIMESTAMPDIFF(MINUTE ,atm_logical_names.last_withrawel,now()) as last_withrawel_time,
    TIMESTAMPDIFF(MINUTE ,atm_logical_names.last_money_deposit,now()) as last_money_deposit_time,
    TIMESTAMPDIFF(MINUTE ,atm_logical_names.last_check_deposit,now()) as last_check_deposit_time,
    atm_logical_names.last_withrawel,
    atm_logical_names.last_money_deposit,
    atm_logical_names.last_check_deposit,
    DATE_FORMAT(now(), '%H:%i:%s') as datetimenow

    FROM `list_atm_confirmed` , atm_logical_names  
    WHERE list_atm_confirmed.id_atm= atm_logical_names.id_atm
    AND list_atm_confirmed.state=1
    AND TIMESTAMPDIFF(SECOND ,atm_logical_names.last_connexion_client,now()) <= 900
    GROUP BY atm_logical_names.`id_atm`";

    $resultG=mysqli_query($link,$sqlG);
    if (!$resultG)
    {
        error_log("Erreur SQL 238:  ".$sqlG."  " .mysqli_error($link));
        die(' ERREUR QUERY 238 !');
    }

    if ($resultG)
    {
        if(mysqli_num_rows($resultG)>0)
        {
            $o=0;
            $tableService = array();
            while ($rowG = mysqli_fetch_assoc($resultG))
            {
                $o++;
                $state_withrawel = 0;
                $state_money_deposit = 0;
                $state_check_deposit = 0;

                if ($rowG["datetimenow"] >= $rowG["datetimeBegin"] && $rowG["datetimenow"] <= $rowG["datetimeEnd"])
                {
                    if ($rowG["passive_value_withrawel"] <= $rowG["last_withrawel_time"])
                    {
                        $state_withrawel = 1;
                    }
                    if ($rowG["passive_value_money_deposit"] <= $rowG["last_money_deposit_time"])
                    {
                        $state_money_deposit = 1;
                    }
                    if ($rowG["passive_value_check_deposit"] <= $rowG["last_check_deposit_time"])
                    {
                        $state_check_deposit = 1;
                    }
                    $passive_value_withrawel=$rowG["passive_value_withrawel"];
                    $passive_value_money_deposit=$rowG["passive_value_money_deposit"];
                    $passive_value_check_deposit=$rowG["passive_value_check_deposit"];
                }
                else
                {
                    if ($rowG["passive_value_withrawel_out_schedule"] <= $rowG["last_withrawel_time"])
                    {
                        $state_withrawel = 1;
                    }
                    if ($rowG["passive_value_money_deposit_out_schedule"] <= $rowG["last_money_deposit_time"])
                    {
                        $state_money_deposit = 1;
                    }
                    if ($rowG["passive_value_check_deposit_out_schedule"] <= $rowG["last_check_deposit_time"])
                    {
                        $state_check_deposit = 1;
                    }
                    $passive_value_withrawel=$rowG["passive_value_withrawel_out_schedule"];
                    $passive_value_money_deposit=$rowG["passive_value_money_deposit_out_schedule"];
                    $passive_value_check_deposit=$rowG["passive_value_check_deposit_out_schedule"];
                }

                if ($state_withrawel==1 || $state_money_deposit==1 || $state_check_deposit==1)
                {

                    $idfilial=getfilialATM($rowG["id_atm"]);
                    list($id_poste_affecter, $name_poste_affecter) = explode('---', get_post_affect_ATM($idfilial));
                    $name_poste_affecter=str_replace(CHR(32),'',$name_poste_affecter);
                    list($terminalID, $ipAdresseGAB, $nomGAB, $dateAjout, $ville) = explode('---', getinfoATM($rowG["id_atm"]));
                    //////***************************************************************************************************/////
                    //////***********************************Vacation*********************************************//////
                    $sql = "SELECT `id_vacation_ALM`, `id_vacation_BCR`, `id_vacation_CAM`, `id_vacation_CDM`, 
                    `id_vacation_CEU`, `id_vacation_CHK`, `id_vacation_CIM`, `id_vacation_CRD`, 
                    `id_vacation_DEP`, `id_vacation_IDC`, `id_vacation_IPM`, `id_vacation_PIN`, 
                    `id_vacation_PTR`, `id_vacation_SIU`, `id_vacation_TTU`, `id_vacation_VDM`, `vacation_date`, `name_file`						
                    FROM  `hist_vacations`	WHERE `hist_vacations`.`id_atm` ='" . mysqli_real_escape_string($link,$rowG["id_atm"]) . "'  
                    AND if_load=1 ORDER BY `id_global_vacation` DESC LIMIT 1";

                    $k = 0;
                    $result = mysqli_query($link, $sql);
                    if (!$result)
                    {
                        error_log("Erreur SQL 239:  ".$sql."  " .mysqli_error($link));
                        die(' ERREUR QUERY 239 !');
                    }
                    if ($result)
                    {
                        if (mysqli_num_rows($result) > 0)
                        {
                            while ($row = mysqli_fetch_assoc($result))
                            {
                                $state_btn = 'btn-warning';
                                if(get_device_status($rowG["id_atm"],$row["vacation_date"]))
                                {
                                    $state_btn = 'btn-info';
                                }
                                $k++;
                                // Verifications Services autorisé.
                                $serviceATMAutorise = explode(',', get_list_service_atm($rowG["id_atm"]));
                                foreach ($serviceATMAutorise as $service)
                                {
                                    $tableService[] = $service;
                                }

                                echo '<tr>';

                                /*********************ID ATM********************/
                                if(get_profile_atm($rowG["id_atm"])==1)
                                {
                                    echo '<td class="text-center">' . $rowG["id_atm"] .' <i class="fa fa-exclamation-triangle" style="color: orange" aria-hidden="true" title="Strategic ATM"></i></td>';
                                }
                                else
                                {
                                    echo '<td class="text-center">' . $rowG["id_atm"] .'</td>';
                                }
                                /*********************Code GAB ********************/
                                echo ' <td class="text-center" id="div0' . $rowG["id_atm"] . '">' . $terminalID . '</td>';

                                if (($paramettre == 1) && ($idprivilege == 1))
                                {
                                    echo '<td class="text-center">' . getStatEtatGAB($rowG["state"]) . '</td>';
                                }
                                /********************Nom GAB*************************/
                                echo '<td class="text-center">' . $nomGAB . '</td>';

                                /********************Adresse IP*************************/
                                echo '<td class="text-center">'. $ipAdresseGAB . '</td>	';
 
                                /*******************Ville*************************/
                                echo ' <td class="text-center">' . $ville . '</td>';

                                /*******************Passive Retrait	*************************/
                                if($state_withrawel==1)
                                {
                                    $last_withrawel_time = secondsToWords($rowG["last_withrawel_time"]*60);
                                    echo '<td class="text-center"><div class="clearfix">
                                    <div>';get_Transaction_Passive($rowG["id_atm"],$terminalID,$nomGAB,$passive_value_withrawel,$rowG["last_withrawel"]);echo '</div>
                                    <div class="float-righ">  <small class="text-muted">'.$last_withrawel_time.'</small></div>
                                    </div></td>';
                                }
                                else
                                {
                                    echo ' <td class="text-center"><span class="badge badge-secondary">---</span></td>';
                                }

                                /*******************Passive dépôt d'argent  Ajout*************************/
                                if($state_money_deposit==1)
                                {
                                    $last_money_deposit_time =secondsToWords($rowG["last_money_deposit_time"]*60);
                                    echo '<td class="text-center"><div class="clearfix">
                                    <div>';get_depot_argent_Passive($rowG["id_atm"],$terminalID,$nomGAB,$passive_value_money_deposit,$rowG["last_money_deposit"]);echo'</div>
                                    <div >  <small class="text-muted">'.$last_money_deposit_time.'</small></div>
                                    </div></td>';

                                }
                                else
                                {
                                    echo ' <td class="text-center"><span class="badge badge-secondary">---</span></td>';
                                }
                                /*******************Passive dépôt de chèque*************************/
                                if($state_check_deposit==1)
                                {
                                    $last_check_deposit_time = secondsToWords($rowG["last_check_deposit_time"]*60);
                                    echo '<td class="text-center"><div class="clearfix">
                                    <div>';get_depot_cheque_Passive($rowG["id_atm"],$terminalID,$nomGAB,$passive_value_check_deposit,$rowG["last_check_deposit"]);echo '</div>
                                    <div>  <small class="text-muted">'.$last_check_deposit_time.'</small></div>
                                    </div></td>';

                                }
                                else
                                {
                                    echo ' <td class="text-center"><span class="badge badge-secondary">---</span></td>';
                                }

                                /*******************Derniere Connexion au serveur*************************/
                               /* echo '<td class="text-center"';
                                $Detail_Peripheral=get_value_Peripheral_arret($terminalID);
                                getDetail_Peripheral_arret($Detail_Peripheral[0],$Detail_Peripheral[1],$nomGAB,$Detail_Peripheral[2]);
                                //getDetail_Peripheral_gab($Detail_Peripheral[0],$Detail_Peripheral[1],$nomGAB,$Detail_Peripheral[2]);
                                get_date_up_atm($Detail_Peripheral[3]);
                                echo'</td>';*/

                                /*******************Statut périphérique**************************************************************************************/
                                echo '<td>
                                <div class="span4" align="center">
                                    <div class="btn-group"> 
                                        <button class="btn '.$state_btn.' dropdown-toggle" id="btnGroupVerticalDrop1" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="cil-airplay"></i>
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                <div class="btn-group"> ';
                                $service = 4;
                                if (in_array($service, $tableService))//Verifications Services autorisation services
                                {
                                    getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CDM"],'vacations_CDM','xfs_errors_CDM','CDM',$row["vacation_date"],'WFS_INF_CDM_STATUS',mysqli_real_escape_string($link,$row["name_file"]));
                                }
                                $service = 7;
                                if (in_array($service, $tableService))//Verifications Services autorisation services
                                {
                                    getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_CIM"],'vacations_CIM','xfs_errors_CIM','CIM',$row["vacation_date"],'WFS_INF_CIM_STATUS',mysqli_real_escape_string($link,$row["name_file"]));
                                }
                                $service = 12;
                                if (in_array($service, $tableService))//Verifications Services autorisation services
                                {
                                    getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_PIN"],'vacations_PIN','xfs_errors_PIN','PIN',$row["vacation_date"],'WFS_INF_PIN_STATUS',mysqli_real_escape_string($link,$row["name_file"]));
                                }
                                $service = 13;
                                if (in_array($service, $tableService))//Verifications Services autorisation services
                                {
                                    getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_PTR"],'vacations_PTR','xfs_errors_PTR','PTR',$row["vacation_date"],'WFS_INF_PTR_STATUS',mysqli_real_escape_string($link,$row["name_file"]));
                                }
                                $service = 10;
                                if (in_array($service, $tableService))//Verifications Services autorisation services
                                {
                                    getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_IDC"],'vacations_IDC','xfs_errors_IDC','IDC',$row["vacation_date"],'WFS_INF_IDC_STATUS',mysqli_real_escape_string($link,$row["name_file"]));
                                }
                                $service = 14;
                                if (in_array($service, $tableService))//Verifications Services autorisation services
                                {
                                    getStatusVacation($idprivilege,$service,$paramettre,$rowG["id_atm"],$row["id_vacation_SIU"],'vacations_SIU','xfs_errors_SIU','SIU',$row["vacation_date"],'WFS_INF_SIU_STATUS',mysqli_real_escape_string($link,$row["name_file"]));
                                }

                                $varcolor=getColorDashboard($rowG["id_atm"]) ;
                                if($varcolor != "#888683")
                                {
                                    echo '<a class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                        onClick="javascript:getDashboardATM(\''.$rowG["id_atm"].'\')" 
                                        data-target="#moduleDashboardATM"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-2x" title="CPU,RAM"></i></strong></a> ';
                                }
                                else
                                {
                                    echo '<a class="text-center dropdown-item " tabindex="-1"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-2x" title="CPU,RAM"></i></strong></a>';
                                }
                                echo '<a class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                        onClick="javascript:getjournalATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\')"    
                                        data-target="#detailjournalATM"> <strong style="color:#52c322" ><i class="fa fa-newspaper-o fa-2x" title="E-J"> </i></strong></a>';

                                echo '<a title="'.$lang['cmd_hist'].'" class="text-center dropdown-item " tabindex="-1" data-toggle="modal"
                                        onClick="javascript:getcommandeATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
                                        data-target="#detailcommandeATM"> <strong style="color:#52c322" >
                                        <svg class="icon x128" height="30" width="30">
                                            <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-monitor"></use>
                                        </svg>
                                        </strong></a>';

                                echo '<a class="text-center dropdown-item " title="'.$lang['det_con_gab'].'" tabindex="-1" data-toggle="modal" 
                                        onClick="javascript:getdeconATM(\'' . $rowG["id_atm"] . '\')"    
                                        data-target="#detaildeconATM"> <strong style="color:#52c322;">
                                        <svg class="icon x128" height="30" width="30">
                                            <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-link"></use>
                                        </svg>
                                       
                                        </strong></a>';
                                echo '</div>
                                    </li>
                                    </ul>
                                </div>
                                </div>';

                                echo '</td> ';
                                /**********************Button Actions********************/
                                echo '<td class="text-center">';

                                echo ' <div class="btn-group">
                                            <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span class="cil-transfer"></span> </button>
                                    <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 34px, 0px); top: 0px; left: 0px; will-change: transform;">';
                                /**********************Config Admin********************/



                                /*********************************************************/
                                /**********************Redémarrer********************/

                                echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal" 
                                        onClick="javascript:getRedemarrerATM(\''.$rowG["id_atm"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')"   
                                        data-target="#detailRedemarrerATM"  aria-pressed="true"><i style="color:#FF0040"  class="cil-pregnant" title="'.$lang['reboot'].' "></i>&nbsp; '.$lang["reboot"].'  </a>';

                                /*********************************************************
                                /**********************Ping********************/
                                /*echo '<a tabindex="-1" class="dropdown-item" data-toggle="modal"
                                onClick="javascript:getPingATM(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$rowG["id_atm"].'\',\''.$rowG["terminal"].'\',\''.$rowG["ip_adress"].'\')"   
                                data-target="#detailPingATM"  aria-pressed="true"><i style="color:#FF0040"  class="cil-transfer" title="Ping"></i>&nbsp; Ping </a>';*/
                                /*********************************************************
                                /********************** Capture écran ATM********************/

                                echo' <a tabindex="-1" class="dropdown-item"  data-toggle="modal" 
                                        onClick="javascript:getScreenshotATM(\''.$rowG["id_atm"].'\')"   
                                        data-target="#detailScreenshotATM"><strong style="color:#FF0040" ><i class="cil-camera" title="'.$lang["screenshot"].'"></i></strong>&nbsp;  '.$lang["screenshot"].'     </a>';

                                /**********************Historique CMD********************/

                                echo '<a tabindex="-1" class="dropdown-item"  data-toggle="modal" 
                                        onClick="javascript:getcommandeATM(\'' . $rowG["id_atm"] . '\',\'' . $terminalID . '\',\''.$idprivilege.'\')"
                                        data-target="#detailcommandeATM"> <strong style="color:#FF0040" ><i class="cil-mood-bad" title="'.$lang["cmd_hist"].'" > </i></strong>&nbsp; '.$lang["cmd_hist"].'  </a>';



                                echo ' </div>';
                                echo '  </div>  
                                          </td>';
                                /**********************Fin Button ********************/

                                /**********************Déclarer GAB********************/
                                echo ' <td class="text-center">';

                                if (($rowG["terminal"] <> 0) && ($rowG["state"] == 1))
                                {
                                    echo "<a name='declarer' href='declarer.php?terminal=" . $rowG["terminal"] . "&dateArret=" . date("Y-m-d H:i:s") . "&id_motif=227' target='_blank'><strong style='color:#FF0040' ><i class='fa fa-plus-square' title='".$lang['declar_i']."'></i></strong></a>";
                                }
                                /**********************Si Nouveau GAB********************/
                                echo '</td>';
                                echo'</tr>';
                            }
                        } //if (mysqli_num_rows($result)>0)
                        mysqli_free_result($result);
                    }//if ($result=mysqli_query($conn(),$sql) or die('Erreur   verif_user !<br>'.$sql.'<br>'.mysqli_error()))
                }//if(condition passive value
            }
        }

        mysqli_free_result($resultG);
    } //if ($resultG=mysqli_query($conn(),$sqlG) or die('Erreur   verif_user !<br>'.$sqlG.'<br>'.mysqli_error()))



    echo '  </tbody>
  
        </table>';
    echo'</div>';
	mysqli_close($link);	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function  getModalService_for_config($idService,$nomService)
{
?>
  <button type="button" class="btn btn-primary" data-toggle="modal" href="#myModal_<?php echo $idService;?> ">
    <?php echo 	$nomService; ?>
  </button>
	<!-- The Modal -->
	<div class='modal fade' id='myModal_<?php echo $idService;?>' role='dialog'>
		<div id='modal_d' class='modal-dialog modal-lg'>
			<div class='modal-content'>
					<!-- Modal Header -->
					<div class='modal-header'>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
						<div style='font-size:13pt;color: #3a1d19;' class='modal-title' >Config service <?php echo $nomService;?><br></div>
					</div>
					<!-- Close Modal Header -->
					
					<!-- Modal Body -->
					<div id='bodyConfig_<?php echo $idService;?>' class='modal-body' style='padding:20px 20px;'>
						<?php get_Input_id_atm_for_config_incidents($idService,$nomService);
						get_Tableau_for_config_incident_fwDevice($idService,$nomService); ?>
					</div>
					
					
					<!-- Close Modal Body -->
					
					<!-- Modal Footer -->
					<div class='modal-footer'>
						<?php button_valider_config_gab($idService,$nomService); ?>
					</div>
					<!-- Close Modal Footer -->
					
			</div>
		</div>
	</div>
	<!-- Close The Modal -->
<?php	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function  getModalService_for_config_logical_names($idService,$nomService)
{
?>
  <button type="button" class="btn btn-primary" data-toggle="modal" href="#myModal_<?php echo $idService;?> ">
    <?php echo 	$nomService; ?>
  </button>
	<!-- The Modal -->
	<div class='modal fade' id='myModal_<?php echo $idService;?>' role='dialog'>
		<div id='modal_d' class='modal-dialog modal-lg'>
			<div class='modal-content'>
					<!-- Modal Header -->
					<div class='modal-header'>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
						<div style='font-size:13pt;color: #3a1d19;' class='modal-title' >Config service <?php echo $nomService;?><br></div>
					</div>
					<!-- Close Modal Header -->
					
					<!-- Modal Body -->
					<div id='bodyConfig_logical_<?php echo $idService;?>' class='modal-body' style='padding:20px 20px;'>
						<?php get_Input_id_atm_for_config_logical_names($idService,$nomService);
						get_Tableau_for_config_logical_names($idService,$nomService); ?>
					</div>
					
					
					<!-- Close Modal Body -->
					
					<!-- Modal Footer -->
					<div class='modal-footer'>
						<?php button_valider_config_logical_names($idService,$nomService); ?>
					</div>
					<!-- Close Modal Footer -->
					
			</div>
		</div>
	</div>
	<!-- Close The Modal -->



<?php			
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_Input_id_atm_for_config_logical_names($id_service,$nomService)
{
	echo '
			<div class="row">
				  <div class="col-sm-6">
					<label for="atm_all_'.$nomService.'">Id(s) ATM:</label>
					<input type="text" class="form-control" id="atm_all_'.$nomService.'" required >
				  
				  </div>
				  <div class="col-sm-6">
					<label for="atm_sauf_'.$nomService.'">Logical(s) name: </label>
					<input type="text" class="form-control" id="logical_name_'.$nomService.'">
				  </div>
			</div>
			<br>
	
	';	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_Input_id_atm_for_config_incidents($id_service,$nomService)
{
	echo '
			<div class="row">
				  <div class="col-sm-6">
					<label for="atm_all_'.$nomService.'">Id(s) ATM:</label>
					<input type="text" class="form-control" id="atm_all_'.$nomService.'" required >
				  
				  </div>
				  <div class="col-sm-6">
					<label for="atm_sauf_'.$nomService.'">Logical(s) name: </label>
					<input type="text" class="form-control" id="logical_name_'.$nomService.'">
				  </div>
			</div>
			<br>
	
	';	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_Tableau_for_config_incident_fwDevice($id_service,$nomService)
{

    $connexion=ma_db_connexion();
    if($id_service==16)
    {
        $sql="SELECT value,message_fr,message  FROM  xfs_errors_".mysqli_real_escape_string($connexion,$nomService)." 	WHERE cmd LIKE 'WFS_INF_".mysqli_real_escape_string($connexion,$nomService)."_STATUS'  AND  category LIKE 'wDevice' ";
    } else
    {
        $sql="SELECT value,message_fr,message  FROM  xfs_errors_".mysqli_real_escape_string($connexion,$nomService)." 	WHERE cmd LIKE 'WFS_INF_".mysqli_real_escape_string($connexion,$nomService)."_STATUS'  AND  category LIKE 'fwDevice' ";
    }

    $result = mysqli_query($connexion, $sql);
    if (!$result)
    {
        error_log("Erreur SQL 240:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 240 !');
    }

if ($result)
	{			

   if(mysqli_num_rows($result)>0)
    {
		echo ' 									
    <table class="table table-bordered table-hover table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>MESSAGE (FR)</th>
                <th>MESSAGE (AN)</th>
            </tr>
        </thead>
        <tbody>';
		
       while ($row = mysqli_fetch_assoc($result)) 
        {
           	echo '   <tr>';
					  echo '<td>';
					  echo "<input type='checkbox' id = 'checkedStatus'  name='allCheckedStatus[]' value='".$row["value"]."'>";	
					  echo '</td>';
							
					 	echo '<td>'.$row["message_fr"].'</td>
							  <td>'.$row["message"].' </td>
						</tr>';

			
		}
	
		 	echo '   <tr>';
					  echo '<td>';
					  echo "<input type='checkbox' id = 'checkedStatus'  name='allCheckedStatus[]' value='init'>";
					  echo '</td>';

					 	echo '<td>Aucun</td>
							  <td>---</td>
			</tr>';

			echo '</tbody>
					</table>
				';

	}	
mysqli_free_result($result);	
	}
mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_Tableau_for_config_logical_names($id_service,$nomService)
{

    $connexion=ma_db_connexion();
	$sql="SELECT count(DISTINCT id_atm) as nbrGab, logical_name FROM atm_logical_names WHERE id_service='".mysqli_real_escape_string($connexion,$id_service)."' GROUP BY atm_logical_names.logical_name ";

    $result = mysqli_query($connexion, $sql);
    if (!$result)
    {
        error_log("Erreur SQL 241:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 241 !');
    }
		if ($result)
			{	
            echo ' 									
                    <table class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th>Nbr GAB</th>
                            <th>Nom logique</th>
                            
                        </tr>
                    </thead>
                    <tbody>';

		   if(mysqli_num_rows($result)>0)
			{
							   while ($row = mysqli_fetch_assoc($result)) 
								{
									echo '   <tr>';
												
												echo '<td>'.$row["nbrGab"].'</td>
													  <td>'.$row["logical_name"].' </td>
												</tr>';	
								}
		
			}
			else
			{
					echo '   <tr rowspan="4">';
								echo '<td >RAS</td>';
								 echo '<td >RAS</td>';
								
								echo '   </tr>';
				
			}
		
				mysqli_free_result($result);
				echo '</tbody>
											</table>
										';
				
			}
		mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function button_valider_config_gab($id_service,$nomService){
echo '
<div class="row">
	<div class="col-sm-4">
	</div>
	<div class="col-sm-2">
	</div>
	<div class="col-sm-6">	
		<button  type="button" class="btn btn-success" onclick="javascript:validerConfigIncident(\''.$id_service.'\',\''.$nomService.'\')"> Valider </button>
		<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>	
	</div>
		
</div><!-- /.row -->
<br>
';		
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function button_valider_config_logical_names($id_service,$nomService){
echo '
<div class="row">
	<div class="col-sm-4">
	</div>
	<div class="col-sm-2">
	</div>
	<div class="col-sm-6">	
		<button  type="button" class="btn btn-success" onclick="javascript:validerConfigLogicalNames(\''.$id_service.'\',\''.$nomService.'\')"> Valider </button>
		<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>	
	</div>
		
</div><!-- /.row -->
<br>
';		
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_config_service_for_incidents()
{
    $connexion=ma_db_connexion();
	$sql="SELECT id_service, service FROM list_service ";
    $result = mysqli_query($connexion, $sql);
    if (!$result)
    {
        error_log("Erreur SQL 242:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 242 !');
    }
    if ($result)
	{	
        if (mysqli_num_rows($result) > 0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_service = $row["id_service"];
                $nomService = $row["service"];
                getModalService_for_config($id_service,$nomService);

            }

        }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_config_service_for_logical_names()
{
    $connexion=ma_db_connexion();

    $sql="SELECT id_service, service FROM list_service ";
    $result = mysqli_query($connexion, $sql);
    if (!$result)
    {
        error_log("Erreur SQL 243:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 243 !');
    }
    if ($result)
	{	
        if (mysqli_num_rows($result) > 0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_service = $row["id_service"];
                $nomService = $row["service"];
                getModalService_for_config_logical_names($id_service,$nomService);

            }
        }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getNextJOAGENCE($datedeb)
{
  $dated=explode('-',$datedeb);
  $timestampcurr=mktime(0,0,0,$dated[1],$dated[2],$dated[0]);

  if (get_nbr_jour_ferie()=="0")
  {
  // Jour suivant 
  $timestampcurr=mktime(0,0,0,date('m',$timestampcurr),(date('d',$timestampcurr)+1)   ,date('Y',$timestampcurr));

  //Tant que ce n'est pas un JO
  while( (date('w',$timestampcurr)==0) || (date('w',$timestampcurr)==6))
  {

        // Jour suivant 
        $timestampcurr=mktime(0,0,0,date('m',$timestampcurr),(date('d',$timestampcurr)+1)   ,date('Y',$timestampcurr));
  }  

  }
  //le cas 1 du nombre d'1 jour ferie
  else  if (get_nbr_jour_ferie()=="1") 
  {
  if   (date('D')=="Thu")
  {
          $timestampcurr=mktime(0,0,0,date('m',$timestampcurr),(date('d',$timestampcurr)+4)   ,date('Y',$timestampcurr));
  }
  else  if (date('D')=="Fri")
  {
  $timestampcurr=mktime(0,0,0,date('m',$timestampcurr),(date('d',$timestampcurr)+3)   ,date('Y',$timestampcurr));
  }
   else  if ((date('D')=="Mon") || (date('D')=="Tue")  || (date('D')=="Wed")  || (date('D')=="Sat") || ((date('D')=="Sun") )) 
  {
  $timestampcurr=mktime(0,0,0,date('m',$timestampcurr),(date('d',$timestampcurr)+2)   ,date('Y',$timestampcurr));
  } 
  }
 //  le cas du nombre des deux jour ferie
  else  if (get_nbr_jour_ferie()=="2") 
  {
  if   ((date('D')=="Wed"))
  {
    $timestampcurr=mktime(0,0,0,date('m',$timestampcurr),(date('d',$timestampcurr)+5)   ,date('Y',$timestampcurr));
  }
    else  if (date('D')=="Thu")
  {
  $timestampcurr=mktime(0,0,0,date('m',$timestampcurr),(date('d',$timestampcurr)+4)   ,date('Y',$timestampcurr));
  }
   else  if ((date('D')=="Mon") || (date('D')=="Tue")  || (date('D')=="Sun")  || (date('D')=="Sat") || (date('D')=="Fri")) 
  {
  $timestampcurr=mktime(0,0,0,date('m',$timestampcurr),(date('d',$timestampcurr)+3)   ,date('Y',$timestampcurr));
  } 
  }	
	
     return $timestampcurr;

} //function getNextJOAGENCE$
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getNextJO($datedeb)
{
  $dated=explode('-',$datedeb);
  $timestampcurr=mktime(0,0,0,$dated[1],$dated[2],$dated[0]);

  // Jour suivant 
  $timestampcurr=mktime(0,0,0,date('m',$timestampcurr),(date('d',$timestampcurr)+1)   ,date('Y',$timestampcurr));
     return $timestampcurr;

} //function getNextJO
/////////////////////////////////////////////////////////////////
function getDateRappel($date_rappel,$dateactuel,$parametre)
{
// echo $date_rappel."=======================".$dateactuel."===========================".date_transaction($dateactuel)."<br>";

	if((($date_rappel)=="JO7") && ($parametre=="2"))
		{
			return date('Y-m-d 09:00:00',getNextJOAGENCE($dateactuel));
		}

	else if((($date_rappel)=="JO7")  && ($parametre=="1"))
		{
			return date('Y-m-d 08:00:00',getNextJO( $dateactuel) );
		} 
   else if((($date_rappel)=="86400") ||  (($date_rappel)=="172800") || (($date_rappel)=="259200") || (($date_rappel)=="345600"))
		{
			list($p1, $p2) = explode('  ',  date_transaction($dateactuel));
			list($yr, $mn, $dy) = explode('-', $p1);
			list($hh, $mm, $ss) = explode(':', $p2);		
			return date('Y-m-d  09:00:00',mktime($hh, $mm,$ss+$date_rappel, $mn,$dy,$yr));
		}
		else
		{
			list($p1, $p2) = explode('  ',  date_transaction($dateactuel));
			list($yr, $mn, $dy) = explode('-', $p1);
			list($hh, $mm, $ss) = explode(':', $p2);		
			return date('Y-m-d  H:i:s',mktime($hh, $mm,$ss+$date_rappel, $mn,$dy,$yr));			
		}
}
/////////////////////////////////////////////////////////////////
function regle_heure_backoffice()
{
    $connexion=ma_db_connexion();

    $sql="SELECT `id_regle_heure`, `fusion_horaie` FROM `iprc_authentification_cfg`.`new_regle_heure`  WHERE `id_regle_heure`='1'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");

    $result = mysqli_query($connexion, $sql);
    if (!$result)
    {
        error_log("Erreur SQL 244:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 244 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["fusion_horaie"];
            }
		}
		else
		{
			return "";
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_max_id_porteur()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  MAX(`id_porteur`) as idporteur FROM `new_porteur`";

    $result = mysqli_query($connexion, $sql);
    if (!$result)
    {
        error_log("Erreur SQL 245:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 245 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["idporteur"];
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getLangue()
{
    $connexion=ma_db_connexion();

    $sql="SELECT `id_langue`, `libelle`, `etat` FROM `langue` WHERE `etat` = 1";
    $result = mysqli_query($connexion, $sql);
    if (!$result)
    {
        error_log("Erreur SQL 246:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 246 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<a href="#"><i class="fa fa-gear fa-fw"></i> Langue : <span  onclick="modifier_langue(\''.$row["id_langue"].'\',1)">'.$row["libelle"].'</span></a>';
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_langue($id_langue,$etat)
{
    $connexion=ma_db_connexion();
    $sql = "UPDATE `langue` SET  `etat` = 0 WHERE  `id_langue` = ".$id_langue." ";
    $result = mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 247:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 247 !');
    }
    mysqli_free_result($result);

    $sql2 = "UPDATE `langue` SET  `etat` = 1 WHERE  `id_langue` != ".$id_langue." ";
    $result2 = mysqli_query($connexion,$sql2);
    if (!$result2)
    {
        error_log("Erreur SQL 248:  ".$sql2."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 248 !');
    }
    mysqli_free_result($result2);
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_max_id_alerte()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  MAX(`id_alerte`) as idalerte FROM `new_alertes`";
    $result = mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 249:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 249 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["idalerte"];
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserAlertes($dateArret,$dateCourant,$dateCloture)
{
        $connexion=ma_db_connexion();
        // echo 'INSERT ALERTES<br>';
		$sql = "INSERT INTO  `new_alertes` ( `id_alerte`, `date_arrete`, `date_prise_charge`, `date_cloture`) VALUES ('','".$dateArret."','".$dateCourant."','".$dateCloture."');";
		$result=mysqli_query($connexion,$sql);
        if (!$result)
        {
            error_log("Erreur SQL 250:  ".$sql."  " .mysqli_error($connexion));
            die(' ERREUR QUERY 250 !');
        }

		mysqli_close($connexion);
		return get_max_id_alerte();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_min_id_action($id)
{
    $connexion=ma_db_connexion();

$sql = "SELECT  MIN(`id_action`) as idaction FROM `new_actions_alertes` WHERE id_alertes = '".mysqli_real_escape_string($connexion,$id)."' ";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 251:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 251 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["idaction"];
            }
        }
        else
        {
            return 0;
        }
        mysqli_free_result($result);
    }
		mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_max_id_action($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  MAX(`id_action`) as idaction FROM `new_actions_alertes` WHERE id_alertes = '".mysqli_real_escape_string($connexion,$id)."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 252:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 252 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
             return $row["idaction"];
            }
        }
        else
        {
            return 0;
        }
        mysqli_free_result($result);
    }
	mysqli_close($connexion);
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_porteur($id_porteur,$porteur,$cin,$numCompte,$numCarte,$gsm,$etatGSM)
{

    $connexion=ma_db_connexion();

    $s = "SELECT `id_porteur`, `porteur`, `NumCIN`, `numCompte`, `numCarte`, `GSM`, `etatGSM` FROM `new_porteur` WHERE `id_porteur` = '".mysqli_real_escape_string($connexion,$id_porteur)."'";

    $rs1=mysqli_query($connexion,$s);
    if (!$rs1)
    {
        error_log("Erreur SQL 253:  ".$s."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 253 !');
    }

    if ($rs1)
    {
        if(mysqli_num_rows($rs1)>0)
        {
            $SQL1="UPDATE `new_porteur` SET 
            `porteur`='".addslashes(mysqli_real_escape_string($connexion,$porteur))."',
            `NumCIN`='".mysqli_real_escape_string($connexion,$cin)."',
            `numCompte`='".mysqli_real_escape_string($connexion,$numCompte)."',
            `numCarte`='".mysqli_real_escape_string($connexion,$numCarte)."',
            `GSM`='".mysqli_real_escape_string($connexion,$gsm)."',
            `etatGSM`='".mysqli_real_escape_string($connexion,$etatGSM)."'
            WHERE  `id_porteur` = '".mysqli_real_escape_string($connexion,$id_porteur)."'";

            $result=mysqli_query($connexion,$SQL1) or die('Erreur SQL1  modifier_porteur  111 !<br>'.$SQL1.'<br>'.mysqli_error($connexion));
            mysqli_free_result($result);
        }
    mysqli_free_result($rs1);
    }

    $ss = "SELECT `id_porteur` FROM  `new_alertes` WHERE `id_porteur` = '".mysqli_real_escape_string($connexion,$id_porteur)."'";
    $rs=mysqli_query($connexion,$ss);
    if (!$rs)
    {
        error_log("Erreur SQL 254:  ".$ss."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 254 !');
    }
    if($rs)
    {
        if(mysqli_num_rows($rs)>0)
        {
            $SQL1="UPDATE `new_alertes` SET 
            `NumCIN`='".mysqli_real_escape_string($connexion,$cin)."',
            `numCompte`='".mysqli_real_escape_string($connexion,$numCompte)."',
            `numCarte`='".mysqli_real_escape_string($connexion,$numCarte)."'
            WHERE  `id_porteur` = '".mysqli_real_escape_string($connexion,$id_porteur)."'";
            $result1=mysqli_query($connexion,$SQL1);
            if (!$result1)
            {
                error_log("Erreur SQL 255:  ".$SQL1."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 255 !');
            }
        }
        mysqli_free_result($rs);
    }
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function cloturerAction($idAlerte,$action,$typeAppel,$typeBlocage,$dateCourant,$dateCloture,$note)
{
    $connexion=ma_db_connexion();

    $s = "SELECT `id_alerte` FROM  `new_alertes` WHERE `id_alerte` = '".mysqli_real_escape_string($connexion,$idAlerte)."'";
    $rs=mysqli_query($connexion,$s);
    if (!$rs)
    {
        error_log("Erreur SQL 256:  ".$s."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 256 !');
    }
    if ($rs)
    {
        if(mysqli_num_rows($rs)>0)
        {
            $SQL1="UPDATE `new_alertes` SET `date_prise_charge`='".mysqli_real_escape_string($connexion,$dateCourant)."',`date_cloture`='".mysqli_real_escape_string($connexion,$dateCloture)."',`idUserCloturer`='".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',`etat_alerte`=1
            WHERE  `id_alerte` = '".mysqli_real_escape_string($connexion,$idAlerte)."'";
            $result1=mysqli_query($connexion,$SQL1);
            if (!$result1)
            {
                error_log("Erreur SQL 257:  ".$SQL1."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 257 !');
            }
        }

        // echo $typeRappel.' IIIIIIIIIIIIIIIIIIIIIIIIIIIII INSERT ACTIONS<br>';
        $sql = "INSERT INTO  `new_actions_alertes`( `id_action`, `id_alertes`, `date_prise_charge`, `date_rappel`,  `niveau_intervention`, `nbr_appel`,  `nbr_tentative`, `action`, `typeAppel`, `typeBlocage`, `idUser`,`note`)
        VALUES ('', '".mysqli_real_escape_string($connexion,$idAlerte)."', '".mysqli_real_escape_string($connexion,$dateCourant)."' ,  '".mysqli_real_escape_string($connexion,$dateCloture)."', '".getMAXNiveauIntervention2(mysqli_real_escape_string($connexion,$idAlerte))."', '".getMAXNBRAppel2(mysqli_real_escape_string($connexion,$idAlerte))."', '".getMAXNBRTentative2(mysqli_real_escape_string($connexion,$idAlerte))."', '".mysqli_real_escape_string($connexion,$action)."', '".mysqli_real_escape_string($connexion,$typeAppel)."', '".mysqli_real_escape_string($connexion,$typeBlocage)."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."', '".addslashes(mysqli_real_escape_string($connexion,$note))."');";
        $result=mysqli_query($connexion,$sql);
        if (!$result)
        {
            error_log("Erreur SQL 258:  ".$sql."  " .mysqli_error($connexion));
            die(' ERREUR QUERY 258 !');
        }
        suppimerAlerteOuvert($idAlerte);

        mysqli_free_result($rs);
    }
    mysqli_close($connexion);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getMAXIDIntervention($id)
{
    $connexion=ma_db_connexion();
	$sql = "SELECT  MAX(`id_action`) as action FROM `new_actions_alertes` WHERE id_alertes = '".mysqli_real_escape_string($connexion,$id)."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 259:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 259 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["action"];
            }
        }
        else
        {
            return 0;
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getMAXNBRTentative2($id)
{
    $connexion=ma_db_connexion();
	$sql = "SELECT  `nbr_tentative` as tentative FROM `new_actions_alertes` WHERE  id_action = '".getMAXIDIntervention(mysqli_real_escape_string($connexion,$id))."' ";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 260:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 260 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["tentative"]+1;
            }
        }
        else
        {
            return 1;
        }
        mysqli_free_result($result);
    }
	mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getMAXNBRTentative($id,$typeRappel)
{
    if($typeRappel==1)
    {
        $connexion=ma_db_connexion();
        $sql = "SELECT  `nbr_tentative` as tentative FROM `new_actions_alertes` WHERE  id_action = '".getMAXIDIntervention(mysqli_real_escape_string($connexion,$id))."' ";

        $result=mysqli_query($connexion,$sql);
        if (!$result)
        {
            error_log("Erreur SQL 261:  ".$sql."  " .mysqli_error($connexion));
            die(' ERREUR QUERY 261 !');
        }
        if ($result)
        {
            if(mysqli_num_rows($result)>0)
            {
                while ($row = mysqli_fetch_assoc($result))
                {
                    return $row["tentative"]+1;
                }
            }
            else
            {
                return 1;
            }
            mysqli_free_result($result);
        }
        mysqli_close($connexion);
    }
    else
    {
        return 1;
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getStatEtatGAB($id)
{
    $libelle='libelle_eng';
    if($_SESSION['lang']=='fr')
    {
        $libelle='libelle';
    }
    $connexion=ma_db_connexion();
    $sql = "SELECT  ".$libelle." as libelle FROM `stat_gab` WHERE `id_stat`  = '".mysqli_real_escape_string($connexion,$id)."' ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 262:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 262 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["libelle"];
            }
        }
        else
        {
            return "";
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getMAXNiveauIntervention2($id,$typeRappel)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `niveau_intervention`  FROM `new_actions_alertes` WHERE id_action = '".getMAXIDIntervention(mysqli_real_escape_string($connexion,$id))."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 263:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 263 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["niveau_intervention"];
            }
        }
        else
        {
            return 1;
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getMAXNBRAppel2($id,$typeRappel)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `nbr_appel` as nbrAppel FROM `new_actions_alertes` WHERE id_action = '".getMAXIDIntervention(mysqli_real_escape_string($connexion,$id))."' ";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 264:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 264 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["nbrAppel"];
            }
        }
        else
        {
            return 1;
        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getMAXNBRAppel($id,$typeRappel)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `nbr_appel` as nbrAppel FROM `new_actions_alertes` WHERE id_action = '".getMAXIDIntervention(mysqli_real_escape_string($connexion,$id))."' ";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 265:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 265 !');
    }
    if ($result)
    {
        if($typeRappel==2)
        {
            if(mysqli_num_rows($result)>0)
            {
                while ($row = mysqli_fetch_assoc($result))
                {
                    return $row["nbrAppel"]+1;
                }
            }
            else
            {
                return 1;
            }
        }
        else
        {
        if(mysqli_num_rows($result)>0)
            {
                while ($row = mysqli_fetch_assoc($result))
                {
                    return $row["nbrAppel"];
                }
            }
            else
            {
                return 1;
            }
        }

        mysqli_free_result($result);
    }
mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function updateDateRappelAlerte($idAlerte,$dateRappel)
{
    $connexion=ma_db_connexion();
    $s = "SELECT `id_alerte` FROM  `new_alertes` WHERE `id_alerte` = '".mysqli_real_escape_string($connexion,$idAlerte)."'";
    $rs=mysqli_query($connexion,$s);
    if (!$rs)
    {
        error_log("Erreur SQL 266:  ".$s."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 266 !');
    }
    if ($rs)
    {
        if(mysqli_num_rows($rs)>0)
        {
            $SQL1="UPDATE `new_alertes` SET   `dateRappel`='".mysqli_real_escape_string($connexion,$dateRappel)."' WHERE  `id_alerte` = '".mysqli_real_escape_string($connexion,$idAlerte)."'";
            $result=mysqli_query($connexion,$SQL1);
            if (!$result)
            {
                error_log("Erreur SQL 267:  ".$SQL1."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 267 !');
            }
        }
        mysqli_free_result($rs);
    }
    mysqli_close($connexion);
}
///////////////////////////////////////////////
function suppimerAlerteOuvert($alerte)
{
    $connexion=ma_db_connexion();
    $sql_3 = "DELETE FROM `new_alertes_ouvert` WHERE  `id_alerte` = '".mysqli_real_escape_string($connexion,$alerte)."'";
    $result=mysqli_query($connexion,$sql_3);
    if (!$result)
    {
        error_log("Erreur SQL 268:  ".$sql_3."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 268 !');
    }
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserAction($idAlerte,$action,$typeAppel,$typeRappel,$niveau_intervention,$typeBlocage,$dateCourant,$dateRappel)
{
    $connexion=ma_db_connexion();
    // echo $typeRappel.' IIIIIIIIIIIIIIIIIIIIIIIIIIIII INSERT ACTIONS<br>';
    $sql = "INSERT INTO  `new_actions_alertes`( `id_action`, `id_alertes`, `date_prise_charge`, `date_rappel`,  `niveau_intervention`, `nbr_appel`,  `nbr_tentative`, `action`, `typeAppel`, `typeBlocage`, `idUser`)
             VALUES ('', '".mysqli_real_escape_string($connexion,$idAlerte)."', '".mysqli_real_escape_string($connexion,$dateCourant)."' ,  '".mysqli_real_escape_string($connexion,$dateRappel)."', '".mysqli_real_escape_string($connexion,$niveau_intervention)."' , '".getMAXNBRAppel($idAlerte,$typeRappel)."', '".getMAXNBRTentative($idAlerte,$typeRappel)."', '".mysqli_real_escape_string($connexion,$action)."', '".mysqli_real_escape_string($connexion,$typeAppel)."', '".mysqli_real_escape_string($connexion,$typeBlocage)."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."');";
    $rs2=mysqli_query($connexion,$sql);
    if (!$rs2)
    {
        error_log("Erreur SQL 269:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 269 !');
    }
    mysqli_close($connexion);
    updateDateRappelAlerte($idAlerte,$dateRappel);
    inserAlerteOuvert($idAlerte);

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function updateAlerte($idAlerte,$idPorteur,$numCompte,$numCarte,$cin,$typeProduit,$typeBlocage,$etatalerte,$remarque,$dateRappel)
{
    $connexion=ma_db_connexion();
    // echo 'UPDATE ALERTES<br>';
    $s = "SELECT `id_alerte` FROM  `new_alertes` WHERE `id_alerte` = '".mysqli_real_escape_string($connexion,$idAlerte)."'";
    $rs=mysqli_query($connexion,$s);
    if (!$rs)
    {
        error_log("Erreur SQL 270:  ".$s."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 270 !');
    }
	if ($rs)
    {
        if(mysqli_num_rows($rs)>0)
        {
            $SQL1="UPDATE `new_alertes` SET 
            `NumCIN`='".mysqli_real_escape_string($connexion,$cin)."',
            `numCompte`='".mysqli_real_escape_string($connexion,$numCompte)."',
            `numCarte`='".mysqli_real_escape_string($connexion,$numCarte)."',
            `id_porteur`='".mysqli_real_escape_string($connexion,$idPorteur)."',
            `id_type_produit`='".mysqli_real_escape_string($connexion,$typeProduit)."',
            `id_type_blocage`='".mysqli_real_escape_string($connexion,$typeBlocage)."',
            `etat_alerte`='".mysqli_real_escape_string($connexion,$etatalerte)."',
            `dateRappel`='".mysqli_real_escape_string($connexion,$dateRappel)."',
            `remarque`='".addslashes(mysqli_real_escape_string($connexion,$remarque))."'
            WHERE  `id_alerte` = '".mysqli_real_escape_string($connexion,$idAlerte)."'";

            $rs2=mysqli_query($connexion,$SQL1);
            if (!$rs2)
            {
                error_log("Erreur SQL 271:  ".$SQL1."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 271 !');
            }

        }
            mysqli_free_result($rs);
    }
	mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getComptePorteur($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `numCompte` FROM `new_porteur` WHERE `id_porteur`  = '".mysqli_real_escape_string($connexion,$id)."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 272:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 272 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["numCompte"];
            }
        }
        else
        {
            return "";
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getCINPorteur($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `NumCIN` FROM `new_porteur` WHERE `id_porteur`  = '".mysqli_real_escape_string($connexion,$id)."' ";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 273:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 273 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["NumCIN"];
            }
        }
        else
        {
            return "";
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_service_atm($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_atm`, `id_service` FROM `config_service_atm` WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$id)."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 274:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 274 !');
    }
    if ($result)
		{	
			if(mysqli_num_rows($result)>0)
				{
				while ($row = mysqli_fetch_assoc($result)) 
						{
							return $row["id_service"];  	
						}
				}	
			else
				{
					return "";
				}
				mysqli_free_result($result);	
		}
	mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_names_logical_names_atm($id,$id_service)
{
    $connexion=ma_db_connexion();
    $logical_name = array();
	$sql = "SELECT  `logical_name` FROM `atm_logical_names` WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$id)."'  AND  `id_service` = '".mysqli_real_escape_string($connexion,$id_service)."' AND `state` = 1";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 275:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 275 !');
    }
    if ($result)
    {
        if (mysqli_num_rows($result)>0)
        {
            $j=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $logical_name[$j]=$row["logical_name"];
                $j++;
             }
        }
        else
        {
                 $logical_name[0]='';
        }
        mysqli_free_result($result);
        return $logical_name;
	}
	mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_logical_names_atm($id,$id_service)
{
    $connexion=ma_db_connexion();

    $logical_name = array();
	$sql = "SELECT  `id_logical_name` FROM `atm_logical_names` WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$id)."'  AND  `id_service` = '".mysqli_real_escape_string($connexion,$id_service)."' AND `state` = 1";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 276:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 276 !');
    }
    if ($result)
	{
       if (mysqli_num_rows($result)>0)
        {
            $j=0;
            while ($row = mysqli_fetch_assoc($result))
             {
                $logical_name[$j]=$row["id_logical_name"];
                $j++;
             }
        }
        else
        {
                 $logical_name[0]='';
        }
        mysqli_free_result($result);
        return $logical_name;
	}
	mysqli_close($connexion);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_list_config_service($id_service)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `config_service` FROM `list_service` WHERE `id_service` = '".mysqli_real_escape_string($connexion,$id_service)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 277:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 277 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["config_service"];
            }
        }
        else
        {
            return "";
        }
		mysqli_free_result($result);
	}
mysqli_close($connexion);
		
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_status_logical_names_atm($id,$id_service,$idlogicalName)
{
    $connexion=ma_db_connexion();
    $status_logical = array();
	$sql = "SELECT  `all_id` FROM `".get_libelle_list_config_service($id_service)."` WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$id)."' 
			AND  `id_logical_name` = '".mysqli_real_escape_string($connexion,$idlogicalName)."'  GROUP BY `id_logical_name`";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 278:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 278 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $j=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $status_logical[$j]=($row["all_id"]);
                $j++;
            }
        }
        else
        {
            $status_logical[0]='';
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
				
	return $status_logical;					
				
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_status_id_logical_names_atm($id_logical,$id,$id_service)
{
    $connexion=ma_db_connexion();

    $status_logical = array();
	$sql = "SELECT  `all_id` FROM `".get_libelle_list_config_service(mysqli_real_escape_string($connexion,$id_service))."` WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$id)."' AND `id_logical_name` = '".mysqli_real_escape_string($connexion,$id_logical)."'  GROUP BY `id_logical_name`";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 279:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 279 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{  $j=0;
			while ($row = mysqli_fetch_assoc($result)) 
					{
						$status_logical[$j]=$row["all_id"];		
						$j++;
					}
			}	
		else
			{
				 $status_logical[0]='';	
			}		
			
mysqli_free_result($result);	
	}
mysqli_close($connexion);
				
				
return $status_logical;					
				
				
				
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_list_service($id_service)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `service` FROM `list_service` WHERE `id_service` = '".mysqli_real_escape_string($connexion,$id_service)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 280:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 280 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["service"];  	
					}
			}	
		else
			{
				return "";
			}
mysqli_free_result($result);	
	}
mysqli_close($connexion);
			
			
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_service_atm_logical_name($ATM)
{
	$sql = "SELECT  `list_service`.`id_service` AS id_service,`service`,`config_service`,`id_logical_name`,`logical_name` FROM `list_service`, `atm_logical_names` 
	WHERE `list_service`.`id_service`=`atm_logical_names`.`id_service` AND  `atm_logical_names`.`id_atm` = '".intval($ATM)."'
	ORDER BY `list_service`.`id_service`, `logical_name`";
	return $sql;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_service_atm()
{
	$sql = "SELECT  `id_service`,`service`,`config_service` FROM `list_service`";
	return $sql;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_list_table_xfs_error($id_service)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `table_xfs_error` FROM `list_service` WHERE `id_service` = '".mysqli_real_escape_string($connexion,$id_service)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 281:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 281 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["table_xfs_error"];  	
					}
			}	
		else
			{
				return "";
			}
mysqli_free_result($result);	
	}			
	mysqli_close($connexion);
			
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_status_logical_names_atm($id_service,$idlogicalName)
{	
	$status_id = array();		
	$status_error = array();		
	$logical_category = array();
    $connexion=ma_db_connexion();

    $sql = "SELECT  `id_error`,  `code_error`, `category` FROM `".get_libelle_list_table_xfs_error(mysqli_real_escape_string($connexion,$id_service))."` WHERE  `id_service` = '".mysqli_real_escape_string($connexion,$id_service)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 282:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 282 !');
    }
    if ($result)
	{		
       if (mysqli_num_rows($result)>0)
        {
            $j=0;
            while ($row = mysqli_fetch_assoc($result))
             {
                 $status_id[$j]=$row["id_error"];
                 $status_error[$row["id_error"]]=$row["code_error"];
                 $logical_category[$row["id_error"]]=$row["category"];
                 $j++;
             }
        }
        else
        {
             $status_id[0]='';
             $status_error[0]='';
             $logical_category[0]='';
        }
        mysqli_free_result($result);
        return array($status_id,$status_error,$logical_category);
	}
	mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_logical_names_atm($id,$id_service)
{	
	$logical_id = array();		
	$logical_name = array();
    $connexion=ma_db_connexion();

    $sql = "SELECT  `id_logical_name`, `id_atm`, `logical_name` FROM `atm_logical_names` WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$id)."' AND  `id_service` = '".mysqli_real_escape_string($connexion,$id_service)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 283:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 283 !');
    }
    if ($result)
	{
        if (mysqli_num_rows($result)>0)
        {
            $j=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $logical_id[$j]=($row["id_logical_name"]);
                $logical_name[$row["id_logical_name"]]=$row["logical_name"];
                $j++;
            }
        }
        else
        {
             $logical_id[0]='';
             $logical_name[0]='';
        }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
	return array($logical_id,$logical_name);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_name_terminal_gag($id_atm)
{
    $connexion=ma_db_connexion();

    $SQL = "SELECT `nom_gab`,`terminal` FROM `new_list_gab` WHERE `id_terminal_xfs` = '".  mysqli_real_escape_string($connexion,$id_atm)."' LIMIT 1 ";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);

    if (!$result)
    {
        error_log("Erreur SQL 466:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 466 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $val=array($row["terminal"],
                    $row["nom_gab"]);
            }
        }
        else
        {
            $val= array('','');
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return $val;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getConfigServiceATM($paramettre,$idprivilege,$ATM,$date_debut,$date_fin,$historique_vacation)
{
    include "../languages/" . $_SESSION['lang'] . ".php";
    $connexion=ma_db_connexion();

    $val=get_name_terminal_gag($ATM);
    echo '<div class="modal-dialog modal-lg">
	    <div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Service : '.$ATM.' - '.$val[0].' - '.$val[1].'</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
																										
            <!-- Modal body -->
            <div class="modal-body">';
        echo '<form class="form-horizontal" role="form" style="padding-left: 50px;background-color:#f8f8f8;">
	        <div  class="form-group" > <br>';
        $tableau = explode(',', get_list_service_atm($ATM));
        foreach($tableau as $verif)
        {
            $inlineCheckbox[] = $verif;
        }
        $sql_service=get_all_service_atm();

        $result_service=mysqli_query($connexion,$sql_service);
        if (!$result_service)
        {
            error_log("Erreur SQL 284:  ".$sql_service."  " .mysqli_error($connexion));
            die(' ERREUR QUERY 284 !');
        }
        if ($result_service)
        {
            if(mysqli_num_rows($result_service)>0)
            {
                $m=0;
                $i=0;
                while ($row = mysqli_fetch_assoc($result_service))
                {
                    if (($i % 3) == 0){$m=$m+3;  echo '</div><div  class="form-group">';}else{echo '';}

                    echo '<input class="col-sm-2 form-check-input" type="checkbox" name="allserviceATM[]" id="inlineCheckbox'.$row["id_service"].'"';
                    if (in_array($row["id_service"], $inlineCheckbox))
                    {
                        echo 'checked';
                    }
                    echo  " value='".$row["id_service"]."'";  echo ' >';
                    echo '<label class="col-sm-2 form-check-label" for="inlineCheckbox'.$row["id_service"].'">'.$row["service"].'</label>';

                    if (($m % 3) == 0){  echo '';}else{echo '</div>';}
                    $i++;
                }
            }
            mysqli_free_result($result_service);
        }
        mysqli_close($connexion);
        echo '</div>	
        <div  class="form-group">				
            <label for="buttonVaction" class="col-sm-2 control-label"></label>
		</div>
		</form> ';
	echo '</div>																										
        <!-- Modal footer -->
        <div class="modal-footer justify-content-between">
        
                <button type="button" class="btn btn-primary"  
                onClick="javascript:confirmServiceATM(\''.$ATM.'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')" 
                data-dismiss="modal" >'.$lang['confir'].'</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
        </div>
																										
            </div>
    </div>';
	
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function updateXFSErrors($paramettre,$idprivilege,$id_logical,$idatm,$id_service,$id_error,$etatVal)
{
    $connexion=ma_db_connexion();
				
    $tableConfig=get_libelle_list_config_service($id_service);
    $tableau_logical_autorise2=get_list_status_id_logical_names_atm($id_logical,$idatm,$id_service);
	
    // 1 CAS Désactivation XFS ERRORS
	if($etatVal==0)
	{
	    $tableau = explode(',', $tableau_logical_autorise2[0]);
	    foreach($tableau as $verif)
	    {
	        $tableau_logical_autorise[] = $verif;
	    }
	    $u=0;
	    $id_Slogical_name="";
	    foreach ($tableau_logical_autorise AS $_val)
	    {
	        // if ($_SESSION['id_utilisateur']==46){ echo "TEST".$_val."   ===> errore   :  ".$id_error."<br>";}
            if ($id_error<>$_val)
            {
                // if ($_SESSION['id_utilisateur']==46){ echo " TEST   ================== > 2 ".$_val."   ===> errore   :  ".$id_error."<br>";}
                if($u==0)
                {
                    $id_Slogical_name=$_val;
                }
                else
                {
                    $id_Slogical_name=$id_Slogical_name.','.$_val;
                }
                $u++;
            }
	    }

	    if(substr($id_Slogical_name, 0, 1)==','){$id_Slogical_name=substr($id_Slogical_name, 1);}
	    else{$id_Slogical_name=$id_Slogical_name;}
					
	    $sql = "SELECT  `id_insert` FROM `".mysqli_real_escape_string($connexion,$tableConfig)."` WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$idatm)."' AND `id_service`= '".mysqli_real_escape_string($connexion,$id_service)."' AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$id_logical)."'";
	    $result=mysqli_query($connexion,$sql);
	    if (!$result)
	    {
	        error_log("Erreur SQL 285:  ".$sql."  " .mysqli_error($connexion));
	        die(' ERREUR QUERY 285 !');
	    }
	    if ($result)
	    {
	        if(mysqli_num_rows($result)>0)
	        {
	            $SQL2="UPDATE `".mysqli_real_escape_string($connexion,$tableConfig)."` SET  `all_id`='".mysqli_real_escape_string($connexion,$id_Slogical_name)."' WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$idatm)."' AND `id_service`= '".mysqli_real_escape_string($connexion,$id_service)."'  AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$id_logical)."'";
	            $result2=mysqli_query($connexion,$SQL2);
	            if (!$result2)
	            {
	                error_log("Erreur SQL 286:  ".$SQL2."  " .mysqli_error($connexion));
	                die(' ERREUR QUERY 286 !');
	            }
	        }
	        mysqli_free_result($result);
	    }
	}
	else // 2 CAS Activation XFS ERRORS
	{
        $id_Slogical_name=$tableau_logical_autorise2[0].','.$id_error;

        $sql = "SELECT  `id_insert` FROM `".mysqli_real_escape_string($connexion,$tableConfig)."` WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$idatm)."' AND `id_service`= '".mysqli_real_escape_string($connexion,$id_service)."'  AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$id_logical)."'";
        $result=mysqli_query($connexion,$sql);
        if (!$result)
        {
            error_log("Erreur SQL 287:  ".$sql."  " .mysqli_error($connexion));
            die(' ERREUR QUERY 287 !');
        }
        if ($result)
        {
            if(mysqli_num_rows($result)>0)
            {
                $SQL2="UPDATE `".mysqli_real_escape_string($connexion,$tableConfig)."` SET  `all_id`='".mysqli_real_escape_string($connexion,$id_Slogical_name)."' WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$idatm)."' AND `id_service`= '".mysqli_real_escape_string($connexion,$id_service)."'  AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$id_logical)."'";
                $result2=mysqli_query($connexion,$SQL2);
                if (!$result2)
                {
                    error_log("Erreur SQL 288:  ".$SQL2."  " .mysqli_error($connexion));
                    die(' ERREUR QUERY 288 !');
                }
            }
            mysqli_free_result($result);
        }
	}
	mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function confirmSLogicalNamesServiceATM($id_Slogical_name,$idatm,$idservice,$id_logical_name,$tables)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `id_insert` FROM `".mysqli_real_escape_string($connexion,$tables)."` WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$idatm)."' AND `id_service`= '".mysqli_real_escape_string($connexion,$idservice)."' AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$id_logical_name)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 289:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 289 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
           $SQL2="UPDATE `".mysqli_real_escape_string($connexion,$tables)."` SET  `all_id`='".mysqli_real_escape_string($connexion,$id_Slogical_name)."' WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$idatm)."' 
           AND `id_service`= '".mysqli_real_escape_string($connexion,$idservice)."' 
           AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$id_logical_name)."'";
            $result2=mysqli_query($connexion,$SQL2);
            if (!$result2)
            {
                error_log("Erreur SQL 290:  ".$SQL2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 290 !');
            }
        }

    mysqli_free_result($result);
    }
		mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function confirmLogicalNamesServiceATM($id_logical_name,$idatm,$idservice)
{
    $connexion=ma_db_connexion();
    $SQL1="UPDATE `atm_logical_names` SET  `state`=0  WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$idatm)."' AND `id_service` = '".mysqli_real_escape_string($connexion,$idservice)."'";

    $result1=mysqli_query($connexion,$SQL1);
    if (!$result1)
    {
        error_log("Erreur SQL 291:  ".$SQL1."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 291 !');
    }
    if ($result1)
	{	
		foreach (explode(",", $id_logical_name) AS $id_logical)
        {
            if(!empty($id_logical))
            {
                $sql = "SELECT `id_logical_name`, `id_atm`, `id_service`, `state` FROM `atm_logical_names` 
                WHERE `id_logical_name` = '".mysqli_real_escape_string($connexion,$id_logical)."' AND `id_atm` = '".mysqli_real_escape_string($connexion,$idatm)."' AND `id_service` = '".mysqli_real_escape_string($connexion,$idservice)."'";

                $result=mysqli_query($connexion,$sql);
                if (!$result)
                {
                    error_log("Erreur SQL 292:  ".$sql."  " .mysqli_error($connexion));
                    die(' ERREUR QUERY 292 !');
                }
                if ($result)
                {
                    if(mysqli_num_rows($result)>0)
                    {
                       $SQL2="UPDATE `atm_logical_names` SET  `state`=1 
                       WHERE `id_logical_name` = '".mysqli_real_escape_string($connexion,$id_logical)."' AND `id_atm` = '".mysqli_real_escape_string($connexion,$idatm)."' AND `id_service` = '".mysqli_real_escape_string($connexion,$idservice)."'";

                        $result2=mysqli_query($connexion,$SQL2);
                        if (!$result2)
                        {
                            error_log("Erreur SQL 293:  ".$SQL2."  " .mysqli_error($connexion));
                            die(' ERREUR QUERY 293 !');
                        }
                    }
                    mysqli_free_result($result);
                }
            }
        }
	    mysqli_free_result($result1);
	}
    mysqli_close($connexion);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function insertAgence($code_agence,$name_agence,$ville,$code_region)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `code_agence` FROM `new_list_agence` WHERE `code_agence` = '".mysqli_real_escape_string($connexion,$code_agence)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 294:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 294 !');
    }
    if ($result)
    {
		if(mysqli_num_rows($result)>0)
        {
            $SQL2="UPDATE `new_list_agence` SET 
            `nom_agence`='".addslashes(mysqli_real_escape_string($connexion,$name_agence))."',
            `adresse`='".addslashes(mysqli_real_escape_string($connexion,$name_agence))."',
            `ville`='".mysqli_real_escape_string($connexion,$ville)."',
            `id_direction`='".mysqli_real_escape_string($connexion,$code_region)."'
            WHERE  `code_agence` = '".mysqli_real_escape_string($connexion,$code_agence)."'";
            $result2=mysqli_query($connexion,$SQL2);
            if (!$result2)
            {
                error_log("Erreur SQL 295:  ".$SQL2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 295 !');
            }
        }
		else
        {
            $cmd2="INSERT INTO  `new_list_agence` (`code_agence`, `nom_agence`, `adresse`, `ville`, `id_direction`, `nb_gab`)					
            VALUES ('".mysqli_real_escape_string($connexion,$code_agence)."','".addslashes(mysqli_real_escape_string($connexion,$name_agence))."','".addslashes(mysqli_real_escape_string($connexion,$name_agence))."',  '".mysqli_real_escape_string($connexion,$ville)."' , '".mysqli_real_escape_string($connexion,$code_region)."',1)";
            $result3=mysqli_query($connexion,$cmd2);
            if (!$result3)
            {
                error_log("Erreur SQL 296:  ".$cmd2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 296 !');
            }
        }
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function insertRegion($code_region,$libelle,$pays)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `id_filiale` FROM `new_filiale` WHERE `id_filiale` = '".mysqli_real_escape_string($connexion,$code_region)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 297:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 297 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
        {
           $SQL2="UPDATE `new_filiale` SET 
           `nom_filiale`='".mysqli_real_escape_string($connexion,$libelle)."',
           `nom_filiale2`='".mysqli_real_escape_string($connexion,$libelle)."',
           `PAYS`='".mysqli_real_escape_string($connexion,$pays)."'
            WHERE  `id_filiale` = '".mysqli_real_escape_string($connexion,$code_region)."'";
            $result2=mysqli_query($connexion,$SQL2);
            if (!$result2)
            {
                error_log("Erreur SQL 298:  ".$SQL2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 298 !');
            }
        }
		else
        {
            $cmd2="INSERT INTO  `new_filiale` (`id_filiale`, `nom_filiale`, `id_filiale2`, `id_filiale3`, `nom_filiale2`, `PAYS`, `etat_activation`)					
            VALUES ('".mysqli_real_escape_string($connexion,$code_region)."', '".mysqli_real_escape_string($connexion,$libelle)."',  '".mysqli_real_escape_string($connexion,$code_region)."' , '".mysqli_real_escape_string($connexion,$code_region)."', '".mysqli_real_escape_string($connexion,$libelle)."','".mysqli_real_escape_string($connexion,$pays)."',1)";
            $result3=mysqli_query($connexion,$cmd2);
            if (!$result3)
            {
                error_log("Erreur SQL 299:  ".$cmd2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 299 !');
            }
        }
	    mysqli_free_result($result);
	}
mysqli_close($connexion);
			
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function confirmeDeclarerNouveauGAB($idatm,$cd_ATM,$name_ATM,$name_agence,$send_statut,$parse_journal,$exec_command,$depl_image,$depl_binaire,$upload_command,$constucteur,$profil,$cd_agance,$ville,$code_region,$region,$pays,$ip_adresse_gab)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `id_terminal_xfs` FROM `new_list_gab` WHERE  `terminal` = '".mysqli_real_escape_string($connexion,$cd_ATM)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 300:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 300 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $SQL2="UPDATE `list_atm_confirmed` SET `terminal`= '".mysqli_real_escape_string($connexion,$cd_ATM)."', `state_confirm`=0,  `state`=1,state_send_image = '".mysqli_real_escape_string($connexion,$depl_image)."' , state_send_binaire = '".mysqli_real_escape_string($connexion,$depl_binaire)."'
            , state_upload = '".mysqli_real_escape_string($connexion,$upload_command)."' ,`state_send_status` ='".mysqli_real_escape_string($connexion,$send_statut)."' ,`state_parse_journal`= '".mysqli_real_escape_string($connexion,$parse_journal)."' , `state_exec_command`= '".mysqli_real_escape_string($connexion,$exec_command)."' , `type_gab`='".mysqli_real_escape_string($connexion,$constucteur)."' WHERE  `id_atm` = '".mysqli_real_escape_string($connexion,$idatm)."'";

            $result1=mysqli_query($connexion,$SQL2);
            if (!$result1)
            {
                error_log("Erreur SQL 301:  ".$SQL2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 301 !');
            }

            $SQL3="UPDATE `new_list_gab` SET    `id_terminal_xfs`= '".mysqli_real_escape_string($connexion,$idatm)."', `id_activation` = 1 , `id_fournisseur`='".mysqli_real_escape_string($connexion,$constucteur)."' WHERE  `terminal` = '".mysqli_real_escape_string($connexion,$cd_ATM)."'";
            $result2=mysqli_query($connexion,$SQL3);
            if (!$result2)
            {
                error_log("Erreur SQL 302:  ".$SQL3."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 302 !');
            }

            $SQL4="INSERT IGNORE INTO cmd_execution
            (`id_atm`,`state`)
            VALUES ('".mysqli_real_escape_string($connexion,$idatm)."',1)";
            $result3=mysqli_query($connexion,$SQL4);
            if (!$result3)
            {
                error_log("Erreur SQL 303:  ".$SQL4."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 303 !');
            }

        }
        else
        {

            $SQL2="UPDATE `list_atm_confirmed` SET  `terminal`= '".mysqli_real_escape_string($connexion,$cd_ATM)."', `state_confirm`=0,  `state`=1 ,state_send_image = '".mysqli_real_escape_string($connexion,$depl_image)."' , state_send_binaire = '".mysqli_real_escape_string($connexion,$depl_binaire)."'
            , state_upload = '".mysqli_real_escape_string($connexion,$upload_command)."' ,`state_send_status` = '".mysqli_real_escape_string($connexion,$send_statut)."' ,`state_parse_journal`= '".mysqli_real_escape_string($connexion,$parse_journal)."' , `state_exec_command`= '".mysqli_real_escape_string($connexion,$exec_command)."', `type_gab`= '".mysqli_real_escape_string($connexion,$constucteur)."' WHERE  `id_atm` = '".mysqli_real_escape_string($connexion,$idatm)."'";
           
            $result2=mysqli_query($connexion,$SQL2);
            if (!$result2)
            {
                error_log("Erreur SQL 304:  ".$SQL2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 304 !');
            }

            $cmd2="INSERT INTO  `new_list_gab` 
					(`terminal`, `id_terminal_xfs`, `date_ajout`, `cdf`,
					`date_installation`, `gestion`, `nom_gab`,
					`ip_adresse_gab`, `type_gab`,`id_profil`, `code_bank`,
					`code_group`, `code_succursale`, `code_agence`,
					`libelle_agence`, `adresse_gab`, `id_fournisseur`,
					`ville`, `id_activation`, `id_utilisateur`, `gestionnaire` )
					  VALUES ('".mysqli_real_escape_string($connexion,$cd_ATM)."', '".mysqli_real_escape_string($connexion,$idatm)."', NOW(), '".mysqli_real_escape_string($connexion,$cd_agance)."' ,
					  NOW(), 1, '".addslashes(mysqli_real_escape_string($connexion,$name_ATM))."',
					  '".mysqli_real_escape_string($connexion,$ip_adresse_gab)."','".mysqli_real_escape_string($connexion,$constucteur)."', '".mysqli_real_escape_string($connexion,$profil)."' , '".mysqli_real_escape_string($connexion,$code_region)."' ,
					  '".mysqli_real_escape_string($connexion,$code_region)."',  '', '".mysqli_real_escape_string($connexion,$cd_agance)."',
					  '".addslashes(mysqli_real_escape_string($connexion,$name_agence))."', '".addslashes(mysqli_real_escape_string($connexion,$name_agence))."',  '".mysqli_real_escape_string($connexion,$constucteur)."', 
					  '".mysqli_real_escape_string($connexion,$ville)."',1,'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',1)";

            $result3=mysqli_query($connexion,$cmd2);
            if (!$result3)
            {
                error_log("Erreur SQL 305:  ".$cmd2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 305 !');
            }

            $SQL3="INSERT IGNORE INTO cmd_execution
            (`id_atm`,`state`)
            VALUES ('".$idatm."',1)";
            $result4=mysqli_query($connexion,$SQL3);
            if (!$result4)
            {
                error_log("Erreur SQL 306:  ".$SQL3."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 306 !');
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
	
	/***********************Insert Config incidents services (fwDevice)**************************/
	set_default_config_fwDevice($idatm);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**************************************************************************************************************/
function set_default_config_fwDevice($id_atm)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `id_service`, `type_status`,value_status,type_config
    FROM `config_incident_services` WHERE type_config='default' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 307:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 307 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_service= $row["id_service"];
                $type_status= $row["type_status"];
                $value_status= $row["value_status"];

                $sql2 = "SELECT  atm_logical_names.id_logical_name,atm_logical_names.id_atm    
                    FROM  `atm_logical_names`
                    WHERE  atm_logical_names.id_service=".mysqli_real_escape_string($connexion,$id_service)." AND atm_logical_names.state = 1 
                    AND atm_logical_names.id_atm  =".mysqli_real_escape_string($connexion,$id_atm)."   ";
                $result2=mysqli_query($connexion,$sql2);
                if (!$result2)
                {
                    error_log("Erreur SQL 308:  ".$sql2."  " .mysqli_error($connexion));
                    die(' ERREUR QUERY 308 !');
                }
                if ($result2)
                {
                    if(mysqli_num_rows($result2)>0)
                    {
                        while ($row2 = mysqli_fetch_assoc($result2))
                        {
                            /**********************INSERT CONFIG***************************/
                            $sql3 = "INSERT INTO config_incident_services
                                (id_atm,id_logical_name,id_service,type_status,value_status,date_insert,type_config)
                                VALUES (".mysqli_real_escape_string($connexion,$id_atm).",".mysqli_real_escape_string($connexion,$row2["id_logical_name"]).",".mysqli_real_escape_string($connexion,$id_service).",
                                ".mysqli_real_escape_string($connexion,$type_status).",".mysqli_real_escape_string($connexion,$value_status).",now(),'global')	 ";
                            $result3=mysqli_query($connexion,$sql3);
                            if (!$result3)
                            {
                                error_log("Erreur SQL 309:  ".$sql3."  " .mysqli_error($connexion));
                                die(' ERREUR QUERY 309 !');
                            }
                        }
                    }
                    mysqli_free_result($result2);
                }

            }
        }

    mysqli_free_result($result);
    }
    mysqli_close($connexion);
}



/**************************************************************************************************************/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function ajouter_service_atm($id_service,$idatm)
{

    $connexion=ma_db_connexion();
	$sql = "SELECT  `id_service` FROM `config_service_atm` WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$idatm)."'";
    $result=mysqli_query($connexion,$sql);

    if (!$result)
    {
        error_log("Erreur SQL 310:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 310 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
        {
           $SQL2="UPDATE `config_service_atm` SET 
           `id_service`='".mysqli_real_escape_string($connexion,$id_service)."',
           `datePriseEnCharge`=NOW(),
           `id_user`='".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."'
            WHERE  `id_atm` = '".mysqli_real_escape_string($connexion,$idatm)."'";

            $result2=mysqli_query($connexion,$SQL2);
            if (!$result2)
            {
                error_log("Erreur SQL 311:  ".$SQL2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 311 !');
            }
        }
		else
        {
            $cmd2="INSERT INTO  `config_service_atm` (`id_service_atm`, `id_atm`, `id_service`, `id_user`, `datePriseEnCharge`)
              VALUES ('', '".addslashes(mysqli_real_escape_string($connexion,$idatm))."', '".addslashes(mysqli_real_escape_string($connexion,$id_service))."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',NOW())";
            $result3=mysqli_query($connexion,$cmd2);
            if (!$result3)
            {
                error_log("Erreur SQL 312:  ".$cmd2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 312 !');
            }
        }
    mysqli_free_result($result);
	}
mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifierATMConfirmed($id_atm,$cd_ATM,$cd_ATM_old,$name_ATM,$profil,$constucteur,$nbr_jr_file,$state,$send_statut,$parse_journal,$exec_command,$depl_image,$depl_binaire,$sleep_command,$state_depot_argent,$state_depot_cheque,$time_sleeping,$cd_agence,$state_uplaod_cmd)
{
    $connexion=ma_db_connexion();

	$sql = "SELECT  `id_terminal_xfs` FROM `new_list_gab` WHERE `terminal` = '".mysqli_real_escape_string($connexion,$cd_ATM_old)."'";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 313:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 313 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $SQL2="UPDATE `list_atm_confirmed` SET 
           `terminal`='".mysqli_real_escape_string($connexion,$cd_ATM)."',
           `type_gab`='".mysqli_real_escape_string($connexion,$constucteur)."',
           `nbr_jr_file`='".mysqli_real_escape_string($connexion,$nbr_jr_file)."',
           `state`='".mysqli_real_escape_string($connexion,$state)."',
           `state_send_status`='".mysqli_real_escape_string($connexion,$send_statut)."',
           `state_parse_journal`='".mysqli_real_escape_string($connexion,$parse_journal)."',
           `state_exec_command`='".mysqli_real_escape_string($connexion,$exec_command)."',
           `state_send_image`='".mysqli_real_escape_string($connexion,$depl_image)."',
           `state_send_binaire`='".mysqli_real_escape_string($connexion,$depl_binaire)."',
           `state_sleep_command`='".mysqli_real_escape_string($connexion,$sleep_command)."',
           `time_sleeping`='".mysqli_real_escape_string($connexion,$time_sleeping)."',
           `state_upload`='".mysqli_real_escape_string($connexion,$state_uplaod_cmd)."'
           WHERE  `terminal` = '".mysqli_real_escape_string($connexion,$cd_ATM_old)."'";

            mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
            $result2=mysqli_query($connexion,$SQL2);
            if (!$result2)
            {
                error_log("Erreur SQL 314:  ".$SQL2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 314 !');
            }

            $SQL3 = "UPDATE `new_list_gab` SET 
            `terminal`='".mysqli_real_escape_string($connexion,$cd_ATM)."',
            `nom_gab`='".addslashes(mysqli_real_escape_string($connexion,$name_ATM))."',
            `id_profil`='".mysqli_real_escape_string($connexion,$profil)."',
            `id_activ_depot_argent`='".mysqli_real_escape_string($connexion,$state_depot_argent)."',
            `id_activ_depot_cheque`='".mysqli_real_escape_string($connexion,$state_depot_cheque)."',
            `id_fournisseur`='".mysqli_real_escape_string($connexion,$constucteur)."',
            `code_agence`='".mysqli_real_escape_string($connexion,$cd_agence)."'
            WHERE  `terminal` = '".mysqli_real_escape_string($connexion,$cd_ATM_old)."'";

           
            $result3=mysqli_query($connexion,$SQL3);
            if (!$result3)
            {
                error_log("Erreur SQL 315:  ".$SQL3."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 315 !');
            }
        }
    }
    mysqli_free_result($result);
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifierGAB($id_atm,$name_ATM,$constucteur,$cd_agance,$ville,$region,$cd_terminal)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `id_terminal_xfs` FROM `new_list_gab` WHERE `terminal` = '".mysqli_real_escape_string($connexion,$cd_terminal)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 316:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 316 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                $SQL2="UPDATE `new_list_gab` SET 
                `nom_gab`='".addslashes(mysqli_real_escape_string($connexion,$name_ATM))."',
                `id_fournisseur`='".mysqli_real_escape_string($connexion,$constucteur)."',
                `type_gab`='".mysqli_real_escape_string($connexion,$constucteur)."',
                `code_agence`='".mysqli_real_escape_string($connexion,$cd_agance)."',
                `code_bank`='".mysqli_real_escape_string($connexion,$region)."',
                `ville`='".mysqli_real_escape_string($connexion,$ville)."'
                WHERE  `terminal` = '".mysqli_real_escape_string($connexion,$cd_terminal)."'";
                $result2=mysqli_query($connexion,$SQL2);
                if (!$result2)
                {
                    error_log("Erreur SQL 317:  ".$SQL2."  " .mysqli_error($connexion));
                    die(' ERREUR QUERY 317 !');
                }
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
		mysqli_close($connexion);
	
	
	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifierAgence($code_agence,$name_agence,$name_region,$name_ville)
{
    $connexion=ma_db_connexion();

	$sql = "SELECT  `code_agence` FROM `new_list_agence` WHERE `code_agence` = '".mysqli_real_escape_string($connexion,$code_agence)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 318:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 318 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                $SQL2="UPDATE `new_list_agence` SET  `nom_agence`='".addslashes(mysqli_real_escape_string($connexion,$name_agence))."' WHERE  `code_agence` = '".mysqli_real_escape_string($connexion,$code_agence)."'";
                $result2=mysqli_query($connexion,$SQL2);
                if (!$result2)
                {
                    error_log("Erreur SQL 319:  ".$SQL2."  " .mysqli_error($connexion));
                    die(' ERREUR QUERY 319 !');
                }
            }
		}
		else
        {
            return "";
        }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getAllServiceATM()
{
    $connexion=ma_db_connexion();

    $sql = "SELECT   `id_service`  FROM `list_service`  ORDER BY `id_service` DESC";
    $errors="";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 320:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 320 !');
    }
    if ($result)
	{	
        if(mysqli_num_rows($result)>0)
        {
            $i=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                if($i==0){$errors=$row["id_service"];}
                else{$errors=$row["id_service"].",".$errors;}
                $i++;
            }
        }
		else
        {
            return "";
        }
        mysqli_free_result($result);
        return  $errors;
	}
    mysqli_close($connexion);
	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getConfigAllServiceATM($ATM)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT   `id_service_atm`  FROM `config_service_atm` WHERE `id_atm`  = '".mysqli_real_escape_string($connexion,$ATM)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 321:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 321 !');
    }
    if ($result)
	{
 		if(mysqli_num_rows($result)>0)
        {
            $sql2 = "UPDATE `config_service_atm` SET `id_service` =  '".getAllServiceATM()."' WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$ATM)."'";
            $result2=mysqli_query($connexion,$sql2);
            if (!$result2)
            {
                error_log("Erreur SQL 322:  ".$sql2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 322 !');
            }
        }
        else
        {
            $cmd2="INSERT INTO  `config_service_atm` (`id_service_atm`, `id_atm`, `id_service`, `id_user`, `datePriseEnCharge`)
            VALUES ('', '".mysqli_real_escape_string($connexion,$ATM)."', '".getAllServiceATM()."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."', now())";
            $result2=mysqli_query($connexion,$cmd2);
            if (!$result2)
            {
                error_log("Erreur SQL 323:  ".$cmd2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 323 !');
            }
        }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getConfigAllServiceLogicalNameATM($ATM)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT   `id_logical_name`, `id_atm`, `logical_name`, `id_service`, `state`  FROM `atm_logical_names` 
			WHERE `id_atm`  = '".mysqli_real_escape_string($connexion,$ATM)."' AND `if_new` = 0";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 324:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 324 !');
    }
    if ($result)
	{			
					if(mysqli_num_rows($result)>0)
						{
						    $i=0;
						  while ($row = mysqli_fetch_assoc($result)) 
							{	
							SWITCH ($row["id_service"]) 
								{
									
 									CASE '1': //ALM
									
									
																	//////////////////////  1  ALM   ////////////////////////////
										$S_ALM="SELECT `id_insert`, `fwDevice`, `bAlarmSet`, `wAntiFraudModule`, `all_id` FROM `default_config_ALM` WHERE `id_insert`=1";
                                        $res_ALM=mysqli_query($connexion,$S_ALM);
                                        if (!$res_ALM)
                                        {
                                            error_log("Erreur SQL 325:  ".$S_ALM."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 325 !');
                                        }

										 /********************************** alimenter conf ALM ***********************************/
                                        $sql2 = "SELECT   `id_insert`  FROM `config_ALM` 
                                                WHERE `id_atm`  = '".mysqli_real_escape_string($connexion,$ATM)."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."' 
                                                AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' ";
                                        $result2=mysqli_query($connexion,$sql2);
                                        if (!$result2)
                                        {
                                            error_log("Erreur SQL 326:  ".$sql2."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 326 !');
                                        }
										if ($result2)
											{												
												if(mysqli_num_rows($result2)>0)
                                                {
                                                while ($row2 = mysqli_fetch_assoc($result2))
                                                {
                                                    while ($rows = mysqli_fetch_assoc($res_ALM))
                                                    {
                                                        $sql3 = "UPDATE `config_ALM` SET `last_update` =  NOW(),
                                                        `user_update` = '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."' ,
                                                        `fwDevice` = '".mysqli_real_escape_string($connexion,$rows["fwDevice"])."' ,
                                                        `bAlarmSet` = '".mysqli_real_escape_string($connexion,$rows["bAlarmSet"])."' ,
                                                        `wAntiFraudModule` = '".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."' ,
                                                        `all_id` = '".mysqli_real_escape_string($connexion,$rows["all_id"])."'
                                                        WHERE `id_insert` = '".mysqli_real_escape_string($connexion,$row2["id_insert"])."'";
                                                        $result3=mysqli_query($connexion,$sql3);
                                                        if (!$result3)
                                                        {
                                                            error_log("Erreur SQL 327:  ".$sql3."  " .mysqli_error($connexion));
                                                            die(' ERREUR QUERY 327 !');
                                                        }
                                                    }
                                                }

                                                }
												else
                                                {
                                                    while ($rows = mysqli_fetch_assoc($res_ALM))
                                                    {
                                                        $sql4 = "INSERT INTO  `config_ALM` (`id_insert`, `id_atm`, `id_service`, `state`, `last_update`, `user_update`, `id_logical_name`,
                                                                `logical_name`, `fwDevice`, `bAlarmSet`, 
                                                                `wAntiFraudModule`, `all_id`)
                                                                VALUES ('', '".mysqli_real_escape_string($connexion,$ATM)."', '".mysqli_real_escape_string($connexion,$row["id_service"])."',1,NOW(),'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."','".mysqli_real_escape_string($connexion,$row["id_logical_name"])."',
                                                                '".mysqli_real_escape_string($connexion,$row["logical_name"])."','".mysqli_real_escape_string($connexion,$rows["fwDevice"])."','".mysqli_real_escape_string($connexion,$rows["bAlarmSet"])."',
                                                                '".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."','".mysqli_real_escape_string($connexion,$rows["all_id"])."')";
                                                                $result4=mysqli_query($connexion,$sql4);
                                                                if (!$result4)
                                                                {
                                                                    error_log("Erreur SQL 328:  ".$sql4."  " .mysqli_error($connexion));
                                                                    die(' ERREUR QUERY 328 !');
                                                                }
                                                    }
                                                }
													
										 /********************************** FIN alimenter conf ALM ***********************************/
                                        $sql5 = "UPDATE `atm_logical_names` SET `if_new` =  1
                                        WHERE `id_logical_name` = '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."'";
                                        $result5=mysqli_query($connexion,$sql5);
                                        if (!$result5)
                                        {
                                            error_log("Erreur SQL 329:  ".$sql5."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 329 !');
                                        }

                                        mysqli_free_result($res_ALM);
                                        mysqli_free_result($result2);
										}
									BREAK;										
									
									
 									CASE '2': //BCR
									
											$S_BCR="SELECT `id_insert`, `fwDevice`, `bAlarmSet`, `wAntiFraudModule`, `all_id` FROM `default_config_BCR` 
													WHERE `id_insert`=1";
                                        $res_BCR=mysqli_query($connexion,$S_BCR);
                                        if (!$res_BCR)
                                        {
                                            error_log("Erreur SQL 330:  ".$S_BCR."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 330 !');
                                        }

								
										 /********************************** alimenter conf BCR ***********************************/
                                        $sql2 = "SELECT   `id_insert`  FROM `config_BCR` 
                                                WHERE `id_atm`  = '".mysqli_real_escape_string($connexion,$ATM)."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."' 
                                                AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' ";
                                        $result2=mysqli_query($connexion,$sql2);
                                        if (!$result2)
                                        {
                                            error_log("Erreur SQL 331:  ".$sql2."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 331 !');
                                        }
										if ($result2)
											{												
												if(mysqli_num_rows($result2)>0)
												{
													while ($row2 = mysqli_fetch_assoc($result2)) 
													{
														while ($rows = mysqli_fetch_assoc($res_BCR)) 
                                                        {
                                                            $sql3 = "UPDATE `config_BCR` SET `last_update` =  NOW(),
                                                            `user_update` = '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."' ,
                                                            `fwDevice` = '".mysqli_real_escape_string($connexion,$rows["fwDevice"])."' ,
                                                            `bAlarmSet` = '".mysqli_real_escape_string($connexion,$rows["bAlarmSet"])."' ,
                                                            `wAntiFraudModule` ='".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."' ,
                                                            `all_id` = '".mysqli_real_escape_string($connexion,$rows["all_id"])."'
                                                            WHERE `id_insert` = '".mysqli_real_escape_string($connexion,$row2["id_insert"])."'";
                                                            $result3=mysqli_query($connexion,$sql3);
                                                            if (!$result3)
                                                            {
                                                                error_log("Erreur SQL 332:  ".$sql3."  " .mysqli_error($connexion));
                                                                die(' ERREUR QUERY 332 !');
                                                            }
                                                        }
													}
												}
												else
                                                {
                                                    while ($rows = mysqli_fetch_assoc($res_BCR))
                                                    {
                                                        $sql4 = "INSERT INTO  `config_BCR` (`id_insert`, `id_atm`, `id_service`, `state`, `last_update`, `user_update`, `id_logical_name`,
                                                        `logical_name`, `fwDevice`, `bAlarmSet`, 
                                                        `wAntiFraudModule`, `all_id`)
                                                        VALUES ('', '".mysqli_real_escape_string($connexion,$ATM)."', '".mysqli_real_escape_string($connexion,$row["id_service"])."',1,NOW(),'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."','".mysqli_real_escape_string($connexion,$row["id_logical_name"])."',
                                                        '".mysqli_real_escape_string($connexion,$row["logical_name"])."','".mysqli_real_escape_string($connexion,$rows["fwDevice"])."','".mysqli_real_escape_string($connexion,$rows["bAlarmSet"])."',
                                                        '".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."','".mysqli_real_escape_string($connexion,$rows["all_id"])."')";

                                                        $result4=mysqli_query($connexion,$sql4);
                                                        if (!$result4)
                                                        {
                                                            error_log("Erreur SQL 333:  ".$sql4."  " .mysqli_error($connexion));
                                                            die(' ERREUR QUERY 333 !');
                                                        }
                                                    }
                                                }
										 /********************************** FIN alimenter conf BCR ***********************************/
                                                $sql5 = "UPDATE `atm_logical_names` SET `if_new` =  1
                                                WHERE `id_logical_name` = '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."'";
                                                $result5=mysqli_query($connexion,$sql5);
                                                if (!$result5)
                                                {
                                                    error_log("Erreur SQL 334:  ".$sql5."  " .mysqli_error($connexion));
                                                    die(' ERREUR QUERY 334 !');
                                                }
                                                mysqli_free_result($res_BCR);
                                                mysqli_free_result($result2);
										}																
									BREAK;										
									

 									CASE '3': // CAM
									
											$S_CAM="SELECT `id_insert`, `fwDevice`, `fwMedia_WFS_CAM_ROOM`,
													 `fwMedia_WFS_CAM_PERSON`, `fwMedia_WFS_CAM_EXITSLOT`,
													 `usPictures`, `wAntiFraudModule`,
													 `fwCameras_WFS_CAM_ROOM`, `fwCameras_WFS_CAM_PERSON`,
													 `fwCameras_WFS_CAM_EXITSLOT`, `all_id` 
													FROM `default_config_CAM`  	WHERE `id_insert`=1";
                                        $res_CAM=mysqli_query($connexion,$S_CAM);
                                        if (!$res_CAM)
                                        {
                                            error_log("Erreur SQL 335:  ".$S_CAM."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 335 !');
                                        }

										 /********************************** alimenter conf CAM ***********************************/
											$sql2 = "SELECT   `id_insert`  FROM `config_CAM` 
													 WHERE `id_atm`  = '".mysqli_real_escape_string($connexion,$ATM)."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."' 
													 AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' ";
                                        $result2=mysqli_query($connexion,$sql2);
                                        if (!$result2)
                                        {
                                            error_log("Erreur SQL 336:  ".$sql2."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 336 !');
                                        }
										if ($result2)
											{	
												if(mysqli_num_rows($result2)>0)
													{
													while ($row2 = mysqli_fetch_assoc($result2)) 
															{															
														while ($rows = mysqli_fetch_assoc($res_CAM)) 
																	{								 
																$sql3 = " UPDATE `config_CAM` SET `last_update` =  NOW(),
																`user_update` =   '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."' ,
																`fwDevice` =   '".mysqli_real_escape_string($connexion,$rows["fwDevice"])."' ,
																`fwMedia_WFS_CAM_ROOM` =   '".mysqli_real_escape_string($connexion,$rows["fwMedia_WFS_CAM_ROOM"])."' ,
																`fwMedia_WFS_CAM_PERSON` =   '".mysqli_real_escape_string($connexion,$rows["fwMedia_WFS_CAM_PERSON"])."' ,
																`fwMedia_WFS_CAM_EXITSLOT` =   '".mysqli_real_escape_string($connexion,$rows["fwMedia_WFS_CAM_EXITSLOT"])."' ,
																`usPictures` =   '".mysqli_real_escape_string($connexion,$rows["usPictures"])."' ,
																`wAntiFraudModule` =   '".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."' ,
																`fwCameras_WFS_CAM_ROOM` =   '".mysqli_real_escape_string($connexion,$rows["fwCameras_WFS_CAM_ROOM"])."' ,
																`fwCameras_WFS_CAM_PERSON` =   '".mysqli_real_escape_string($connexion,$rows["fwCameras_WFS_CAM_PERSON"])."' ,
																`fwCameras_WFS_CAM_EXITSLOT` =   '".mysqli_real_escape_string($connexion,$rows["fwCameras_WFS_CAM_EXITSLOT"])."' ,
																`all_id` =   '".mysqli_real_escape_string($connexion,$rows["all_id"])."'
																WHERE `id_insert` = '".mysqli_real_escape_string($connexion,$row2["id_insert"])."'";
                                                                        $result3=mysqli_query($connexion,$sql3);
                                                                        if (!$result3)
                                                                        {
                                                                            error_log("Erreur SQL 337:  ".$sql3."  " .mysqli_error($connexion));
                                                                            die(' ERREUR QUERY 337 !');
                                                                        }
																	}
															}																	
													}	
												else
                                                {
                                                    while ($rows = mysqli_fetch_assoc($res_CAM))
                                                    {
                                                        $sql4 = "INSERT INTO  `config_CAM` (`id_insert`, `id_atm`, `id_service`, `state`, `last_update`, `user_update`, `id_logical_name`,
                                                        `logical_name`, `fwDevice`, `fwMedia_WFS_CAM_ROOM`,
                                                         `fwMedia_WFS_CAM_PERSON`, `fwMedia_WFS_CAM_EXITSLOT`,
                                                         `usPictures`, `wAntiFraudModule`,
                                                         `fwCameras_WFS_CAM_ROOM`, `fwCameras_WFS_CAM_PERSON`,
                                                         `fwCameras_WFS_CAM_EXITSLOT`, `all_id`)
                                                        VALUES ('', '".mysqli_real_escape_string($connexion,$ATM)."', '".mysqli_real_escape_string($connexion,$row["id_service"])."',1,NOW(),
                                                        '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."','".mysqli_real_escape_string($connexion,$row["id_logical_name"])."',
                                                        '".mysqli_real_escape_string($connexion,$row["logical_name"])."','".mysqli_real_escape_string($connexion,$rows["fwDevice"])."','".mysqli_real_escape_string($connexion,$rows["fwMedia_WFS_CAM_ROOM"])."',
                                                        '".mysqli_real_escape_string($connexion,$rows["fwMedia_WFS_CAM_PERSON"])."','".mysqli_real_escape_string($connexion,$rows["fwMedia_WFS_CAM_EXITSLOT"])."',
                                                        '".mysqli_real_escape_string($connexion,$rows["usPictures"])."','".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."',
                                                        '".mysqli_real_escape_string($connexion,$rows["fwCameras_WFS_CAM_ROOM"])."','".mysqli_real_escape_string($connexion,$rows["fwCameras_WFS_CAM_PERSON"])."',
                                                        '".mysqli_real_escape_string($connexion,$rows["fwCameras_WFS_CAM_EXITSLOT"])."','".mysqli_real_escape_string($connexion,$rows["all_id"])."')";
                                                        $result4=mysqli_query($connexion,$sql4);
                                                        if (!$result4)
                                                        {
                                                            error_log("Erreur SQL 338:  ".$sql4."  " .mysqli_error($connexion));
                                                            die(' ERREUR QUERY 338 !');
                                                        }
                                                    }
                                                }
										 /********************************** FIN alimenter conf CAM ***********************************/
                                                $sql5 = "UPDATE `atm_logical_names` SET `if_new` =  1
                                                WHERE `id_logical_name` = '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."'";
                                                $result5=mysqli_query($connexion,$sql5);
                                                if (!$result5)
                                                {
                                                    error_log("Erreur SQL 339:  ".$sql5."  " .mysqli_error($connexion));
                                                    die(' ERREUR QUERY 339 !');
                                                }
                                                mysqli_free_result($res_CAM);
                                                mysqli_free_result($result2);
										}																
									BREAK;										
									

									CASE '4': //CDM
									
									$S_CDM="SELECT `id_insert`, `fwDevice`, `fwSafeDoor`, `fwDispenser`, `fwIntermediateStacker`, `fwPosition`, `fwPositionStatus`, `fwShutter`, `fwTransport`, 
										`fwTransportStatus`, `fwJammedShutterPosition`, `dwGuidLights`, `wDevicePosition`, `usPowerSaveRecoveryTime`, `all_id` 
										FROM `default_config_CDM` WHERE `id_insert`=1";
                                        $res_CDM=mysqli_query($connexion,$S_CDM);
                                        if (!$res_CDM)
                                        {
                                            error_log("Erreur SQL 340:  ".$S_CDM."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 340 !');
                                        }

										 /********************************** alimenter conf CDM ***********************************/
                                        $sql2 = "SELECT   `id_insert`  FROM `config_CDM` 
                                                WHERE `id_atm`  = '".$ATM."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."' 
                                                AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' ";
                                        $result2=mysqli_query($connexion,$sql2);
                                        if (!$result2)
                                        {
                                            error_log("Erreur SQL 341:  ".$sql2."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 341 !');
                                        }
										if ($result2)
											{												
												if(mysqli_num_rows($result2)>0)
												{
													while ($row2 = mysqli_fetch_assoc($result2)) 
													{
														while ($rows = mysqli_fetch_assoc($res_CDM)) 
                                                        {
                                                            $sql3 = "UPDATE `config_CDM` SET `last_update` =  NOW(),
                                                            `user_update` = '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."' ,
                                                            `fwDevice` = '".mysqli_real_escape_string($connexion,$rows["fwDevice"])."' ,
                                                            `fwSafeDoor` = '".mysqli_real_escape_string($connexion,$rows["fwSafeDoor"])."' ,
                                                            `fwDispenser` = '".mysqli_real_escape_string($connexion,$rows["fwDispenser"])."' ,
                                                            `fwIntermediateStacker` = '".mysqli_real_escape_string($connexion,$rows["fwIntermediateStacker"])."' ,
                                                            `fwPosition` = '".mysqli_real_escape_string($connexion,$rows["fwPosition"])."' ,
                                                            `fwPositionStatus` = '".mysqli_real_escape_string($connexion,$rows["fwPositionStatus"])."' ,
                                                            `fwShutter` = '".mysqli_real_escape_string($connexion,$rows["fwShutter"])."' ,
                                                            `fwTransport` = ".mysqli_real_escape_string($connexion,$rows["fwTransport"])."' ,
                                                            `fwTransportStatus` = '".mysqli_real_escape_string($connexion,$rows["fwTransportStatus"])."' ,
                                                            `fwJammedShutterPosition` = '".mysqli_real_escape_string($connexion,$rows["fwJammedShutterPosition"])."' ,
                                                            `dwGuidLights` = '".mysqli_real_escape_string($connexion,$rows["dwGuidLights"])."' ,
                                                            `wDevicePosition` = '".mysqli_real_escape_string($connexion,$rows["wDevicePosition"])."' ,
                                                            `usPowerSaveRecoveryTime` = '".mysqli_real_escape_string($connexion,$rows["usPowerSaveRecoveryTime"])."' ,
                                                            `all_id` = '".mysqli_real_escape_string($connexion,$rows["all_id"])."
                                                             WHERE `id_insert` = '".mysqli_real_escape_string($connexion,$row2["id_insert"])."'";
                                                            $result3=mysqli_query($connexion,$sql3);
                                                            if (!$result3)
                                                            {
                                                                error_log("Erreur SQL 342:  ".$sql3."  " .mysqli_error($connexion));
                                                                die(' ERREUR QUERY 342 !');
                                                            }
                                                        }
													}
												}
												else
                                                {
                                                    while ($rows = mysqli_fetch_assoc($res_CDM))
                                                    {

                                                        $sql4 = "INSERT INTO  `config_CDM` (`id_insert`, `id_atm`, `id_service`, `state`, `last_update`, `user_update`, `id_logical_name`,
                                                        `logical_name`, `fwDevice`, `fwSafeDoor`, `fwDispenser`, 
                                                        `fwIntermediateStacker`, `fwPosition`, `fwPositionStatus`, 
                                                        `fwShutter`, `fwTransport`, `fwTransportStatus`, `fwJammedShutterPosition`, 
                                                         `dwGuidLights`, `wDevicePosition`, `usPowerSaveRecoveryTime`, `all_id`)
                                                        VALUES ('', '".mysqli_real_escape_string($connexion,$ATM)."', '".mysqli_real_escape_string($connexion,$row["id_service"])."',1,NOW(),
                                                        '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."','".mysqli_real_escape_string($connexion,$row["id_logical_name"])."',
                                                        '".mysqli_real_escape_string($connexion,$row["logical_name"])."','".mysqli_real_escape_string($connexion,$rows["fwDevice"])."','".mysqli_real_escape_string($connexion,$rows["fwSafeDoor"])."','".mysqli_real_escape_string($connexion,$rows["fwDispenser"])."',
                                                        '".mysqli_real_escape_string($connexion,$rows["fwIntermediateStacker"])."','".mysqli_real_escape_string($connexion,$rows["fwPosition"])."','".mysqli_real_escape_string($connexion,$rows["fwPositionStatus"])."',
                                                        '".mysqli_real_escape_string($connexion,$rows["fwShutter"])."','".mysqli_real_escape_string($connexion,$rows["fwTransport"])."',
                                                        '".mysqli_real_escape_string($connexion,$rows["fwTransportStatus"])."','".mysqli_real_escape_string($connexion,$rows["fwJammedShutterPosition"])."',
                                                        '".mysqli_real_escape_string($connexion,$rows["dwGuidLights"])."','".mysqli_real_escape_string($connexion,$rows["wDevicePosition"])."','".mysqli_real_escape_string($connexion,$rows["usPowerSaveRecoveryTime"])."','".mysqli_real_escape_string($connexion,$rows["all_id"])."')";
                                                        $result4=mysqli_query($connexion,$sql4);
                                                        if (!$result4)
                                                        {
                                                            error_log("Erreur SQL 343:  ".$sql4."  " .mysqli_error($connexion));
                                                            die(' ERREUR QUERY 343 !');
                                                        }
                                                    }
                                                }
										 /********************************** FIN alimenter conf CDM ***********************************/
                                                $sql5 = "UPDATE `atm_logical_names` SET `if_new` =  1
                                                WHERE `id_logical_name` = '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."'";
                                                $result5=mysqli_query($connexion,$sql5);
                                                if (!$result5)
                                                {
                                                    error_log("Erreur SQL 344:  ".$sql5."  " .mysqli_error($connexion));
                                                    die(' ERREUR QUERY 344 !');
                                                }
                                                mysqli_free_result($res_CDM);
                                                mysqli_free_result($result2);
										}										 
										 
									BREAK;		

 									CASE '6': // CHK
									
                                        $S_CHK="SELECT `id_insert`, `fwDevice`, `bAlarmSet`, `wAntiFraudModule`, `all_id` FROM `default_config_CHK` 
                                                WHERE `id_insert`=1";
                                        $res_CHK=mysqli_query($connexion,$S_CHK);
                                        if (!$res_CHK)
                                        {
                                            error_log("Erreur SQL 345:  ".$S_CHK."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 345 !');
                                        }
										 /********************************** alimenter conf CHK ***********************************/
                                        $sql2 = "SELECT   `id_insert`  FROM `config_CHK` 
                                                WHERE `id_atm`  = '".mysqli_real_escape_string($connexion,$ATM)."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."' 
                                                AND `id_logical_name`= '".$row["id_logical_name"]."' ";
                                        $result2=mysqli_query($connexion,$sql2);
                                        if (!$result2)
                                        {
                                            error_log("Erreur SQL 346:  ".$sql2."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 346 !');
                                        }
										if ($result2)
										{
                                            if(mysqli_num_rows($result2)>0)
                                            {
                                                while ($row2 = mysqli_fetch_assoc($result2))
                                                {
                                                    while ($rows = mysqli_fetch_assoc($res_CHK))
                                                    {
                                                        $sql3 = "UPDATE `config_CHK` SET `last_update` =  NOW(),
                                                        `user_update` = '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."' ,
                                                        `fwDevice` =   '".mysqli_real_escape_string($connexion,$rows["fwDevice"])."' ,
                                                        `bAlarmSet` =   '".mysqli_real_escape_string($connexion,$rows["bAlarmSet"])."' ,
                                                        `wAntiFraudModule` =   '".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."' ,
                                                        `all_id` =   '".mysqli_real_escape_string($connexion,$rows["all_id"])."'
                                                        WHERE `id_insert` = '".mysqli_real_escape_string($connexion,$row2["id_insert"])."'";
                                                        $result3=mysqli_query($connexion,$sql3);
                                                        if (!$result3)
                                                        {
                                                            error_log("Erreur SQL 347:  ".$sql3."  " .mysqli_error($connexion));
                                                            die(' ERREUR QUERY 347 !');
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                while ($rows = mysqli_fetch_assoc($res_CHK))
                                                {
                                                    $sql4 = "INSERT INTO  `config_CHK` (`id_insert`, `id_atm`, `id_service`, `state`, `last_update`, `user_update`, `id_logical_name`,
                                                    `logical_name`, `fwDevice`, `bAlarmSet`, 
                                                    `wAntiFraudModule`, `all_id`)
                                                    VALUES ('', '".mysqli_real_escape_string($connexion,$ATM)."', '".mysqli_real_escape_string($connexion,$row["id_service"])."',1,NOW(),'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."','".mysqli_real_escape_string($connexion,$row["id_logical_name"])."',
                                                    '".mysqli_real_escape_string($connexion,$row["logical_name"])."','".mysqli_real_escape_string($connexion,$rows["fwDevice"])."','".mysqli_real_escape_string($connexion,$rows["bAlarmSet"])."',
                                                    '".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."','".mysqli_real_escape_string($connexion,$rows["all_id"])."')";
                                                    $result4=mysqli_query($connexion,$sql4);
                                                    if (!$result4)
                                                    {
                                                        error_log("Erreur SQL 348:  ".$sql4."  " .mysqli_error($connexion));
                                                        die(' ERREUR QUERY 348 !');
                                                    }
                                                }
                                            }
										 /********************************** FIN alimenter conf CHK ***********************************/
                                            $sql5 = "UPDATE `atm_logical_names` SET `if_new` =  1
                                            WHERE `id_logical_name` = '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."'";
                                            $result5=mysqli_query($connexion,$sql5);
                                            if (!$result5)
                                            {
                                                error_log("Erreur SQL 349:  ".$sql5."  " .mysqli_error($connexion));
                                                die(' ERREUR QUERY 349 !');
                                            }
											mysqli_free_result($res_CHK);						
											mysqli_free_result($result2);	
										}																
									BREAK;	
									
									CASE '7': //CIM
									
									
										$S_CIM="SELECT `id_insert`, `fwDevice`, `fwSafeDoor`, `fwAcceptor`,
												 `fwIntermediateStacker`, `fwStackerItems`, 
												 `fwBanknoteReader`, `bDropBox`, `fwPosition`, 
												 `fwShutter`, `fwPositionStatus`, 
												 `fwTransport`, `fwTransportStatus`, 
												 `fwJammedShutterPosition`, `dwGuidLights`, 
												 `usPowerSaveRecoveryTime`, `wMixedMode`, 
												 `wAntiFraudModule`, `all_id`
												 FROM `default_config_CIM` WHERE `id_insert`=1";

                                        $res_CIM=mysqli_query($connexion,$S_CIM);
                                        if (!$res_CIM)
                                        {
                                            error_log("Erreur SQL 350:  ".$S_CIM."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 350 !');
                                        }
										 /********************************** alimenter conf CIM ***********************************/
											$sql2 = "SELECT   `id_insert`  FROM `config_CIM` 
													WHERE `id_atm`  = '".mysqli_real_escape_string($connexion,$ATM)."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."' 
													AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' ";
                                        $result2=mysqli_query($connexion,$sql2);
                                        if (!$result2)
                                        {
                                            error_log("Erreur SQL 351:  ".$sql2."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 351 !');
                                        }
										if ($result2)
										{
                                            if(mysqli_num_rows($result2)>0)
                                            {
                                                while ($row2 = mysqli_fetch_assoc($result2))
                                                {
                                                    while ($rows = mysqli_fetch_assoc($res_CIM))
                                                    {
                                                        $sql3 = "UPDATE `config_CIM` SET `last_update` =  NOW(),
                                                        `user_update` =   '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."' ,
                                                        `fwDevice` =   '".mysqli_real_escape_string($connexion,$rows["fwDevice"])."' ,
                                                        `fwSafeDoor` =   '".mysqli_real_escape_string($connexion,$rows["fwSafeDoor"])."' ,
                                                        `fwAcceptor` =   '".mysqli_real_escape_string($connexion,$rows["fwAcceptor"])."' ,
                                                        `fwIntermediateStacker` =   '".mysqli_real_escape_string($connexion,$rows["fwIntermediateStacker"])."' ,
                                                        `fwStackerItems` =   '".mysqli_real_escape_string($connexion,$rows["fwStackerItems"])."' ,
                                                        `fwBanknoteReader` =   '".mysqli_real_escape_string($connexion,$rows["fwBanknoteReader"])."' ,
                                                        `bDropBox` =   '".mysqli_real_escape_string($connexion,$rows["bDropBox"])."' ,
                                                        `fwPosition` =   '".mysqli_real_escape_string($connexion,$rows["fwPosition"])."' ,
                                                        `fwShutter` =   '".mysqli_real_escape_string($connexion,$rows["fwShutter"])."' ,
                                                        `fwPositionStatus` =   '".mysqli_real_escape_string($connexion,$rows["fwPositionStatus"])."' ,
                                                        `fwTransport` =   '".mysqli_real_escape_string($connexion,$rows["fwTransport"])."' ,
                                                        `fwTransportStatus` = '".mysqli_real_escape_string($connexion,$rows["fwTransportStatus"])."' ,																
                                                        `fwJammedShutterPosition` =   '".mysqli_real_escape_string($connexion,$rows["fwJammedShutterPosition"])."' ,
                                                        `dwGuidLights` =   '".mysqli_real_escape_string($connexion,$rows["dwGuidLights"])."' ,																
                                                        `usPowerSaveRecoveryTime` =   '".mysqli_real_escape_string($connexion,$rows["usPowerSaveRecoveryTime"])."' ,
                                                        `wMixedMode` =   '".mysqli_real_escape_string($connexion,$rows["wMixedMode"])."' ,
                                                        `wAntiFraudModule` =   '".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."' ,
                                                        `all_id` =   '".mysqli_real_escape_string($connexion,$rows["all_id"])."'
                                                        WHERE `id_insert` = '".mysqli_real_escape_string($connexion,$row2["id_insert"])."'";

                                                        $result3=mysqli_query($connexion,$sql3);
                                                        if (!$result3)
                                                        {
                                                            error_log("Erreur SQL 352:  ".$sql3."  " .mysqli_error($connexion));
                                                            die(' ERREUR QUERY 352 !');
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                while ($rows = mysqli_fetch_assoc($res_CIM))
                                                {

                                                    $sql4 = "INSERT INTO  `config_CIM` (`id_insert`, `id_atm`, `id_service`, `state`, `last_update`, `user_update`, `id_logical_name`,
                                                    `logical_name`, `fwDevice`, `fwSafeDoor`, `fwAcceptor`,
                                                     `fwIntermediateStacker`, `fwStackerItems`, 
                                                     `fwBanknoteReader`, `bDropBox`, `fwPosition`, 
                                                     `fwShutter`, `fwPositionStatus`, 
                                                     `fwTransport`, `fwTransportStatus`, 
                                                     `fwJammedShutterPosition`, `dwGuidLights`, 
                                                     `usPowerSaveRecoveryTime`, `wMixedMode`, 
                                                     `wAntiFraudModule`, `all_id`)
                                                    VALUES ('', '".mysqli_real_escape_string($connexion,$ATM)."', '".mysqli_real_escape_string($connexion,$row["id_service"])."',1,NOW(),'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',
                                                    '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."',
                                                    '".mysqli_real_escape_string($connexion,$row["logical_name"])."','".mysqli_real_escape_string($connexion,$rows["fwDevice"])."','".mysqli_real_escape_string($connexion,$rows["fwSafeDoor"])."',
                                                    '".mysqli_real_escape_string($connexion,$rows["fwAcceptor"])."',
                                                    '".mysqli_real_escape_string($connexion,$rows["fwIntermediateStacker"])."','".mysqli_real_escape_string($connexion,$rows["fwStackerItems"])."','".mysqli_real_escape_string($connexion,$rows["fwBanknoteReader"])."',
                                                    '".mysqli_real_escape_string($connexion,$rows["bDropBox"])."','".mysqli_real_escape_string($connexion,$rows["fwPosition"])."','".mysqli_real_escape_string($connexion,$rows["fwShutter"])."','".mysqli_real_escape_string($connexion,$rows["fwPositionStatus"])."',
                                                    '".mysqli_real_escape_string($connexion,$rows["fwTransport"])."','".mysqli_real_escape_string($connexion,$rows["fwTransportStatus"])."',
                                                    '".mysqli_real_escape_string($connexion,$rows["fwJammedShutterPosition"])."','".mysqli_real_escape_string($connexion,$rows["dwGuidLights"])."',
                                                    '".mysqli_real_escape_string($connexion,$rows["usPowerSaveRecoveryTime"])."','".mysqli_real_escape_string($connexion,$rows["wMixedMode"])."',
                                                    '".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."','".mysqli_real_escape_string($connexion,$rows["all_id"])."')";
                                                    $result4=mysqli_query($connexion,$sql4);
                                                    if (!$result4)
                                                    {
                                                        error_log("Erreur SQL 353:  ".$sql4."  " .mysqli_error($connexion));
                                                        die(' ERREUR QUERY 353 !');
                                                    }
                                                }
                                            }
										 /********************************** FIN alimenter conf CIM ***********************************/
                                            $sql5 = "UPDATE `atm_logical_names` SET `if_new` =  1
                                            WHERE `id_logical_name` = '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."'";
                                            $result5=mysqli_query($connexion,$sql5);
                                            if (!$result5)
                                            {
                                                error_log("Erreur SQL 354:  ".$sql5."  " .mysqli_error($connexion));
                                                die(' ERREUR QUERY 354 !');
                                            }
											mysqli_free_result($res_CIM);						
											mysqli_free_result($result2);	
										}										 
										 
									BREAK;										
									
 									CASE '10': //IDC
									
										$S_IDC="SELECT `id_insert`, `fwDevice`, `fwMedia`, 
												`fwRetainBin`, `fwSecurity`, `usCards`, 
												`fwChipPower`, `dwGuidLights`, 
												`dwGuidLights_WFS_IDC_GUIDANCE_CARDUNIT`, `fwChipModule`, 
												`fwMagReadModule`, `fwMagWriteModule`, 
												`fwFrontImageModule`, `fwBackImageModule`, 
												`wDevicePosition`, `usPowerSaveRecoveryTime`, 
												`wAntiFraudModule`, `all_id` 
												FROM `default_config_IDC` WHERE `id_insert`=1";
                                        $res_IDC=mysqli_query($connexion,$S_IDC);
                                        if (!$res_IDC)
                                        {
                                            error_log("Erreur SQL 355:  ".$S_IDC."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 355 !');
                                        }

										 /********************************** alimenter conf IDC ***********************************/
											$sql2 = "SELECT   `id_insert`  FROM `config_IDC` 
													WHERE `id_atm`  = '".mysqli_real_escape_string($connexion,$ATM)."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."' 
													AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' ";
                                        $result2=mysqli_query($connexion,$sql2);
                                        if (!$result2)
                                        {
                                            error_log("Erreur SQL 356:  ".$sql2."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 356 !');
                                        }
										if ($result2)
										{
												if(mysqli_num_rows($result2)>0)
												{
													while ($row2 = mysqli_fetch_assoc($result2)) 
                                                    {
														while ($rows = mysqli_fetch_assoc($res_IDC)) 
														{
                                                            $sql3 = "UPDATE `config_IDC` SET `last_update` =  NOW(),
                                                            `user_update` =   '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."' ,
                                                            `fwDevice` =   '".mysqli_real_escape_string($connexion,$rows["fwDevice"])."' ,
                                                            `fwMedia` =   '".mysqli_real_escape_string($connexion,$rows["fwMedia"])."' ,
                                                            `fwRetainBin` =   '".mysqli_real_escape_string($connexion,$rows["fwRetainBin"])."' ,
                                                            `fwSecurity` =   '".mysqli_real_escape_string($connexion,$rows["fwSecurity"])."' ,
                                                            `usCards` =   '".mysqli_real_escape_string($connexion,$rows["usCards"])."' ,
                                                            `fwChipPower` =   '".mysqli_real_escape_string($connexion,$rows["fwChipPower"])."' ,
                                                            `dwGuidLights` =   '".mysqli_real_escape_string($connexion,$rows["dwGuidLights"])."' ,
                                                            `dwGuidLights_WFS_IDC_GUIDANCE_CARDUNIT` =   '".mysqli_real_escape_string($connexion,$rows["dwGuidLights_WFS_IDC_GUIDANCE_CARDUNIT"])."' ,
                                                            `fwChipModule` =   '".mysqli_real_escape_string($connexion,$rows["fwChipModule"])."' ,
                                                            `fwMagReadModule` =   '".mysqli_real_escape_string($connexion,$rows["fwMagReadModule"])."' ,
                                                            `fwMagWriteModule` =   '".mysqli_real_escape_string($connexion,$rows["fwMagWriteModule"])."' ,
                                                            `fwFrontImageModule` =   '".mysqli_real_escape_string($connexion,$rows["fwFrontImageModule"])."' ,
                                                            `fwBackImageModule` =   '".mysqli_real_escape_string($connexion,$rows["fwBackImageModule"])."' ,
                                                            `wDevicePosition` =   '".mysqli_real_escape_string($connexion,$rows["wDevicePosition"])."' ,
                                                            `usPowerSaveRecoveryTime` =   '".mysqli_real_escape_string($connexion,$rows["usPowerSaveRecoveryTime"])."' ,
                                                            `wAntiFraudModule` =   '".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."' ,
                                                            `all_id` =   '".mysqli_real_escape_string($connexion,$rows["all_id"])."'
                                                            WHERE `id_insert` = '".mysqli_real_escape_string($connexion,$row2["id_insert"])."'";
                                                            $result3=mysqli_query($connexion,$sql3);
                                                            if (!$result3)
                                                            {
                                                                error_log("Erreur SQL 357:  ".$sql3."  " .mysqli_error($connexion));
                                                                die(' ERREUR QUERY 357 !');
                                                            }
														}
                                                    }
												}
												else
													{
													while ($rows = mysqli_fetch_assoc($res_IDC)) 
																	{														

																$sql4 = "INSERT INTO  `config_IDC` (`id_insert`, `id_atm`, `id_service`, `state`, `last_update`, `user_update`, `id_logical_name`,
																		`logical_name`, `fwDevice`, `fwMedia`, 
																		`fwRetainBin`, `fwSecurity`, `usCards`, 
																		`fwChipPower`, `dwGuidLights`, 
																		`dwGuidLights_WFS_IDC_GUIDANCE_CARDUNIT`, `fwChipModule`, 
																		`fwMagReadModule`, `fwMagWriteModule`, 
																		`fwFrontImageModule`, `fwBackImageModule`, 
																		`wDevicePosition`, `usPowerSaveRecoveryTime`, 
																		`wAntiFraudModule`, `all_id`)
																		VALUES ('', '".mysqli_real_escape_string($connexion,$ATM)."', '".mysqli_real_escape_string($connexion,$row["id_service"])."',1,NOW(),'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."','".mysqli_real_escape_string($connexion,$row["id_logical_name"])."',
																		'".mysqli_real_escape_string($connexion,$row["logical_name"])."','".mysqli_real_escape_string($connexion,$rows["fwDevice"])."','".mysqli_real_escape_string($connexion,$rows["fwMedia"])."',
																		'".mysqli_real_escape_string($connexion,$rows["fwRetainBin"])."',
																		'".mysqli_real_escape_string($connexion,$rows["fwSecurity"])."','".mysqli_real_escape_string($connexion,$rows["usCards"])."',
																		'".mysqli_real_escape_string($connexion,$rows["fwChipPower"])."','".mysqli_real_escape_string($connexion,$rows["dwGuidLights"])."',
																		'".mysqli_real_escape_string($connexion,$rows["dwGuidLights_WFS_IDC_GUIDANCE_CARDUNIT"])."','".mysqli_real_escape_string($connexion,$rows["fwChipModule"])."',
																		'".mysqli_real_escape_string($connexion,$rows["fwMagReadModule"])."','".mysqli_real_escape_string($connexion,$rows["fwMagWriteModule"])."',
																		'".mysqli_real_escape_string($connexion,$rows["fwFrontImageModule"])."','".mysqli_real_escape_string($connexion,$rows["fwBackImageModule"])."',
																		'".mysqli_real_escape_string($connexion,$rows["wDevicePosition"])."','".mysqli_real_escape_string($connexion,$rows["usPowerSaveRecoveryTime"])."',
																		'".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."','".mysqli_real_escape_string($connexion,$rows["all_id"])."')";
                                                                        $result4=mysqli_query($connexion,$sql4);
                                                                        if (!$result4)
                                                                        {
                                                                            error_log("Erreur SQL 358:  ".$sql4."  " .mysqli_error($connexion));
                                                                            die(' ERREUR QUERY 358 !');
                                                                        }

																	}												
													}
										 /********************************** FIN alimenter conf IDC ***********************************/
																$sql5 = "UPDATE `atm_logical_names` SET `if_new` =  1
																WHERE `id_logical_name` = '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."'";
                                            $result5=mysqli_query($connexion,$sql5);
                                            if (!$result5)
                                            {
                                                error_log("Erreur SQL 359:  ".$sql5."  " .mysqli_error($connexion));
                                                die(' ERREUR QUERY 359 !');
                                            }

											mysqli_free_result($res_IDC);						
											mysqli_free_result($result2);	
										}
									BREAK;	
									
									
 									CASE '12': //PIN
									
											$S_PIN="SELECT `id_insert`, `fwDevice`, `fwEncStat`, `dwGuidLights_WFS_PIN_GUIDLIGHTS_SIZE`,
													`dwGuidLights`, `fwAutoBeepMode`, `dwCertificateState`,
													`wDevicePosition`, `usPowerSaveRecoveryTime`, `wAntiFraudModule`, `all_id` 
													FROM `default_config_PIN` WHERE `id_insert`=1";
                                        $res_PIN=mysqli_query($connexion,$S_PIN);
                                        if (!$res_PIN)
                                        {
                                            error_log("Erreur SQL 360:  ".$S_PIN."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 360 !');
                                        }

							  									
										 /********************************** alimenter conf PIN ***********************************/
											$sql2 = "SELECT   `id_insert`  FROM `config_PIN` 
													WHERE `id_atm`  = '".mysqli_real_escape_string($connexion,$ATM)."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."' 
													AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' ";
                                        $result2=mysqli_query($connexion,$sql2);
                                        if (!$result2)
                                        {
                                            error_log("Erreur SQL 361:  ".$sql2."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 361 !');
                                        }
										if ($result2=mysqli_query($connexion,$sql2) or die('Erreur sql2  getConfigAllServiceLogicalNameATM 333333 !<br>'.$sql2.'<br>'.mysqli_error($connexion)))
											{												
												if(mysqli_num_rows($result2)>0)
													{
													while ($row2 = mysqli_fetch_assoc($result2)) 
															{															
														while ($rows = mysqli_fetch_assoc($res_PIN)) 
																	{										 
																$sql3 = "UPDATE `config_PIN` SET `last_update` =  NOW(),
																`user_update` =   '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."' ,
																`fwDevice` =   '".mysqli_real_escape_string($connexion,$rows["fwDevice"])."' ,
																`fwEncStat` =   '".mysqli_real_escape_string($connexion,$rows["fwEncStat"])."' ,
																`dwGuidLights_WFS_PIN_GUIDLIGHTS_SIZE` =   '".mysqli_real_escape_string($connexion,$rows["dwGuidLights_WFS_PIN_GUIDLIGHTS_SIZE"])."' ,
																`dwGuidLights` =   '".mysqli_real_escape_string($connexion,$rows["dwGuidLights"])."' ,
																`fwAutoBeepMode` =   '".mysqli_real_escape_string($connexion,$rows["fwAutoBeepMode"])."' ,
																`dwCertificateState` =   '".mysqli_real_escape_string($connexion,$rows["dwCertificateState"])."' ,
																`wDevicePosition` =   '".mysqli_real_escape_string($connexion,$rows["wDevicePosition"])."' ,
																`usPowerSaveRecoveryTime` =   '".mysqli_real_escape_string($connexion,$rows["usPowerSaveRecoveryTime"])."' ,
																`wAntiFraudModule` =   '".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."' ,
																`all_id` =   '".mysqli_real_escape_string($connexion,$rows["all_id"])."'
																WHERE `id_insert` = '".mysqli_real_escape_string($connexion,$row2["id_insert"])."'";
                                                                        $result3=mysqli_query($connexion,$sql3);
                                                                        if (!$result3)
                                                                        {
                                                                            error_log("Erreur SQL 362:  ".$sql3."  " .mysqli_error($connexion));
                                                                            die(' ERREUR QUERY 362 !');
                                                                        }
																	}
															}								 
													}	
												else
													{
													while ($rows = mysqli_fetch_assoc($res_PIN)) 
																	{														

																$sql4 = "INSERT INTO  `config_PIN` (`id_insert`, `id_atm`, `id_service`, `state`, `last_update`, `user_update`, `id_logical_name`,
																		`logical_name`, `fwDevice`, `fwEncStat`,
																		`dwGuidLights_WFS_PIN_GUIDLIGHTS_SIZE`,
																		 `dwGuidLights`, `fwAutoBeepMode`, `dwCertificateState`,
																		`wDevicePosition`, `usPowerSaveRecoveryTime`,
																		`wAntiFraudModule`, `all_id` )
																		VALUES ('', '".mysqli_real_escape_string($connexion,$ATM)."', '".mysqli_real_escape_string($connexion,$row["id_service"])."',1,NOW(),'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."','".mysqli_real_escape_string($connexion,$row["id_logical_name"])."',
																		'".mysqli_real_escape_string($connexion,$row["logical_name"])."','".mysqli_real_escape_string($connexion,$rows["fwDevice"])."','".mysqli_real_escape_string($connexion,$rows["fwEncStat"])."',
																		'".mysqli_real_escape_string($connexion,$rows["dwGuidLights_WFS_PIN_GUIDLIGHTS_SIZE"])."',
																		'".mysqli_real_escape_string($connexion,$rows["dwGuidLights"])."','".mysqli_real_escape_string($connexion,$rows["fwAutoBeepMode"])."','".mysqli_real_escape_string($connexion,$rows["dwCertificateState"])."',
																		'".mysqli_real_escape_string($connexion,$rows["wDevicePosition"])."','".mysqli_real_escape_string($connexion,$rows["usPowerSaveRecoveryTime"])."',
																		'".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."','".mysqli_real_escape_string($connexion,$rows["all_id"])."')";
                                                                        $result4=mysqli_query($connexion,$sql4);
                                                                        if (!$result4)
                                                                        {
                                                                            error_log("Erreur SQL 363:  ".$sql4."  " .mysqli_error($connexion));
                                                                            die(' ERREUR QUERY 363 !');
                                                                        }
																	}											
													}
										 /********************************** FIN alimenter conf PIN ***********************************/
                                                $sql5 = "UPDATE `atm_logical_names` SET `if_new` =  1
                                                WHERE `id_logical_name` = '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."'";
                                                $result5=mysqli_query($connexion,$sql5);
                                                if (!$result5)
                                                {
                                                    error_log("Erreur SQL 364:  ".$sql5."  " .mysqli_error($connexion));
                                                    die(' ERREUR QUERY 364 !');
                                                }

											mysqli_free_result($res_PIN);						
											mysqli_free_result($result2);	
										}																
									BREAK;	


 									CASE '13': //PTR
									
									
                                        $S_PTR="SELECT `id_insert`, `fwDevice`, `fwMedia`, `fwPaper_WFS_PTR_SUPPLYSIZE`,
                                             `fwPaper_WFS_PTR_SUPPLYUPPER`, `fwPaper_WFS_PTR_SUPPLYLOWER`,
                                             `fwPaper_WFS_PTR_SUPPLYEXTERNAL`, `fwPaper_WFS_PTR_SUPPLYAUX`, 
                                             `fwPaper_WFS_PTR_SUPPLYAUX2`, `fwPaper_WFS_PTR_SUPPLYPARK`,
                                             `usRetractCount`, `wRetractBin`, `fwToner`,
                                             `fwInk`, `fwLamp`, `wDevicePosition`,
                                             `usPowerSaveRecoveryTime`, `wPaperType_WFS_PTR_SUPPLYUPPER`,
                                             `wPaperType_WFS_PTR_SUPPLYLOWER`, `wPaperType_WFS_PTR_SUPPLYEXTERNAL`, 
                                             `wPaperType_WFS_PTR_SUPPLYPARK`, `wPaperType_WFS_PTR_SUPPLYAUX`, 
                                             `wPaperType_WFS_PTR_SUPPLYAUX2`, `wAntiFraudModule`,
                                             `wBlackMarkMode`, `all_id` 
                                                FROM `default_config_PTR` WHERE `id_insert`=1";
                                        $res_PTR=mysqli_query($connexion,$S_PTR);
                                        if (!$res_PTR)
                                        {
                                            error_log("Erreur SQL 365:  ".$S_PTR."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 365 !');
                                        }

													
										 /********************************** alimenter conf PTR ***********************************/
											$sql2 = "SELECT   `id_insert`  FROM `config_PTR` 
													WHERE `id_atm`  = '".mysqli_real_escape_string($connexion,$ATM)."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."' 
													AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' ";
                                        $result2=mysqli_query($connexion,$sql2);
                                        if (!$result2)
                                        {
                                            error_log("Erreur SQL 366:  ".$sql2."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 366 !');
                                        }
										if ($result2)
										{
												if(mysqli_num_rows($result2)>0)
												{
													while ($row2 = mysqli_fetch_assoc($result2)) 
													{
														while ($rows = mysqli_fetch_assoc($res_PTR)) 
														 {
																$sql3 = "UPDATE `config_PTR` SET `last_update` =  NOW(),
																`user_update` =   '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."' ,
																`fwDevice` =   '".mysqli_real_escape_string($connexion,$rows["fwDevice"])."' ,
																`fwMedia` =   '".mysqli_real_escape_string($connexion,$rows["fwMedia"])."' ,
																`fwPaper_WFS_PTR_SUPPLYSIZE` =   '".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYSIZE"])."' ,
																`fwPaper_WFS_PTR_SUPPLYUPPER` =   '".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYUPPER"])."' ,
																`fwPaper_WFS_PTR_SUPPLYLOWER` =   '".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYLOWER"])."' ,
																`fwPaper_WFS_PTR_SUPPLYEXTERNAL` =   '".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYEXTERNAL"])."' ,
																`fwPaper_WFS_PTR_SUPPLYAUX` =   '".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYAUX"])."' ,
																`fwPaper_WFS_PTR_SUPPLYAUX2` =   '".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYAUX2"])."' ,
																`fwPaper_WFS_PTR_SUPPLYPARK` =   '".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYPARK"])."' ,
																`usRetractCount` =   '".mysqli_real_escape_string($connexion,$rows["usRetractCount"])."' ,
																`wRetractBin` =   '".mysqli_real_escape_string($connexion,$rows["wRetractBin"])."' ,
																`fwToner` =   '".mysqli_real_escape_string($connexion,$rows["fwToner"])."' ,
																`fwInk` =   '".mysqli_real_escape_string($connexion,$rows["fwInk"])."' ,
																`fwLamp` =   '".mysqli_real_escape_string($connexion,$rows["fwLamp"])."' ,
																`wDevicePosition` =   '".mysqli_real_escape_string($connexion,$rows["wDevicePosition"])."' ,
																`usPowerSaveRecoveryTime` =   '".mysqli_real_escape_string($connexion,$rows["usPowerSaveRecoveryTime"])."' ,
																`wPaperType_WFS_PTR_SUPPLYUPPER` =   '".mysqli_real_escape_string($connexion,$rows["wPaperType_WFS_PTR_SUPPLYUPPER"])."' ,
																`wPaperType_WFS_PTR_SUPPLYLOWER` =   '".mysqli_real_escape_string($connexion,$rows["wPaperType_WFS_PTR_SUPPLYLOWER"])."' ,
																`wPaperType_WFS_PTR_SUPPLYEXTERNAL` =   '".mysqli_real_escape_string($connexion,$rows["wPaperType_WFS_PTR_SUPPLYEXTERNAL"])."' ,
																`wPaperType_WFS_PTR_SUPPLYPARK` =   '".mysqli_real_escape_string($connexion,$rows["wPaperType_WFS_PTR_SUPPLYPARK"])."' ,
																`wPaperType_WFS_PTR_SUPPLYAUX` =   '".mysqli_real_escape_string($connexion,$rows["wPaperType_WFS_PTR_SUPPLYAUX"])."' ,
																`wPaperType_WFS_PTR_SUPPLYAUX2` =   '".mysqli_real_escape_string($connexion,$rows["wPaperType_WFS_PTR_SUPPLYAUX2"])."' ,
																`wAntiFraudModule` =   '".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."' ,
																`wBlackMarkMode` =   '".mysqli_real_escape_string($connexion,$rows["wBlackMarkMode"])."' ,
																`all_id` =   '".mysqli_real_escape_string($connexion,$rows["all_id"])."'
																WHERE `id_insert` = '".mysqli_real_escape_string($connexion,$row2["id_insert"])."'";
                                                                        $result3=mysqli_query($connexion,$sql3);
                                                                        if (!$result3)
                                                                        {
                                                                            error_log("Erreur SQL 367:  ".$sql3."  " .mysqli_error($connexion));
                                                                            die(' ERREUR QUERY 367 !');
                                                                        }
														}
													}
												}
												else
													{
													while ($rows = mysqli_fetch_assoc($res_PTR)) 
																	{														

																$sql4 = "INSERT INTO  `config_PTR` (`id_insert`, `id_atm`, `id_service`, `state`, `last_update`, `user_update`, `id_logical_name`,
																		`logical_name`, `fwDevice`, `fwMedia`,
																		`fwPaper_WFS_PTR_SUPPLYSIZE`,
																		 `fwPaper_WFS_PTR_SUPPLYUPPER`, `fwPaper_WFS_PTR_SUPPLYLOWER`,
																		 `fwPaper_WFS_PTR_SUPPLYEXTERNAL`, `fwPaper_WFS_PTR_SUPPLYAUX`, 
																		 `fwPaper_WFS_PTR_SUPPLYAUX2`, `fwPaper_WFS_PTR_SUPPLYPARK`,
																		 `usRetractCount`, `wRetractBin`, `fwToner`,
																		 `fwInk`, `fwLamp`, `wDevicePosition`,
																		 `usPowerSaveRecoveryTime`, `wPaperType_WFS_PTR_SUPPLYUPPER`,
																		 `wPaperType_WFS_PTR_SUPPLYLOWER`, `wPaperType_WFS_PTR_SUPPLYEXTERNAL`, 
																		 `wPaperType_WFS_PTR_SUPPLYPARK`, `wPaperType_WFS_PTR_SUPPLYAUX`, 
																		 `wPaperType_WFS_PTR_SUPPLYAUX2`, `wAntiFraudModule`,
																		 `wBlackMarkMode`, `all_id`)
																		VALUES ('', '".mysqli_real_escape_string($connexion,$ATM)."', '".mysqli_real_escape_string($connexion,$row["id_service"])."',1,NOW(),'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."','".mysqli_real_escape_string($connexion,$row["id_logical_name"])."',
																		'".mysqli_real_escape_string($connexion,$row["logical_name"])."','".mysqli_real_escape_string($connexion,$rows["fwDevice"])."','".mysqli_real_escape_string($connexion,$rows["fwMedia"])."',
																		'".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYSIZE"])."',
																		'".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYUPPER"])."','".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYLOWER"])."',
																		'".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYEXTERNAL"])."','".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYAUX"])."',
																		'".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYAUX2"])."','".mysqli_real_escape_string($connexion,$rows["fwPaper_WFS_PTR_SUPPLYPARK"])."',
																		'".mysqli_real_escape_string($connexion,$rows["usRetractCount"])."','".mysqli_real_escape_string($connexion,$rows["wRetractBin"])."','".mysqli_real_escape_string($connexion,$rows["fwToner"])."',
																		'".mysqli_real_escape_string($connexion,$rows["fwInk"])."','".mysqli_real_escape_string($connexion,$rows["fwLamp"])."','".mysqli_real_escape_string($connexion,$rows["wDevicePosition"])."',
																		'".mysqli_real_escape_string($connexion,$rows["usPowerSaveRecoveryTime"])."','".mysqli_real_escape_string($connexion,$rows["wPaperType_WFS_PTR_SUPPLYUPPER"])."',
																		'".mysqli_real_escape_string($connexion,$rows["wPaperType_WFS_PTR_SUPPLYLOWER"])."','".mysqli_real_escape_string($connexion,$rows["wPaperType_WFS_PTR_SUPPLYEXTERNAL"])."',
																		'".mysqli_real_escape_string($connexion,$rows["wPaperType_WFS_PTR_SUPPLYPARK"])."','".mysqli_real_escape_string($connexion,$rows["wPaperType_WFS_PTR_SUPPLYAUX"])."',
																		'".mysqli_real_escape_string($connexion,$rows["wPaperType_WFS_PTR_SUPPLYAUX2"])."','".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."',
																		'".mysqli_real_escape_string($connexion,$rows["wBlackMarkMode"])."','".mysqli_real_escape_string($connexion,$rows["all_id"])."')";
                                                                        $result4=mysqli_query($connexion,$sql4);
                                                                        if (!$result4)
                                                                        {
                                                                            error_log("Erreur SQL 368:  ".$sql4."  " .mysqli_error($connexion));
                                                                            die(' ERREUR QUERY 368 !');
                                                                        }

																	}												
													}
										 /********************************** FIN alimenter conf PTR ***********************************/
                                            $sql5 = "UPDATE `atm_logical_names` SET `if_new` =  1
                                            WHERE `id_logical_name` = '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."'";
                                            $result5=mysqli_query($connexion,$sql5);
                                            if (!$result5)
                                            {
                                                error_log("Erreur SQL 369:  ".$sql5."  " .mysqli_error($connexion));
                                                die(' ERREUR QUERY 369 !');
                                            }
											mysqli_free_result($res_PTR);						
											mysqli_free_result($result2);	
										}																
									BREAK;	
									
 									CASE '14': //SIU
									
										$S_SIU="SELECT `id_insert`,	`fwDevice`, `bAlarmSet`, `wAntiFraudModule`, `all_id`  
												FROM `default_config_SIU`
												WHERE `id_insert`=1";
                                        $res_SIU=mysqli_query($connexion,$S_SIU);
                                        if (!$res_SIU)
                                        {
                                            error_log("Erreur SQL 370:  ".$S_SIU."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 370 !');
                                        }

										 /********************************** alimenter conf SIU ***********************************/
											$sql2 = "SELECT   `id_insert`  FROM `config_SIU` 
													WHERE `id_atm`  = '".mysqli_real_escape_string($connexion,$ATM)."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."' 
													AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' ";
                                        $result2=mysqli_query($connexion,$sql2);
                                        if (!$result2)
                                        {
                                            error_log("Erreur SQL 371:  ".$sql2."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 371 !');
                                        }
										if ($result2)
											{												
												if(mysqli_num_rows($result2)>0)
													{
													while ($row2 = mysqli_fetch_assoc($result2)) 
                                                    {
														while ($rows = mysqli_fetch_assoc($res_SIU)) 

                                                        {
																$sql3 = "UPDATE `config_SIU` SET `last_update` =  NOW(),
																`user_update` =   '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."' ,
																`fwDevice` =   '".mysqli_real_escape_string($connexion,$rows["fwDevice"])."' ,
																`bAlarmSet` =   '".mysqli_real_escape_string($connexion,$rows["bAlarmSet"])."' ,
																`wAntiFraudModule` =   '".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."' ,
																`all_id` =   '".mysqli_real_escape_string($connexion,$rows["all_id"])."'
																WHERE `id_insert` = '".mysqli_real_escape_string($connexion,$row2["id_insert"])."'";
                                                                    $result3=mysqli_query($connexion,$sql3);
                                                                    if (!$result3)
                                                                    {
                                                                        error_log("Erreur SQL 372:  ".$sql3."  " .mysqli_error($connexion));
                                                                        die(' ERREUR QUERY 372 !');
                                                                    }
                                                        }
                                                    }
													}	
												else
													{
													while ($rows = mysqli_fetch_assoc($res_SIU)) 
																	{														

																$sql4 = "INSERT INTO  `config_SIU` (`id_insert`, `id_atm`, `id_service`, `state`, `last_update`, `user_update`, `id_logical_name`,
																		`logical_name`, `fwDevice`, `bAlarmSet`, 
																		`wAntiFraudModule`, `all_id`)
																		VALUES ('', '".mysqli_real_escape_string($connexion,$ATM)."', '".mysqli_real_escape_string($connexion,$row["id_service"])."',1,NOW(),'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."','".mysqli_real_escape_string($connexion,$row["id_logical_name"])."',
																		'".mysqli_real_escape_string($connexion,$row["logical_name"])."','".mysqli_real_escape_string($connexion,$rows["fwDevice"])."','".mysqli_real_escape_string($connexion,$rows["bAlarmSet"])."',
																		'".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."','".mysqli_real_escape_string($connexion,$rows["all_id"])."')";
                                                                        $result4=mysqli_query($connexion,$sql4);
                                                                        if (!$result4)
                                                                        {
                                                                            error_log("Erreur SQL 373:  ".$sql4."  " .mysqli_error($connexion));
                                                                            die(' ERREUR QUERY 373 !');
                                                                        }

																	}												
													}
										 /********************************** FIN alimenter conf SIU ***********************************/
																$sql5 = "UPDATE `atm_logical_names` SET `if_new` =  1
																WHERE `id_logical_name` = '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."'";
                                                $result5=mysqli_query($connexion,$sql5);
                                                if (!$result5)
                                                {
                                                    error_log("Erreur SQL 374:  ".$sql5."  " .mysqli_error($connexion));
                                                    die(' ERREUR QUERY 374 !');
                                                }
											mysqli_free_result($res_SIU);						
											mysqli_free_result($result2);	
										}																
									BREAK;										
									
									
 									CASE '16': //VDM
									
									
										 $S_VDM="SELECT `id_insert`, `fwDevice`, 
												`bAlarmSet`, `wAntiFraudModule`, `all_id` 
												FROM `default_config_VDM` 
												WHERE `id_insert`=1";
                                        $res_VDM=mysqli_query($connexion,$S_VDM);
                                        if (!$res_VDM)
                                        {
                                            error_log("Erreur SQL 375:  ".$S_VDM."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 375 !');
                                        }

										 /********************************** alimenter conf VDM ***********************************/
											$sql2 = "SELECT   `id_insert`  FROM `config_VDM` 
													WHERE `id_atm`  = '".mysqli_real_escape_string($connexion,$ATM)."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."' 
													AND `id_logical_name`= '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' ";
                                        $result2=mysqli_query($connexion,$sql2);
                                        if (!$result2)
                                        {
                                            error_log("Erreur SQL 376:  ".$sql2."  " .mysqli_error($connexion));
                                            die(' ERREUR QUERY 376 !');
                                        }
										if ($result2)
											{												
												if(mysqli_num_rows($result2)>0)
													{
													while ($row2 = mysqli_fetch_assoc($result2)) 
															{															
														while ($rows = mysqli_fetch_assoc($res_VDM)) 
																	{								 
																$sql3 = "UPDATE `config_VDM` SET `last_update` =  NOW(),
																`user_update` =   '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."' ,
																`fwDevice` =   '".mysqli_real_escape_string($connexion,$rows["fwDevice"])."' ,
																`bAlarmSet` =   '".mysqli_real_escape_string($connexion,$rows["bAlarmSet"])."' ,
																`wAntiFraudModule` =   '".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."' ,
																`all_id` =   '".mysqli_real_escape_string($connexion,$rows["all_id"])."'
																WHERE `id_insert` = '".mysqli_real_escape_string($connexion,$row2["id_insert"])."'";
                                                                        $result3=mysqli_query($connexion,$sql3);
                                                                        if (!$result3)
                                                                        {
                                                                            error_log("Erreur SQL 377:  ".$sql3."  " .mysqli_error($connexion));
                                                                            die(' ERREUR QUERY 377 !');
                                                                        }
																	}
															}								 
													}	
												else
													{
													while ($rows = mysqli_fetch_assoc($res_VDM)) 
																	{														

																$sql4 = "INSERT INTO  `config_VDM` (`id_insert`, `id_atm`, `id_service`, `state`, `last_update`, `user_update`, `id_logical_name`,
																		`logical_name`, `fwDevice`, `bAlarmSet`, 
																		`wAntiFraudModule`, `all_id`)
																		VALUES ('', '".mysqli_real_escape_string($connexion,$ATM)."', '".mysqli_real_escape_string($connexion,$row["id_service"])."',1,NOW(),'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."','".mysqli_real_escape_string($connexion,$row["id_logical_name"])."',
																		'".mysqli_real_escape_string($connexion,$row["logical_name"])."','".mysqli_real_escape_string($connexion,$rows["fwDevice"])."','".mysqli_real_escape_string($connexion,$rows["bAlarmSet"])."',
																		'".mysqli_real_escape_string($connexion,$rows["wAntiFraudModule"])."','".mysqli_real_escape_string($connexion,$rows["all_id"])."')";
                                                                        $result4=mysqli_query($connexion,$sql4);
                                                                        if (!$result4)
                                                                        {
                                                                            error_log("Erreur SQL 378:  ".$sql4."  " .mysqli_error($connexion));
                                                                            die(' ERREUR QUERY 378 !');
                                                                        }

																	}												
													}
										 /********************************** FIN alimenter conf VDM ***********************************/
                                                $sql5 = "UPDATE `atm_logical_names` SET `if_new` =  1
                                                WHERE `id_logical_name` = '".mysqli_real_escape_string($connexion,$row["id_logical_name"])."' AND `id_service` = '".mysqli_real_escape_string($connexion,$row["id_service"])."'";
                                                $result5=mysqli_query($connexion,$sql5);
                                                if (!$result5)
                                                {
                                                    error_log("Erreur SQL 379:  ".$sql5."  " .mysqli_error($connexion));
                                                    die(' ERREUR QUERY 379 !');
                                                }
											mysqli_free_result($res_VDM);						
											mysqli_free_result($result2);	
										}
																
									BREAK;										
									
									}// FIN SWITCH ($row["id_service"]) 
									
							$i++;		
							}
						} //if(mysqli_num_rows($result)>0)

					mysqli_free_result($result);	
	}
mysqli_close($connexion);
}






//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function activerToutesStatusXFSErrors($idatm)
{
    $connexion=ma_db_connexion();
	
    $sql2 = "SELECT   `id_atm`  FROM `cmd_execution` WHERE `id_atm`  = '".mysqli_real_escape_string($connexion,$idatm)."' ";
    $result=mysqli_query($connexion,$sql2);
    if (!$result)
    {
        error_log("Erreur SQL 380:  ".$sql2."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 380 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)==0)
        {
            $cmd2="INSERT INTO  `cmd_execution` (`id_atm`, `id_cmd`, `state`,  `if_executed`)  VALUES ('".mysqli_real_escape_string($connexion,$idatm)."', 1,1,1)";
            $result2=mysqli_query($connexion,$cmd2);
            if (!$result2)
            {
                error_log("Erreur SQL 381:  ".$cmd2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 381 !');
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    getConfigAllServiceATM($idatm);
    getConfigAllServiceLogicalNameATM($idatm);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getConfigStatusXFSName($paramettre,$idprivilege,$ATM,$date_debut,$date_fin,$historique_vacation)
{
    include "../languages/" . $_SESSION['lang'] . ".php";

    $val=get_name_terminal_gag($ATM);
								 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Activer toutes les status XFS Errors : '.$ATM.' - '.$val[0].' - '.$val[1].'</h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>																										
												<!-- Modal body -->
												<div class="modal-body">
																								
										    	</div>																										
												<!-- Modal footer -->
												<div class="modal-footer justify-content-between">
												<button type="button" class="btn btn-primary"
                                                    onClick="javascript:activerToutesStatusXFSErrors(\''.$ATM.'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')" 
                                                     data-dismiss="modal" >'.$lang['confir'].'</button>
												<button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
												</div>
																										
									</div>
								</div>';	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nbr_rebot_day($id_atm)
{
    $bool=false;
    $date_now = date('Y-m-d');
    $connexion=ma_db_connexion();
    $SQL="SELECT COUNT(1) AS nbr_rebot  FROM hist_cmd_execution_reboot
    WHERE `id_atm` = '".  mysqli_real_escape_string($connexion,$id_atm)."'
    AND DATE(`date_send_cmd`) = '".  mysqli_real_escape_string($connexion,$date_now)."'
    AND if_executed = 1";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 00116260:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 00116260 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            if($row["nbr_rebot"]>=2)
            {
                $bool=true;
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return $bool;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getRedemarrerATM($paramettre,$idprivilege,$ATM,$date_debut,$date_fin,$historique_vacation)
{
    include "../languages/" . $_SESSION['lang'] . ".php";
    $bool=get_nbr_rebot_day($ATM);
    $val=get_name_terminal_gag($ATM);

    echo '<div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="background-color:#e9ecef;color:#2b3449;" >																										  
        <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">'.$lang['terminal'].' '.$lang['reboot'].' : '.$val[0].' - '.$val[1].' </h4>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>																										
            <!-- Modal body -->
            <div class="modal-body">';
                echo '<form class="form-horizontal" role="form">
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label" for="appendedInput">'.$lang['cd_confir'].'</label>
                            <div class="controls col-sm-8">
                                <div class="input-group">
                                    <input class="form-control" id="code_redemarage'.$ATM.'" name="code_redemarage"  type="text" placeholder="'.$lang['code_1234'].'" value="">';
                                        if($bool)
                                        {
                                            echo '<div class="input-group-append">
                                                <span class="input-group-text"  >
                                                    <i style="color:#FF0040" class="fa fa-exclamation-triangle fa-1x" aria-hidden="true" title="'.$lang['att_gab_reb'].' "></i>
                                                </span>
                                            </div>';
                                        }
                                echo'</div>
                            </div>
                    </div>
                
                </form> ';
            echo '</div>																										
            <!-- Modal footer -->
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-primary"  
                onClick="javascript:activerRedemarrerATM(\''.$ATM.'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')" 
                data-dismiss="modal" >'.$lang['confir'].'</button>
                <button class="btn btn-danger" type="button" data-dismiss="modal">'.$lang['close'].'</button>
            </div>
        </div>
    </div>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getPingATM($paramettre,$idprivilege,$ATM,$terminal,$ipatm)
{
    include "../languages/" . $_SESSION['lang'] . ".php";
    echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													
													<h4 class="modal-title">'.$lang['terminal'].' PING : '.$terminal.' - '.getLibelleATM($ATM).' - '.$ipatm.'</h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>																										
												<!-- Modal body -->
												<div class="modal-body">';
    echo '
																	<form class="form-horizontal" role="form">

																		<div  class="form-group row">			
																			<div class="col-sm-12">
																					<div id="testerPing" name="testerPing" >';
                                                                                    if (($terminal)<>"")
                                                                                    {
                                                                                        afficher_ping($terminal);
                                                                                    }
                                                                                    echo'</div>
                                                                             </div>
																		</div>	
																		
																	</form> ';

                                echo '								
										    	</div>																										
												<!-- Modal footer -->
												<div class="modal-footer ">
												    <button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
												</div>
																										
									</div>
								</div>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getScreenshotATM($ATM)
{
    include "../languages/" . $_SESSION['lang'] . ".php";
    $val=get_name_terminal_gag($ATM);

    echo '<div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="background-color:#e9ecef;color:#2b3449;" >																										  
        <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"> '.$lang['terminal'].' '.$lang['screenshot'].' : '.$val[0].' - '.$val[1].' </h4>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>																										
            <!-- Modal body -->
            <div class="modal-body">';
    echo '<form class="form-horizontal" role="form">
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label" for="appendedInput">'.$lang['cd_confir'].'</label>
                            <div class="controls col-sm-8">
                                <div class="input-group">
                                    <input  id="code_Screenshot'.$ATM.'" name="code_Screenshot" type="text" placeholder="'.$lang['code_0000'].'" value="" class="form-control">
                                </div>
                            </div>
                    </div>
                  	
                </form> ';
    echo '</div>																										
            <!-- Modal footer -->
            <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-primary"  
                        onClick="javascript:activerScreenshotATM(\''.$ATM.'\')" 
                        data-dismiss="modal" >'.$lang['confir'].'</button>
                <button class="btn btn-danger" type="button" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getConfigStatusLogicalName($paramettre,$idprivilege,$ATM,$date_debut,$date_fin,$historique_vacation)
{
    $connexion=ma_db_connexion();
    $val=get_name_terminal_gag($ATM);
    echo '
								<div class="modal-dialog modal-lg">
									<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Status Errors xsf - Logical Name : '.$ATM.' - '.$val[0].' - '.$val[1].' </h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
										<div class="modal-body">';
											echo '<form class="form-horizontal" role="form">';

														    	$sql_service=get_all_service_atm_logical_name($ATM);
														    	$result_service=mysqli_query($connexion,$sql_service);
                                                                if (!$result_service)
                                                                {
                                                                    error_log("Erreur SQL 382:  ".$sql_service."  " .mysqli_error($connexion));
                                                                    die(' ERREUR QUERY 382 !');
                                                                }
																if ($result_service)
																	{	

																if(mysqli_num_rows($result_service)>0)
																	{	$j=0;
																// echo "OK1";
																// ,`id_logical_name`,`logical_name`
																	echo '		
																	<!-- Modal body -->
																<div class="modal-body">
																	<div class="accordion" id="accordionExample275">';															
																		   while ($row = mysqli_fetch_assoc($result_service)) 
																			{//	echo "OK2";
																		echo '	  <div class="card z-depth-0 bordered">
																							<div class="card-header" id="headingSL'.$j.'" style="background-color:#e7722c;">
																							  <h5 class="mb-0">
																								<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseSL'.$j.'"
																								  aria-expanded="true" aria-controls="collapseSL'.$j.'" >
																								  <strong style="font-size:18px;font-weight:bold;color:#FFFFFF;" >'.$row["service"].'  -  '.$row["logical_name"].'</strong>
																								  </button>
																							  </h5>
																							</div>
																							<div id="collapseSL'.$j.'" class="collapse" aria-labelledby="headingSL'.$j.'" data-parent="#accordionExample275">
																								<div class="card-body" style="padding-left: 50px;background-color:#f8f8f8;" >
																											<div  class="form-group">';	
																											// echo "OK3";
																											// $verif="";
																											$idlogicalName="";
																											$tableau_logical_autorise = array();																
																											$tableau_Slogical = array();																											
																											$tableau_logical_autorise2=get_list_status_logical_names_atm($ATM,$row["id_service"],$row["id_logical_name"]);
																											$tableau_Slogical=get_all_status_logical_names_atm($row["id_service"],$row["id_logical_name"]);
																											$tableau = explode(',', $tableau_logical_autorise2[0]);
																											foreach($tableau as $verif)
																											{
																												$tableau_logical_autorise[] = $verif;
																											}
																											// echo "<br><br> ========================================================================";
																											if ($_SESSION['id_utilisateur']==46)
																													{
																														// foreach ($tableau_logical_autorise AS $_url){ echo "<br>  ".$_url;}
																														}	
																
																											
																											$m=0;
																											$v=0;
																									if((is_array($tableau_Slogical[0])))	
																										{																												
																											foreach ($tableau_Slogical[0] AS $id_Slogical)
																												{
																													if ($_SESSION['id_utilisateur']==46)
																													{																		
																														if (in_array($id_Slogical, $tableau_logical_autorise))
																															{
																																//echo " XFS ERRORS ".$id_Slogical."<br>";
																															}	
																													}
																												if(!empty($id_Slogical))	
																													{																														
																													if (($v % 3) == 0){$m=$m+3;  echo '</div><div  class="form-group">';}else{echo '';}	
																																													
																																	echo'	
																																			<label for="id_Slogical" class="col-sm-3 control-label"  style="font-size:10px;">'.$tableau_Slogical[2][$id_Slogical].' / '.str_replace("WFS_CDM_","",$tableau_Slogical[1][$id_Slogical]).'</label>
																																			<div class="col-sm-1">
																																				<input class="form-check-input" type="checkbox"   name="allSLogicalnamesATM'.$row["id_service"].''.$row["id_logical_name"].'[]" id="tableau_Slogical'.$id_Slogical.'"';
																																					if (in_array($id_Slogical, $tableau_logical_autorise)){echo 'checked';}
																																					echo  " value='".$id_Slogical."'";  echo ' >    
																																			</div>
																																		';					
																													if (($m % 3) == 0){  echo '';}else{echo '</div>';}	
																														$v++;
																													}
																												}																												
																										}
																		echo'													
																								</div>';
																		if(!empty($id_Slogical))	
																			{						
																		echo'					
																		<div  class="form-group">				
																			<label for="buttonVaction" class="col-sm-2 control-label"></label>
																			<div class="col-sm-10">
																				<button type="button" class="btn btn-danger"  
																				onClick="javascript:confirmSLogicalNamesServiceATM(\''.$ATM.'\',\''.$row["id_service"].'\',\''.$row["id_logical_name"].'\',\''.$row["config_service"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')" 
																				data-dismiss="modal" >Confirmer</button></div>
																		</div>';
																			}
																		echo'</div>		
																					</div>';	
																					$j++;
																		}	
															echo '	
																	</div>											
																</div>';	
																		}	
																		mysqli_free_result($result_service);	
																	}
																mysqli_close($connexion);
															echo '												
															
								
																	
													</form>
										</div>	 	
									</div>																								
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
									</div>';
	
}
///////////////////////////////////////////////
function suppimerRegion($id_sup)
{
    $connexion=ma_db_connexion();

    $sql_2 = "DELETE FROM `new_filiale` WHERE  `id_filiale` = '".mysqli_real_escape_string($connexion,$id_sup)."'";
    $result2=mysqli_query($connexion,$sql_2);
    if (!$result2)
    {
        error_log("Erreur SQL 383:  ".$sql_2."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 383 !');
    }

    mysqli_close($connexion);
}
///////////////////////////////////////////////
function suppimerProfil($id_profil)
{
    $connexion=ma_db_connexion();

    $sql_1 = "SET FOREIGN_KEY_CHECKS = 0; ";
    $result1=mysqli_query($connexion,$sql_1);
    if (!$result1)
    {
        error_log("Erreur SQL 384:  ".$sql_1."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 384 !');
    }
    mysqli_free_result($result1);

    $sql_2 = "DELETE FROM `atm_profile` WHERE  `id_profile` = '".mysqli_real_escape_string($connexion,$id_profil)."'";
    $result2=mysqli_query($connexion,$sql_2);
    if (!$result2)
    {
        error_log("Erreur SQL 385:  ".$sql_2."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 385 !');
    }

    $sql_3 = "SET FOREIGN_KEY_CHECKS = 1;";
    $result3=mysqli_query($connexion,$sql_3);
    if (!$result3)
    {
        error_log("Erreur SQL 386:  ".$sql_3."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 386 !');
    }
    mysqli_free_result($result3);
mysqli_close($connexion);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function ajouterRegion($region)
{
    $connexion=ma_db_connexion();

    $sql = "INSERT INTO  `new_filiale`(`id_filiale`, `nom_filiale`, `nom_filiale2`)
			    VALUES ('', '".mysqli_real_escape_string($connexion,$region)."', '".mysqli_real_escape_string($connexion,$region)."');";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 387:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 387 !');
    }
    mysqli_close($connexion);

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function ajouterProfil($profil)
{
    $connexion=ma_db_connexion();

    $sql = "INSERT INTO  `atm_profile`(`id_profile`, `description`)
			    VALUES ('', '".mysqli_real_escape_string($connexion,$profil)."');";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 388:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 388 !');
    }
    mysqli_free_result($result);
    mysqli_close($connexion);

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getAjouterRegion()
{
echo '
<form class="form-horizontal" role="form">				
				<div  class="form-group">				
					<label <for="region" class="col-sm-2 control-label"> </label>
					<div class="col-sm-10">
						<input  id="region" name="region" type="text"   value=""    class="form-control input-sm">	    
					</div>
				</div>		
				
</form>';
}
///////////////////////////////////////////////	
function getAjouterProfil()
{
echo '
<form class="form-horizontal" role="form">				
				<div  class="form-group">				
					<label <for="profil" class="col-sm-2 control-label"> </label>
					<div class="col-sm-10">
						<input  id="profil" name="profil" type="text"   value=""    class="form-control input-sm">	    
					</div>
				</div>		
				
</form>';
}
///////////////////////////////////////////////	
function suiviRegion()
{
		
	echo '                   
			<div class="col-lg-12">	
			<!-- /.panel -->
                    <div class="panel panel-info">
                        <div class="panel-heading" style="background-color:#e7722c;font-size:18px;color:#fff;line-height: 80%;">
                            <i class="fa fa-cogs"></i>  Configuration
                        </div>
						
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="row">
							<div class="col-lg-6">
                                 <div class="table-responsive">	
							   <table class="table table-bordered table-hover table-striped">';
    $connexion=ma_db_connexion();


    $SQL2 = "SELECT `id_filiale`, `nom_filiale`, `nom_filiale2` FROM `new_filiale`  ORDER BY `nom_filiale` DESC";
							mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result2=mysqli_query($connexion,$SQL2);
    if (!$result2)
    {
        error_log("Erreur SQL 389:  ".$SQL2."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 389 !');
    }
    if($result2)
    {

                echo '<thead>											
                        <tr>
                        <th colspan="3" style="background-color:#fabf8f;font-size:18px;color:#fff;line-height: 160%;text-align: center;" >Région 
                                <a tabindex="-1" class="btn btn-info btn-circle"  title="Ajouter  région"  data-toggle="modal" 
                                onClick="javascript:getAjouterRegion()"   
                                data-target="#ajouter_Region"><span class="fa fa-plus"></span></a>													
                        </th>
                        </tr>											
                    
                        <tr>
                            <th>#</th>
                            <th>Région</th>
                        </tr>
                    </thead>
                    <tbody>';
            if(mysqli_num_rows($result2)>0)
            {		$i=0;
                while ($row = mysqli_fetch_assoc($result2))
                    {
                echo '   <tr>
                            <td>'.$i.'</td>
                            <td>'.$row["nom_filiale"].'</td>
                            <td>';
                        //	if (verif_habilitation($_SESSION['habilitation_action'],3)==true)
                            {
                            echo ' <a  class="btn btn-danger btn-circle" title="Supprimer" href="javascript:suppimerRegion(\''.$row["id_filiale"].'\')"><i class="fa fa-times" ></i></a>';
                            }

                            echo '</td>
                        </tr>';
                        $i++;
                    }
            }
                echo '   </tbody>';

     mysqli_free_result($result2);
    }
mysqli_close($connexion);
    echo '  
    </table>
        </div>
         <!-- /.table-responsive -->
           </div>';
    suiviProfil();
    echo '</table>
    </div>
    <!-- /.table-responsive -->
    </div> 
    </div>
    <!-- /.row -->
    </div>
    <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
    </div>
    <!-- /.col-lg-8 -->
    ';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function suiviProfil()
{
	// session_start();		
		
	echo '                   
			
                           
							<div class="col-lg-6">
                                 <div class="table-responsive">	
							   <table class="table table-bordered table-hover table-striped">';
    $connexion=ma_db_connexion();


    $SQL2 = "SELECT id_profile, description FROM atm_profile  ORDER BY `description` DESC";
								mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result2=mysqli_query($connexion,$SQL2);
    if (!$result2)
    {
        error_log("Erreur SQL 390:  ".$SQL2."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 390 !');
    }
							if($result2)
							{							
										
                                        echo '<thead>											
                                                <tr>
												<th colspan="3" style="background-color:#fabf8f;font-size:18px;color:#fff;line-height: 160%;text-align: center;" >Profil 
														<a tabindex="-1" class="btn btn-info btn-circle"  title="Ajouter  Profil"  data-toggle="modal" 
														onClick="javascript:getAjouterProfil()"   
														data-target="#ajouter_Profil"><span class="fa fa-plus"></span></a>													
												</th>
												</tr>											
											
                                                <tr>
                                                    <th>#</th>
                                                    <th>Profil</th>
                                                </tr>
                                            </thead>
                                            <tbody>';
									if(mysqli_num_rows($result2)>0)
									{		$i=0;									
										while ($row = mysqli_fetch_assoc($result2)) 
											{											
                                        echo '   <tr>
                                                    <td>'.$i.'</td>
                                                    <td>'.$row["description"].'</td>
                                                    <td>';
												//	if (verif_habilitation($_SESSION['habilitation_action'],3)==true)
													{
													echo ' <a  class="btn btn-danger btn-circle" title="SupprimerProfil" href="javascript:suppimerProfil(\''.$row["id_profile"].'\')"><i class="fa fa-times" ></i></a>';
													}

													echo '</td>
                                                </tr>';
												$i++;
											}
									}
						mysqli_free_result($result2);
						}
							mysqli_close($connexion);
                                        echo '   </tbody>';										
										
										
                                       echo '  </table>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>';
								
                                 echo '</table>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>';
								
								
								

								
								
		
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getConfigLogicalNameService($paramettre,$idprivilege,$ATM,$date_debut,$date_fin,$historique_vacation)
{
    $val=get_name_terminal_gag($ATM);
							echo '
								<div class="modal-dialog modal-lg">
									<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Logical Name par Service : '.$ATM.' - '.$val[0].' - '.$val[1].'</h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
										<div class="modal-body">';
											echo '<form class="form-horizontal" role="form">';
                                            $connexion=ma_db_connexion();

											$sql_service=get_all_service_atm();
                                            $result_service=mysqli_query($connexion,$sql_service);
                                            if (!$result_service)
                                            {
                                                error_log("Erreur SQL 391:  ".$sql_service."  " .mysqli_error($connexion));
                                                die(' ERREUR QUERY 391 !');
                                            }

														if ($result_service)
															{
                                                                if(mysqli_num_rows($result_service)>0)
																	{	
																
																	echo '		
																	<!-- Modal body -->
																<div class="modal-body">
																	<div class="accordion" id="accordionExample275">';
																	$j=1;
																		   while ($row = mysqli_fetch_assoc($result_service)) 
																			{
																		echo '	  <div class="card z-depth-0 bordered">
																							<div class="card-header" id="heading'.$j.'" style="background-color:#e7722c;">
																							  <h5 class="mb-0">
																								<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse'.$j.'"
																								  aria-expanded="true" aria-controls="collapse'.$j.'" >
																								  <strong style="font-size:18px;font-weight:bold;color:#FFFFFF;" >'.$row["service"].' </strong>
																								  </button>
																							  </h5>
																							</div>
																							<div id="collapse'.$j.'" class="collapse" aria-labelledby="heading'.$j.'" data-parent="#accordionExample275">
																								<div class="card-body" style="padding-left: 50px;background-color:#f8f8f8;" >
																											<div  class="form-group">';	
																											$tableau_logical_autorise = array();																
																											$tableau_logical = array();																											
																											$tableau_logical_autorise=get_list_logical_names_atm($ATM,$row["id_service"]);
																											$tableau_logical=get_all_logical_names_atm($ATM,$row["id_service"]);
																										    $m=0;
																											$v=0;
																									if((is_array($tableau_logical[0])))	
																										{																												
																											foreach ($tableau_logical[0] AS $id_logical)
																												{
																												if(!empty($id_logical))	
																													{																														
																													
																													if (($v % 3) == 0){$m=$m+3;  echo '</div><div  class="form-group">';}else{echo '';}	
																																													
																																	echo'	
																																			<label for="dateClotureA" class="col-sm-2 control-label">'.$tableau_logical[1][$id_logical].'</label>
																																			<div class="col-sm-1">
																																				<input class="form-check-input" type="checkbox"   name="allLogicalnamesATM'.$row["id_service"].'[]" id="tableau_logical'.$id_logical.'"';
																																					if (in_array($id_logical, $tableau_logical_autorise)){echo 'checked';}
																																					echo  " value='".$id_logical."'";  echo ' >    
																																			</div>
																																		';					
																													if (($m % 3) == 0){  echo '';}else{echo '</div>';}	
																														$v++;
																													}
																												}																												
																										}
																		echo'													
																								</div>';
																		if(!empty($id_logical))	
																			{						
																		echo'					
																		<div  class="form-group">				
																			<label for="buttonVaction" class="col-sm-2 control-label"></label>
																			<div class="col-sm-10">
																				<button type="button" class="btn btn-danger"  
																				onClick="javascript:confirmLogicalNamesServiceATM(\''.$ATM.'\',\''.$row["id_service"].'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')" 
																				data-dismiss="modal" >Confirmer</button></div>
																		</div>';
																			}
																		echo'</div>		
																					</div>';
																		$j++;
																		}	
															echo '	
																	</div>											
																</div>';	
																		}
														mysqli_free_result($result_service);
															}
														mysqli_close($connexion);
															echo '												
															
								
																	
													</form>
										</div>	 	
									</div>																								
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
									</div>';
	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getCartePorteur($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `numCarte` FROM `new_porteur` WHERE `id_porteur`  = '".mysqli_real_escape_string($connexion,$id)."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 392:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 392 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["numCarte"];  	
					}
			}	
		else
			{
				return "";
			}
    mysqli_free_result($result);
	}
mysqli_close($connexion);
}
/************************************************************************************************************/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_constructeur($id)
{
    $connexion=ma_db_connexion();
$sql = "SELECT   `id_fournisseur` ,`nom_fournisseur`  FROM  `new_list_fournisseur` ";
	
	
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 393:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 393 !');
    }
if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
					    if($row['id_fournisseur']==$id)
                            {
                                echo '<option value="'.$row["id_fournisseur"].'" selected>'.$row["nom_fournisseur"].'</option>';
                            }
					    else
					        {
                                echo '<option value="'.$row["id_fournisseur"].'">'.$row["nom_fournisseur"].'</option>';
                            }

					}
			}	
		else
			{
				return "";
			}
mysqli_free_result($result);	
	}
mysqli_close($connexion);
	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_constructeur_gab($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT   `id_fournisseur` ,`nom_fournisseur`  FROM  `new_list_fournisseur` WHERE `id_fournisseur` = ".$id." ";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 394:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 394 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo $row["nom_fournisseur"];
            }
        }
        else
        {
            return "";
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_constructeur_gab($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT   `id_fournisseur` ,`nom_fournisseur`  FROM  `new_list_fournisseur` ";


    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 395:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 395 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                if($row['id_fournisseur']==$id)
                {
                    echo '<option value="'.$row["id_fournisseur"].'" selected>'.$row["nom_fournisseur"].'</option>';
                }
                else
                 {
                     echo '<option value="'.$row["id_fournisseur"].'">'.$row["nom_fournisseur"].'</option>';
                 }
            }
        }
        else
        {
            return "";
        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_all_constructeur()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT   `id_fournisseur` ,`nom_fournisseur`  FROM  `new_list_fournisseur` ORDER BY `id_fournisseur` ASC";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 396:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 396 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["id_fournisseur"].'">'.$row["nom_fournisseur"].'</option>';
            }
        }
        else
        {
            return "";
        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);
}

function get_select_all_region($id)
{
    $connexion=ma_db_connexion();
	
    $sql = "SELECT   `id_filiale` ,`nom_filiale`  FROM  `new_filiale`";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 397:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 397 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                if($row['id_filiale']==$id)
                {
                    echo '<option value="'.$row["id_filiale"].'" selected>'.$row["nom_filiale"].'</option>';
                }
                else
                {
                    echo '<option value="'.$row["id_filiale"].'" >'.$row["nom_filiale"].'</option>';
                }
            }
        }

        mysqli_free_result($result);
    }
mysqli_close($connexion);
}
/************************************************************************************************************/
function detailInfoGAB($idATM)
{	
	$info=get_info_gab($idATM);
	if(($info[0]<>"") && ($info[8]<>""))
		{
			return	$idATM." - ".$info[0]." - ".$info[8]; 
		}
	else
		{
			return	$idATM;
		}

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_info_gab_par_ip($ip)
{
    $connexion=ma_db_connexion();

$sql = "SELECT `terminal`, `id_terminal_xfs`, `date_ajout`, `numero_serie`, `date_installation`, `emplacement`, `type_emplacement`, `gestionnaire`,
 `nom_gab`, `ip_adresse_gab`, `type_gab`, `code_bank`, `code_group`, `code_succursale`, `code_agence`, `adresse_gab`, `id_fournisseur`, `ville`, `libelle_agence`  
		FROM `new_list_gab` WHERE `ip_adresse_gab` = '".mysqli_real_escape_string($connexion,$ip)."'";
		// echo $sql;

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 398:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 398 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return	array($row["terminal"],
                    $row["id_terminal_xfs"],
                    $row["date_ajout"],
                    $row["numero_serie"],
                    $row["date_installation"],
                    $row["emplacement"],
                    $row["type_emplacement"],
                    $row["gestionnaire"],
                    $row["nom_gab"],
                    $row["ip_adresse_gab"],
                    $row["type_gab"],
                    $row["code_bank"],
                    $row["code_group"],
                    $row["code_succursale"],
                    $row["code_agence"],
                    $row["adresse_gab"],
                    $row["id_fournisseur"],
                    $row["ville"],
                    $row["terminal"],
                    $row["libelle_agence"]
                );
            }
        }
        else
        {
            return array('','','','','','','','','',
                '','','','','','','','','','');
        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_info_region_gab($id)
{
    $connexion=ma_db_connexion();
$sql = "SELECT  `nom_filiale`, `PAYS` FROM `new_filiale` WHERE `id_filiale` = '".mysqli_real_escape_string($connexion,$id)."'";
		// echo $sql;

	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 399:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 399 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return array($row["nom_filiale"],
					  $row["PAYS"]);   	
					}
			}	
		else
			{
				return array('','');
			}
    mysqli_free_result($result);
	}
mysqli_close($connexion);
		
}
/************************************************************************************************************/
function declarerNouveauGAB($paramettre,$idprivilege,$ATM,$date_debut,$date_fin,$historique_vacation)
{
    include "../languages/" . $_SESSION['lang'] . ".php";
    $info_atm_Confirmed=getinfoIPATMConfirmed($ATM);
    $ipAdresse=$info_atm_Confirmed[0];
    $work_station_name=$info_atm_Confirmed[1];
    $info=get_info_gab_par_ip($ipAdresse);
    $region=get_info_region_gab($info[11]);

    if(($info[17])==""){$ville="CASABLANCA";}else{$ville=$info[17];}
    if(($region[1])==""){$pays="MAROC";}else{$pays=$region[1];}

    echo '<div class="modal-dialog modal-xl">
	    <div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">    																							  
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">'.$lang["new_atm"].'</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
																										
			<!-- Modal body -->
			<div class="modal-body">
			    <form class="form-horizontal" role="form">
			        <div class="nav-tabs-boxed">
                        <ul class="nav nav-tabs" id="myTab1" role="tablist">
                            <li class="nav-item"><a class="nav-link active" id="currency_dispenser-tab" data-toggle="tab" href="#currency_dispenser" role="tab" aria-controls="currency_dispenser" aria-selected="true">Information Géneral</a></li>
                            <li class="nav-item"><a class="nav-link" id="coin_dispenser-tab" data-toggle="tab" href="#coin_dispenser" role="tab" aria-controls="coin_dispenser" aria-selected="false">Config Fonctionnalités Client</a></li>
                        </ul>
                        <div class="tab-content" id="myTab1Content">
                                <div class="tab-pane fade show active" id="currency_dispenser" role="tabpanel" aria-labelledby="currency_dispenser-tab">
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12">
                                            <div class="card card-accent-info ">
                                                <div class="card-body">
                                                   
                                                    <div  class="mb-3 row">
                                                        <label for="id_ATM" class="col-sm-2 col-form-label">'.$lang["terminal"].'</label>
                                                        <div class="col-sm-10">
                                                            <input  id="id_ATM"  name="id_ATM" type="text" disabled="disabled"   value="'.$ATM.'" class="form-control input-sm">
                                                        </div>
                                                    </div>

                                                    <div  class="mb-3 row">
                                                        <label for="id_ATM" class="col-sm-2 col-form-label">'.$lang["atm_id"].'</label>
                                                        <div class="col-sm-10">
                                                            <input  id="cd_ATM'.$ATM.'"  name="cd_ATM'.$ATM.'" type="text" placeholder="000000001"  value="'.$info[0].'" class="form-control input-sm">
                                                        </div>
                                                    </div>

                                                    <div  class="mb-3 row">
                                                        <label for="name_ATM" class="col-sm-2 col-form-label">'.$lang['atm_name'].'</label>
                                                        <div class="col-sm-10">
                                                            <input  id="name_ATM'.$ATM.'"  name="name_ATM'.$ATM.'" type="text"   value="'.$info[8].'" class="form-control input-sm">
                                                        </div>
                                                    </div>
                                                    
                                                    <div  class="mb-3 row">
                                                        <label for="name_ATM" class="col-sm-2 col-form-label">Nom Machine</label>
                                                        <div class="col-sm-10">
                                                            <input  id="work_station_name'.$ATM.'"  name="work_station_name'.$ATM.'"  type="text" disabled  value="'.$work_station_name.'" class="form-control input-sm">
                                                        </div>
                                                    </div>
                                                    
                                                    <div  class="mb-3 row">
                                                        <label for="name_ATM" class="col-sm-2 col-form-label">Adresse IP</label>
                                                        <div class="col-sm-10">
                                                            <input  id="ip_adresse_gab'.$ATM.'"  name="ip_adresse_gab'.$ATM.'"  type="text"   value="'.$ipAdresse.'" class="form-control input-sm">
                                                        </div>
                                                    </div>
                                                    
                                                    <div  class="mb-3 row">
                                                        <label for="name_ATM" class="col-sm-2 col-form-label">Constructeur</label>
                                                        <div class="col-sm-10">
                                                            <select   name="constucteur111111'.$ATM.'"  id="constucteur'.$ATM.'" class="form-control">';
                                                                //get_select_all_constructeur();
                                                                get_constructeur_gab($info[16]);
                                                                echo '</select>
                                                        </div>
                                                    </div>
                                                    
                                                    <div  class="mb-3 row">
                                                        <label for="name_ATM" class="col-sm-2 col-form-label">Profil</label>
                                                        <div class="col-sm-10">
                                                           <select   name="profil'.$ATM.'"   id="profil'.$ATM.'"  class="form-control">';
                                                            get_select_profile_sel($info[26]);
                                                            echo '</select>
                                                        </div>
                                                    </div>

                                                    <div  class="mb-3 row">
                                                        <label for="name_ATM" class="col-sm-2 col-form-label">Code agence</label>
                                                        <div class="col-sm-10">
                                                            <input  id="cd_agance'.$ATM.'" name="cd_agance'.$ATM.'" type="text"   value="'.$info[14].'"    class="form-control input-sm">
                                                        </div>
                                                    </div>
                                                    
                                                    <div  class="mb-3 row">
                                                        <label for="name_ATM" class="col-sm-2 col-form-label">'.$lang["agency"].'</label>
                                                        <div class="col-sm-10">
                                                            <input  id="name_agence'.$ATM.'" name="name_agence'.$ATM.'" type="text"   value="'.$info[19].'"    class="form-control input-sm">	
                                                        </div>
                                                    </div>
                                                    
                                                     <div  class="mb-3 row">
                                                        <label for="name_ATM" class="col-sm-2 col-form-label">'.$lang["ville"].'</label>
                                                        <div class="col-sm-10">
                                                            <input  id="ville'.$ATM.'" name="ville'.$ATM.'" type="text"   value="'.$ville.'"    class="form-control input-sm">		
                                                        </div>
                                                    </div>
                                                    
                                                    <div  class="mb-3 row">
                                                        <label for="name_ATM" class="col-sm-2 col-form-label">'.$lang["region"].'</label>
                                                        <div class="col-sm-10">
                                                            <select   name="code_region'.$ATM.'"  id="code_region'.$ATM.'" class="form-control">';
                                                                get_select_all_region($info[11]);
                                                            echo '</select>		
                                                        <input  id="region'.$ATM.'" name="region'.$ATM.'" type="hidden"   value=""    class="form-control input-sm">	
                                                        </div>
                                                    </div>
                                                    
                                                    <div  class="mb-3 row">
                                                        <label for="name_ATM" class="col-sm-2 col-form-label">Pays</label>
                                                        <div class="col-sm-10">
                                                            <input  id="pays'.$ATM.'" name="pays'.$ATM.'" type="text"   value="'.$pays.'"    class="form-control input-sm">	
                                                        </div>
                                                    </div>
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="coin_dispenser" role="tabpanel" aria-labelledby="coin_dispenser-tab">
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12">
                                            <div class="card card-accent-success">
                                                <div class="card-body">
                                                    <div class="row">     
                                                        <div  class="form-group row col-sm-6" id="radioDiv1">               
                                                            <label for="State" class="col-sm-4 form-check-label">Envois Statut</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">   
                                                                <input type="radio" class="form-check-input" id="Send_statut1" value="1" name="Send_statut" checked>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>  
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Send_statut2" value="0" name="Send_statut" >
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>  
                                                        </div>                                                              
                                                    </div>
                                                    <div class="row"> 
                                                        <div  class="form-group row col-sm-6" id="radioDiv2">               
                                                            <label for="Parse_journal" class="col-sm-4 form-check-label">Analyser Journal</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Parse_journal1" value="1" name="Parse_journal">
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>  
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Parse_journal2" value="0" name="Parse_journal" checked>
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>  
                                                        </div>          
                                                    </div>
                                                    <div class="row">
                                                        <div  class="form-group row col-sm-6" id="radioDiv3">               
                                                            <label for="Depl_image" class="col-sm-4 form-check-label">Exécution Command</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Exec_command1" value="1" name="Exec_command" checked>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>  
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Exec_command2" value="0" name="Exec_command" >
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>  
                                                        </div>    
                                                    </div>
                                                    <div class="row">
                                                        <div  class="form-group row col-sm-6" id="radioDiv4">               
                                                            <label for="State_depot_argent" class="col-sm-4 form-check-label">Déploiement Image</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Depl_image1" value="1" name="Depl_image" checked>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>  
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Depl_image2" value="0" name="Depl_image" >
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>  
                                                        </div>  
                                                    </div>
                                                    
                                                    <div class="row">
                                                        <div  class="form-group row col-sm-6" id="radioDiv5">               
                                                            <label for="State_depot_argent" class="col-sm-4 form-check-label">Déploiement Binaire</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Depl_binaire1" value="1" name="Depl_binaire" checked>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>  
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Depl_binaire2" value="0" name="Depl_binaire" >
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>  
                                                        </div>  
                                                    </div> 
                                                    
                                                    <div class="row">
                                                        <div  class="form-group row col-sm-6" id="radioDiv6">         
                                                            <label for="State_depot_argent" class="col-sm-4 form-check-label">Upload Command</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                
                                                                <input type="radio" class="form-check-input" id="upload_command1" value="1" name="upload_command" checked>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>  
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="upload_command2" value="0" name="upload_command" >
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>  
                                                        </div>  
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /.col-->
                                    </div>
                                </div>
                            </div>
                    </div>
				</form> 
									
			</div>																										
			<!-- Modal footer -->
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-primary" style="padding:7px 40px"  
                onClick="javascript:confirmeDeclarerNouveauGAB(\''.$ATM.'\',\''.$paramettre.'\',\''.$idprivilege.'\',\''.$date_debut.'\',\''.$date_fin.'\',\''.$historique_vacation.'\')" 
                data-dismiss="modal" >'.$lang['confir'].'</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
            </div>
																										
		</div>
	</div>';

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_info_agence($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT `code_agence`, `nom_agence`, `ville`, `id_direction`  FROM `new_list_agence`  WHERE `code_agence` = '".mysqli_real_escape_string($connexion,$id)."'";
		// echo $sql;

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 400:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 400 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
              return	array($row["code_agence"],
                              $row["nom_agence"],
                              $row["ville"],
                              $row["id_direction"]);
            }
        }
		else
			{
					return array('','','','');
			}
        mysqli_free_result($result);
	}	
	
	mysqli_close($connexion);
}
/************************************************************************************************************/
function getModifierAgence($code_agence)
{
	
								$infoAgence=get_info_agence($code_agence);
								
								 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Modifier Agence</h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">';
																echo '
																	<form class="form-horizontal" role="form">
																		<div  class="form-group">				
																			<label for="id_ATM" class="col-sm-2 control-label">Code Agence</label>
																			<div class="col-sm-10">
																				<input  id="id_code_agence2"  name="id_code_agence2" type="text" disabled=disabled   value="'.$code_agence.'"class="form-control input-sm">
																				<input  id="code_agence'.$code_agence.'"  name="code_agence'.$code_agence.'" type="hidden"    value="'.$code_agence.'"class="form-control input-sm">
																				<input  id="name_region'.$code_agence.'"  name="name_region'.$code_agence.'" type="hidden"    value="'.$code_agence.'"class="form-control input-sm">
																				<input  id="name_ville'.$code_agence.'"  name="name_ville'.$code_agence.'" type="hidden"    value="'.$code_agence.'"class="form-control input-sm">
																			</div>
																		</div>
																		
																		
																		<div  class="form-group">
																			<label for="name_agence" class="col-sm-2 control-label">Name Agence</label>
																			<div class="col-sm-10">
																				<input  id="name_agence'.$code_agence.'"  name="name_agence'.$code_agence.'" type="text"   value="'.$infoAgence[1].'" class="form-control input-sm">
																			</div>
																		</div>														
																

																		

																			<div  class="form-group">				
																			<label for="buttonVaction" class="col-sm-2 control-label"></label>
																			<div class="col-sm-10">
																				<button type="button" class="btn btn-danger"  
																				onClick="javascript:modifierAgence(\''.$code_agence.'\')" 
																				 data-dismiss="modal" >Modifier</button>';						
																			echo'</div>
																		</div>	
																		
																	</form> ';
																									
												
							echo '	
									
											</div>																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_info_atm($id)
{
    $connexion=ma_db_connexion();

    $sql ="SELECT `list_atm_confirmed`.`terminal` as `terminal`, `id_atm`, `work_station_name`, `ip_adress`, `mac_adress`, `date_add`, `state`, `execution_mode`,
 `execution_mode_version`, `last_version`, `last_connexion`, `state_send_status`, `state_parse_journal`, `state_exec_command`, `list_atm_confirmed`.`type_gab` as `type_gab`, `nbr_jr_file`,
  `state_send_image`, `state_send_binaire` ,`state_sleep_command`,`time_sleeping`,`new_list_gab`.`nom_gab` as `gab_name` ,`new_list_gab`.`id_activ_depot_argent` ,`new_list_gab`.`id_activ_depot_cheque`,
  `new_list_gab`.`code_agence` as `code_agence`,`new_list_gab`.`id_profil` as `id_profil`,`list_atm_confirmed`.`work_station_name` as `work_station_name`,`list_atm_confirmed`.`state_upload` as `state_upload`
   FROM `list_atm_confirmed`,`new_list_gab` WHERE `list_atm_confirmed`.`terminal` = '".mysqli_real_escape_string($connexion,$id)."' AND `new_list_gab`.`terminal` = `list_atm_confirmed`.`terminal`";


    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 401:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 401 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {

                return array($row["terminal"],
                    $row["id_atm"],
                    $row["work_station_name"],
                    $row["ip_adress"],
                    $row["mac_adress"],
                    $row["date_add"],
                    $row["state"],
                    $row["execution_mode"],
                    $row["execution_mode_version"],
                    $row["last_version"],
                    $row["last_connexion"],
                    $row["state_send_status"],
                    $row["state_parse_journal"],
                    $row["state_exec_command"],
                    $row["type_gab"],
                    $row["nbr_jr_file"],
                    $row["state_send_image"],
                    $row["state_send_binaire"],
                    $row["state_sleep_command"],
                    $row["time_sleeping"],
                    $row["gab_name"],
                    $row["id_activ_depot_argent"],
                    $row["id_activ_depot_cheque"],
                    $row["work_station_name"],
                    $row["code_agence"],
                    $row["state_upload"],
                    $row["id_profil"]);
            }

        }
        else
        {
            return array('','','','','','','','','',
                '','','','','','','','','','','','','','','','','');
        }

    }
    mysqli_close($connexion);

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_info_gab($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT `terminal`, `id_terminal_xfs`, `date_ajout`, `numero_serie`, `date_installation`, `emplacement`, `type_emplacement`, `gestionnaire`,
 `nom_gab`, `ip_adresse_gab`, `type_gab`, `code_bank`, `code_group`, `code_succursale`, `code_agence`, `adresse_gab`, `id_fournisseur`, `ville` 
		FROM `new_list_gab` WHERE `terminal` = '".mysqli_real_escape_string($connexion,$id)."'";
		// echo $sql;

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 402:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 402 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return	array($row["terminal"],
                            $row["id_terminal_xfs"],
                            $row["date_ajout"],
                            $row["numero_serie"],
                            $row["date_installation"],
                            $row["emplacement"],
                            $row["type_emplacement"],
                            $row["gestionnaire"],
                            $row["nom_gab"],
                            $row["ip_adresse_gab"],
                            $row["type_gab"],
                            $row["code_bank"],
                            $row["code_group"],
                            $row["code_succursale"],
                            $row["code_agence"],
                            $row["adresse_gab"],
                            $row["id_fournisseur"],
                            $row["ville"]);
            }

        }
        else
        {
            return array('','','','','','','','','',
                '','','','','','','','','');
        }

    }
mysqli_close($connexion);
}
/************************************************************************************************************/
function getModifierGAB($ATM)
{
    include "../languages/" . $_SESSION['lang'] . ".php";

    $infoGAB=get_info_gab($ATM);
    echo '
    <div class="modal-dialog modal-lg">
        <div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  										
		    <!-- Modal Header -->
			    <div class="modal-header">
				    <h4 class="modal-title">'.$lang['modifier'].' '.$lang['terminal'].'</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>																						
				<!-- Modal body -->
				<div class="modal-body">
				    <form class="form-horizontal" role="form">
                        <div  class="form-group row">				
                            <label for="id_ATM" class="col-sm-4 col-form-label" >'.$lang['terminal'].'</label>
                            <div class="col-sm-8">
                                <input  id="id_ATM2"  name="id_ATM2" type="text" disabled=disabled   value="'.$ATM.'"class="form-control input-sm">
                                <input  id="id_ATM'.$ATM.'"  name="id_ATM'.$ATM.'" type="hidden"    value="'.$ATM.'"class="form-control input-sm">
                                <input  id="cd_terminal'.$ATM.'"  name="cd_terminal'.$ATM.'" type="hidden"   value="'.$infoGAB[0].'" class="form-control input-sm">
                                </div>
                        </div>
																		
                        <div  class="form-group row">
                            <label for="name_ATM" class="col-sm-4 col-form-label">'.$lang['atm_name'].'</label>
                            <div class="col-sm-8">
                                <input  id="name_ATM'.$ATM.'"  name="name_ATM'.$ATM.'" type="text"   value="'.$infoGAB[8].'" class="form-control input-sm">
                            </div>
                        </div>
																		
                        <div  class="form-group row">				
                            <label for="Vacation" class="col-sm-4 col-form-label">'.$lang['cashp_type'].'</label>
                            <div class="col-sm-8">
                                <select   name="constucteur'.$ATM.'"  id="constucteur'.$ATM.'" class="form-control">';
                                    get_select_constructeur($infoGAB[16]);
                                    //get_select_all_constructeur();
                                echo '</select>
                            </div>  
                        </div>		
                        <input  id="cd_agance'.$ATM.'" name="cd_agance'.$ATM.'" type="hidden"   value="'.$infoGAB[14].'"    class="form-control input-sm">	    
						<input  id="ville'.$ATM.'" name="ville'.$ATM.'" type="hidden"   value="'.$infoGAB[17].'"    class="form-control input-sm">	    
						<input  id="region'.$ATM.'" name="region'.$ATM.'" type="hidden"   value="'.$infoGAB[11].'"    class="form-control input-sm">	    
		
                     											
					</form> 
                </div>																										
                <!-- Modal footer -->
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-primary"  onClick="javascript:modifierGAB(\''.$ATM.'\')" data-dismiss="modal" >'.$lang['modifier'].'</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
                </div>
        </div>
    </div>';

}

/************************************************************************************************************/
function getModifierATMConfirmed($ATM)
{
    include "../languages/" . $_SESSION['lang'] . ".php";
    $infoGAB=get_info_atm($ATM);
    echo '<div class="modal-dialog modal-xl">
	        <div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Modifier ATM Confirmed</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <form class="form-horizontal" role="form">
                        <div class="nav-tabs-boxed">
                            <ul class="nav nav-tabs" id="myTab1" role="tablist">
                                <li class="nav-item"><a class="nav-link active" id="currency_dispenser-tab" data-toggle="tab" href="#currency_dispenser" role="tab" aria-controls="currency_dispenser" aria-selected="true">Information Géneral</a></li>
                                <li class="nav-item"><a class="nav-link" id="coin_dispenser-tab" data-toggle="tab" href="#coin_dispenser" role="tab" aria-controls="coin_dispenser" aria-selected="false">Config Fonctionnalités Client</a></li>
                            </ul>
                            <div class="tab-content" id="myTab1Content">
                                <div class="tab-pane fade show active" id="currency_dispenser" role="tabpanel" aria-labelledby="currency_dispenser-tab">

                                    <div class="row">
                                        <div class="col-sm-12 col-md-12">
                                            <div class="card card-accent-info ">
                                                <div class="card-body">
                                                    <div  class="mb-3 row">
                                                        <label for="id_ATM" class="col-sm-2 col-form-label">ID ATM</label>
                                                        <div class="col-sm-10">
                                                            <input  id="id_ATM'.$ATM.'"  name="id_ATM'.$ATM.'" type="text" disabled=disabled  value="'.$infoGAB[1].'" class="form-control input-sm">
                                                        </div>
                                                    </div>

                                                    <div  class="mb-3 row">
                                                        <label for="id_ATM" class="col-sm-2 col-form-label">Code Terminal</label>
                                                        <div class="col-sm-10">
                                                            <input  id="id_ATM2"  name="id_ATM2" type="text"   value="'.$ATM.'"class="form-control input-sm">
                                                            <input  id="id_ATM'.$ATM.'"  name="id_ATM'.$ATM.'" type="hidden"    value="'.$ATM.'"class="form-control input-sm">
                                                            <input  id="cd_terminal'.$ATM.'"  name="cd_terminal'.$ATM.'" type="hidden"   value="'.$infoGAB[0].'" class="form-control input-sm">
                                                        </div>
                                                    </div>

                                                    <div  class="mb-3 row">
                                                        <label for="id_ATM" class="col-sm-2 col-form-label">Code Agence</label>
                                                        <div class="col-sm-10">
                                                            <input  id="cd_agence'.$ATM.'"  name="cd_agence'.$ATM.'"  value="'.$infoGAB[24].'" class="form-control input-sm">
                                                        </div>
                                                    </div>

                                                    <div  class="mb-3 row">
                                                        <label for="name_ATM" class="col-sm-2 col-form-label">Name ATM</label>
                                                        <div class="col-sm-10">
                                                            <input  id="name_ATM'.$ATM.'"  name="name_ATM'.$ATM.'" type="text"   value="'.$infoGAB[20].'" class="form-control input-sm">
                                                        </div>
                                                    </div>

                                                    <div  class="mb-3 row">
                                                        <label for="Vacation" class="col-sm-2 col-form-label">Profil</label>
                                                        <div class="col-sm-10">
                                                            <select   name="profil'.$ATM.'"   id="profil'.$ATM.'"  class="form-control">';
                                                                get_select_profile_sel($infoGAB[26]);
                                                                echo '</select>
                                                        </div>
                                                    </div>

                                                    <div  class="mb-3 row">
                                                        <label for="work_station_name" class="col-sm-2 col-form-label">Nom Machine</label>
                                                        <div class="col-sm-10">
                                                            <input  id="work_station_name'.$ATM.'"  name="work_station_name'.$ATM.'" type="text" disabled=disabled  value="'.$infoGAB[23].'" class="form-control input-sm">
                                                        </div>
                                                    </div>
                                                    <div  class="mb-3 row">
                                                        <label for="ip_adresse_gab" class="col-sm-2 col-form-label">Adresse IP</label>
                                                        <div class="col-sm-10">
                                                            <input  id="ip_adresse_gab'.$ATM.'"  name="ip_adresse_gab'.$ATM.'" type="text"  value="'.$infoGAB[3].'" class="form-control input-sm">
                                                        </div>
                                                    </div>

                                                    <div  class="mb-3 row">
                                                        <label for="Vacation" class="col-sm-2 col-form-label">Constructeur</label>
                                                        <div class="col-sm-10">
                                                            <select   name="constucteur'.$ATM.'"  id="constucteur'.$ATM.'" class="form-control">';
                                                                get_select_constructeur($infoGAB[14]);
                                                                echo '</select>
                                                        </div>
                                                    </div>

                                                    <div  class="mb-3 row">
                                                        <label for="date_ajout_atm" class="col-sm-2 col-form-label">Date Ajout ATM</label>
                                                        <div class="col-sm-10">
                                                            <input  id="date_ajout_atm'.$ATM.'"  name="date_ajout_atm'.$ATM.'" type="text" disabled=disabled    value="'.$infoGAB[5].'" class="form-control input-sm">
                                                        </div>
                                                    </div>

                                                    <div  class="mb-3 row">
                                                        <label for="ver_client_atm" class="col-sm-2 col-form-label">Version Client</label>
                                                        <div class="col-sm-10">
                                                            <input  id="ver_client_atm'.$ATM.'"  name="ver_client_atm'.$ATM.'" type="text" disabled=disabled    value="'.$infoGAB[9].'" class="form-control input-sm">
                                                        </div>
                                                    </div>
                                                    <div  class="mb-3 row">
                                                        <label for="last_conn_atm" class="col-sm-2 col-form-label">Dernière Connexion</label>
                                                        <div class="col-sm-10">
                                                            <input  id="last_conn_atm'.$ATM.'"  name="last_conn_atm'.$ATM.'" type="text" disabled=disabled    value="'.$infoGAB[10].'" class="form-control input-sm">
                                                        </div>
                                                    </div>

                                                    <div  class="mb-3 row">
                                                        <label for="nbr_jr_file" class="col-sm-2 col-form-label">Jour Envois File</label>
                                                        <div class="col-sm-10">
                                                            <input  id="nbr_jr_file'.$ATM.'"  name="nbr_jr_file'.$ATM.'" type="text" value="'.$infoGAB[15].'" class="form-control input-sm">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="coin_dispenser" role="tabpanel" aria-labelledby="coin_dispenser-tab">
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12">
                                            <div class="card card-accent-success">
                                                <div class="card-body">
                                                    <div class="row">     
                                                        <div  class="form-group row col-sm-6" id="radioDiv1">				
                                                            <label for="State" class="col-sm-4 form-check-label">Etat Activation</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">   
                                                                <input id="State1" class="form-check-input" type ="radio" name="State" value="1" '; if($infoGAB[6]=='1') { echo 'checked'; } echo'/>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>	
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input id="State2" class="form-check-input" type ="radio" name="State" value="0" '; if($infoGAB[6]=='0') { echo 'checked'; } echo'/>
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>	
                                                        </div>	
                                                        <div class="form-group row col-sm-1">
                                                            <div class="c-vr"></div>
                                                        </div>
                                                        <div  class="form-group row col-sm-6" id="radioDiv2">				
                                                            <label for="Send_statut" class="col-sm-4 form-check-label">Envois Statut</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Send_statut1" value="1" name="Send_statut"'; if($infoGAB[11]=='1') { echo 'checked'; } echo'/>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>	
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Send_statut2" value="0" name="Send_statut"'; if($infoGAB[11]=='0') { echo 'checked'; } echo'/>
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span>
                                                            </div>	
                                                        </div>																	
                                                    </div>
                                                    <div class="row"> 
                                                        <div  class="form-group row col-sm-6" id="radioDiv3">				
                                                            <label for="Parse_journal" class="col-sm-4 form-check-label">Analyser Journal</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Parse_journal1" value="1" name="Parse_journal"'; if($infoGAB[12]=='1') { echo 'checked'; } echo'/>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>	
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Parse_journal2" value="0" name="Parse_journal" '; if($infoGAB[12]=='0') { echo 'checked'; } echo'/>
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>	
                                                        </div>		
                                                        <div class="form-group row col-sm-1">
                                                            <div class="c-vr"></div>
                                                        </div>
                                                        <div  class="form-group row col-sm-6" id="radioDiv4">				
                                                            <label for="Exec_command" class="col-sm-4 form-check-label">Exécution Command</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Exec_command1" value="1" name="Exec_command" '; if($infoGAB[13]=='1') { echo 'checked'; } echo'/>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>	
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Exec_command2" value="0" name="Exec_command" '; if($infoGAB[13]=='0') { echo 'checked'; } echo'/>
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>	
                                                        </div>		
                                                    </div>
                                                    <div class="row">
                                                        <div  class="form-group row col-sm-6" id="radioDiv5">				
                                                            <label for="Depl_image" class="col-sm-4 form-check-label">Déploiement Image</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Depl_image1" value="1" name="Depl_image" '; if($infoGAB[16]=='1') { echo 'checked'; } echo'/>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>	
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Depl_image2" value="0" name="Depl_image" '; if($infoGAB[16]=='0') { echo 'checked'; } echo'/>
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>	
                                                        </div>	
                                                        <div class="form-group row col-sm-1">
                                                            <div class="c-vr"></div>
                                                        </div>
                                                        <div  class="form-group row col-sm-6" id="radioDiv6">				
                                                            <label for="Depl_binaire" class="col-sm-4 form-check-label">Déploiement Binaire</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Depl_binaire1" value="1" name="Depl_binaire" '; if($infoGAB[17]=='1') { echo 'checked'; } echo'/>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>	
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="Depl_binaire2" value="0" name="Depl_binaire" '; if($infoGAB[17]=='0') { echo 'checked'; } echo'/>
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>	
                                                        </div>		
                                                    </div>
                                                    <div class="row">
                                                        <div  class="form-group row col-sm-6" id="radioDiv8">				
                                                            <label for="State_depot_argent" class="col-sm-4 form-check-label">Depot Argent</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="State_depot_argent1" value="1" name="State_depot_argent" '; if($infoGAB[21]=='1') { echo 'checked'; } echo'/>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>	
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="State_depot_argent2" value="0" name="State_depot_argent" '; if($infoGAB[21]=='0') { echo 'checked'; } echo'/>
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>	
                                                        </div>
                                                        <div class="form-group row col-sm-1">
                                                            <div class="c-vr"></div>
                                                        </div>	
                                                        <div  class="form-group row col-sm-6" id="radioDiv9">				
                                                            <label for="State_depot_cheque" class="col-sm-4 form-check-label">Depot Cheque</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="State_depot_cheque1" value="1" name="State_depot_cheque" '; if($infoGAB[22]=='1') { echo 'checked'; } echo'/>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>	
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="State_depot_cheque2" value="0" name="State_depot_cheque" '; if($infoGAB[22]=='0') { echo 'checked'; } echo'/>
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>	
                                                        </div>		
                                                    </div>
                                                    <div class="row">	
                                                        <div  class="form-group row col-sm-6" id="radioDiv7">				
                                                            <label for="sleep_command" class="col-sm-4 form-check-label">Sleep Command</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="sleep_command1" value="123" name="sleep_command" '; if($infoGAB[18]=='123') { echo 'checked'; } echo'/>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>	
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="sleep_command2" value="0" name="sleep_command" '; if($infoGAB[18]!='123') { echo 'checked'; } echo'/>
                                                                <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>	
                                                        </div> 	
                                                        <div class="form-group row col-sm-1">
                                                            <div class="c-vr"></div>
                                                        </div>
                                                        <div  class="form-group row col-sm-6" id="radioDiv10">				
                                                            <label for="sleep_command" class="col-sm-4 form-check-label">Upload Command</label>
                                                            <div class="col-sm-4 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="upload_command1" value="1" name="upload_command" '; if($infoGAB[25]=='1') { echo 'checked'; } echo'/>
                                                                <span class="cil-check" style="color: #33cc33;" aria-hidden="false"></span>
                                                            </div>	
                                                            <div class="col-sm-3 custom-control custom-radio custom-control-inline">
                                                                <input type="radio" class="form-check-input" id="upload_command2" value="0" name="upload_command" '; if($infoGAB[25]!='1') { echo 'checked'; } echo'/>
                                                                 <span class="cil-x-circle" style="color: #C9302C;" aria-hidden="false"></span> 
                                                            </div>	
                                                        </div>
                                                        	 	
                                                    </div> 
                                                    
                                                    <div class="row">	
                                                        <div  class="form-group row col-sm-6">
                                                            <label for="time_sleeping" class="col-sm-4 form-check-label">Time Sleeping (MIN)</label>
                                                            <div class="col-sm-6 custom-control custom-control-inline">
                                                                <input  id="time_sleeping'.$ATM.'"  name="time_sleeping'.$ATM.'" type="text" value="'.$infoGAB[19].'" class="form-control input-sm">
                                                            </div>
                                                        </div>
                                                    </div> 
                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /.col-->
                                    </div>
                                </div>

                            </div>
                        </div>
                    </form>
                </div>
                <!-- Modal footer -->
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-primary" style="padding:7px 40px"  
                    onClick="javascript:modifierATMConfirmed(\''.$ATM.'\')" 
                    data-dismiss="modal" >'.$lang['confir'].'</button>
                    <button type="button" class="btn btn-danger" style="padding:7px 35px" data-dismiss="modal">'.$lang['close'].'</button>
                </div>  
            </div>
    </div>';

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_alerte($idAlerte,$dateArret,$datePriseCharge,$dateCloture,$porteur,$typeProduit,$typeBlocage,$EtatAlerte,$remarque)
{
    $connexion=ma_db_connexion();

    $sqlModif = "SELECT `id_alerte` FROM  `new_alertes_modifier` WHERE `id_alerte` = '".mysqli_real_escape_string($connexion,$idAlerte)."'";

    $rsModif=mysqli_query($connexion,$sqlModif);
    if (!$rsModif)
    {
        error_log("Erreur SQL 403:  ".$sqlModif."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 403 !');
    }
    if ($rsModif)
    {
        if(mysqli_num_rows($rsModif)==0)
        {
            $sql="INSERT INTO `new_alertes_modifier` SELECT * FROM `new_alertes` WHERE `id_alerte` = '".mysqli_real_escape_string($connexion,$idAlerte)."'";
            $result=mysqli_query($connexion,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 404:  ".$sql."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 404 !');
            }
        }
      mysqli_free_result($rsModif);
    }
	
	
	
	
    $s = "SELECT `id_alerte` FROM  `new_alertes` WHERE `id_alerte` = '".mysqli_real_escape_string($connexion,$idAlerte)."'";
    $rs=mysqli_query($connexion,$s);
    if (!$rs)
    {
        error_log("Erreur SQL 405:  ".$s."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 405 !');
    }
    if ($rs)
    {
        if(mysqli_num_rows($rs)>0)
        {
           $SQL1="UPDATE `new_alertes` SET 
           `date_arrete`='".mysqli_real_escape_string($connexion,$dateArret)."',
           `date_prise_charge`='".mysqli_real_escape_string($connexion,$datePriseCharge)."',
           `date_cloture`='".mysqli_real_escape_string($connexion,$dateCloture)."',
           `id_porteur`='".mysqli_real_escape_string($connexion,$porteur)."',
           `NumCIN`='".getCINPorteur(mysqli_real_escape_string($connexion,$porteur))."',
           `numCompte`='".getComptePorteur(mysqli_real_escape_string($connexion,$porteur))."', 
           `numCarte`='".getCartePorteur(mysqli_real_escape_string($connexion,$porteur))."',
           `id_type_produit`='".mysqli_real_escape_string($connexion,$typeProduit)."',
           `id_type_blocage`='".mysqli_real_escape_string($connexion,$typeBlocage)."',
           `etat_alerte`='".mysqli_real_escape_string($connexion,$EtatAlerte)."',
           `remarque`='".addslashes(mysqli_real_escape_string($connexion,$remarque))."'
            WHERE  `id_alerte` = '".mysqli_real_escape_string($connexion,$idAlerte)."'";
            $result1=mysqli_query($connexion,$SQL1);
            if (!$result1)
            {
                error_log("Erreur SQL 406:  ".$SQL1."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 406 !');
            }


            $SQL2="UPDATE `new_actions_alertes` SET `date_prise_charge`='".mysqli_real_escape_string($connexion,$datePriseCharge)."' WHERE  `id_action` = '".get_min_id_action(mysqli_real_escape_string($connexion,$idAlerte))."'";
            $result2=mysqli_query($connexion,$SQL2);
            if (!$result2)
            {
                error_log("Erreur SQL 407:  ".$SQL1."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 407 !');
            }
        }
          mysqli_free_result($rs);
    }
		mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_max2_id_action($id_alerte,$id_action)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  MAX(`id_action`) as idaction FROM `new_actions_alertes` WHERE `id_alertes` = '".mysqli_real_escape_string($connexion,$id_alerte)."' AND  `id_action` < '".mysqli_real_escape_string($connexion,$id_action)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 408:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 408 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["idaction"];
            }
        }
		else
        {
            return 0;
        }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_actions($id_alerte,$id_action,$datePriseCharge,$dateRappel,$typeAppel,$note,$niveauIntervention,$NBAppel,$NBTentative)	
{
    $connexion=ma_db_connexion();

    // echo get_max2_id_action($id_alerte,$id_action)."---------".$id_alerte."---------".$id_action;
	if(strtotime($dateRappel) >= strtotime($datePriseCharge)) 
		{	
			$sqlModif = "SELECT `id_action` FROM  `new_actions_alertes_modifier` WHERE `id_action` = '".mysqli_real_escape_string($connexion,$id_action)."'";
            $rsModif=mysqli_query($connexion,$sqlModif);
            if (!$rsModif)
            {
                error_log("Erreur SQL 409:  ".$sqlModif."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 409 !');
            }
    	if ($rsModif)
			{			
			if(mysqli_num_rows($rsModif)==0)
				{
				    $sql0="INSERT INTO `new_actions_alertes_modifier` SELECT * FROM `new_actions_alertes` WHERE `id_action` = '".mysqli_real_escape_string($connexion,$id_action)."'";
                    $result=mysqli_query($connexion,$sql0);
                    if (!$result)
                    {
                        error_log("Erreur SQL 410:  ".$sql0."  " .mysqli_error($connexion));
                        die(' ERREUR QUERY 410 !');
                    }
				}
			  mysqli_free_result($rsModif);	
			}

			$sql = "SELECT `id_action` FROM  `new_actions_alertes` WHERE `id_action` = '".mysqli_real_escape_string($connexion,$id_action)."'";
            $rs=mysqli_query($connexion,$sql);
            if (!$rs)
            {
                error_log("Erreur SQL 411:  ".$sql."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 411 !');
            }
			if ($rs)
				{			
                if(mysqli_num_rows($rs)>0)
                    {
						   $SQL1="UPDATE `new_actions_alertes` SET 
						   `date_prise_charge`='".mysqli_real_escape_string($connexion,$datePriseCharge)."',
						   `date_rappel`='".mysqli_real_escape_string($connexion,$dateRappel)."',
						   `typeAppel`='".mysqli_real_escape_string($connexion,$typeAppel)."',					   
						   `note`='".addslashes(mysqli_real_escape_string($connexion,$note))."',
						   `niveau_intervention`='".mysqli_real_escape_string($connexion,$niveauIntervention)."',
						   `nbr_appel`='".mysqli_real_escape_string($connexion,$NBAppel)."',
						   `nbr_tentative`='".mysqli_real_escape_string($connexion,$NBTentative)."',
						   `idUser`='".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."'
							WHERE  `id_action` = '".mysqli_real_escape_string($connexion,$id_action)."'";
                        $result1=mysqli_query($connexion,$SQL1);
                        if (!$result1)
                        {
                            error_log("Erreur SQL 412:  ".$SQL1."  " .mysqli_error($connexion));
                            die(' ERREUR QUERY 412 !');
                        }

				if ((get_max2_id_action($id_alerte,$id_action)<>'') || (get_max2_id_action($id_alerte,$id_action)<>0))
					{
					    $SQL3="UPDATE `new_actions_alertes` SET `date_rappel`='".mysqli_real_escape_string($connexion,$datePriseCharge)."' WHERE  `id_action` = '".get_max2_id_action(mysqli_real_escape_string($connexion,$id_alerte),mysqli_real_escape_string($connexion,$id_action))."'";
                        $result3=mysqli_query($connexion,$SQL3);
                        if (!$result3)
                        {
                            error_log("Erreur SQL 413:  ".$SQL3."  " .mysqli_error($connexion));
                            die(' ERREUR QUERY 413 !');
                        }
					}					
				}
			mysqli_free_result($rs);	
     		}
				
			if (get_min_id_action($id_alerte)==$id_action)
				{
                       $SQL2="UPDATE `new_alertes` SET
					   `date_prise_charge`='".mysqli_real_escape_string($connexion,$datePriseCharge)."'
						WHERE  `id_alerte` = '".mysqli_real_escape_string($connexion,$id_alerte)."'";
                    $result2=mysqli_query($connexion,$SQL2);
                    if (!$result2)
                    {
                        error_log("Erreur SQL 414:  ".$SQL2."  " .mysqli_error($connexion));
                        die(' ERREUR QUERY 414 !');
                    }
				}
		}
		else
		{
			   echo'<div class="col-sm-12" >
				<div class="alert alert-danger"> <strong>Attention veuillez saisir la date Rappel >= la date prise en charge !!!!!!!!! </strong></div>
				</div>';	
		}
		
		mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserAlerteOuvert($idAlerte)
{
    $connexion=ma_db_connexion();

    suppimerAlerteOuvert($idAlerte);
    $sql="INSERT INTO `new_alertes_ouvert` SELECT * FROM `new_alertes` WHERE `id_alerte` = '".mysqli_real_escape_string($connexion,$idAlerte)."' AND `etat_alerte`=0";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 415:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 415 !');
    }

   mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_type_appel_etat_incident($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `etat_incident` FROM `new_type_appel` WHERE id_etat = '".mysqli_real_escape_string($connexion,$id)."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 416:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 416 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["etat_incident"];
            }
        }
        else
        {
            return 0;
        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);
	
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function confirmerDeclarerAlerte($id_ATM,$name_ATM,$Vacation,$Erreur,$statusXFS,$categoryXFS,$codeError,$dateVacation)
{
    $connexion=ma_db_connexion();

    $sql = "INSERT INTO `declarer_incident` (`id_incident`, `id_terminal`, `vacation`, `xfs_error`, `xfs_status`, `category`, `code_error`, `date_vacation`, `id_utilisateur`)
			    VALUES ('', '".mysqli_real_escape_string($connexion,$id_ATM)."',  '".mysqli_real_escape_string($connexion,$Vacation)."',  '".mysqli_real_escape_string($connexion,$Erreur)."' , '".mysqli_real_escape_string($connexion,$statusXFS)."', '".mysqli_real_escape_string($connexion,$categoryXFS)."', '".mysqli_real_escape_string($connexion,$codeError)."', '".mysqli_real_escape_string($connexion,$dateVacation)."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."');";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 417:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 417 !');
    }
    mysqli_close($connexion);
   // echo'<div class="col-sm-12" ><br>
	// <div class="alert alert-success" align="center"> <strong>Déclaration bien enregistrée </strong></div>
  // </div>';	
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function verif_user($user,$mdp)
{
$ipadr=get_ip();
$connexion=ma_db_connexion();
$sql = "SELECT `email`,`password`  
FROM `iprc_authentification_cfg`.`new_utilisateur`,`iprc_authentification_cfg`.`new_utilisateur_ip_adresse`,`iprc_authentification_cfg`.`new_adressage_ip` 
WHERE `new_utilisateur`.`id_utilisateur`=`new_utilisateur_ip_adresse`.`id_utilisateur`
AND `new_adressage_ip`.`id_ipadresse`=`new_utilisateur_ip_adresse`.`id_ip_adress`
AND  (`commentaire` = LOWER('".mysqli_real_escape_string($connexion,$ipadr)."') OR `commentaire` = LOWER('0.0.0.0'))
AND `new_utilisateur_ip_adresse`.`etat`='1'
AND email = LOWER('".mysqli_real_escape_string($connexion,$user)."') 
AND `password` = AES_ENCRYPT('IPRC','".mysqli_real_escape_string($connexion,$mdp)."') 
AND `new_utilisateur`.`etat`=1";
// echo $sql ;

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 418:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 418 !'.mysqli_error($connexion));
    }

if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
				while ($row = mysqli_fetch_assoc($result)) 
					{
						if ($row["email"] == mb_strtolower($user)) 
							{
							return true;
							}
						else
							{
							return false;
							}						
					}
			}
		mysqli_free_result($result);
	}				
mysqli_close($connexion);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_type_appel()
{
    $connexion=ma_db_connexion();

    $sql = "SELECT `id_etat`, `libelle` FROM `new_type_appel`";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 419:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 419 !');
    }
if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
							echo '<option value="'.$row["id_etat"].'">'.$row["libelle"].'</option>';  		
					}
			}	

mysqli_free_result($result);	
	}	
	mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_type_appel1($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT `id_etat`, `libelle` FROM `new_type_appel`  WHERE `id_etat` = '".mysqli_real_escape_string($connexion,$id)."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 420:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 420 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
							echo '<option value="'.$row["id_etat"].'">'.$row["libelle"].'</option>';  		
					}
			}	

mysqli_free_result($result);	
	}		
	mysqli_close($connexion);
	
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_niveau_intervention()
{
    $connexion=ma_db_connexion();

    $sql = "SELECT `id_niveau`, `libelle` FROM `new_niveau_intervention`";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 421:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 421 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
							echo '<option value="'.$row["id_niveau"].'">'.$row["libelle"].'</option>';  		
					}
			}	

mysqli_free_result($result);	
	}	
	mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_niveau_intervention1($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT `id_niveau`, `libelle` FROM `new_niveau_intervention`  WHERE `id_niveau` = '".mysqli_real_escape_string($connexion,$id)."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 422:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 422 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
							echo '<option value="'.$row["id_niveau"].'">'.$row["libelle"].'</option>';  		
					}
			}	

mysqli_free_result($result);	
	}	
	mysqli_close($connexion);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_type_rappel()
{
    $connexion=ma_db_connexion();

    $sql = "SELECT `idType`, `libelle` FROM `new_type_rappel`";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 423:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 423 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
							echo '<option value="'.$row["idType"].'">'.$row["libelle"].'</option>';  		
					}
			}	

mysqli_free_result($result);	
	}		
	mysqli_close($connexion);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getClotureRelance($id_alerte)
{
			
echo '
<form class="form-horizontal" role="form">
<div  class="form-group">
<label for="input_terminal" class="col-sm-2 control-label"></label>
				<div class="col-sm-10">
					<input  id="idAlerte2"  name="idAlerte2" type="Hidden"   value="'.$id_alerte.'"class="form-control input-sm">
					<input  id="dateCloture"  name="dateCloture" type="text"   value="'.date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))).'"class="form-control input-sm">
				</div>
				</div>	
				';


echo '<div  class="form-group">				
<label for="idTypeAppel" class="col-sm-2 control-label">Type Appel</label>
				<div class="col-sm-10">
				<select class="form-control" id="idTypeAppel"  name="idTypeAppel">';
				get_select_type_appel();
				echo ' </select>					
         	</div>
				</div>	

				<div  class="form-group">				
					<label for="noteCL" class="col-sm-2 control-label">Note</label>
					<div class="col-sm-10">
						<textarea name="noteCL" id="noteCL" class="form-control" rows="3"></textarea>														 
					</div>
				</div>	
				
				';
				
echo '</form> ';
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getAjouterRelance($id_alerte)
{
			
echo '
<form class="form-horizontal" role="form">
<div  class="form-group">
<label for="input_terminal" class="col-sm-2 control-label"></label>
				<div class="col-sm-10">
					<input  id="idAlerte"  name="idAlerte" type="hidden"   value="'.$id_alerte.'"class="form-control input-sm">
				</div>
				</div>		
				
<div  class="form-group">				
<label for="idTypeRappel" class="col-sm-2 control-label">Type appel</label>
				<div class="col-sm-10">
				<select class="form-control" id="idTypeRappel"  name="idTypeRappel">';
				get_select_type_rappel();
				echo ' </select>					
         	</div>
				</div>					
<div  class="form-group">				
<label for="idNiveauIntervention" class="col-sm-2 control-label">Niveau Intervention</label>
				<div class="col-sm-10">
				<select class="form-control" id="idNiveauIntervention"  name="idNiveauIntervention">';
				get_select_niveau_intervention();
				echo ' </select>					
         	</div>
				</div>	
<div  class="form-group">				
<label for="dureeRappel" class="col-sm-2 control-label">Durée Rappel</label>
				<div class="col-sm-10">
					 <select class="form-control" id="dureeRappel" required name="dureeRappel" >';
									 echo '    <option value="3600">1h</option>
												<option value="5400">1h30</option>
												<option value="7200">2h</option>
												<option value="14400">4h</option>
												<option value="JO7">Jour ouvrable</option>
												<option value="86400">24h (1Jour)</option>
												<option value="172800">48h (2Jours)</option>
												<option value="259200">72h (3Jours)</option>					
												<option value="345600">96h (4Jours)</option>	
					</select>     
				</div>
				</div>
<div  class="form-group">				
<label for="idTypeAppel" class="col-sm-2 control-label">Type Appel</label>
				<div class="col-sm-10">
				<select class="form-control" id="idTypeAppel"  name="idTypeAppel">';
				get_select_type_appel();
				echo ' </select>					
         	</div>
				</div>				
				';
				
echo '</form> ';
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function redemarrerATM($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT `id_atm` FROM `cmd_execution`  WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 424:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 424 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
        {
           $SQL2="UPDATE `cmd_execution` SET
           `id_cmd`= 1,
           `date_send_cmd`= NOW(),
           `user_exec`= '".$_SESSION['id_utilisateur']."',
           `if_executed`= 0,
           `date_after_exec_cmd`= '0000-00-00 00:00:00'				   
            WHERE  `id_atm` = '".$id."'";
            $result2=mysqli_query($connexion,$SQL2);
            if (!$result2)
            {
                error_log("Erreur SQL 425:  ".$SQL2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 425 !');
            }
        }
		mysqli_free_result($result);	
	}
mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function ScreenshotATM($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT `id_atm` FROM `cmd_execution`  WHERE `id_atm` = '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 426:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 426 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $SQL2="UPDATE `cmd_execution` SET
                   `id_cmd`= 53,
                   `date_send_cmd`= NOW(),
                   `user_exec`= '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',
                   `if_executed`= 0	,
                    `value_cmd`= 0,
                    `date_after_exec_cmd`= '0000-00-00 00:00:00'                   
                    WHERE  `id_atm` = '".mysqli_real_escape_string($connexion,$id)."'";
            $result2=mysqli_query($connexion,$SQL2);
            if (!$result2)
            {
                error_log("Erreur SQL 427:  ".$SQL2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 427 !');
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_array_action($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `date_prise_charge`, `date_rappel`, `action`, `typeAppel`, `typeBlocage`, `note`,`niveau_intervention`, `nbr_appel`, `nbr_tentative` FROM `new_actions_alertes` 
		WHERE `id_action` = '".mysqli_real_escape_string($connexion,$id)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 428:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 428 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
				return	array($row["date_prise_charge"],
					  $row["date_rappel"],
					  $row["action"],
					  $row["typeAppel"],
					  $row["typeBlocage"],
					  $row["note"],
					  $row["niveau_intervention"],
					  $row["nbr_appel"],
					  $row["nbr_tentative"]);	
					}
			}	
		else
			{
				return array('','','','','','','','','');
			}
mysqli_free_result($result);	
	}	
	mysqli_close($connexion);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getNote($id_action)
{
$action=get_return_array_action($id_action);	
echo '
<form class="form-horizontal" role="form">
				<div  class="form-group">				
					<div class="col-sm-10">'.$action[5].'</div>
				</div>		
</form> ';
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getModifierAction($id_alerte,$id_action)
{
$action=get_return_array_action($id_action);		
echo '
<form class="form-horizontal" role="form">

				<div  class="form-group">
					<label for="input_terminal" class="col-sm-2 control-label"></label>
					<div class="col-sm-10">
						<input  id="id_alerteAC"  name="id_alerteAC" type="hidden"   value="'.$id_alerte.'"class="form-control input-sm">
						<input  id="id_actionAC"  name="id_actionAC" type="hidden"   value="'.$id_action.'"class="form-control input-sm">
					</div>
				</div>	
				
				<div  class="form-group">				
					<label for="datePriseChargeAC" class="col-sm-2 control-label">Date prise en charge</label>
					<div class="col-sm-10">
						<input  id="datePriseChargeAC" name="datePriseChargeAC" type="text"   value="'.$action[0].'"    class="form-control input-sm">	    
					</div>
				</div>	

				
				<div  class="form-group">				
					<label for="dateRappelAC" class="col-sm-2 control-label">Date rappel</label>
					<div class="col-sm-10">
						<input  id="dateRappelAC" name="dateRappelAC" type="text"   value="'.$action[1].'"    class="form-control input-sm">	    
					</div>
				</div>	


				
				<div  class="form-group">				
					<label for="typeAppelAC" class="col-sm-2 control-label">Type appel</label>
					<div class="col-sm-10">
						<select name="typeAppelAC" id="typeAppelAC"  class="form-control">';
							get_select_type_appel1($action[3]);
							get_select_type_appel();
						echo '</select>    
					</div>
				</div>	

				
				<div  class="form-group">				
					<label for="niveauInterventionAC" class="col-sm-2 control-label">Niveau</label>
					<div class="col-sm-10">
						<select name="niveauInterventionAC" id="niveauInterventionAC"  class="form-control">';
							get_select_niveau_intervention1($action[6]);
							get_select_niveau_intervention();
						echo '</select>    
					</div>
				</div>	

				
				<div  class="form-group">				
					<label for="NBAppelAC" class="col-sm-2 control-label">NB Appel</label>
					<div class="col-sm-10">
						<input  id="NBAppelAC" name="NBAppelAC" type="text"   value="'.$action[7].'"    class="form-control input-sm">	    
					</div>
				</div>	
				
				<div  class="form-group">				
					<label for="NBTentativeAC" class="col-sm-2 control-label">NB Tentative</label>
					<div class="col-sm-10">
						<input  id="NBTentativeAC" name="NBTentativeAC" type="text"   value="'.$action[8].'"    class="form-control input-sm">	    
					</div>
				</div>	
				
				
				<div  class="form-group">				
					<label for="notAC" class="col-sm-2 control-label">Note</label>
					<div class="col-sm-10">
						<textarea name="notAC" id="notAC" class="form-control" rows="3">'.$action[5].'</textarea>														 
					</div>
				</div>		
</form> ';
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getStatusColor($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT `color_status` FROM `xfs_errors_STATUS` WHERE `id_status` ='".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 429:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 429 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["color_status"];
            }
        }
        else
        {
            return "";
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
								
}	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDetailPeripheralStatus($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
    $paramAffichage=1;
    SWITCH ($nameVacation)
    {
        CASE 'ALM':
            getDetailPeripheralStatusALM($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
            BREAK;
        //	CASE 'BCR':
        //				getDetailPeripheralStatusBCR($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        //	BREAK;
        CASE 'CAM':
            getDetailPeripheralStatusCAM($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
            BREAK;
        CASE 'CDM':
            getDetailPeripheralStatusCDM($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
            BREAK;
        CASE 'CEU':
            getDetailPeripheralStatusCEU($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        BREAK;

        CASE 'CHK':
            getDetailPeripheralStatusCHK($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        BREAK;

        CASE 'CIM':
            getDetailPeripheralStatusCIM($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        BREAK;

        CASE 'CIM2':
            getDetailPeripheralStatusCIM2($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,'CIM',$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        BREAK;

        CASE 'CRD':
            getDetailPeripheralStatusCRD($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        BREAK;

        CASE 'DEP':
            getDetailPeripheralStatusDEP($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        BREAK;

        CASE 'IDC':
            getDetailPeripheralStatusIDC($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        BREAK;

        CASE 'IPM':
            getDetailPeripheralStatusIPM($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        BREAK;

        CASE 'PIN':
            getDetailPeripheralStatusPIN($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        BREAK;

        CASE 'PTR':
            getDetailPeripheralStatusPTR($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        BREAK;

        CASE 'SIU':
            getDetailPeripheralStatusSIU($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        BREAK;

        CASE 'TTU':
            getDetailPeripheralStatusTTU($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        BREAK;

        CASE 'VDM':
            getDetailPeripheralStatusVDM($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage);
        BREAK;
    }

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function boolEtatPeripherique($category,$stat_verif,$supervised,$code_error,$message,$categorieCassette)
{
$B=0;	
			    if (($stat_verif==1) && ($supervised==1)) 
						{           
								
						}			  
					else if (($stat_verif==0) && ($supervised==1)) 
						{           

									$B++;	
						} 
					else
						{ 

						}	
return 	$B++;					
			
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function boolEtatPeripherique2($category,$stat_verif,$supervised,$code_error,$message,$categorieCassette)
{
$B=0;	
			    if (($stat_verif==1) && ($supervised==1)) 
						{           
							$B++;		
						}			  
					else if (($stat_verif==0) && ($supervised==1)) 
						{           

								
						} 
					else
						{ 

						}	
return 	$B++;					
			
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function boolStatGAB($service,$atm,$table,$cmd,$stat_verif,$categorie,$libelle_service)
{

    $V=0;
    $V2=0;

    foreach($stat_verif as $cle2 => $valeur2)
    {
        foreach ($valeur2 as $id =>  $Etat)
        {
            //echo "Etat : ".$Etat.'<br>';
            if(is_array($Etat))
            {
                $value_category="";
                $category="";
            }
            else
            {
                list($category, $value_category) = explode('-',  $Etat);
            }
            if (($category=='fwDevice') && 	($value_category==0 OR $value_category==6) && ($value_category<>""))
            {
                $V2++;
            }
            //echo $category .'   -     '.$value_category.'   -     '.$service.'<br>';
            //echo $service.'<br>';
            //echo $value_category.'<br>';
            if (($category=='fwDevice') && 	($value_category<>0 ) && ($value_category<>""))
            {
                $V++;
            }
            if (($category=='fwDevice') &&  ($service==10 OR $service==12 )   && 	($value_category<>0 OR  $value_category<>6) && ($value_category<>""))
            {
                $V++;
            }
            if (($category=='fwDevice') &&  ($service==10 OR $service==12 )   && 	($value_category==0 OR  $value_category==6) && ($value_category<>""))
            {
                $V=0;
            }
        }
    }

return 	array($V,$V2);			
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_utilisateur($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `email` FROM `iprc_authentification_cfg`.`new_utilisateur`
    WHERE `id_utilisateur` like '".mysqli_real_escape_string($connexion,$id)."'";

		  
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 430:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 430 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						if(preg_match('`[-_.]`',substr($row["email"],1, 1)))
								{ 
				
									return substr(strtoupper(str_replace('@iprc.ma' ,'',($row["email"]))),2);	
			
								
								}
						else
								{

									return strtoupper(str_replace('@iprc.ma' ,'',($row["email"])));
								}		
					}
			}	
		else
			{
				return "";
			}
mysqli_free_result($result);	
	}		  
		  
		mysqli_close($connexion);
		  
		  
} 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function date_different($d1, $d2){
    $d1 = (is_string($d1) ? strtotime($d1) : $d1);
    $d2 = (is_string($d2) ? strtotime($d2) : $d2);

    $diff_secs = abs($d1 - $d2);
    $base_year = min(date("Y", $d1), date("Y", $d2));

    $diff = mktime(0, 0, $diff_secs, 1, 1, $base_year);
    return array(
      "years" => date("Y", $diff) - $base_year,
      "months_total" => (date("Y", $diff) - $base_year) * 12 + date("n", $diff) - 1,
      "months" => date("n", $diff) - 1,
      "days_total" => floor($diff_secs / (3600 * 24)),
      "days" => date("j", $diff) - 1,
      "hours_total" => floor($diff_secs / 3600),
      "hours" => date("H", $diff),
      "minutes_total" => floor($diff_secs / 60),
      "minutes" => (int) date("i", $diff),
      "seconds_total" => $diff_secs,
      "seconds" => (int) date("s", $diff)
    );
  }

///////////////////////////////////////////////
function suppimerAgence($code_agence)
{
						echo 'Vous n\'avez pas le droit de supprimer cet agence';
						// $sql_3 = "DELETE FROM `new_list_agence` WHERE  `code_agence` = '".$code_agence."'";
						// echo $sql_3;
						// mysqli_query($sql_3) or die('Erreur supprimer sql_3 suppimerTerminal 2222 !<br>'.$sql_3.'<br>'.mysqli_error());	
	
}
///////////////////////////////////////////////
function suppimerTerminal($terminal)
{
    $connexion=ma_db_connexion();


    $sql = "SELECT  `id_atm` FROM `list_atm_confirmed` WHERE  `terminal` = '".mysqli_real_escape_string($connexion,$terminal)."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 431:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 431 !');
    }
    if($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $sql2="UPDATE `list_atm_confirmed` SET `terminal`= '', `state_confirm`=1,  `state`=0   WHERE  `terminal` = '".mysqli_real_escape_string($connexion,$terminal)."'";
            $result2=mysqli_query($connexion,$sql2);
            if (!$result2)
            {
                error_log("Erreur SQL 432:  ".$sql2."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 432 !');
            }
        }
        mysqli_free_result($result);
    }


    $sql5 = "SELECT  `terminal` FROM `new_list_gab_supprimer` WHERE  `terminal` = '".mysqli_real_escape_string($connexion,$terminal)."' ";
    $result5=mysqli_query($connexion,$sql5);
    if (!$result5)
    {
        error_log("Erreur SQL 433:  ".$sql5."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 433 !');
    }
    if($result5)
    {
        if(mysqli_num_rows($result5)==0)
        {
            $sql6 = " INSERT INTO `new_list_gab_supprimer` (SELECT * FROM `new_list_gab`  WHERE   `terminal` = '".mysqli_real_escape_string($connexion,$terminal)."')";
            $result6=mysqli_query($connexion,$sql6);
            if (!$result6)
            {
                error_log("Erreur SQL 434:  ".$sql6."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 434 !');
            }
        }
        mysqli_free_result($result5);
    }

    $sql_3 = "DELETE FROM `new_list_gab` WHERE  `terminal` = '".mysqli_real_escape_string($connexion,$terminal)."'";
    $result3=mysqli_query($connexion,$sql_3);
    if (!$result3)
    {
        error_log("Erreur SQL 435:  ".$sql_3."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 435 !');
    }
    mysqli_close($connexion);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_remarque2($remarque,$id_incident)
{
    $connexion=ma_db_connexion();

    $sql = "UPDATE `new_incident_gab` SET `remarque_press`= '".addslashes(mysqli_real_escape_string($connexion,$remarque))."' WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 436:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 436 !');
    }


    $sql2 = "UPDATE `new_incident_gab_ouvert` SET `remarque_press`= '".addslashes(mysqli_real_escape_string($connexion,$remarque))."' WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result2=mysqli_query($connexion,$sql2);
    if (!$result2)
    {
        error_log("Erreur SQL 437:  ".$sql2."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 437 !');
    }

    mysqli_close($connexion);

}
/////////////////////////////////////////////////////////////
function get_update_remarque_incident($id,$remarque)
{
	
echo '<input size="10"  align="center" 	onChange="javascript:modifier_remarque2(\''.$id.'\')" id="remarque'.$id.'"  name="remarque'.$id.'" type="text"   
	value="'.$remarque.'"  class="form-control input-sm">';
	 echo '<a onClick="javascript:get_annuler_update_remarque2(\''.$id.'\',\''.$remarque.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifiernumSerie($numSerie,$id)
{
    $connexion=ma_db_connexion();

    $sql1 = "UPDATE `new_list_gab` SET `numero_serie`='".mysqli_real_escape_string($connexion,$numSerie)."' WHERE  `terminal` like '".mysqli_real_escape_string($connexion,$id)."'";

    $result=mysqli_query($connexion,$sql1);
    if (!$result)
    {
        error_log("Erreur SQL 438:  ".$sql1."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 438 !');
    }

    mysqli_free_result($result);
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////
function getupdateNumSerie($id,$serie)
{
	
echo '<input size="10"  align="center" 	onChange="javascript:modifiernumSerie(\''.$id.'\')" id="numSerie'.$id.'"  name="numSerie'.$id.'" type="text"   
	value="'.$serie.'"  class="form-control input-sm">';
	 echo '<a onClick="javascript:get_annuler_update_numSerie(\''.$id.'\',\''.$serie.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 function incident_modifier_num_affectation($num_affectation,$id_incident)
{
    $connexion=ma_db_connexion();

    $sql="SELECT * FROM  `new_incident_gab`  WHERE `id_incident`  =  '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 439:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 439 !');
    }
    if ($result)
	{	
		if (mysqli_num_rows($result)>0)
			{
                while ($row = mysqli_fetch_assoc($result))
                {
                    $sql2 = "INSERT INTO `new_incident_gab_modifier`(
                    `id_incident`, 
                    `id_incident2`, 
                    `id_gab`, 
                    `date_modification`, 							
                    `date_arrete`, 
                    `date_arrete2`, 
                    `date_prise_en_charge`, 
                    `date_prise_en_charge2`, 
                    `date_rappel`, 
                    `date_rappel2`, 
                    `date_remise`, 
                    `date_remise2`, 
                    `num_affectation`, 
                    `num_affectation2`, 
                    `id_user`
                    )VALUES (
                    '', 
                    '".mysqli_real_escape_string($connexion,$id_incident)."',  
                    '".mysqli_real_escape_string($connexion,$row["id_gab"])."',NOW(),					
                    '".mysqli_real_escape_string($connexion,$row["date_arrete"])."',  
                    '".mysqli_real_escape_string($connexion,$row["date_arrete"])."',  
                    '".mysqli_real_escape_string($connexion,$row["date_prise_en_charge"])."',  					
                    '".mysqli_real_escape_string($connexion,$row["date_prise_en_charge"])."',  			
                    '".mysqli_real_escape_string($connexion,$row["date_derniere_rappel"])."',  
                    '".mysqli_real_escape_string($connexion,$row["date_derniere_rappel"])."',  
                    '".mysqli_real_escape_string($connexion,$row["date_remise"])."',  
                    '".mysqli_real_escape_string($connexion,$row["date_remise"])."',  
                    '".mysqli_real_escape_string($connexion,$row["num_affectation"])."',  
                    '".mysqli_real_escape_string($connexion,$num_affectation)."',
                    '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."')";
                    $result2=mysqli_query($connexion,$sql2);
                    if (!$result2)
                    {
                        error_log("Erreur SQL 440:  ".$sql2."  " .mysqli_error($connexion));
                        die(' ERREUR QUERY 440 !');
                    }
                }
			}
			mysqli_free_result($result);	
	}
mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_num_tiket_bcp($num_ticket,$id_incident)
{
    incident_modifier_num_affectation($num_ticket,$id_incident);
    $connexion=ma_db_connexion();
    $sql = "UPDATE `new_incident_gab` SET `num_affectation`='".mysqli_real_escape_string($connexion,$num_ticket)."' WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 441:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 441 !');
    }

    $sql2 = "UPDATE `new_incident_gab_ouvert` SET `num_affectation`= '".mysqli_real_escape_string($connexion,$num_ticket)."' WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result3=mysqli_query($connexion,$sql2);
    if (!$result3)
    {
        error_log("Erreur SQL 442:  ".$sql2."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 442 !');
    }

    $sql1 = "UPDATE `new_intevention_incident` SET `num_affectation`='".mysqli_real_escape_string($connexion,$num_ticket)."' WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result1=mysqli_query($connexion,$sql1);
    if (!$result1)
    {
        error_log("Erreur SQL 443:  ".$sql1."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 443 !');
    }

    $sql1temp = "UPDATE `new_intevention_incident_tmp` SET `num_affectation`='".mysqli_real_escape_string($connexion,$num_ticket)."' WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result2=mysqli_query($connexion,$sql1temp);
    if (!$result2)
    {
        error_log("Erreur SQL 444:  ".$sql1temp."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 444 !');
    }

mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////
function get_update_num_affectation($id,$num_affectation)
{
	
echo '<input size="10"  align="center" 	onChange="javascript:modifier_num_tiket_bcp(\''.$id.'\')" id="num_tiket_abi'.$id.'"  name="num_tiket_abi'.$id.'" type="text"   
	value="'.$num_affectation.'"  class="form-control input-sm">';
	 echo '<a onClick="javascript:get_annuler_update_num_affectation2(\''.$id.'\',\''.$num_affectation.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_auto_clo($id_incident,$auto_clo,$id_gab)
{
    $connexion=ma_db_connexion();

    $sql1 = "UPDATE  `new_incident_gab`  SET   `clo_auto` =  '".mysqli_real_escape_string($connexion,$auto_clo)."' WHERE  `id_incident` = '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result=mysqli_query($connexion,$sql1) ;
    if (!$result)
    {
        error_log("Erreur SQL 445:  ".$sql1."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 445 !');
    }

    $sql2 = "UPDATE  `new_incident_gab_ouvert`  SET   `clo_auto` =  '".mysqli_real_escape_string($connexion,$auto_clo)."' WHERE  `id_incident` =  '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result2=mysqli_query($connexion,$sql2) ;
    if (!$result2)
    {
        error_log("Erreur SQL 446:  ".$sql2."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 446 !');
    }

mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_adresse_ip2($adresse_ip,$id)
{
    $connexion=ma_db_connexion();
    $sql1 = "UPDATE `new_list_gab` SET `ip_adresse_gab`= '".mysqli_real_escape_string($connexion,$adresse_ip)."' WHERE  `terminal` like '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql1) ;
    if (!$result)
    {
        error_log("Erreur SQL 447:  ".$sql1."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 447 !');
    }

    mysqli_close($connexion);
}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_nom_gab2($nom_gab,$id)
{
    $connexion=ma_db_connexion();
    $sql1 = "UPDATE `new_list_gab` SET `nom_gab`= '".mysqli_real_escape_string($connexion,$nom_gab)."' WHERE  `terminal` like '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql1) ;
    if (!$result)
    {
        error_log("Erreur SQL 448:  ".$sql1."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 448 !');
    }
    mysqli_close($connexion);
}

/////////////////////////////////////////////////////////////
function get_update_adresse_ip($id,$adresse_ip)
{
    echo '<input size="10"  align="center" 	onChange="javascript:modifier_adresse_ip2(\''.$id.'\')" id="adresse_ip'.$id.'"  name="adresse_ip'.$id.'" type="text"   
	value="'.$adresse_ip.'"  class="form-control input-sm">';
    echo '<a onClick="javascript:get_annuler_update_adresse_ip2(\''.$id.'\',\''.$adresse_ip.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}
/////////////////////////////////////////////////////////////
function get_id_atm_forme($id)
{
	if($id==0){return '---';}else{return $id;}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function suiviListeGAB($terminal,$page)
{
    include "languages/" . $_SESSION['lang'] . ".php";
    $description='description';
    if($_SESSION['lang'] == 'fr')
    {
        $description='description_fr';
    }
    $connexion=ma_db_connexion();

    if($terminal=="")
    {
        $SQL1 = "SELECT `terminal`, `id_terminal_xfs`, `cdf`, `date_installation`, `gestion`, `nom_gab`, atm_profile.".$description." as profil ,
		`ip_adresse_gab`, `type_gab`, `code_bank`,`code_group`, `code_succursale`, `code_agence`, `libelle_agence`, 
		`adresse_gab`, `id_fournisseur`, `ville`, `id_activation`, `id_utilisateur` FROM `new_list_gab` , atm_profile
		WHERE new_list_gab.id_profil= atm_profile.id_profile ORDER BY `terminal` ASC";
        $page = new Pagination($SQL1, 15);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL = $page->req();
    }
    else
    {
        $SQL = "SELECT `terminal`, `id_terminal_xfs`, `cdf`, `date_installation`, `gestion`, `nom_gab`, atm_profile.".$description." as profil ,
		`ip_adresse_gab`, `type_gab`, `code_bank`, `code_group`, `code_succursale`, `code_agence`, `libelle_agence`, 
		`adresse_gab`, `id_fournisseur`, `ville`, `id_activation`, `id_utilisateur` FROM `new_list_gab` , atm_profile 
        WHERE (new_list_gab.id_profil= atm_profile.id_profile AND	
        (trim(`terminal`) like '".mysqli_real_escape_string($connexion,$terminal)."' 	
		OR UPPER(`nom_gab`) like '%".strtoupper(mysqli_real_escape_string($connexion,$terminal))."%' ))                    
        ORDER BY `terminal` DESC";
    }

    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 449:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 449 !');
    }
    if ($result)
	{		
	    echo '<table class="table table-responsive-sm table-hover table-outline mb-0">
            <thead class="thead-light">
                <tr>
                    <th class="text-center">ID</th>
                    <th class="text-center">'.$lang['atm_id'].'</th>
                    <th class="text-center">'.$lang['atm_name'].'</th>
                    <th class="text-center">IP</th>
                    <th class="text-center">'.$lang['type_gab'].'</th>                                                                                          
                    <th class="text-center">'.$lang['ville'].'</th>
                    <th class="text-center">'.$lang['atm_profil'].'</th>
                    <th  class="text-center">'.$lang['modifier'].'</th>
                    <th  class="text-center"></th>
                </tr>
            </thead>
            <tbody>';
	    if(mysqli_num_rows($result)>0)
	    {
	        $i=1;
	        while ($row = mysqli_fetch_assoc($result))
            {
                echo '<tr>
                    <td class="text-center">'.$row["id_terminal_xfs"].'</td>
                    <td class="text-center">'.$row["terminal"].'</td>
                    <td class="text-center">'.$row["nom_gab"].'</td>
                    <td class="text-center">'.$row["ip_adresse_gab"].'</td>
                    <td class="text-center">';get_select_constructeur_gab($row["type_gab"]);echo '</td>                                           
                    <td class="text-center">'.$row["ville"].'</td>
                    <td class="text-center">'.$row["profil"].'</td>
                    <td class="text-center">
                        <a tabindex="-1"  data-toggle="modal" onClick="javascript:getModifierGAB(\''.$row["terminal"].'\')" data-target="#moduleModifierGAB"><span class="cil-people" title="'.$lang['modifier'].'"></span></a> 
                   </td>
                    <td class="text-center">
                        <span class="c-icon cil-triangle" title="'.$lang['supprimer'].'" onclick="suppimerTerminal(\''.$row["terminal"].'\')"</span> 
                    </td>
                </tr>';
                $i++;
            }
	    }
	    if(($terminal=="") || ($terminal=="%"))
	    {
            echo '<tr><td colspan="9" class="text-center">';
            echo   '<ul class="pagination justify-content-center">'.$lien.'</ul>';
            echo   '<div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>';
            echo'</td></tr>';
	    }
	    echo '</tbody></table>';
	    mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function suiviListeAgence($code_agence,$page)
{
    $connexion=ma_db_connexion();

    if($code_agence=="")
    {
        $SQL1 = "SELECT `code_agence`, `nom_agence`, `ville`, `id_direction`  FROM `new_list_agence` 
        ORDER BY `code_agence` ASC";
        $page = new Pagination($SQL1, 15);
        $total = $page->getCount('Affichage des lignes  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL = $page->req();
    }
    else
    {
        $SQL1 = "SELECT `code_agence`, `nom_agence`, `ville`, `id_direction`  FROM `new_list_agence` 
        WHERE (trim(`code_agence`) like '".mysqli_real_escape_string($connexion,$code_agence)."')                    
        ORDER BY `code_agence` ASC";
    }
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 450:  ".$SQL1."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 450 !');
    }
    if ($result)
	{		
	    echo '<div class="col-lg-12">	
		    <!-- /.panel -->
                <div class="panel panel-info">
                    <div class="panel-heading" style="background-color:#e7722c;font-size:18px;color:#fff;line-height: 80%;">
                        <i class="fa fa-share-alt"></i> Suivi agence
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover table-striped">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Code Agence</th>
                                                <th>Nom Agence</th>
                                                <th>Ville</th>
                                                <th>Région</th>                                                    
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>';
	    if(mysqli_num_rows($result)>0)
	    {
	        $i=1;
	        while ($row = mysqli_fetch_assoc($result))
            {
                $region=get_info_region_gab($row["id_direction"]);
                echo '   <tr>
                    <td>'.$i.'</td>
                    <td>'.$row["code_agence"].'</td>
                    <td>'.$row["nom_agence"].'</td>
                    <td>'.$row["ville"].'</td>
                    <td>'.$region[0].'</td>
                    <td>';
                    echo '<a tabindex="-1"  data-toggle="modal" onClick="javascript:getModifierAgence(\''.$row["code_agence"].'\')" data-target="#moduleModifierAgence"><strong style="font-size:18px;font-weight:bold;color:#FF0040" ><i class="fa  fa-pencil-square-o" title=Modifier Agence"></i></strong></a> 
				    <a   title="Supprimer" href="javascript:suppimerAgence(\''.$row["code_agence"].'\')"><strong style="font-size:18px;font-weight:bold;color:#FF0040" ><i class="fa fa-close" ></i></strong></a> ';
                    echo '</td>
                    </tr>';
                    $i++;
            }
	    }
											
	    if(($code_agence=="") || ($code_agence=="%"))
	    {
	        echo'<tr><td colspan="7" align="center">';
	        echo   '<ul class="pagination"><li>'.$lien.' </li></ul>';
	        echo   '<div class="alert" style="background-color:#fabf8f;font-size:18px;color:#fff;line-height: 80%;"><strong>'.$total.'</strong></div>';
	        echo'</td>
			</tr> ';
	    }
											
	    echo '</tbody>
                                        </table>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.col-lg-4 (nested) -->
                                <div class="col-lg-8">
                                    <div id="morris-bar-chart"></div>
                                </div>
                                <!-- /.col-lg-8 (nested) -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-8 -->

				';	
mysqli_free_result($result);	
}
mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_etat_type_appel($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `libelle` FROM `new_type_appel` WHERE id_etat = '".mysqli_real_escape_string($connexion,$id)."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 451:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 451 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["libelle"];  	
					}
			}	
		else
			{
				return "";
			}
	mysqli_free_result($result);	
	}
mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getinfoATM($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `new_list_gab`.`terminal`, `new_list_gab`.`ip_adresse_source`, `new_list_gab`.`nom_gab`, `new_list_gab`.`date_ajout`,
    `new_filiale`.`nom_filiale` as `nom_filiale` FROM `new_list_gab`,`new_filiale` WHERE `new_list_gab`.`code_group`=`new_filiale`.`id_filiale` 
    AND `new_list_gab`.id_terminal_xfs = '".mysqli_real_escape_string($connexion,$id)."' ";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 452:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 452 !');
    }
    if ($result)
	{
	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                return $row["terminal"]."---".$row["ip_adresse_source"]."---".$row["nom_gab"]."---".$row["date_ajout"]."---".$row["nom_filiale"];
            }
		}
		else
        {
            return " ---- ---- ---- ";
        }
		mysqli_free_result($result);		
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getfilialATM($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `code_group` FROM `new_list_gab` WHERE id_terminal_xfs = '".mysqli_real_escape_string($connexion,$id)."' ";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 453:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 453 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["code_group"];
            }
        }
        else
        {
            return "";
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getfilialTerminal($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `code_group` FROM `new_list_gab` WHERE terminal = '".mysqli_real_escape_string($connexion,$id)."' ";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 454:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 454 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["code_group"];
            }
        }
        else
        {
            return "";
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_post_affect_ATM($if_filial_atm)
{
    $connexion=ma_db_connexion();
    $arrayWork_post=array();
    $arrayWork_post_name=array();

    $sql = "SELECT  `id_post`,`name_poste`,`id_filiale` FROM `work_post`  ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 455:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 455 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                //$arrayWork_post=array($row["id_post"],$row["name_poste"],$row["id_filiale"]);
                $arrayWork_post[$row["id_post"]]=explode(',',$row["id_filiale"]);
                $arrayWork_post_name[$row["name_poste"]]=explode(',',$row["id_filiale"]);
                //$arrayIdfil= ;

            }
        }

        mysqli_free_result($result);
    }


    $id_postefinal=0;
    $name_postefinal="";
    foreach ($arrayWork_post as $key=>$value )
    {
        foreach ($value as $key2=>$value2 )
        {
            if($value2==$if_filial_atm)
            {
                $id_postefinal=$key;
            }
        }
    }
    foreach ($arrayWork_post_name as $key=>$value )
    {
        foreach ($value as $key2=>$value2 )
        {
            if($value2==$if_filial_atm)
            {
                $name_postefinal=$key;
            }
        }
    }

   // echo " // Id work post : ".$key2."<br/>";
    //echo " // Value Filiale : ".$value2."<br/>";
    //echo "Id Poste Affecter :".$id_postefinal."<br/>";
    mysqli_close($connexion);
    return $id_postefinal."---".$name_postefinal;


}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getLastConnexionATM_toServer($idAtm)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT date_connect  FROM `hist_connect` WHERE `hist_connect`.`id_atm` = '".mysqli_real_escape_string($connexion,$idAtm)."' ORDER BY id_con DESC LIMIT 1";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 456:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 456 !');
    }
    if($result)
    {
	    if(mysqli_num_rows($result)>0)
	    {
		    while ($row = mysqli_fetch_assoc($result))
            {
                return $row["date_connect"];
            }
	    }
	    else
	    {
		    return "0000-00-00 00:00:00";
	    }
		mysqli_free_result($result);
    }
mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getLibelleATM($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `nom_gab` FROM `new_list_gab` WHERE id_terminal_xfs = '".mysqli_real_escape_string($connexion,$id)."' ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 457:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 457 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["nom_gab"];  	
					}
			}	
	else
	{
		return "";
	}
		mysqli_free_result($result);	
	}

	else
	{
		return "";
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getinfoIPATMConfirmed($id)
{
    $connexion=ma_db_connexion();

$sql = "SELECT  `ip_adress`,`work_station_name` FROM `list_atm_confirmed` WHERE  `id_atm` = '".mysqli_real_escape_string($connexion,$id)."' ";


    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 458:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 458 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return	array($row["ip_adress"],
                    $row["work_station_name"]);

            }

        }

    else
        {
            return array('','');
        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getIPATMConfirmed($id)
{
    $ip_adress="";
    $connexion=ma_db_connexion();
    $sql = "SELECT  `ip_adresse_source` FROM `new_list_gab` WHERE  `terminal` = '".mysqli_real_escape_string($connexion,$id)."' ";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 77777:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 77777 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            $ip_adress= $row["ip_adresse_source"];
        }

        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return $ip_adress;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nbr_action_alerte($id)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  count(`id_action`) as NB_action FROM `new_actions_alertes` WHERE `id_alertes` = '".mysqli_real_escape_string($connexion,$id)."' ";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 459:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 459 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                return $row["NB_action"];
            }
		}
		else
		{
		    return 0;
		}
		mysqli_free_result($result);
	}	
	mysqli_close($connexion);
	
}

///////////////////////////////////////////////
function suppimerAction($id_action,$id_alerte)
{
	if (get_nbr_action_alerte($id_alerte)>1)
			{
                $connexion=ma_db_connexion();

                $sql_2 = "DELETE FROM `new_actions_alertes` WHERE  `id_action` = '".mysqli_real_escape_string($connexion,$id_action)."'";
                $result=mysqli_query($connexion,$sql_2);
                if (!$result)
                {
                    error_log("Erreur SQL 460:  ".$sql_2."  " .mysqli_error($connexion));
                    die(' ERREUR QUERY 460 !');
                }
				mysqli_close($connexion);
			}
		else
			{
				   echo'<div class="col-sm-12" >
					<div class="alert alert-danger"> <strong>Vous avez pas le droit de supprimer cette action</strong></div>
				  </div>';		
			}
}
///////////////////////////////////////////////
function suppimerAlerte($alerte)
{
	
suppimerAlerteOuvert($alerte);
    $connexion=ma_db_connexion();

    $sql_2 = "DELETE FROM `new_actions_alertes` WHERE  `id_alertes` = '".mysqli_real_escape_string($connexion,$alerte)."'";
    $result=mysqli_query($connexion,$sql_2);
    if (!$result)
    {
        error_log("Erreur SQL 461:  ".$sql_2."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 461 !');
    }

    $sql_3 = "DELETE FROM `new_alertes` WHERE  `id_alerte` = '".mysqli_real_escape_string($connexion,$alerte)."'";
    $result=mysqli_query($connexion,$sql_3);
    if (!$result)
    {
        error_log("Erreur SQL 462:  ".$sql_3."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 462 !');
    }

    mysqli_close($connexion);


}

function change_state($id_atm)
{
    $connexion=ma_db_connexion();

    $SQL = "UPDATE `list_atm_confirmed` SET  `state` = 1 WHERE  `id_atm` = ".mysqli_real_escape_string($connexion,$id_atm)." ";
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 465:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 465 !');
    }

mysqli_close($connexion);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDownloadFileGAB($id_atm, $terminalID,$idprivilege)
{
    include "../languages/" . $_SESSION['lang'] . ".php";
    $val=get_name_terminal_gag($id_atm);
    echo '<div  class="modal-dialog modal-xl" role="document" style="max-width: 1700px;">		
		<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;" >					
	    <!-- Modal Header -->
		<div class="modal-header">
			<h4 class="modal-title">'.$lang["down_file"].' : ' . $terminalID . ' <i class="fa fa-minus"></i> '.$val[1].'</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
		</div>	
        <br>
        <form id="form_insert_upload_execution" role="form" method="post" class="form-horizontal">
            <div class="card" style="border-radius:33px;width: 95%; margin:0 auto; margin-bottom: 20px;" >	
                <div class="card-header" style="border-top-left-radius:31px;border-top-right-radius:31px"><div class="card-title">Send download commands </div></div>
                <div class="card-body">
                    
                    <div class="mb-3 row">
               
                       <label for="id_ATM" class="col-sm-2 col-form-label">Files path :</label>
                        <div class="col-sm-6">
                            <input type="text" id="chemin_file" class="form-control required" name="chemin_file" value="C:/Ivision/configuration/" placeholder="Chemin fichier ..." required="required">
                        </div>
                        <div class="col-sm-4">
                            <button type="button" class="col-sm-2 btn btn-danger" style="float: right;" onclick="insert_upload_execution(\''.$id_atm.'\')" >'.$lang["confir"].'</button>    
                        </div>
                    </div>
                </div>
            </div>
        </form>
		    <div class="modal-footer">
                <button  type="button"  class="btn btn-block btn-dark c-loading-button"  onclick="javascript:reloadDiv_upload_execution(\''.$id_atm.'\',\''.$idprivilege.'\');" >'.$lang['reload'].' <i id="btn_reload_cmd_ATM" ></i></button>
            </div>
    
		    <!-- Modal body -->
			<div class="modal-body">	
				<form class="form-horizontal" role="form">
					<div class="container col-md-12">
						<div class="row"></div>
                    </div>
                    <div>
						<table class="table table-responsive-sm table-bordered table-striped table-sm">
							<thead>
                                <tr>
                                    <th>#</th>
                                    <th>Download path </th>                                     
                                    <th>Date after download</th>                                       
                                    <th>number of files</th>                                         
                                    <th>Upload Content Code</th>                                         
                                    <th>Download status </th>                                         
                                    <th>Detail</th>                                         
                                </tr>
							</thead>';

                                getall_upload_content($id_atm,$idprivilege);
			            echo '</table>					
			        </div>		
				</form> 
			    </div>																																																					
				<!-- Modal footer -->
                <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>																																		
	        </div>
</div>';
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function insert_form_upload_execution($id_atm,$path_upload)
{
    $okMessage ="Commande insérer";
    $errorMessage = "Commande non insérer";
    $connexion=ma_db_connexion();

    $path_upload = addslashes($path_upload);

    if(!empty($id_atm) && !empty($path_upload))
    {
        if(verf_atm_upload_execution($id_atm))
        {
            $SQL1 = "UPDATE `upload_execution` SET  `date_send_upload` =  now() ,`id_cmd` =  55 , 
            `user_exec` =  '" . mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur']) . "' ,
            `state` =  1 ,`state_upload` =  1 ,`path_upload` =  '" . addslashes($path_upload) . "' WHERE `id_atm` = '" . mysqli_real_escape_string($connexion,$id_atm). "'";
        }
        else
        {
            $SQL1 = "INSERT INTO upload_execution (" .
            " id_atm, date_send_upload, id_cmd, user_exec,state,state_upload,path_upload" .
            ") VALUES (  " . "'" . mysqli_real_escape_string($connexion,$id_atm). "',  now() ,'55',
			" . "'" . mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur']) . "', '1', '1' ," . "'" . addslashes($path_upload) . "') ;";
        }

        //var_dump($SQL1);die();
        mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
        $result=mysqli_query($connexion,$SQL1);
        if ($result)
        {
            $responseArray = array('type' => 'success', 'message' => $okMessage);
        }
        else
        {
            error_log("Erreur SQL 464:  ".$SQL1."  ".mysqli_error($connexion));
            $responseArray = array('type' => 'danger', 'message' => $errorMessage." Erreur SQL 464".mysqli_error($connexion));
        }
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Path vide ou gab incorrect');
    }
// todo: json envois form

    mysqli_close($connexion);
    $encoded = json_encode($responseArray);
    header('Content-Type: application/json');
    echo $encoded;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function verf_atm_upload_execution($id_atm)
{
    $connexion=ma_db_connexion();
    $bool=false;
    $SQL = "SELECT id_atm FROM upload_execution WHERE id_atm='".mysqli_real_escape_string($connexion,$id_atm)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 459:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 459 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $bool=true;
        }
        else
        {
            $bool=false;
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return $bool;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_remarque_incident_pres($id)
{
    $connexion=ma_db_connexion();
    $SQL = "SELECT `remarque_press`  FROM  `new_incident_gab` WHERE   `new_incident_gab`.`id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    echo '<div class="modal-dialog">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title"> Remarque Prestataire </h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>					
																																	
												<!-- Modal body -->
												<div class="modal-body">';
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 463:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 463 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {

            while ($row = mysqli_fetch_assoc($result))
            {
                $remarque_press= $row["remarque_press"]   ;
                echo'<div class="list-group">
                <h6 class="list-group-item list-group-item-action list-group-item-light">
                    <div class="d-flex w-100 justify-content-between">
                        <p class="mb-1"> '.$remarque_press.'</p>
                    </div>
                </h6>
                   
                </div>';
            }

        }
        mysqli_free_result($result);
    }
    echo'</div>																										
    <!-- Modal footer -->
    <div class="modal-footer">
    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
    </div>
                                                    
    </div>
    </div>';
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function DownloadFileATM($id_atm,$content,$searchIDs)
{
    $connexion=ma_db_connexion();
    $sql = "UPDATE `upload_contents` SET  `state_approbation` = 1 WHERE  `id_atm` = '".mysqli_real_escape_string($connexion,$id_atm)."' 
    AND id_content in( ".mysqli_real_escape_string($connexion,$searchIDs).")  ";

    $result = mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 33333333:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 33333333 !'.$sql);
    }
    mysqli_free_result($result);

    $sql1 = "UPDATE `upload_execution` SET  `state_upload` = 3 WHERE  `id_atm` = '".mysqli_real_escape_string($connexion,$id_atm)."' ";


  $result1 = mysqli_query($connexion,$sql1);
    if (!$result1)
    {
        error_log("Erreur SQL 33333331:  ".$sql1."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 33333331 !');
    }
    mysqli_free_result($result1);
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////
function liste_admin_adresse_messagerie($titre="")
{
    $connexion=ma_db_connexion();
    if($titre=="")
    {
        $titre="%";
    }

    $SQL1 = "SELECT `id_mail`, `titre`,  `niveau_messagenie`, `adresse_mail_aa`, `adresse_mail_cc`,`corps_messagerie`, `id_user` FROM `new_mail_messagerie` 
	WHERE  `id_mail` LIKE '".mysqli_real_escape_string($connexion,$titre)."'  
     ORDER BY `niveau_messagenie`,`id_mail` ASC ";
    $page = new Pagination($SQL1, 10);
    $total = $page->getCount('Affichage des lignes  %d - %d  ( total  : %d )');
    $lien = $page->liens(5);
    $SQL = $page->req();
    echo '<table class="display table table-bordered" style="font-size:11px;font-weight:bold;text-align: center;width:100%;border-color: #FFFFFF;" >
         <tr>         
          <th class="text-warning"> ';

    // echo '<button class="btn btn-primary btn-xs" data-toggle="modal" data-target="#ajouter_adresse_mail"> Ajouter</button>';

    echo '</th>
          <th colspan=9></th>
          </tr>';
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");

    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 33333332:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 33333332 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            echo ' <tr>
              <th style="padding: 2px;text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;">#</th>
              <th style="padding: 2px;text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;">Titre</th>
              <th style="padding: 2px;text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;">Type Mail</th>
              <th style="padding: 2px;text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;">AA</th>
              <th style="padding: 2px;text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;">CC</th>
              <th style="padding: 2px;text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;">Message</th>
              <th style="padding: 2px;text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;">Utilisateur</th>
              <th style="padding: 2px;text-align: center;font-size:10pt;color: #fff;background-color: #e7722c;"></th>
            </tr>';

            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<tr>
                 <td>'.$row["id_mail"].'</td>
                 <td>'.$row["titre"].'</td>
                 <td>'.$row["niveau_messagenie"].'</td>
                 <td><div class="col-sm-10"><textarea style="font-size:11px;font-weight:bold;" class="form-control" id="remarque" name="remarque" rows="3" col="3">'.$row["adresse_mail_aa"].'</textarea></div></td>
                 <td><div class="col-sm-10"><textarea style="font-size:11px;font-weight:bold;"  class="form-control" id="remarque" name="remarque" rows="3">'.$row["adresse_mail_cc"].'</textarea></div></td>
                 <td style="font-size:11px;font-weight:bold;">'.substr($row["corps_messagerie"],0, 50).'...</td>
                 <td>'.get_utilisateur($row["id_user"]).'</td>
        
                <td>';
                echo ' <div class="dropdown clearfix">
                    <button class="btn btn-danger" data-toggle="dropdown" style="font-size:9px;">
                   Action
                   <span class="caret"></span>
                  </button>
                    <ul class="dropdown-menu   pull-right" role="menu" aria-labelledby="dropdownMenu"> ';
                if (verif_habilitation($_SESSION['habilitation_action'],6)==true)
                {
                    echo' <li><a tabindex="-1"  data-toggle="modal" onClick="javascript:detailler_email_consigne(\''.$row["id_mail"].'\')"   data-target="#detailler_email"><span class="cil-list"></span>  Détail </a></li> ';
                }

                //  <li><a href="javascript:supprimer_action_cinematique(\''.mysql_result($result,$i,'id_pro').'\',\''.$id_cinematique.'\')">Supprimer</a></li>';
                //  echo'  <li><a href="javascript:supprimer_email_consigne(\''.mysql_result($result,$i,'id_pro').'\')"><span class="c-icon cil-triangle"></span>   Supprimer</a></li>';

                echo '</ul>
                            </div>';
                echo '</td>
                </tr>';

            }
            echo'<tr><td colspan="11" align="center">';
            echo   '<ul class="pagination"><li>'.$lien.' </li></ul>';
            echo   '<div class="well well-sm" style="background:#eeeeee;color:#3a1d19"><strong>'.$total.'</strong></div>';
            echo'</td></tr>';
        }
        mysqli_free_result($result);
    }
    echo '</table>  ';
    mysqli_close($connexion);

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_device_status($IdATMHisto,$vacation_date)
{

    $connexion=ma_db_connexion();

    $sql="SELECT `id_vacation_alm`,`id_vacation_bcr`, `id_vacation_cam`, `id_vacation_cdm`, `id_vacation_ceu`, 
    `id_vacation_chk`, `id_vacation_cim`, `id_vacation_crd`, `id_vacation_dep`, `id_vacation_idc`,
    `id_vacation_ipm`, `id_vacation_pin`, `id_vacation_ptr`, `id_vacation_siu`, `id_vacation_ttu`, `id_vacation_vdm`,`vacation_date`, `name_file`	   
    FROM `hist_vacations`
    WHERE `hist_vacations`.`id_atm` = '".mysqli_real_escape_string($connexion,$IdATMHisto)."'  AND if_load = '1' ";

    if(!empty($vacation_date))
    {
        $sql = $sql." AND `vacation_date` ='".mysqli_real_escape_string($connexion,$vacation_date)."' ";

    }
    $sql= $sql. "ORDER BY `id_global_vacation` DESC LIMIT 1";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL X4D5VB10 :  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY X4D5VB10 !');
    }


    if ($result)
    {
        // Verifications Services autorisé.
        $serviceATMAutorise = explode(',', get_list_service_atm($IdATMHisto));
        foreach($serviceATMAutorise as $service)
        {
            $tableService[] = $service;
        }
        if(mysqli_num_rows($result)>0)
        {
            $state_all_device = true;
            while ($row = mysqli_fetch_assoc($result))
            {

                $service = 4;
                if (in_array($service, $tableService))//Verifications Services autorisation services
                {
                    $state_all_device =  device_incident($service,$IdATMHisto,$row["id_vacation_cdm"],'vacations_CDM','xfs_errors_CDM','CDM',$row["vacation_date"],'WFS_INF_CDM_STATUS',$row["name_file"]);
                    if (!$state_all_device){break;}
                }

                $service = 7;
                if (in_array($service, $tableService))//Verifications Services autorisation services
                {
                    $state_all_device =  device_incident( $service, $IdATMHisto, $row["id_vacation_cim"], 'vacations_CIM', 'xfs_errors_CIM', 'CIM', $row["vacation_date"], 'WFS_INF_CIM_STATUS', mysqli_real_escape_string($connexion, $row["name_file"]));
                    if (!$state_all_device){break;}
                }
                $service = 12;
                if (in_array($service, $tableService))//Verifications Services autorisation services
                {
                    $state_all_device =  device_incident( $service, $IdATMHisto, $row["id_vacation_pin"], 'vacations_PIN', 'xfs_errors_PIN', 'PIN', $row["vacation_date"], 'WFS_INF_PIN_STATUS', mysqli_real_escape_string($connexion, $row["name_file"]));
                    if (!$state_all_device){break;}
                }
                $service = 13;
                if (in_array($service, $tableService))//Verifications Services autorisation services
                {
                    $state_all_device =  device_incident( $service, $IdATMHisto, $row["id_vacation_ptr"], 'vacations_PTR', 'xfs_errors_PTR', 'PTR', $row["vacation_date"], 'WFS_INF_PTR_STATUS', mysqli_real_escape_string($connexion, $row["name_file"]));
                    if (!$state_all_device){break;}
                }
                $service = 10;
                if (in_array($service, $tableService))//Verifications Services autorisation services
                {
                    $state_all_device =  device_incident( $service, $IdATMHisto, $row["id_vacation_idc"], 'vacations_IDC', 'xfs_errors_IDC', 'IDC', $row["vacation_date"], 'WFS_INF_IDC_STATUS', mysqli_real_escape_string($connexion, $row["name_file"]));
                    if (!$state_all_device){break;}
                }
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return $state_all_device;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function device_incident($service,$atm,$id_vacation,$libelle_vacation,$libelle_xfs_errors,$libelle_service,$vacation_date,$commande,$name_file)
{
    $state_all_device = true;
    if(empty($id_vacation)){$EtatPeripheral="";}
    else{$EtatPeripheral=getReturnEtatPeripheral($libelle_vacation,$atm,$libelle_service,$id_vacation,$vacation_date,$name_file);}
    if(is_array($EtatPeripheral))
    {
        $etatStatBool=boolStatGAB($service,$atm,$libelle_xfs_errors,$commande,$EtatPeripheral,'',$libelle_service);
        // echo "<pre>";print_r($EtatPeripheral);echo "</pre>";
        if ($etatStatBool[0]<>0) // Cas 1 afficher image incident GAB
        {
            $state_all_device = false;
        }
    }
    return $state_all_device;
}