<?php

/************************************************************************************************************/
function getDetailPeripheralStatusBCR($ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{

    $connexion=ma_db_connexion();

    $sql = "SELECT `date_vacation`, `vacations_BCR`.`fwDevice` as Device, `vacations_BCR`.`fwBCRScanner` as BCRScanner, `vacations_BCR`.`dwGuidLights` as GuidLights, `vacations_BCR`.`dwGuidLights_WFS_BCR_GUIDANCE_BCR` as GuidLights_WFS_BCR_GUIDANCE_BCR,
            `vacations_BCR`.`wDevicePosition` as DevicePosition, `vacations_BCR`.`usPowerSaveRecoveryTime` as PowerSaveRecoveryTime, `vacations_BCR`.`wAntiFraudModule` as  AntiFraudModule
                FROM `".$tableVacation."` 
                WHERE `id_atm` ='".$ATM."'
                AND `logical_name`   ='".$logical_name."'";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 14 alm :  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 14 !');
    }
					/***************************************************/
    if ($result)
    {
        $k=0;
        if(mysqli_num_rows($result)>0)
        {

            $j = 0;
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Détails  peripheral <strong style="font-size:18px;font-weight:bold;color:#e7722c;" >: '.$nameVacation.' ('.$row["date_vacation"].')</strong></h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">
												<div class="accordion" id="accordionExample275">';
                $k++;

                $EtatPeripheral =     array("Device|fwDevice-".$row["Device"],"BCRScanner|fwBCRScanner-".$row["BCRScanner"],
                    "GuidLights|dwGuidLights-".$row["GuidLights"],"GuidLights_WFS_BCR_GUIDANCE_BCR|dwGuidLights_WFS_BCR_GUIDANCE_BCR-".$row["GuidLights_WFS_BCR_GUIDANCE_BCR"],
                    "DevicePosition|wDevicePosition-".$row["DevicePosition"],
                    "PowerSaveRecoveryTime|usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTime"],"AntiFraudModule|wAntiFraudModule-".$row["AntiFraudModule"]);


                if ($module==2)
                {
                    // getModuleDeclaration($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$category,$code_error,$logical_name,$paramAffichage);
                }

                if ($module==1)
                {
                    echo '								
                                        
                          <div class="card z-depth-0 bordered">
                                <div class="card-header" id="heading'.$j.'" style="background-color:#e7722c;">
                                  <h5 class="mb-0">
                                    <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse'.$j.'"
                                      aria-expanded="true" aria-controls="collapse'.$j.'" >
                                      <strong style="font-size:18px;font-weight:bold;color:#FFFFFF;" >'.$row["logical_name"].' </strong>
                                      </button>
                                  </h5>
                                </div>
                                <div id="collapse'.$j.'"';if ($j==0){ echo  'class="collapse in"';} else {echo  'class="collapse"';} echo 'aria-labelledby="heading'.$j.'" data-parent="#accordionExample275">
                                        <div class="card-body" style="padding-left: 50px;background-color:#f8f8f8;" >';

                    get_statut_gab('xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,'',$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$module,$row["logical_name"],$paramAffichage);

                    echo'<br></div>
                                                                                            </div>											
                                                                                  </div>';

                }
                $j++;
            }
        }
        mysqli_free_result($result);
    }

                echo '		</div>
                         </div>
                                                    
                <!-- Modal footer -->
                         <div class="modal-footer">
                                 <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                         </div>
                                                    
                     </div>
                </div>';
    mysqli_close($connexion);
}