<?php

include("userlib.php");
$requestMethod = $_SERVER['REQUEST_METHOD'];

switch($requestMethod) {

    case 'POST':

        if(empty($_POST['user'])){$user="";}else{$user=$_POST['user'];}
        if(empty($_POST['mdp'])){$mdp="";}else{$mdp=$_POST['mdp'];}


        if (($user <> "")&&(verif_user($user,$mdp)==true)) {

            require_once('JWT/jwt.php');

            /**
             * Create some payload data with user data we would normally retrieve from a
             * database with users credentials. Then when the client sends back the token,
             * this payload data is available for us to use to retrieve other data
             * if necessary.
             */
            $userId=get_id_user($_POST['user']);

            /**
             * Uncomment the following line and add an appropriate date to enable the
             * "not before" feature.
             */
            // $nbf = strtotime('2021-01-01 00:00:01');

            /**
             * Uncomment the following line and add an appropriate date and time to enable the
             * "expire" feature.
             */

            $iat = time();
            $exp = time() + (1*60);
            $iss = "192.168.1.10";



            // Get our server-side secret key from a secure location.
            $serverKey = '5f2b5cdbe5194f10b3241568fe4e2b24';

            // create a token
            $payloadArray = array();
            $payloadArray['userId'] = $userId;
            $payloadArray['usermail'] = $user;
            if (isset($iat)) {$payloadArray['iat'] = $iat;}
            if (isset($exp)) {$payloadArray['exp'] = $exp;}
            if (isset($iss)) {$payloadArray['iss'] = $iss;}
            $token = JWT::encode($payloadArray, $serverKey);

            // return to caller
            $returnArray = array('token' => $token);
            $jsonEncodedReturnArray = json_encode($returnArray, JSON_PRETTY_PRINT);
            echo $jsonEncodedReturnArray;

        }
        else {
            $returnArray = array('error' => 'Invalid user ID or password.');
            $jsonEncodedReturnArray = json_encode($returnArray, JSON_PRETTY_PRINT);
            echo $jsonEncodedReturnArray;
        }

        break;

    case 'GET':

        $token = null;

        if (isset($_GET['token'])) {$token = $_GET['token'];}

        if (!is_null($token)) {

            require_once('JWT/jwt.php');

            // Get our server-side secret key from a secure location.
            $serverKey = '5f2b5cdbe5194f10b3241568fe4e2b24';

            try {
                $payload = JWT::decode($token, $serverKey, array('HS256'));
                $returnArray = array('userId' => $payload->userId);
                $returnArray['usermail'] = $payload->usermail;
                if (isset($payload->exp)) {
                    $returnArray['exp'] = date('Y-m-d H:i:s', $payload->exp);
                }
            }
            catch(Exception $e) {
                $returnArray = array('error' => $e->getMessage());
            }
        }
        else {
            $returnArray = array('error' => 'You are not logged in with a valid token.');
        }

        // return to caller
        $jsonEncodedReturnArray = json_encode($returnArray, JSON_PRETTY_PRINT);
        echo $jsonEncodedReturnArray;

        break;

    default:
        $returnArray = array('error' => 'You have requested an invalid method.');
        $jsonEncodedReturnArray = json_encode($returnArray, JSON_PRETTY_PRINT);
        echo $jsonEncodedReturnArray;
}
