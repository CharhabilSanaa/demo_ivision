<?php
function getStatusVacation($idprivilege,$service,$paramettre,$atm,$id_vacation,$libelle_vacation,$libelle_xfs_errors,$libelle_service,$vacation_date,$commande,$name_file)
{
    //echo $id_vacation;
    if(empty($id_vacation)){$EtatPeripheral="";}
    else{$EtatPeripheral=getReturnEtatPeripheral($libelle_vacation,$atm,$libelle_service,$id_vacation,$vacation_date,$name_file);}
    if(is_array($EtatPeripheral))
    {


        $etatStatBool=boolStatGAB($service,$atm,$libelle_xfs_errors,$commande,$EtatPeripheral,'',$libelle_service);

        //echo "<pre>";print_r($EtatPeripheral);echo "</pre>";
        if ($etatStatBool[0]<>0) // Cas 1 afficher image incident GAB
        {		//list($Libelle_logical, $value_logical) = explode('-',  $EtatPeripheral);
            echo' <a class="text-center dropdown-item " tabindex="-1"  data-toggle="modal" 
            onClick="javascript:getDetailPeripheralStatus(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$atm.'\',
            \''.$id_vacation.'\',
            \''.$libelle_vacation.'\',
            \''.$libelle_xfs_errors.'\',
            \''.$commande.'\',
            \''.$libelle_service.'\',
            \''.$vacation_date.'\',
            \''.$name_file.'\',
            \'\',
            \'\',
            \'\',0)"   
            data-target="#detailPeripheralStatus"> <img width="30" height="30"	src="image_ivision_gab/'.$libelle_service.'_ERROR.png" title="'.$libelle_service.'"/>  </a>';
            // .getStatusColor(0);
        }
        else
        {
            if ($etatStatBool[1]<>0) // Cas 2 afficher image GAB opérationnel
            {
                echo' <a class="text-center dropdown-item " tabindex="-1"  data-toggle="modal" 
                onClick="javascript:getDetailPeripheralStatus(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$atm.'\',
                \''.$id_vacation.'\',
                \''.$libelle_vacation.'\',
                \''.$libelle_xfs_errors.'\',
                \''.$commande.'\',
                \''.$libelle_service.'\',
                \''.$vacation_date.'\',
                \''.$name_file.'\',
                \'\',
                \'\',
                \'\',1)"   
                data-target="#detailPeripheralStatus"> <img width="30" height="30"	src="image_ivision_gab/'.$libelle_service.'_UP.png" title="'.$libelle_service.'"/>   </a>';
            }
            else
            {
                //var_dump($EtatPeripheral);
                //echo "<pre>";print_r($etatStatBool);echo "</pre>";
                echo'<a class="text-center dropdown-item "> <img width="30" height="30"	src="image_ivision_gab/'.$libelle_service.'_UNSUP.png" title="'.$libelle_service.'"/> </a> ';
            }
            // echo'<br> ALM  : </strong></a>'.getStatusColor(1);
        }
    }
    else
    {
        echo' <a class="text-center dropdown-item "><img width="30" height="30"	src="image_ivision_gab/'.$libelle_service.'_UNSUP.png" title="'.$libelle_service.'"/></a> ';
    }
										
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getStatus2Vacation($idprivilege,$service,$paramettre,$atm,$id_vacation,$libelle_vacation,$libelle_xfs_errors,$libelle_service,$vacation_date,$commande,$name_file,$img,$libelleService)
{
																								
														if(empty($id_vacation)){$EtatPeripheral="";}
														else{$EtatPeripheral=getReturnEtatPeripheral($libelle_vacation,$atm,$libelle_service,$id_vacation,$vacation_date,$name_file);}												
																									
													if(is_array($EtatPeripheral))	
														{
															
														 $etatStatBool=boolStatGAB($service,$atm,$libelle_xfs_errors,$commande,$EtatPeripheral,'',$libelleService);
														 // echo $etatStatBool[0]."----".$etatStatBool[1]."<br>";
														 if ($etatStatBool[0]<>0) // Cas 1 afficher image incident GAB
																			{		//list($Libelle_logical, $value_logical) = explode('-',  $EtatPeripheral);
																					echo' <a tabindex="-1"  data-toggle="modal" 
																					onClick="javascript:getDetailPeripheralStatus(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$atm.'\',
																					\''.$id_vacation.'\',
																					\''.$libelle_vacation.'\',
																					\''.$libelle_xfs_errors.'\',
																					\''.$commande.'\',
																					\''.$libelle_service.'\',
																					\''.$vacation_date.'\',
																					\''.$name_file.'\',
																					\'\',
																					\'\',
																					\'\',0)"   
																					data-target="#detailPeripheralStatus"> <img width="30" height="30"	src="image_ivision_gab/'.$img.'_ERROR.png" title="'.$img.' '.$libelleService.'"/> </a>';
																					// .getStatusColor(0);														
																			}
																		else
																			{
																			if ($etatStatBool[1]<>0) // Cas 2 afficher image GAB opérationnel
																					{
																					echo' <a tabindex="-1"  data-toggle="modal" 
																					onClick="javascript:getDetailPeripheralStatus(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$atm.'\',
																					\''.$id_vacation.'\',
																					\''.$libelle_vacation.'\',
																					\''.$libelle_xfs_errors.'\',
																					\''.$commande.'\',
																					\''.$libelle_service.'\',
																					\''.$vacation_date.'\',
																					\''.$name_file.'\',
																					\'\',
																					\'\',
																					\'\',1)"   
																					data-target="#detailPeripheralStatus"> <img width="30" height="30"	src="image_ivision_gab/'.$img.'_UP.png" title="'.$img.' '.$libelleService.'"/> </a>';
																				
																				}
																					else
																					{
																					   echo' <img width="30" height="30"	src="image_ivision_gab/'.$img.'_UNSUP.png" title="'.$img.' '.$libelleService.'"/> ';	
																					}
																				
																					// echo'<br> ALM  : </strong></a>'.getStatusColor(1);													
																			}
																  
														
														}
														else
														{
															  echo' <img width="30" height="30"	src="image_ivision_gab/'.$img.'_UNSUP.png" title="'.$img.' '.$libelleService.'"/> ';	
														}
										
}
/************************************************************************************************************/
function getStatus3VacationCassette($idprivilege,$service,$paramettre,$atm,$id_vacation,$libelle_vacation,$libelle_xfs_errors,$libelle_service,$vacation_date,$commande,$name_file,$img,$libelleService)
{
																								
														if(empty($id_vacation)){$EtatPeripheral="";}
														else{$EtatPeripheral=getReturnEtatPeripheral($libelle_vacation,$atm,$libelle_service,$id_vacation,$vacation_date,$name_file);}												
																									
													if(is_array($EtatPeripheral))	
														{
															
														 $etatStatBool=boolStatGAB($service,$atm,$libelle_xfs_errors,$commande,$EtatPeripheral,'',$libelleService);
														 // echo $etatStatBool[0]."----".$etatStatBool[1]."<br>";
														 if ($etatStatBool[0]<>0) // Cas 1 afficher image incident GAB
																			{		//list($Libelle_logical, $value_logical) = explode('-',  $EtatPeripheral);
																					echo' <a tabindex="-1"  data-toggle="modal" 
																					onClick="javascript:getDetailPeripheralStatus(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$atm.'\',
																					\''.$id_vacation.'\',
																					\''.$libelle_vacation.'\',
																					\''.$libelle_xfs_errors.'\',
																					\''.$commande.'\',
																					\''.$libelle_service.'\',
																					\''.$vacation_date.'\',
																					\''.$name_file.'\',
																					\'\',
																					\'\',
																					\'\',0)"   
																					data-target="#detailPeripheralStatus"> <img width="30" height="30"	src="image_ivision_gab/'.$img.'_ERROR.png" title="'.$img.' '.$libelleService.'"/> </a>';
																					// .getStatusColor(0);														
																			}
																		else
																			{
																			if ($etatStatBool[1]<>0) // Cas 2 afficher image GAB opérationnel
																					{
																					echo' <a tabindex="-1"  data-toggle="modal" 
																					onClick="javascript:getDetailPeripheralStatus(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$atm.'\',
																					\''.$id_vacation.'\',
																					\''.$libelle_vacation.'\',
																					\''.$libelle_xfs_errors.'\',
																					\''.$commande.'\',
																					\''.$libelle_service.'\',
																					\''.$vacation_date.'\',
																					\''.$name_file.'\',
																					\'\',
																					\'\',
																					\'\',1)"   
																					data-target="#detailPeripheralStatus"> <img width="30" height="30"	src="image_ivision_gab/'.$img.'_UP.png" title="'.$img.' '.$libelleService.'"/> </a>';
																				
																				}
																					else
																					{
																					   echo' <img width="30" height="30"	src="image_ivision_gab/'.$img.'_UNSUP.png" title="'.$img.' '.$libelleService.'"/> ';	
																					}
																				
																					// echo'<br> ALM  : </strong></a>'.getStatusColor(1);													
																			}
																  
														
														}
														else
														{
															  echo' <img width="30" height="30"	src="image_ivision_gab/'.$img.'_UNSUP.png" title="'.$img.' '.$libelleService.'"/> ';	
														}
										
}
/************************************************************************************************************/
function getDetailPeripheralStatusVDM($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
    $connexion=ma_db_connexion();
						$sql = "SELECT `date_vacation`, `vacations_VDM`.`wDevice` AS DeviceVDM, `vacations_VDM`.`wService` AS ServiceVDM, `id_logical_name` ,  `logical_name` , `id_service`
								FROM `".mysqli_real_escape_string($connexion,$tableVacation)."` 
								WHERE `id_atm` ='".  mysqli_real_escape_string($connexion,$ATM)."'
								AND `logical_name`   ='".mysqli_real_escape_string($connexion,$logical_name)."'
								AND `fwDevice` <>3 ";		
								
								// echo $sql;
					/***************************************************/
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 10001:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 10001 !');
    }
    if ($result)
    {
              $k=0;
              if (mysqli_num_rows($result)>0)
              {
              echo '
                <div class="modal-dialog modal-lg">
                    <div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title">Détails    peripheral <strong style="font-size:18px;font-weight:bold;color:#e7722c" >: '.$nameVacation.' ('.mysqli_result($result,0 ,'date_vacation').')</strong></h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                                                                                    
                            <!-- Modal body -->
                            <div class="modal-body">';
                  while ($row = mysqli_fetch_assoc($result))
                  {
                      $k++;

                      $EtatPeripheral = array("Device|wDevice-".$row["DeviceVDM"],"Service|wService-".$row["ServiceVDM"]);

                      echo '								
								<div class="card-body table-responsive">
								  <table class="table table-hover">
									<thead class="text-warning">
									  <th><strong style="font-size:18px;font-weight:bold;color:#ffffff" >'.$nameVacation.'</strong></th>
									</thead>
									<tbody>
								<tr>					
											<td>';

                      get_statut_gab(0,0,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$module,$logical_name,$paramAffichage);

                      echo'</td>										
											</tr>
										  </tbody>
										</table>										
									</div>
											
											';

                  }
              }

              echo '		</div>
																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';
              mysqli_free_result($result);
    }
    mysqli_close($connexion);

							   
							   
}
/************************************************************************************************************/
function getDetailPeripheralStatusTTU($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
/*
    $connexion=ma_db_connexion();
    $sql = "SELECT `date_vacation`, `vacations_TTU`.`fwDevice` AS DeviceTTU, `vacations_TTU`.`wKeyboard` AS KeyboardIPM, `vacations_TTU`.`wKeylock` AS KeylockTTU, 
    `vacations_TTU`.`wLEDs` AS LEDsTTU, `vacations_TTU`.`wDisplaySizeX` AS DisplaySizeXTTU, `vacations_TTU`.`wDisplaySizeY` AS DisplaySizeYTTU, `id_logical_name` ,  `logical_name` , `id_service`, 
    `vacations_TTU`.`wDevicePosition` AS DevicePositionTTU, `vacations_TTU`.`usPowerSaveRecoveryTime` AS PowerSaveRecoveryTimeTTU, `vacations_TTU`.`wAntiFraudModule` AS AntiFraudModuleTTU 
    FROM `".mysqli_real_escape_string($connexion,$tableVacation)."` 
    WHERE `id_atm` ='".mysqli_real_escape_string($connexion,$ATM)."'
    AND `logical_name`   ='".mysqli_real_escape_string($connexion,$logical_name)."'
    AND `fwDevice` <>3 ";
										
								
								// echo $sql;

						$result = mysql_query($sql) or die('Erreur SQL getDetailPeripheralStatusTTU !<br>'.$sql.'<br>'.mysql_error());
							 $k=0;
							 
							 
							 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Détails    peripheral <strong style="font-size:18px;font-weight:bold;color:#e7722c" >: '.$nameVacation.' ('.mysql_result($result,$j ,'date_vacation').')</strong></h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">';
												
												
							   if (mysql_num_rows($result)>0)
							   {	
								for ($j=0; $j < mysql_num_rows($result) ; $j++)
									{			
										$k++;			
									
										 $EtatPeripheral = array("Device|fwDevice-".mysql_result($result,0 ,'DeviceTTU'),"Keyboard|wKeyboard-".mysql_result($result,0 ,'KeyboardIPM'),
										    "Keylock|wKeylock-".mysql_result($result,0 ,'KeylockTTU'),
											"LEDs|wLEDs-".mysql_result($result,0 ,'LEDsTTU'),"DisplaySizeX|wDisplaySizeX-".mysql_result($result,0 ,'DisplaySizeXTTU'),
											"DisplaySizeY|wDisplaySizeY-".mysql_result($result,0 ,'DisplaySizeYTTU'),
											"DevicePosition|wDevicePosition-".mysql_result($result,0 ,'DevicePositionTTU'),"PowerSaveRecoveryTime|usPowerSaveRecoveryTime-".mysql_result($result,0 ,'PowerSaveRecoveryTimeTTU'),
											"AntiFraudModule|wAntiFraudModule-".mysql_result($result,0 ,'AntiFraudModuleTTU'));
											
								echo '								
								<div class="card-body table-responsive">
								  <table class="table table-hover">
									<thead class="text-warning">
									  <th><strong style="font-size:18px;font-weight:bold;color:#ffffff" >'.$nameVacation.'</strong></th>
									</thead>
									<tbody>
								<tr>					
											<td>';
											
											get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$module,$logical_name,$paramAffichage); 
											
										echo'</td>										
											</tr>
										  </tbody>
										</table>										
									</div>
											
											';	
											
									}
							   }
							   
						echo '		</div>
																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';	   
							   
			*/
}
/************************************************************************************************************/
function getDetailPeripheralStatusSIU($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
    $connexion=ma_db_connexion();
    $id_service=14;
    $val=get_name_terminal_gag($ATM);
    $sql = "SELECT    `date_vacation` ,  `id_service` , `vacations_SIU`.`fwDevice` as DeviceSIU, `vacations_SIU`.`fwSensors_WFS_SIU_OPERATORSWITCH` as Sensors_WFS_SIU_OPERATORSWITCHSIU, 
    `vacations_SIU`.`fwSensors_WFS_SIU_TAMPER` as Sensors_WFS_SIU_TAMPERSIU, 
    `vacations_SIU`.`fwSensors_WFS_SIU_INTTAMPER` as Sensors_WFS_SIU_INTTAMPERSIU, `vacations_SIU`.`fwSensors_WFS_SIU_SEISMIC` as Sensors_WFS_SIU_SEISMICSIU, 
    `vacations_SIU`.`fwSensors_WFS_SIU_HEAT`  as Sensors_WFS_SIU_HEATSIU, `vacations_SIU`.`fwSensors_WFS_SIU_PROXIMITY` as Sensors_WFS_SIU_PROXIMITYSIU, 
    `vacations_SIU`.`fwSensors_WFS_SIU_AMBLIGHT`  as Sensors_WFS_SIU_AMBLIGHTSIU, `vacations_SIU`.`fwSensors_WFS_SIU_ENHANCEDAUDIO`  as Sensors_WFS_SIU_ENHANCEDAUDIOSIU, 
    `vacations_SIU`.`fwSensors_WFS_SIU_BOOT_SWITCH`  as Sensors_WFS_SIU_BOOT_SWITCHSIU, 
    `vacations_SIU`.`fwSensors_WFS_SIU_CONSUMER_DISPLAY`  as Sensors_WFS_SIU_CONSUMER_DISPLAYSIU, `vacations_SIU`.`fwSensors_WFS_SIU_OPERATOR_CALL_BUTTON`  as Sensors_WFS_SIU_OPERATOR_CALL_BUTTONSIU,
    `vacations_SIU`.`fwSensors_WFS_SIU_HANDSETSENSOR`  as Sensors_WFS_SIU_HANDSETSENSORSIU, 
    `vacations_SIU`.`fwSensors_WFS_SIU_GENERALINPUTPORT`  as Sensors_WFS_SIU_GENERALINPUTPORTSIU, `vacations_SIU`.`fwSensors_WFS_SIU_HEADSETMICROPHONE` as Sensors_WFS_SIU_HEADSETMICROPHONESIU, 
    `vacations_SIU`.`fwSensors_WFS_SIU_FASCIAMICROPHONE` as Sensors_WFS_SIU_FASCIAMICROPHONESIU, 
    `vacations_SIU`.`fwDoors_WFS_SIU_CABINET`  as Doors_WFS_SIU_CABINETSIU, `vacations_SIU`.`fwDoors_WFS_SIU_SAFE`  as Doors_WFS_SIU_SAFESIU, `vacations_SIU`.`fwDoors_WFS_SIU_VANDALSHIELD` as Doors_WFS_SIU_VANDALSHIELDSIU, 
    `vacations_SIU`.`fwDoors_WFS_SIU_CABINET_FRONT` as Doors_WFS_SIU_CABINET_FRONTSIU, 
    `vacations_SIU`.`fwDoors_WFS_SIU_CABINET_REAR`  as Doors_WFS_SIU_CABINET_REARSIU, `vacations_SIU`.`fwDoors_WFS_SIU_CABINET_LEFT`  as Doors_WFS_SIU_CABINET_LEFTSIU, 
    `vacations_SIU`.`fwDoors_WFS_SIU_CABINET_RIGHT` as Doors_WFS_SIU_CABINET_RIGHTSIU, 
    `vacations_SIU`.`fwIndicators_WFS_SIU_OPENCLOSE` as Indicators_WFS_SIU_OPENCLOSESIU, `vacations_SIU`.`fwIndicators_WFS_SIU_FASCIALIGHT` as Indicators_WFS_SIU_FASCIALIGHTSIU, 
    `vacations_SIU`.`fwIndicators_WFS_SIU_AUDIO`  as Indicators_WFS_SIU_AUDIOSIU, 
    `vacations_SIU`.`fwIndicators_WFS_SIU_HEATING` as Indicators_WFS_SIU_HEATINGSIU,  `vacations_SIU`.`fwIndicators_WFS_SIU_CONSUMER_DISPLAY_BACKLIGHT` as Indicators_WFS_SIU_CONSUMER_DISPLAY_BACKLIGHTSIU, 
    `vacations_SIU`.`fwIndicators_WFS_SIU_SIGNAGEDISPLAY` as Indicators_WFS_SIU_SIGNAGEDISPLAYSIU, 
    `vacations_SIU`.`fwIndicators_WFS_SIU_TRANSINDICATOR` as Indicators_WFS_SIU_TRANSINDICATORSIU,  `vacations_SIU`.`fwIndicators_WFS_SIU_GENERALOUTPUTPORT` as Indicators_WFS_SIU_GENERALOUTPUTPORTSIU, 
    `vacations_SIU`.`fwAuxiliaries_WFS_SIU_VOLUME` as Auxiliaries_WFS_SIU_VOLUMESIU, 
    `vacations_SIU`.`fwAuxiliaries_WFS_SIU_UPS` as Auxiliaries_WFS_SIU_UPSSIU,  `vacations_SIU`.`fwAuxiliaries_WFS_SIU_REMOTE_STATUS_MONITOR` as Auxiliaries_WFS_SIU_REMOTE_STATUS_MONITORSIU, 
    `vacations_SIU`.`fwAuxiliaries_WFS_SIU_AUDIBLE_ALARM` as Auxiliaries_WFS_SIU_AUDIBLE_ALARMSIU, 
    `vacations_SIU`.`fwAuxiliaries_WFS_SIU_ENHANCEDAUDIOCONTROL` as Auxiliaries_WFS_SIU_ENHANCEDAUDIOCONTROLSIU,  `vacations_SIU`.`fwAuxiliaries_WFS_SIU_ENHANCEDMICROPHONECONTROL` as Auxiliaries_WFS_SIU_ENHANCEDMICROPHONECONTROLSIU, 
    `vacations_SIU`.`fwAuxiliaries_WFS_SIU_MICROPHONEVOLUME` as Auxiliaries_WFS_SIU_MICROPHONEVOLUMESIU, `vacations_SIU`.`fwGuidLights_WFS_SIU_CARDUNIT` as GuidLights_WFS_SIU_CARDUNITSIU,  
    `vacations_SIU`.`fwGuidLights_WFS_SIU_PINPAD` as GuidLights_WFS_SIU_PINPADSIU,  
    `vacations_SIU`.`fwGuidLights_WFS_SIU_NOTESDISPENSER` as GuidLights_WFS_SIU_NOTESDISPENSERSIU,  `vacations_SIU`.`fwGuidLights_WFS_SIU_COINDISPENSER` as GuidLights_WFS_SIU_COINDISPENSERSIU,  
    `vacations_SIU`.`fwGuidLights_WFS_SIU_RECEIPTPRINTER` as GuidLights_WFS_SIU_RECEIPTPRINTERSIU,  
    `vacations_SIU`.`fwGuidLights_WFS_SIU_PASSBOOKPRINTER` as GuidLights_WFS_SIU_PASSBOOKPRINTERSIU,  `vacations_SIU`.`fwGuidLights_WFS_SIU_ENVDEPOSITORY` as GuidLights_WFS_SIU_ENVDEPOSITORYSIU,  
    `vacations_SIU`.`fwGuidLights_WFS_SIU_CHEQUEUNIT` as GuidLights_WFS_SIU_CHEQUEUNITSIU,
    `vacations_SIU`.`fwGuidLights_WFS_SIU_BILLACCEPTOR` as GuidLights_WFS_SIU_BILLACCEPTORSIU,  `vacations_SIU`.`fwGuidLights_WFS_SIU_ENVDISPENSER` as GuidLights_WFS_SIU_ENVDISPENSERSIU,
    `vacations_SIU`.`fwGuidLights_WFS_SIU_DOCUMENTPRINTER` as GuidLights_WFS_SIU_DOCUMENTPRINTERSIU,
    `vacations_SIU`.`fwGuidLights_WFS_SIU_COINACCEPTOR`as GuidLights_WFS_SIU_COINACCEPTORSIU, `vacations_SIU`.`fwGuidLights_WFS_SIU_SCANNER` as GuidLights_WFS_SIU_SCANNERSIU,
    `vacations_SIU`.`usPowerSaveRecoveryTime`  as PowerSaveRecoveryTimeSIU  , `vacations_SIU`.`wAntiFraudModule` as AntiFraudModuleSIU, `id_logical_name` ,  `logical_name` , `id_service` 
    FROM `".$tableVacation."`
    WHERE `id_atm` ='".$ATM."'
    AND `id_vacation` IN(".$idVacation.")
    AND `fwDevice` <>3 ";

    /***************************************************/
    echo '<div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">																										  
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">GAB : '.$ATM.' - '.$val[0].' - '.$val[1].' -<strong>  '.$nameVacation.' ('.$histDateVacation.')</strong></h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                                                                        
                <!-- Modal body -->
                <div class="modal-body">
                <div class="modal-body">
                <div class="row">
                    <div class="col">
                        <div class="card" style="border: 0px;">
                        
                         <div class="card-body">
                         <div class="nav-tabs-boxed">';

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    $result2=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 001009:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 001009 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $j=0;
            $jj=0;
            $tableau_logical_autorise=get_list_logical_names_atm($ATM,$id_service);
            echo '<ul class="nav nav-tabs" id="myTab1" role="tablist">';
            while ($rowG2 = mysqli_fetch_assoc($result2))
            {

                if (in_array($rowG2["id_logical_name"], $tableau_logical_autorise))
                {
                    if ($rowG2["DeviceCDM"]<>3)
                    {
                        if ($module==1)
                        {
                            echo '<li class="nav-item">';
                            echo ' <a class="nav-link';
                            if($jj==0){ echo ' active" aria-selected="true"';}else{echo '" aria-selected="false"';}
                            echo 'id="'.$rowG2["logical_name"].'_'.$jj.'" data-toggle="tab" role="tab" aria-controls="'.$rowG2["logical_name"].'" 
                             href="#'.$rowG2["logical_name"].'" >' . $rowG2["logical_name"] . '</a>';
                            echo '</li>';

                        }
                    }
                }
                $jj++;
            }
            echo '</ul>
            <div class="tab-content" id="myTab1Content">';

            while ($row = mysqli_fetch_assoc($result))
            {
                if (in_array($row["id_logical_name"], $tableau_logical_autorise))
                {
                    $EtatPeripheral =  array("Device|fwDevice-".$row["DeviceSIU"],
                        "Sensors_WFS_SIU_OPERATORSWITCH|fwSensors_WFS_SIU_OPERATORSWITCH-".$row["Sensors_WFS_SIU_OPERATORSWITCHSIU"],
                        "Sensors_WFS_SIU_TAMPER|fwSensors_WFS_SIU_TAMPER-".$row["Sensors_WFS_SIU_TAMPERSIU"],
                        "Sensors_WFS_SIU_INTTAM|fwSensors_WFS_SIU_INTTAMPER-".$row["Sensors_WFS_SIU_INTTAMPERSIU"],
                        "Sensors_WFS_SIU_SEISMIC|fwSensors_WFS_SIU_SEISMIC-".$row["Sensors_WFS_SIU_SEISMICSIU"],
                        "Sensors_WFS_SIU_HEAT|fwSensors_WFS_SIU_HEAT-".$row["Sensors_WFS_SIU_HEATSIU"],
                        "Sensors_WFS_SIU_PROXIMITY|fwSensors_WFS_SIU_PROXIMITY-".$row["Sensors_WFS_SIU_PROXIMITYSIU"],
                        "Sensors_WFS_SIU_AMBLIGHT|fwSensors_WFS_SIU_AMBLIGHT-".$row["Sensors_WFS_SIU_AMBLIGHTSIU"],
                        "Sensors_WFS_SIU_ENHANCEDAUDIO|fwSensors_WFS_SIU_ENHANCEDAUDIO-".$row["Sensors_WFS_SIU_ENHANCEDAUDIOSIU"],
                        "Sensors_WFS_SIU_BOOT_SWITCH|fwSensors_WFS_SIU_BOOT_SWITCH-".$row["Sensors_WFS_SIU_BOOT_SWITCHSIU"],
                        "Sensors_WFS_SIU_CONSUMER_DISPLAY|fwSensors_WFS_SIU_CONSUMER_DISPLAY-".$row["Sensors_WFS_SIU_CONSUMER_DISPLAYSIU"],
                        "Sensors_WFS_SIU_OPERATOR_CALL_BUTTON|fwSensors_WFS_SIU_OPERATOR_CALL_BUTTON-".$row["Sensors_WFS_SIU_OPERATOR_CALL_BUTTONSIU"],
                        "Sensors_WFS_SIU_HANDSETSENSOR|fwSensors_WFS_SIU_HANDSETSENSOR-".$row["Sensors_WFS_SIU_HANDSETSENSORSIU"],
                        "Sensors_WFS_SIU_GENERALINPUTPORT|fwSensors_WFS_SIU_GENERALINPUTPORT-".$row["Sensors_WFS_SIU_GENERALINPUTPORTSIU"],
                        "Sensors_WFS_SIU_HEADSETMICROPHONE|fwSensors_WFS_SIU_HEADSETMICROPHONE-".$row["Sensors_WFS_SIU_HEADSETMICROPHONESIU"],
                        "Sensors_WFS_SIU_FASCIAMICROPHONE|fwSensors_WFS_SIU_FASCIAMICROPHONE-".$row["Sensors_WFS_SIU_FASCIAMICROPHONESIU"],
                        "Doors_WFS_SIU_CABINET|fwDoors_WFS_SIU_CABINET-".$row["Doors_WFS_SIU_CABINETSIU"],
                        "Doors_WFS_SIU_SAFE|fwDoors_WFS_SIU_SAFE-".$row["Doors_WFS_SIU_SAFESIU"],
                        "Doors_WFS_SIU_VANDALSHIELD|fwDoors_WFS_SIU_VANDALSHIELD-".$row["Doors_WFS_SIU_VANDALSHIELDSIU"],
                        "Doors_WFS_SIU_CABINET_FRONT|fwDoors_WFS_SIU_CABINET_FRONT-".$row["Doors_WFS_SIU_CABINET_FRONTSIU"],
                        "Doors_WFS_SIU_CABINET_REAR|fwDoors_WFS_SIU_CABINET_REAR-".$row["Doors_WFS_SIU_CABINET_REARSIU"],
                        "Doors_WFS_SIU_CABINET_LEFT|fwDoors_WFS_SIU_CABINET_LEFT-".$row["Doors_WFS_SIU_CABINET_LEFTSIU"],
                        "Doors_WFS_SIU_CABINET_RIGHT|fwDoors_WFS_SIU_CABINET_RIGHT-".$row["Doors_WFS_SIU_CABINET_RIGHTSIU"],
                        "Indicators_WFS_SIU_OPENCLOSE|fwIndicators_WFS_SIU_OPENCLOSE-".$row["Indicators_WFS_SIU_OPENCLOSESIU"],
                        "Indicators_WFS_SIU_FASCIALIGHT|fwIndicators_WFS_SIU_FASCIALIGHT-".$row["Indicators_WFS_SIU_FASCIALIGHTSIU"],
                        "Indicators_WFS_SIU_AUDIO|fwIndicators_WFS_SIU_AUDIO-".$row["Indicators_WFS_SIU_AUDIOSIU"],
                        "Indicators_WFS_SIU_HEATING|fwIndicators_WFS_SIU_HEATING-".$row["Indicators_WFS_SIU_HEATINGSIU"],
                        "Indicators_WFS_SIU_CONSUMER_DISPLAY_BACKLIGHT|fwIndicators_WFS_SIU_CONSUMER_DISPLAY_BACKLIGHT-".$row["Indicators_WFS_SIU_CONSUMER_DISPLAY_BACKLIGHTSIU"],
                        "Indicators_WFS_SIU_SIGNAGEDISPLAY|fwIndicators_WFS_SIU_SIGNAGEDISPLAY-".$row["Indicators_WFS_SIU_SIGNAGEDISPLAYSIU"],
                        "Indicators_WFS_SIU_TRANSINDICATOR|fwIndicators_WFS_SIU_TRANSINDICATOR-".$row["Indicators_WFS_SIU_TRANSINDICATORSIU"],
                        "Indicators_WFS_SIU_GENERALOUTPUTPORT|fwIndicators_WFS_SIU_GENERALOUTPUTPORT-".$row["Indicators_WFS_SIU_GENERALOUTPUTPORTSIU"],
                        "Auxiliaries_WFS_SIU_VOLUME|fwAuxiliaries_WFS_SIU_VOLUME-".$row["Auxiliaries_WFS_SIU_VOLUMESIU"],
                        "Auxiliaries_WFS_SIU_UPS|fwAuxiliaries_WFS_SIU_UPS-".$row["Auxiliaries_WFS_SIU_UPSSIU"],
                        "Auxiliaries_WFS_SIU_REMOTE_STATUS_MONITOR|fwAuxiliaries_WFS_SIU_REMOTE_STATUS_MONITOR-".$row["Auxiliaries_WFS_SIU_REMOTE_STATUS_MONITORSIU"],
                        "Auxiliaries_WFS_SIU_AUDIBLE_ALARM|fwAuxiliaries_WFS_SIU_AUDIBLE_ALARM-".$row["Auxiliaries_WFS_SIU_AUDIBLE_ALARMSIU"],
                        "Auxiliaries_WFS_SIU_ENHANCEDAUDIOCONTROL|fwAuxiliaries_WFS_SIU_ENHANCEDAUDIOCONTROL-".$row["Auxiliaries_WFS_SIU_ENHANCEDAUDIOCONTROLSIU"],
                        "Auxiliaries_WFS_SIU_ENHANCEDMICROPHONECONTROL|fwAuxiliaries_WFS_SIU_ENHANCEDMICROPHONECONTROL-".$row["Auxiliaries_WFS_SIU_ENHANCEDMICROPHONECONTROLSIU"],
                        "Auxiliaries_WFS_SIU_MICROPHONEVOLUME|fwAuxiliaries_WFS_SIU_MICROPHONEVOLUME-".$row["Auxiliaries_WFS_SIU_MICROPHONEVOLUMESIU"],
                        "GuidLights_WFS_SIU_CARDUNIT|fwGuidLights_WFS_SIU_CARDUNIT-".$row["GuidLights_WFS_SIU_CARDUNITSIU"],
                        "GuidLights_WFS_SIU_PINPAD|fwGuidLights_WFS_SIU_PINPAD-".$row["GuidLights_WFS_SIU_PINPADSIU"],
                        "GuidLights_WFS_SIU_NOTESDISPENSER|fwGuidLights_WFS_SIU_NOTESDISPENSER-".$row["GuidLights_WFS_SIU_NOTESDISPENSERSIU"],
                        "GuidLights_WFS_SIU_COINDISPENSER|fwGuidLights_WFS_SIU_COINDISPENSER-".$row["GuidLights_WFS_SIU_COINDISPENSERSIU"],
                        "GuidLights_WFS_SIU_RECEIPTPRINTER|fwGuidLights_WFS_SIU_RECEIPTPRINTER-".$row["GuidLights_WFS_SIU_RECEIPTPRINTERSIU"],
                        "GuidLights_WFS_SIU_PASSBOOKPRINTER|fwGuidLights_WFS_SIU_PASSBOOKPRINTER-".$row["GuidLights_WFS_SIU_PASSBOOKPRINTERSIU"],
                        "GuidLights_WFS_SIU_ENVDEPOSITORY|fwGuidLights_WFS_SIU_ENVDEPOSITORY-".$row["GuidLights_WFS_SIU_ENVDEPOSITORYSIU"],
                        "GuidLights_WFS_SIU_CHEQUEUNIT|fwGuidLights_WFS_SIU_CHEQUEUNIT-".$row["GuidLights_WFS_SIU_CHEQUEUNITSIU"],
                        "GuidLights_WFS_SIU_BILLACCEPTOR|fwGuidLights_WFS_SIU_BILLACCEPTOR-".$row["GuidLights_WFS_SIU_BILLACCEPTORSIU"],
                        "GuidLights_WFS_SIU_ENVDISPENSER|fwGuidLights_WFS_SIU_ENVDISPENSER-".$row["GuidLights_WFS_SIU_ENVDISPENSERSIU"],
                        "GuidLights_WFS_SIU_DOCUMENTPRINTER|fwGuidLights_WFS_SIU_DOCUMENTPRINTER-".$row["GuidLights_WFS_SIU_DOCUMENTPRINTERSIU"],
                        "GuidLights_WFS_SIU_COINACCEPTOR|fwGuidLights_WFS_SIU_COINACCEPTOR-".$row["GuidLights_WFS_SIU_COINACCEPTORSIU"],
                        "GuidLights_WFS_SIU_SCANNER|fwGuidLights_WFS_SIU_SCANNER-".$row["GuidLights_WFS_SIU_SCANNERSIU"],
                        "PowerSaveRecoveryTime|usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTimeSIU"],
                        "AntiFraudModule|wAntiFraudModule-".$row["AntiFraudModuleSIU"],
                        "Service|id_service-".$row["id_service"]);

                    if ($module==1)
                    {
                        echo '<div class="tab-pane fade';if($j==0){ echo ' show active';}echo '" 
                        id="'.$row["logical_name"].'" role="tabpanel" aria-labelledby="'.$row["logical_name"].'_'.$j.'">';
                        get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$id_service,$row["id_logical_name"],$paramAffichage);
                        echo'</div>';
                    }
                }
                $j++;
            }
        }
    }


							   
    echo '</div>
         </div>
         </div>
         </div>
         </div>
         </div>
         </div>   
																												
        <!-- Modal footer -->
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
            
        </div>
    </div>';

}
/************************************************************************************************************/
function getDetailPeripheralStatusIPM($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
	/*
	
						$sql = "SELECT `date_vacation`, `vacations_IPM`.`fwDevice` AS DeviceIPM, `vacations_IPM`.`wAcceptor` AS AcceptorIPM, `id_logical_name` ,  `logical_name` , `id_service`, 
							`vacations_IPM`.`wMedia` AS MediaIPM, `vacations_IPM`.`wToner` AS TonerIPM, `vacations_IPM`.`wInk` AS InkIPM, 
							`vacations_IPM`.`wFrontImageScanner` AS FrontImageScannerIPM, `vacations_IPM`.`wBackImageScanner` AS BackImageScannerIPM, `vacations_IPM`.`wMICRReader` AS MICRReaderIPM, 
							`vacations_IPM`.`wStacker` AS StackerIPM, `vacations_IPM`.`wReBuncher` AS ReBuncherIPM, `vacations_IPM`.`wMediaFeeder` AS MediaFeederIPM, `vacations_IPM`.`dwGuidLights` AS GuidLightsIPM, 
							`vacations_IPM`.`dwGuidLights_WFS_IPM_GUIDANCE_MEDIAIN` AS GuidLights_WFS_IPM_GUIDANCE_MEDIAINIPM, `vacations_IPM`.`dwGuidLights_WFS_IPM_GUIDANCE_MEDIAOUT` AS GuidLights_WFS_IPM_GUIDANCE_MEDIAOUTIPM, 
							`vacations_IPM`.`dwGuidLights_WFS_IPM_GUIDANCE_MEDIAREFUSED` AS GuidLights_WFS_IPM_GUIDANCE_MEDIAREFUSEDIPM, `vacations_IPM`.`wDevicePosition` AS DevicePositionIPM, 
							`vacations_IPM`.`wMixedMode` AS MixedModeIPM, `vacations_IPM`.`wAntiFraudModule` AS AntiFraudModuleIPM
								FROM `".$tableVacation."` 
								WHERE `id_atm` ='".$ATM."'
								AND `logical_name`   ='".$logical_name."'
								AND `fwDevice` <>3 ";	
										
								
								// echo $sql;

						$result = mysql_query($sql) or die('Erreur SQL getDetailPeripheralStatusIPM !<br>'.$sql.'<br>'.mysql_error());
							 $k=0;
							 
							 
							 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Détails    peripheral <strong style="font-size:18px;font-weight:bold;color:#e7722c" >: '.$nameVacation.' ('.mysql_result($result,$j ,'date_vacation').')</strong></h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">';
												
												
							   if (mysql_num_rows($result)>0)
							   {	
								for ($j=0; $j < mysql_num_rows($result) ; $j++)
									{			
										$k++;			
									
										 $EtatPeripheral =  array("Device|fwDevice-".mysql_result($result,0 ,'DeviceIPM'),"Acceptor|wAcceptor-".mysql_result($result,0 ,'AcceptorIPM'),
										"Media|wMedia-".mysql_result($result,0 ,'MediaIPM'),"Toner|wToner-".mysql_result($result,0 ,'TonerIPM'),"Ink|wInk-".mysql_result($result,0 ,'InkIPM'),
										"FrontImageScanner|wFrontImageScanner-".mysql_result($result,0 ,'FrontImageScannerIPM'),"BackImageScanner|wBackImageScanner-".mysql_result($result,0 ,'BackImageScannerIPM'),
										"MICRReader|wMICRReader-".mysql_result($result,0 ,'MICRReaderIPM'),
										"Stacker|wStacker-".mysql_result($result,0 ,'StackerIPM'),"ReBuncherIPM|wReBuncher-".mysql_result($result,0 ,'ReBuncherIPM'),
										"MediaFeeder|wMediaFeeder-".mysql_result($result,0 ,'MediaFeederIPM'),"GuidLights|dwGuidLights-".mysql_result($result,0 ,'GuidLightsIPM'),
										"GuidLights_WFS_IPM_GUIDANCE_MEDIAIN|dwGuidLights_WFS_IPM_GUIDANCE_MEDIAIN-".mysql_result($result,0 ,'GuidLights_WFS_IPM_GUIDANCE_MEDIAINIPM'),
										"GuidLights_WFS_IPM_GUIDANCE_MEDIAOUT|dwGuidLights_WFS_IPM_GUIDANCE_MEDIAOUT-".mysql_result($result,0 ,'GuidLights_WFS_IPM_GUIDANCE_MEDIAOUTIPM'),
										"GuidLights_WFS_IPM_GUIDANCE_MEDIAREFUSED|dwGuidLights_WFS_IPM_GUIDANCE_MEDIAREFUSED-".mysql_result($result,0 ,'GuidLights_WFS_IPM_GUIDANCE_MEDIAREFUSEDIPM'),
										"DevicePosition|wDevicePosition-".mysql_result($result,0 ,'DevicePositionIPM'),
										"MixedMode|wMixedMode-".mysql_result($result,0 ,'MixedModeIPM'),"AntiFraudModul|wAntiFraudModule-".mysql_result($result,0 ,'AntiFraudModuleIPM'));
											
								echo '								
								<div class="card-body table-responsive">
								  <table class="table table-hover">
									<thead class="text-warning">
									  <th><strong style="font-size:18px;font-weight:bold;color:#ffffff" >'.$nameVacation.'</strong></th>
									</thead>
									<tbody>
								<tr>					
											<td>';
											
											get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$module,$logical_name,$paramAffichage); 
											
										echo'</td>										
											</tr>
										  </tbody>
										</table>										
									</div>
											
											';	
											
									}
							   }
							   
						echo '		</div>
																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';	   
		*/
							   
}
/************************************************************************************************************/
function getDetailPeripheralStatusDEP($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
    /*
					$sql = "SELECT `date_vacation`, `vacations_DEP`.`fwDevice` AS DeviceDEP, `vacations_DEP`.`fwDepContainer` AS DepContainerDEP, `id_logical_name` ,  `logical_name` , `id_service`, 
							`vacations_DEP`.`fwDepTransport` AS DepTransportDEP, `vacations_DEP`.`fwEnvSupply` AS EnvSupplyDEP, `vacations_DEP`.`fwEnvDispenser` AS EnvDispenserDEP, 
							`vacations_DEP`.`fwShutter` AS ShutterDEP, `vacations_DEP`.`wNumOfDeposits` AS NumOfDepositsDEP, `vacations_DEP`.`dwGuidLights` AS GuidLightsDEP, 
							`vacations_DEP`.`dwGuidLights_WFS_DEP_GUIDANCE_ENVDEPOSITORY` AS GuidLights_WFS_DEP_GUIDANCE_ENVDEPOSITORYDEP, `vacations_DEP`.`dwGuidLights_WFS_DEP_GUIDANCE_ENVDISPENSER`  AS GuidLights_WFS_DEP_GUIDANCE_ENVDISPENSERDEP, `vacations_DEP`.`fwDepositLocation`  AS DepositLocationDEP, 
							`vacations_DEP`.`wDevicePosition`  AS DevicePositionDEP, `vacations_DEP`.`usPowerSaveRecoveryTime`  AS PowerSaveRecoveryTimeDEP, `vacations_DEP`.`wAntiFraudModule`  AS AntiFraudModuleDEP  
								FROM `".$tableVacation."` 
								WHERE `id_atm` ='".$ATM."'
								AND `logical_name`   ='".$logical_name."'
								AND `fwDevice` <>3 ";	
										
								
								// echo $sql;

						$result = mysql_query($sql) or die('Erreur SQL getDetailPeripheralStatusDEP !<br>'.$sql.'<br>'.mysql_error());
							 $k=0;
							 
							 
							 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Détails    peripheral <strong style="font-size:18px;font-weight:bold;color:#e7722c" >: '.$nameVacation.' ('.mysql_result($result,$j ,'date_vacation').')</strong></h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">';
												
												
							   if (mysql_num_rows($result)>0)
							   {	
								for ($j=0; $j < mysql_num_rows($result) ; $j++)
									{			
										$k++;			
									
										$EtatPeripheral = array("Device|fwDevice-".mysql_result($result,$j  ,'DeviceDEP'),"DepContainer|fwDepContainer-".mysql_result($result,$j  ,'DepContainerDEP'),
									"DepTransport|fwDepTransport-".mysql_result($result,$j  ,'DepTransportDEP'),"EnvSupply|fwEnvSupply-".mysql_result($result,$j  ,'EnvSupplyDEP'),"EnvDispenser|fwEnvDispenser-".mysql_result($result,$j  ,'EnvDispenserDEP'),
									"Shutter|fwShutter-".mysql_result($result,$j  ,'ShutterDEP'),"NumOfDeposits|wNumOfDeposits-".mysql_result($result,$j  ,'NumOfDepositsDEP'),"GuidLights|dwGuidLights-".mysql_result($result,$j  ,'GuidLightsDEP'),
									"GuidLights_WFS_DEP_GUIDANCE_ENVDEPOSITORY|dwGuidLights_WFS_DEP_GUIDANCE_ENVDEPOSITORY-".mysql_result($result,$j  ,'GuidLights_WFS_DEP_GUIDANCE_ENVDEPOSITORYDEP'),
									"GuidLights_WFS_DEP_GUIDANCE_ENVDISPENSER|dwGuidLights_WFS_DEP_GUIDANCE_ENVDISPENSER-".mysql_result($result,$j  ,'GuidLights_WFS_DEP_GUIDANCE_ENVDISPENSERDEP'),"DepositLocation|fwDepositLocation-".mysql_result($result,$j  ,'DepositLocationDEP'),
									"DevicePosition|wDevicePosition-".mysql_result($result,$j  ,'DevicePositionDEP'),"PowerSaveRecoveryTime|usPowerSaveRecoveryTime-".mysql_result($result,$j  ,'PowerSaveRecoveryTimeDEP'),"AntiFraudModule|wAntiFraudModule-".mysql_result($result,$j  ,'AntiFraudModuleDEP'));	
											
								echo '								
								<div class="card-body table-responsive">
								  <table class="table table-hover">
									<thead class="text-warning">
									  <th><strong style="font-size:18px;font-weight:bold;color:#ffffff" >'.$nameVacation.'</strong></th>
									</thead>
									<tbody>
								<tr>					
											<td>';
											
											get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$module,$logical_name,$paramAffichage); 
											
										echo'</td>										
											</tr>
										  </tbody>
										</table>										
									</div>
											
											';	
											
									}
							   }
							   
						echo '		</div>
																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';	   
							   
			*/
}
/************************************************************************************************************/
function getDetailPeripheralStatusCRD($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{

				/*	$sql = "SELECT `date_vacation`, `vacations_CRD`.`fwDevice` as DeviceCRD, `vacations_CRD`.`fwDispenser` as DispenserCRD,
							`vacations_CRD`.`fwTransport` as TransportCRD, `vacations_CRD`.`fwMedia` as MediaCRD, `vacations_CRD`.`fwShutter` as ShutterCRD, 
							`vacations_CRD`.`dwGuidLights` as GuidLightsCRD, `vacations_CRD`.`dwGuidLights_WFS_CRD_GUIDANCE_CARDDISP` as GuidLights_WFS_CRD_GUIDANCE_CARDDISPCRD, `vacations_CRD`.`wDevicePosition` as DevicePositionCRD,
							`vacations_CRD`.`usPowerSaveRecoveryTime` as PowerSaveRecoveryTimeCRD, `vacations_CRD`.`wAntiFraudModule` as  AntiFraudModuleCRD, `id_logical_name` ,  `logical_name` , `id_service` 
								FROM `".$tableVacation."` 
								WHERE `id_atm` ='".$ATM."'
								AND `logical_name`   ='".$logical_name."'
								AND `fwDevice` <>3 ";	
										
								
								// echo $sql;

						$result = mysql_query($sql) or die('Erreur SQL getDetailPeripheralStatusCRD !<br>'.$sql.'<br>'.mysql_error());
							 $k=0;
							 
							 
							 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Détails    peripheral <strong style="font-size:18px;font-weight:bold;color:#e7722c" >: '.$nameVacation.' ('.mysql_result($result,$j ,'date_vacation').')</strong></h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">';
												
												
							   if (mysql_num_rows($result)>0)
							   {	
								for ($j=0; $j < mysql_num_rows($result) ; $j++)
									{			
										$k++;			
									
										$EtatPeripheral = array("Device|fwDevice-".mysql_result($result,$j  ,'DeviceCRD'),"Dispenser|fwDispenser-".mysql_result($result,$j  ,'DispenserCRD'),
										"Transport|fwTransport-".mysql_result($result,$j  ,'TransportCRD'),"Media|fwMedia-".mysql_result($result,$j  ,'MediaCRD'),"Shutter|fwShutter-".mysql_result($result,$j  ,'ShutterCRD'),
										"GuidLights|dwGuidLights-".mysql_result($result,$j  ,'GuidLightsCRD'),"GuidLights_WFS_CRD_GUIDANCE_CARDDISP|dwGuidLights_WFS_CRD_GUIDANCE_CARDDISP-".mysql_result($result,$j  ,'GuidLights_WFS_CRD_GUIDANCE_CARDDISPCRD'),
										"DevicePosition|wDevicePosition-".mysql_result($result,$j  ,'DevicePositionCRD'),
										"PowerSaveRecoveryTime|usPowerSaveRecoveryTime-".mysql_result($result,$j  ,'PowerSaveRecoveryTimeCRD'),"AntiFraudModule|wAntiFraudModule-".mysql_result($result,$j  ,'AntiFraudModuleCRD'));
											
								echo '								
								<div class="card-body table-responsive">
								  <table class="table table-hover">
									<thead class="text-warning">
									  <th><strong style="font-size:18px;font-weight:bold;color:#ffffff" >'.$nameVacation.'</strong></th>
									</thead>
									<tbody>
								<tr>					
											<td>';
											
											get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$module,$logical_name,$paramAffichage); 
											
										echo'</td>										
											</tr>
										  </tbody>
										</table>										
									</div>
											
											';	
											
									}
							   }
							   
						echo '		</div>
																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';	   
							   
							*/
}
/************************************************************************************************************/
/************************************************************************************************************/
function getDetailPeripheralStatusCIM($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
    include "../languages/" . $_SESSION['lang'] . ".php";

    $connexion=ma_db_connexion();
    $service=7;
    $val=get_name_terminal_gag($ATM);
    $sql = "SELECT `vacations_CIM`.`date_vacation` , `vacations_CIM`.`fwDevice` as DeviceCIM,  `id_vacation` as vacationCIM , `vacations_CIM`.`fwSafeDoor` as SafeDoorCIM, `vacations_CIM`.`fwAcceptor` as AcceptorCIM, `vacations_CIM`.`fwIntermediateStacker` as IntermediateStackerCIM, 
    `vacations_CIM`.`fwStackerItems` as StackerItemsCIM, `vacations_CIM`.`fwBanknoteReader` as BanknoteReaderCIM, `vacations_CIM`.`bDropBox` as DropBoxCIM, `vacations_CIM`.`fwPosition` as PositionCIM,
    `vacations_CIM`.`fwShutter` as ShutterCIM, `vacations_CIM`.`fwPositionStatus` as PositionStatusCIM, `vacations_CIM`.`fwTransport` as TransportCIM, `vacations_CIM`.`fwTransportStatus` as TransportStatusCIM, 
    `vacations_CIM`.`fwJammedShutterPosition` as JammedShutterPositionCIM, `vacations_CIM`.`dwGuidLights` as GuidLightsCIM, `vacations_CIM`.`wDevicePosition` as DevicePositionCIM, 
    `vacations_CIM`.`usPowerSaveRecoveryTime` as PowerSaveRecoveryTimeCIM, `wMixedMode` as MixedModeCIM, `vacations_CIM`.`wAntiFraudModule`  as AntiFraudModuleCIM, `id_logical_name` ,  `logical_name` , `id_service`
    FROM `".mysqli_real_escape_string($connexion,$tableVacation)."`
    WHERE `id_atm` ='".  mysqli_real_escape_string($connexion,$ATM)."'
    AND `id_vacation` IN(".$idVacation.")
    AND `fwDevice` <>3 ";
    // ECHO $sql;

    /***************************************************/

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    $result2=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1002:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 1002 !');
    }
    if ($result)
    {
        $k=0;
        echo '<div class="modal-dialog modal-xl" role="document">
		    <div class="modal-content">																										  
			    <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">'.$lang['terminal'].' : '.$ATM.' - '.$val[0].' - '.$val[1].' -<strong>  '.$nameVacation.' ('.$histDateVacation.')</strong></h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                  <div class="row">
                    <div class="col">
                        <div class="card" style="border: 0px;">
                         <div class="card-body">
                         <div class="nav-tabs-boxed">';
        if (mysqli_num_rows($result)>0)
        {
            $j=0;
            $jj=0;
            $tableau_logical_autorise=get_list_logical_names_atm($ATM,$service);

            echo '<ul class="nav nav-tabs" id="myTab1" role="tablist">';
            while ($rowG2 = mysqli_fetch_assoc($result2))
            {

                if (in_array($rowG2["id_logical_name"], $tableau_logical_autorise))
                {
                    if ($rowG2["DeviceCDM"]<>3)
                    {
                        if ($module==1)
                        {
                            echo '<li class="nav-item">';
                            echo ' <a class="nav-link';
                            if($jj==0){ echo ' active" aria-selected="true"';}else{echo '" aria-selected="false"';}
                            echo 'id="'.$rowG2["logical_name"].'_'.$jj.'" data-toggle="tab" role="tab" aria-controls="'.$rowG2["logical_name"].'" 
                             href="#'.$rowG2["logical_name"].'" >' . $rowG2["logical_name"] . '</a>';
                            echo '</li>';

                        }
                    }
                }
                $jj++;
            }
            echo '</ul>
            <div class="tab-content" id="myTab1Content">';

            while ($row = mysqli_fetch_assoc($result))
            {
                // if (in_array(mysql_result($result,$j ,'logical_name'), $tableau_logical_autorise))
                if (in_array($row["id_logical_name"], $tableau_logical_autorise))
                {
                    $k++;
                    // $row["id_service"]
                    $EtatPeripheral = array("Device|fwDevice-".$row["DeviceCIM"],"SafeDoor|fwSafeDoor-".$row["SafeDoorCIM"],
                    "Acceptor|fwAcceptor-".$row["AcceptorCIM"],"IntermediateStacker|fwIntermediateStacker-".$row["IntermediateStackerCIM"],"StackerItems|fwStackerItems-".$row["StackerItemsCIM"],
                    "BanknoteReader|fwBanknoteReader-".$row["BanknoteReaderCIM"],"DropBox|bDropBox-".$row["DropBoxCIM"],"Position|fwPosition-".$row["PositionCIM"],
                    "Shutter|fwShutter-".$row["ShutterCIM"],"PositionStatus|fwPositionStatus-".$row["PositionStatusCIM"],"Transport|fwTransport-".$row["TransportCIM"],
                    "TransportStatus|fwTransportStatus-".$row["TransportStatusCIM"],
                    "JammedShutterPosition|fwJammedShutterPosition-".$row["JammedShutterPositionCIM"],"GuidLights|dwGuidLights-".$row["GuidLightsCIM"],"DevicePosition|wDevicePosition-".$row["DevicePositionCIM"],
                    "PowerSaveRecoveryTime|usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTimeCIM"],"MixedMode|wMixedMode-".$row["MixedModeCIM"],"AntiFraudModule|wAntiFraudModule-".$row["AntiFraudModuleCIM"],"Service|id_service-".$row["id_service"]);
															
                    if ($module==2)
                    {
                        // getModuleDeclaration($ATM,mysql_result($result,$j ,'id_vacation'),$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$category,$code_error,mysql_result($result,$j ,'logical_name'));
                    }
																		
                    if ($module==1)
                    {
                        echo '<div class="tab-pane fade';if($j==0){ echo ' show active';}echo '" 
                            id="'.$row["logical_name"].'" role="tabpanel" aria-labelledby="'.$row["logical_name"].'_'.$j.'">';

                        get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$row["id_service"],$row["id_logical_name"],$paramAffichage);

                        $SQLLogical =" SELECT `id_vacation_logical`, `id_vacation`, `jLoop`, `usNumber`, `fwType`, `fwItemType`, `cUnitID`,
                        `cCurrencyID`, 	`ulValues`, `ulCashInCount`, `ulInitialCount`, `ulCount`, `ulMaximum`, `ulRejectCount`, `ulMinimum`, `bAppLock`,
                        `usStatus`, `usCDMType`, `ulDispensedCount`, `ulPresentedCount`,
                        `ulRetractedCount`, `usNumPhysicalCUs`, `lppPhysical`, `detailsPhysicalUnits`
                        FROM `vacations_CIM_cash_unit_logical`
                        WHERE `id_vacation` = '".mysqli_real_escape_string($connexion,$row["vacationCIM"])."' and `fwType` = 2";

                        //var_dump($SQLLogical);die();
                        mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
                        $resLogical=mysqli_query($connexion,$SQLLogical);
                        if (!$resLogical)
                        {
                            error_log("Erreur SQL 001014:  ".$SQLLogical."  " .mysqli_error($connexion));
                            die(' ERREUR QUERY 001014 !');
                        }
                        if ($resLogical)
                        {
                            if (mysqli_num_rows($resLogical)>0)
                            {
                                echo '<hr> 
                                <table class="table table-responsive-sm table-hover table-outline mb-0">
                                    <thead class="thead-light">
                                    <tr>
                                        <th>Cassette</th>
                                        <th>Nbr Billet</th>
                                        <th ';if($idprivilege==1){echo 'colspan="3"';}else{echo'colspan="2"';}echo'>Statut</th>';

                                echo '</tr>
                                </thead>';
                                while ($rowL = mysqli_fetch_assoc($resLogical))
                                {
                                                        // echo " <br>------------------Logical -------------------- <br>";
                                    $EtatCassetteLogical = array("Loop|jLoop-".$rowL["jLoop"],"Number|usNumber-".$rowL["usNumber"],
                                    "fwType|fwType-".$rowL["fwType"],"ItemType|fwItemType-".$rowL["fwItemType"],
                                    "UnitID|cUnitID-".$rowL["cUnitID"],"CashInCount|ulCashInCount-".$rowL["ulCashInCount"],
                                    "CurrencyID|cCurrencyID-".$rowL["cCurrencyID"],"Values|ulValues-".$rowL["ulValues"],
                                    "Initial Count|ulInitialCount-".$rowL["ulInitialCount"],"Count|ulCount-".$rowL["ulCount"],
                                    "Maximum|ulMaximum-".$rowL["ulMaximum"],"CDMType|usCDMType-".$rowL["usCDMType"],
                                    "Reject Count|ulRejectCount-".$rowL["ulRejectCount"],"Minimum|ulMinimum-".$rowL["ulMinimum"],
                                    "AppLock|bAppLock-".$rowL["bAppLock"],"Status|usStatus-".$rowL["usStatus"],
                                    "Dispensed Count|ulDispensedCount-".$rowL["ulDispensedCount"],"Presented Count|ulPresentedCount-".$rowL["ulPresentedCount"],
                                    "Retracted Count|ulRetractedCount-".$rowL["ulRetractedCount"],"Num Physical CUs|usNumPhysicalCUs-".$rowL["usNumPhysicalCUs"],
                                    "Physical|lppPhysical-".$rowL["lppPhysical"],"Details Physical Units|detailsPhysicalUnits-".$rowL["detailsPhysicalUnits"],
                                    "Service|id_service-".$row["id_service"]);

                                    get_statut_gab2($paramettre,$idprivilege,'xfs_errors_CIM','WFS_INF_CIM_CASH_UNIT_INFO',$EtatCassetteLogical,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,'CIM2',$histDateVacation,$histNameFile,$module,'',$row["id_service"],$row["id_logical_name"],$paramAffichage);

                                    $k++;
                                } //for ($u=0; $u < mysql_num_rows($resLogical) ; $u++)
                                echo '</table>';
                            } //if (mysql_num_rows($resLogical)>0)
                            mysqli_free_result($resLogical);
                        }

                        echo'</div>';
                    }// fin condition if($module==1)
                }
                $j++;
            }
        }

        mysqli_free_result($result);
    }//if($result = mysql_query(ma_db_connexion(),$sql) or die('Erreur SQL getDetailPeripheralStatusCIM !<br>'.$sql.'<br>'.mysql_error()))
    mysqli_close($connexion);
            echo '</div>
                    </div>
                    </div>
                    </div>
                    </div>
                    </div>
                    </div>
                                                                                                                
            <!-- Modal footer -->
            <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>																							
	    </div>
	</div>';
							   
							   
}
/************************************************************************************************************/
function getDetailPeripheralStatusCIM2($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
     $connexion=ma_db_connexion();
     $service=7;
     $sql = "SELECT  `date_vacation`,  `logical_name` ,  `id_vacation` as vacationCDM, `id_logical_name` ,   `id_service`						
    FROM `".mysqli_real_escape_string($connexion,$tableVacation)."`
    WHERE `id_atm` ='".  mysqli_real_escape_string($connexion,$ATM)."'
    AND `id_vacation` IN(".mysqli_real_escape_string($connexion,$idVacation).")
    AND `fwDevice` <>3 ";
     //	 echo $sql;
    /***************************************************/
    $val=get_name_terminal_gag($ATM);
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1003:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 1003 !');
    }

    if ($result)
    {
							 $k=1;
							 
							 
							 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																									  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">GAB : '.$ATM.' - '.$val[0].' - '.$val[1].' -<strong style="font-size:18px;font-weight:bold;color:#e7722c" >  '.$nameVacation.' ('.$histDateVacation.')</strong></h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">
												<div class="accordion" id="accordionExample275">
												';

							   if (mysqli_num_rows($result)>0)
							   {	
									$j=0;
								$tableau_logical_autorise = array();
								$tableau_logical_autorise=get_list_logical_names_atm($ATM,$service);								
								// $tableau_logical_autorise=get_list_names_logical_names_atm($ATM,mysql_result($result,0,'id_service'));								
								while ($row = mysqli_fetch_assoc($result)) 
									{										
									// if (in_array(mysql_result($result,$j ,'logical_name'), $tableau_logical_autorise))
									if (in_array($row["id_logical_name"], $tableau_logical_autorise))		 
							
										{
											if ($module==1)
											{								
                                                $SQLLogical =" SELECT `id_vacation_logical`, `id_vacation`, `jLoop`, `usNumber`, `fwType`, `fwItemType`, `cUnitID`, 
                                                `cCurrencyID`, 	`ulValues`, `ulCashInCount`, `ulInitialCount`, `ulCount`, `ulMaximum`, `ulRejectCount`, `ulMinimum`, `bAppLock`, 
                                                `usStatus`, `usCDMType`, `ulDispensedCount`, `ulPresentedCount`, 
                                                `ulRetractedCount`, `usNumPhysicalCUs`, `lppPhysical`, `detailsPhysicalUnits` 
                                                FROM `vacations_CIM_cash_unit_logical` 
                                                WHERE `id_vacation` = '".mysqli_real_escape_string($connexion,$row["vacationCDM"])."'
                                                ";

											if($resLogical = mysqli_query($connexion,$SQLLogical) or die('Erreur SQL getDetailPeripheralStatusCIM2 2222222222  !<br>'.$SQLLogical.'<br>'.mysqli_error($connexion)))
												{							
											if (mysqli_num_rows($resLogical)>0)
													{																		   
														echo '								

													  <div class="card z-depth-0 bordered">
															<div class="card-header" id="heading'.$j.'" style="background-color:#e7722c;">
															  <h5 class="mb-0">
																<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse'.$j.'"
																  aria-expanded="true" aria-controls="collapse'.$j.'" >
																  <strong style="font-size:18px;font-weight:bold;color:#FFFFFF;" >'.$row["logical_name"].' </strong>
																  </button>
															  </h5>
															</div>
															<div id="collapse'.$j.'"';if ($k==1){ echo  'class="collapse in"';} else {echo  'class="collapse"';} echo 'aria-labelledby="heading'.$j.'" data-parent="#accordionExample275">
																	<div class="card-body" style="padding-left: 1px;right:0px;background-color:#f8f8f8;"  >';																		   
																				   
																			
																		   // echo "<strong style='font-size:14px;font-weight:bold;color:#e7722c' ><br><br><i class='material-icons'>Etat Cassette</i>  : </strong>";											   
																				while ($rowLogical = mysqli_fetch_assoc($resLogical)) 
																					{
																						echo '<br><strong style="font-size:15px;font-weight:bold;color:#e25300" > Cassette '.$k.' : </strong>';
																						
																				// echo " <br>------------------Logical -------------------- <br>";	
																				
																						$EtatCassetteLogical = array("Loop|jLoop-".$rowLogical["jLoop"],"Number|usNumber-".$rowLogical["usNumber"],
																						"fwType|fwType-".$rowLogical["fwType"],"ItemType|fwItemType-".$rowLogical["fwItemType"],
																						"UnitID|cUnitID-".$rowLogical["cUnitID"],"CashInCount|ulCashInCount-".$rowLogical["ulCashInCount"],
																						"CurrencyID|cCurrencyID-".$rowLogical["cCurrencyID"],"Values|ulValues-".$rowLogical["ulValues"],
																						"Initial Count|ulInitialCount-".$rowLogical["ulInitialCount"],"Count|ulCount-".$rowLogical["ulCount"],
																						"Maximum|ulMaximum-".$rowLogical["ulMaximum"],"CDMType|usCDMType-".$rowLogical["usCDMType"],
																						"Reject Count|ulRejectCount-".$rowLogical["ulRejectCount"],"Minimum|ulMinimum-".$rowLogical["ulMinimum"],
																						"AppLock|bAppLock-".$rowLogical["bAppLock"],"Status|usStatus-".$rowLogical["usStatus"],
																						"Dispensed Count|ulDispensedCount-".$rowLogical["ulDispensedCount"],"Presented Count|ulPresentedCount-".$rowLogical["ulPresentedCount"],
																						"Retracted Count|ulRetractedCount-".$rowLogical["ulRetractedCount"],"Num Physical CUs|usNumPhysicalCUs-".$rowLogical["usNumPhysicalCUs"],
																						"Physical|lppPhysical-".$rowLogical["lppPhysical"],"Details Physical Units|detailsPhysicalUnits-".$rowLogical["detailsPhysicalUnits"],
																						"Service|id_service-".$row["id_service"]);		

																						get_statut_gab($paramettre,$idprivilege,'xfs_errors_CIM','WFS_INF_CIM_CASH_UNIT_INFO',$EtatCassetteLogical,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,'CIM2',$histDateVacation,$histNameFile,$module,'',$row["id_service"],$row["id_logical_name"],$paramAffichage);	
																						
																									   
																				$k++;	
																					}

															echo'<br></div>
															</div>											
												  </div>';																			
													}	
											mysqli_free_result($resLogical);	
										}//if($resLogical = mysqli_query(ma_db_connexion(),$sql) or die('Erreur SQL getDetailPeripheralStatusCIM2 !<br>'.$sql.'<br>'.mysql_error()))
							   												
											}
										}
										$j++;
								   }
								}
										mysqli_free_result($result);	
										}//if($result = mysqli_query(ma_db_connexion(),$sql) or die('Erreur SQL getDetailPeripheralStatusCIM2 !<br>'.$sql.'<br>'.mysql_error()))
							   mysqli_close($connexion);
						echo '		</div>
										</div>
																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';	   
							     
							   
							   
}
/************************************************************************************************************/
/************************************************************************************************************/
function getDetailPeripheralStatusCHK($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
			/*	$sql = "SELECT `date_vacation`, `fwDevice` AS DeviceCHK , `fwMedia` AS MediaCHK ,
					       `fwInk` AS InkCHK , `dwGuidLights` AS GuidLightsCHK , `dwGuidLights_WFS_CHK_GUIDANCE_CHECKUNIT` AS GuidLights_WFS_CHK_GUIDANCE_CHECKUNITCHK , 
						   `usPowerSaveRecoveryTime` AS PowerSaveRecoveryTimeCHK , `wAntiFraudModule`  AS AntiFraudModuleCHK, `id_logical_name` ,  `logical_name` , `id_service`
							FROM `".$tableVacation."`
							WHERE `id_atm` ='".$ATM."'
							AND `id_vacation` IN(".$idVacation.")
							AND `fwDevice` <>3 ";		

		
								
								// echo $sql;
						$result = mysql_query($sql) or die('Erreur SQL getDetailPeripheralStatusCHK !<br>'.$sql.'<br>'.mysql_error());
							 $k=0;
							 
							 
							 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Détails    peripheral <strong style="font-size:18px;font-weight:bold;color:#e7722c" >: '.$nameVacation.' ('.mysql_result($result,$j ,'date_vacation').')</strong></h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">
												<div class="accordion" id="accordionExample275">';
												
												
						if (mysql_num_rows($result)>0)
							{	
								$tableau_logical_autorise = array();
								$tableau_logical_autorise=get_list_logical_names_atm($ATM,mysql_result($result,0,'id_service'));								
								// $tableau_logical_autorise=get_list_names_logical_names_atm($ATM,mysql_result($result,0,'id_service'));								
								for ($j=0; $j < mysql_num_rows($result) ; $j++)
									{										
									// if (in_array(mysql_result($result,$j ,'logical_name'), $tableau_logical_autorise))
									if (in_array(mysql_result($result,$j ,'id_logical_name'), $tableau_logical_autorise))
										{			
										$k++;	
										
										 $EtatPeripheral = array("Device|fwDevice-".mysql_result($result,$j  ,'DeviceCHK'),"MediaCHK|fwMedia-".mysql_result($result,$j  ,'MediaCHK'),
										"InkCHK|fwInk-".mysql_result($result,$j  ,'InkCHK'),"Device|GuidLightsCHK|dwGuidLights-".mysql_result($result,$j  ,'GuidLightsCHK'),
										"GuidLights_WFS_CHK_GUIDANCE_CHECKUNITCHK|dwGuidLights_WFS_CHK_GUIDANCE_CHECKUNIT-".mysql_result($result,$j  ,'GuidLights_WFS_CHK_GUIDANCE_CHECKUNITCHK'),
										"PowerSaveRecoveryTimeCHK|usPowerSaveRecoveryTime-".mysql_result($result,$j  ,'PowerSaveRecoveryTimeCHK'),"AntiFraudModuleCHK|wAntiFraudModule-".mysql_result($result,$j  ,'AntiFraudModuleCHK'),"Service|id_service-".mysql_result($result,$j ,'id_service'));										
									
										if ($module==2)
										{
											// getModuleDeclaration($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$category,$code_error,$logical_name,$paramAffichage);
										}	
									
										if ($module==1)
											{												
											echo '								

													  <div class="card z-depth-0 bordered">
															<div class="card-header" id="heading'.$j.'" style="background-color:#e7722c;">
															  <h5 class="mb-0">
																<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse'.$j.'"
																  aria-expanded="true" aria-controls="collapse'.$j.'" >
																  <strong style="font-size:18px;font-weight:bold;color:#FFFFFF;" >'.mysql_result($result,$j ,'logical_name').' </strong>
																  </button>
															  </h5>
															</div>
															<div id="collapse'.$j.'"';if ($j==0){ echo  'class="collapse in"';} else {echo  'class="collapse"';} echo 'aria-labelledby="heading'.$j.'" data-parent="#accordionExample275">
																	<div class="card-body" style="padding-left: 1px;right:0px;background-color:#f8f8f8;"  >';
													
													get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',mysql_result($result,0 ,'id_service'),mysql_result($result,$j ,'id_logical_name'),$paramAffichage);  
													
															echo'<br></div>
															</div>											
												  </div>';	
													
											}
										}
									}
							}
							   
						echo '		</div>
										</div>
																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';	   
							      
	*/
							   
}
/************************************************************************************************************/
function getDetailPeripheralStatusCEU($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
	
	
	/*
					$sql = "SELECT `date_vacation`, `vacations_CEU`.`fwDevice` as Device, `vacations_CEU`.`fwMedia` as Media, `vacations_CEU`.`fwRetainBin` as RetainBin,
							`vacations_CEU`.`fwOutputBin` as OutputBin, `vacations_CEU`.`fwInputBin` as InputBin, `vacations_CEU`.`usTotalCards` as TotalCards, `vacations_CEU`.`usOutputCards` as OutputCards, `vacations_CEU`.`usRetainCards` as RetainCards,
							`vacations_CEU`.`wDevicePosition` as DevicePosition, `vacations_CEU`.`usPowerSaveRecoveryTime` as PowerSaveRecoveryTime, `vacations_CEU`.`wToner` as Toner, `id_logical_name` ,  `logical_name` , `id_service`, 
							`vacations_CEU`.`wAntiFraudModule` as AntiFraudModule
								FROM `".$tableVacation."` 
								WHERE `id_atm` ='".$ATM."'
								AND `logical_name`   ='".$logical_name."'
								AND `fwDevice` <>3 ";			
								
								// echo $sql;

						$result = mysql_query($sql) or die('Erreur SQL getDetailPeripheralStatusCEU !<br>'.$sql.'<br>'.mysql_error());
							 $k=0;
							 
							 
							 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Détails    peripheral <strong style="font-size:18px;font-weight:bold;color:#e7722c" >: '.$nameVacation.' ('.mysql_result($result,$j ,'date_vacation').')</strong></h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">';
												
												
							   if (mysql_num_rows($result)>0)
							   {	
								for ($j=0; $j < mysql_num_rows($result) ; $j++)
									{			
										$k++;			
									
										 $EtatPeripheral = array("Device|fwDevice-".mysql_result($result,$j  ,'Device'),"Media|fwMedia-".mysql_result($result,$j  ,'Media'),
										"RetainBin|fwRetainBin-".mysql_result($result,$j  ,'RetainBin'),"OutputBin|fwOutputBin-".mysql_result($result,$j  ,'OutputBin'),"InputBin|fwInputBin-".mysql_result($result,$j  ,'InputBin'),
										"TotalCards|usTotalCards-".mysql_result($result,$j  ,'TotalCards'),"OutputCards|usOutputCards-".mysql_result($result,$j  ,'OutputCards'),"RetainCards|usRetainCards-".mysql_result($result,$j  ,'RetainCards'),
										"DevicePosition|wDevicePosition-".mysql_result($result,$j  ,'DevicePosition'),"PowerSaveRecoveryTime|usPowerSaveRecoveryTime-".mysql_result($result,$j  ,'PowerSaveRecoveryTime'),
										"Toner|wToner-".mysql_result($result,$j  ,'Toner'),"AntiFraudModule|wAntiFraudModule-".mysql_result($result,$j  ,'AntiFraudModule'));
										
											
								echo '								
								<div class="card-body table-responsive">
								  <table class="table table-hover">
									<thead class="text-warning">
									  <th><strong style="font-size:18px;font-weight:bold;color:#ffffff" >'.$nameVacation.'</strong></th>
									</thead>
									<tbody>
								<tr>					
											<td>';
											
											get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$module,$logical_name,$paramAffichage); 
											
										echo'</td>										
											</tr>
										  </tbody>
										</table>										
									</div>
											
											';	
											
									}
							   }
							   
						echo '		</div>
																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';	   
		*/
							   
}
/************************************************************************************************************/
function getDetailPeripheralStatusBCR($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
	
/*
					$sql = "SELECT `date_vacation`, `vacations_BCR`.`fwDevice` as Device, `vacations_BCR`.`fwBCRScanner` as BCRScanner, `vacations_BCR`.`dwGuidLights` as GuidLights, `vacations_BCR`.`dwGuidLights_WFS_BCR_GUIDANCE_BCR` as GuidLights_WFS_BCR_GUIDANCE_BCR,
							`vacations_BCR`.`wDevicePosition` as DevicePosition, `vacations_BCR`.`usPowerSaveRecoveryTime` as PowerSaveRecoveryTime, `vacations_BCR`.`wAntiFraudModule` as  AntiFraudModule, `id_logical_name` ,  `logical_name` , `id_service`
							FROM `".$tableVacation."`
							WHERE `id_atm` ='".$ATM."'
							AND `id_vacation` IN(".$idVacation.")
							AND `fwDevice` <>3 ";			
								
								// echo $sql;

						$result = mysql_query($sql) or die('Erreur SQL getDetailPeripheralStatusBCR !<br>'.$sql.'<br>'.mysql_error());
							 $k=0;
							 
							 
							 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Détails    peripheral <strong style="font-size:18px;font-weight:bold;color:#e7722c;" >: '.$nameVacation.' ('.mysql_result($result,$j ,'date_vacation').')</strong></h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">
												<div class="accordion" id="accordionExample275">';
												
												
						if (mysql_num_rows($result)>0)
							{	
								$tableau_logical_autorise = array();
								$tableau_logical_autorise=get_list_logical_names_atm($ATM,mysql_result($result,0,'id_service'));								
								// $tableau_logical_autorise=get_list_names_logical_names_atm($ATM,mysql_result($result,0,'id_service'));								
								for ($j=0; $j < mysql_num_rows($result) ; $j++)
									{										
									// if (in_array(mysql_result($result,$j ,'logical_name'), $tableau_logical_autorise))
									if (in_array(mysql_result($result,$j ,'id_logical_name'), $tableau_logical_autorise))
										{								
											   $k++;									
								    	       $EtatPeripheral =     array("Device|fwDevice-".mysql_result($result,$j  ,'Device'),"BCRScanner|fwBCRScanner-".mysql_result($result,$j  ,'BCRScanner'),
												"GuidLights|dwGuidLights-".mysql_result($result,$j  ,'GuidLights'),"GuidLights_WFS_BCR_GUIDANCE_BCR|dwGuidLights_WFS_BCR_GUIDANCE_BCR-".mysql_result($result,$j  ,'GuidLights_WFS_BCR_GUIDANCE_BCR'),
												"DevicePosition|wDevicePosition-".mysql_result($result,$j  ,'DevicePosition'),
												"PowerSaveRecoveryTime|usPowerSaveRecoveryTime-".mysql_result($result,$j  ,'PowerSaveRecoveryTime'),"AntiFraudModule|wAntiFraudModule-".mysql_result($result,$j  ,'AntiFraudModule'),"Service|id_service-".mysql_result($result,$j ,'id_service'));
																	

												if ($module==2)
												{
													// getModuleDeclaration($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$category,$code_error,$logical_name,$paramAffichage);
												}	
							
												if ($module==1)
													{												
														echo '								

															  <div class="card z-depth-0 bordered">
																	<div class="card-header" id="heading'.$j.'" style="background-color:#e7722c;">
																	  <h5 class="mb-0">
																		<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse'.$j.'"
																		  aria-expanded="true" aria-controls="collapse'.$j.'" >
																		  <strong style="font-size:18px;font-weight:bold;color:#FFFFFF;" >'.mysql_result($result,$j ,'logical_name').' </strong>
																		  </button>
																	  </h5>
																	</div>
																	<div id="collapse'.$j.'"';if ($j==0){ echo  'class="collapse in"';} else {echo  'class="collapse"';} echo 'aria-labelledby="heading'.$j.'" data-parent="#accordionExample275">
																			<div class="card-body" style="padding-left: 1px;right:0px;background-color:#f8f8f8;"  >';
															
															get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',mysql_result($result,0 ,'id_service'),mysql_result($result,$j ,'id_logical_name'),$paramAffichage);  
															
																	echo'<br></div>
																	</div>											
														  </div>';	
															
													}
										}
									}
							}
							   
						echo '		</div>
										</div>
																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';	   
							      
					*/
							   
}
/************************************************************************************************************/
function getDetailPeripheralStatusCAM($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
	
/*
					$sql = "SELECT `date_vacation`, `vacations_CAM`.`fwDevice` as Device, `vacations_CAM`.`fwMedia_WFS_CAM_ROOM` as Media_WFS_CAM_ROOM, `vacations_CAM`.`fwMedia_WFS_CAM_PERSON` as Media_WFS_CAM_PERSON, logical_name,
							`vacations_CAM`.`fwMedia_WFS_CAM_EXITSLOT` as Media_WFS_CAM_EXITSLOT, `vacations_CAM`.`usPictures` as Pictures, `vacations_CAM`.`wAntiFraudModule` as AntiFraudModule, `vacations_CAM`.`fwCameras_WFS_CAM_ROOM` as Cameras_WFS_CAM_ROOM, 
							`vacations_CAM`.`fwCameras_WFS_CAM_PERSON` as Cameras_WFS_CAM_PERSON, `vacations_CAM`.`fwCameras_WFS_CAM_EXITSLOT` as Cameras_WFS_CAM_EXITSLOT, `id_logical_name` ,  `logical_name` , `id_service`
							FROM `".$tableVacation."`
							WHERE `id_atm` ='".$ATM."'
							AND `id_vacation` IN(".$idVacation.")
							AND `fwDevice` <>3 ";					
								
								// echo $sql;

						$result = mysql_query($sql) or die('Erreur SQL getDetailPeripheralStatusCAM !<br>'.$sql.'<br>'.mysql_error());
							 $k=0;
							 
							 
							 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Détails    peripheral <strong style="font-size:18px;font-weight:bold;color:#e7722c;" >: '.$nameVacation.' ('.mysql_result($result,$j ,'date_vacation').')</strong></h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">
												<div class="accordion" id="accordionExample275">';
												
												
							   if (mysql_num_rows($result)>0)
							   {
								$tableau_logical_autorise = array();
								$tableau_logical_autorise=get_list_logical_names_atm($ATM,mysql_result($result,0,'id_service'));								
								// $tableau_logical_autorise=get_list_names_logical_names_atm($ATM,mysql_result($result,0,'id_service'));										   
								for ($j=0; $j < mysql_num_rows($result) ; $j++)
									{
									// if (in_array(mysql_result($result,$j ,'logical_name'), $tableau_logical_autorise))
									if (in_array(mysql_result($result,$j ,'id_logical_name'), $tableau_logical_autorise))										
										{
										
												$k++;			
											
											$EtatPeripheral =    array("Device|fwDevice-".mysql_result($result,$j  ,'Device'),"Media_WFS_CAM_ROOM|fwMedia_WFS_CAM_ROOM-".mysql_result($result,$j  ,'Media_WFS_CAM_ROOM'),
											"Media_WFS_CAM_PERSON|fwMedia_WFS_CAM_PERSON-".mysql_result($result,$j  ,'Media_WFS_CAM_PERSON'),"Media_WFS_CAM_EXITSLOT|fwMedia_WFS_CAM_EXITSLOT-".mysql_result($result,$j  ,'Media_WFS_CAM_EXITSLOT'),"Pictures|usPictures-".mysql_result($result,$j  ,'Pictures'),
											"AntiFraudModule|wAntiFraudModule-".mysql_result($result,$j  ,'AntiFraudModule'),"Cameras_WFS_CAM_ROOM|fwCameras_WFS_CAM_ROOM-".mysql_result($result,$j  ,'Cameras_WFS_CAM_ROOM'),"Cameras_WFS_CAM_PERSON|fwCameras_WFS_CAM_PERSON-".mysql_result($result,$j  ,'Cameras_WFS_CAM_PERSON'),
											"Cameras_WFS_CAM_EXITSLOT|fwCameras_WFS_CAM_EXITSLOT-".mysql_result($result,$j  ,'Cameras_WFS_CAM_EXITSLOT'),"Service|id_service-".mysql_result($result,$j ,'id_service'));	
												

											if ($module==2)
											{
												// getModuleDeclaration($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$category,$code_error,$logical_name,$paramAffichage);
											}	
									
											if ($module==1)
												{												
											echo '	  <div class="card z-depth-0 bordered">
																<div class="card-header" id="heading'.$j.'" style="background-color:#e7722c;">
																  <h5 class="mb-0">
																	<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse'.$j.'"
																	  aria-expanded="true" aria-controls="collapse'.$j.'" >
																	  <strong style="font-size:18px;font-weight:bold;color:#FFFFFF;" >'.mysql_result($result,$j ,'logical_name').' </strong>
																	  </button>
																  </h5>
																</div>
																<div id="collapse'.$j.'"';if ($j==0){ echo  'class="collapse in"';} else {echo  'class="collapse"';} echo 'aria-labelledby="heading'.$j.'" data-parent="#accordionExample275">
																		<div class="card-body" style="padding-left: 1px;right:0px;background-color:#f8f8f8;"  >';
														
														get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',mysql_result($result,0 ,'id_service'),mysql_result($result,$j ,'id_logical_name'),$paramAffichage);  
														
																echo'<br></div>
																</div>											
													  </div>';	
														
												}
										}
									}
								}
							   
						echo '		</div>
										</div>
																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';	   
							      
						*/
							   
}
/************************************************************************************************************/
function getDetailPeripheralStatusALM($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{

    /*
					$sql = "SELECT `date_vacation`, `vacations_ALM`.`fwDevice` AS Device, `vacations_ALM`.`bAlarmSet` AS AlarmSet, `vacations_ALM`.`wAntiFraudModule` AS AntiFraudModule , `id_logical_name` ,  `logical_name` , `id_service`
							FROM `".$tableVacation."`
							WHERE `id_atm` ='".$ATM."'
							AND `id_vacation` IN(".$idVacation.")
							AND `fwDevice` <>3 ";	
								// echo $sql;
						$result = mysql_query($sql) or die('Erreur SQL getDetailPeripheralStatusALM !<br>'.$sql.'<br>'.mysql_error());
							 $k=0;
							 
							 
							 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Détails    peripheral <strong style="font-size:18px;font-weight:bold;color:#e7722c;" >: '.$nameVacation.' ('.mysql_result($result,$j ,'date_vacation').')</strong></h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">
												<div class="accordion" id="accordionExample275">';
												
												
							   if (mysql_num_rows($result)>0)
							   {	
								for ($j=0; $j < mysql_num_rows($result) ; $j++)
									{			
										$k++;			
									
										$EtatPeripheral =   array("Device|fwDevice-".mysql_result($result,$j ,'Device'),"AlarmSet|bAlarmSet-".mysql_result($result,$j ,'AlarmSet'),
										"AntiFraudModule|wAntiFraudModule-".mysql_result($result,$j ,'AntiFraudModule'),"Service|id_service-".mysql_result($result,$j ,'id_service'));	
										

									if ($module==2)
									{
										// getModuleDeclaration($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$category,$code_error,$logical_name,$paramAffichage);
									}	
																
									if ($module==1)
									{												
								echo '								

											  <div class="card z-depth-0 bordered">
													<div class="card-header" id="heading'.$j.'" style="background-color:#e7722c;">
													  <h5 class="mb-0">
														<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse'.$j.'"
														  aria-expanded="true" aria-controls="collapse'.$j.'" >
														  <strong style="font-size:18px;font-weight:bold;color:#FFFFFF;" >'.mysql_result($result,$j ,'logical_name').' </strong>
														  </button>
													  </h5>
													</div>
													<div id="collapse'.$j.'"';if ($j==0){ echo  'class="collapse in"';} else {echo  'class="collapse"';} echo 'aria-labelledby="heading'.$j.'" data-parent="#accordionExample275">
															<div class="card-body" style="padding-left: 1px;right:0px;background-color:#f8f8f8;"  >';
											
											get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',mysql_result($result,0 ,'id_service'),mysql_result($result,$j ,'id_logical_name'),$paramAffichage);  
											
													echo'<br></div>
													</div>											
										  </div>';	
											
									}
							   }
}
							   
						echo '		</div>
										</div>
																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';	   
				*/
							   
							   
}
/********************************************************************************************************************************************/			
function getListStatusLogicalNameATM2($id,$id_service,$logical_name,$libelle_service)
{
    $conn= ma_db_connexion();
	$status_logical = array();		
	$sql = "SELECT  `all_id` FROM `config_".  mysqli_real_escape_string($conn,$libelle_service)."` WHERE `id_atm` = '".  mysqli_real_escape_string($conn,$id)."'  GROUP BY `id_logical_name`";
	// echo ' ID LOGICAL '.$logical_name;
	// echo $sql;	
    mysqli_query($conn,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($conn,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1004:  ".$sql."  " .mysqli_error($conn));
        die(' ERREUR QUERY 1004 !');
    }

    if ($result)
	{
			   if (mysqli_num_rows($result)>0)
				    {
				        $j=0;
						while ($row = mysqli_fetch_assoc($result)) 
						 {
						// return  mysql_result($result,0,'id_regle_alerte');		
							 $status_logical[$j]=$row["all_id"];	
							 $j++;
						 }//while ($row = mysqli_fetch_assoc($result)) 
				    } //if (mysqli_num_rows($result)>0)
				else
					{
							 $status_logical[0]='';				
					}
	mysqli_free_result($result);				
	}//if ($result=mysqli_query(ma_db_connexion(),$sql) or die('Erreur   getListStatusLogicalNameATM !<br>'.$sql.'<br>'.mysql_error()))
    mysqli_close($conn);
    return $status_logical;
}
/********************************************************************************************************************************************/			
function getListStatusLogicalNameATM($id,$id_service,$logical_name)
{

    $connexion=ma_db_connexion();
	$status_logical = array();		
	$sql = "SELECT  `all_id` FROM `".  mysqli_real_escape_string($connexion,get_libelle_list_config_service($id_service))."` WHERE `id_atm` = '".  mysqli_real_escape_string($connexion,$id)."' 
	AND `id_logical_name`= '".  mysqli_real_escape_string($connexion,$logical_name)."' GROUP BY `id_logical_name`";
	// echo ' ID LOGICAL '.$logical_name;

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1005:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 1005 !'.mysqli_error($connexion));
    }
    if ($result)
	{
			   if (mysqli_num_rows($result)>0)
				    {$j=0;
						while ($row = mysqli_fetch_assoc($result)) 
						 {
						// return  mysql_result($result,0,'id_regle_alerte');		
							 $status_logical[$j]=$row["all_id"];
							 $j++;
						 }
				    } 
				else
					{
							 $status_logical[0]='';				
					}
	mysqli_free_result($result);				
	}//if ($result=mysqli_query(ma_db_connexion(),$sql) or die('Erreur   getListStatusLogicalNameATM !<br>'.$sql.'<br>'.mysql_error()))
    mysqli_close($connexion);
				return $status_logical;

}
/************************************************************************************************************/
function getEtatPeripherique($paramettre,$idprivilege,$category,$stat_verif,$supervised,$code_error,$message,$message_fr,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$id_service,$logical_name,$paramAffichage,$id_error,$EtatPeripheral,$tableau_xfs_erreur_autorise2)
{

    if ($_SESSION['lang']=='fr')
    {
        $msg=$message_fr;
    }
    else
    {
        $msg=$message;
    }
    $conn=ma_db_connexion();
    $tableXFSError = array();
    $XFSErrorATMAutorise = explode(',', $tableau_xfs_erreur_autorise2);
    foreach($XFSErrorATMAutorise as $XFSError)
    {
            $tableXFSError[] = $XFSError;
    }



    if (($stat_verif==1) && ($supervised==1))
    {
        $SQL1 = "SELECT `color_status` FROM `xfs_errors_STATUS` WHERE `id_status` =  1 ";

        mysqli_query($conn,"SET CHARACTER SET 'utf8'");
        $result=mysqli_query($conn,$SQL1);
        if (!$result)
        {
            error_log("Erreur SQL 1006:  ".$SQL1."  " .mysqli_error($conn));
            die(' ERREUR QUERY 1006 !');
        }
        if ($result)
        {

            if (mysqli_num_rows($result)>0)
            {
                while ($row = mysqli_fetch_assoc($result))
                {

                    if ($paramAffichage==1)//CAS d'affichage success
                    {
                        echo "<tr><td><strong style='font-size:12px;font-weight:bold;' >".$category."  </strong> </td><td>".$msg."</td><td>".$row["color_status"]."</td>";
                        if ($idprivilege==1)
                        { // CAS 1 XFS ERROR Désactivé
                            if (in_array($id_error, $tableXFSError))//Verifications xfs_erreur config
                            {
                                echo ' <td><a tabindex="-1"  data-toggle="modal" 
								onClick="javascript:updateXFSErrors(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$ATM.'\',
                                \''.$idVacation.'\',
                                \''.$tableVacation.'\',
                                \''.$xfsErreur.'\',
                                \''.$xfsStatus.'\',
                                \''.$nameVacation.'\',
                                \'\',
                                \'\',
                                \'\',
                                \'\',
                                \''.$logical_name.'\',
                                \''.$paramAffichage.'\',
                                \''.$id_service.'\',											
                                \''.$id_error.'\',0)" >
                                <strong style="font-size:18px;font-weight:bold;color:#009e28" >  <i class="fa fa-check" title="Désactivé"></i></strong></a></td>';
                            }
                            else
							{
							    // CAS 2 XFS ERROR Désactivé

                                echo ' <td><a tabindex="-1"  data-toggle="modal" 
                                onClick="javascript:updateXFSErrors(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$ATM.'\',
                                \''.$idVacation.'\',
                                \''.$tableVacation.'\',
                                \''.$xfsErreur.'\',
                                \''.$xfsStatus.'\',
                                \''.$nameVacation.'\',
                                \'\',
                                \'\',
                                \'\',
                                \'\',
                                \''.$logical_name.'\',
                                \''.$paramAffichage.'\',
                                \''.$id_service.'\',											
                                \''.$id_error.'\',1)" >
                                <strong style="font-size:18px;font-weight:bold;color:#FF0040" >  <i class="fa fa-close" title="Activé"></i></strong></a></td>';
							}
                        }
                        echo '</tr>';
                    }

                }//while ($row = mysqli_fetch_assoc($result))
            }
            mysqli_free_result($result);
        }	//if ($result=mysqli_query(ma_db_connexion(),$SQL1) or die('Erreur   SQL1 getEtatPeripherique !<br>'.$SQL1.'<br>'.mysql_error()))
    }
    else if (($stat_verif==0) && ($supervised==1))
    {
        $SQL1 = "SELECT `color_status` FROM `xfs_errors_STATUS` WHERE `id_status` =  0 ";
        $result=mysqli_query($conn,$SQL1);
        if (!$result)
        {
            error_log("Erreur SQL 1007:  ".$SQL1."  " .mysqli_error($conn));
            die(' ERREUR QUERY 1007 !');
        }
        if ($result)
        {
            if (mysqli_num_rows($result)>0)
            {
                while ($row = mysqli_fetch_assoc($result))
                {
                    echo "<tr><td><strong style='font-size:12px;font-weight:bold;' >".$category."  </strong></td><td>".$msg."</td><td>".$row["color_status"]."</td>";
							   
                    //PARTIE ADMIN autorisé XFS erreur
                    if ($idprivilege==1)
                    { // CAS 1 XFS ERROR Désactivé
                        if (in_array($id_error, $tableXFSError))//Verifications xfs_erreur config
                        {
                            echo ' <td><a tabindex="-1"  data-toggle="modal" 
                            onClick="javascript:updateXFSErrors(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$ATM.'\',
                            \''.$idVacation.'\',
                            \''.$tableVacation.'\',
                            \''.$xfsErreur.'\',
                            \''.$xfsStatus.'\',
                            \''.$nameVacation.'\',
                            \'\',
                            \'\',
                            \'\',
                            \'\',
                            \''.$logical_name.'\',
                            \''.$paramAffichage.'\',
                            \''.$id_service.'\',											
                            \''.$id_error.'\',0)" >
                            <strong style="font-size:18px;font-weight:bold;color:#009e28" >  <i class="fa fa-check" title="Désactivé"></i></strong></a></td>';
                        }
                        else
                        {
                            // CAS 2 XFS ERROR Désactivé
                            echo '<td><a tabindex="-1"  data-toggle="modal" 
                            onClick="javascript:updateXFSErrors(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$ATM.'\',
                            \''.$idVacation.'\',
                            \''.$tableVacation.'\',
                            \''.$xfsErreur.'\',
                            \''.$xfsStatus.'\',
                            \''.$nameVacation.'\',
                            \'\',
                            \'\',
                            \'\',
                            \'\',
                            \''.$logical_name.'\',
                            \''.$paramAffichage.'\',
                            \''.$id_service.'\',											
                            \''.$id_error.'\',1)" >
                            <strong style="font-size:18px;font-weight:bold;color:#FF0040" >  <i class="fa fa-close" title="Activé"></i></strong></a></td>';
                        }
                    }
                    echo '</tr>';

                }
            }
        }
    }
    mysqli_close($conn);

}
function getEtatPeripherique1($paramettre,$idprivilege,$category,$stat_verif,$supervised,$code_error,$message,$message_fr,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$id_service,$logical_name,$paramAffichage,$id_error,$EtatPeripheral,$tableau_xfs_erreur_autorise2)
{

    $msssg=$message;
    if ($_SESSION['lang']=="fr")
    {
        $msssg=$message_fr;
    }
    //var_dump($category);echo "<br>";
    $conn=ma_db_connexion();
    $tableXFSError = array();
    $XFSErrorATMAutorise = explode(',', $tableau_xfs_erreur_autorise2);
    foreach($XFSErrorATMAutorise as $XFSError)
    {
            $tableXFSError[] = $XFSError;
    }


    if (($stat_verif==1) && ($supervised==1))
    {
        $SQL1 = "SELECT `color_status` FROM `xfs_errors_STATUS` WHERE `id_status` =  1 ";
        mysqli_query($conn,"SET CHARACTER SET 'utf8'");
        $result=mysqli_query($conn,$SQL1);
        if (!$result)
        {
            error_log("Erreur SQL 1006:  ".$SQL1."  " .mysqli_error($conn));
            die(' ERREUR QUERY 1006 !');
        }
        if ($result)
        {
            if (mysqli_num_rows($result)>0)
            {
                while ($row = mysqli_fetch_assoc($result))
                {

                    if ($paramAffichage==1 )//CAS d'affichage success
                    {
                        //var_dump($paramAffichage);
                        echo "<td>".$msssg."</td>";
                        if ($category<>"fwType")
                        {
                            echo "<td>".$row["color_status"]."</td>";
                        }
                        if ($idprivilege==1 && ($category<>"fwType"))
                        { // CAS 1 XFS ERROR Désactivé
                            if (in_array($id_error, $tableXFSError))//Verifications xfs_erreur config
                            {
                                echo ' <td><a tabindex="-1"  data-toggle="modal" 
								onClick="javascript:updateXFSErrors(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$ATM.'\',
                                \''.$idVacation.'\',
                                \''.$tableVacation.'\',
                                \''.$xfsErreur.'\',
                                \''.$xfsStatus.'\',
                                \''.$nameVacation.'\',
                                \'\',
                                \'\',
                                \'\',
                                \'\',
                                \''.$logical_name.'\',
                                \''.$paramAffichage.'\',
                                \''.$id_service.'\',											
                                \''.$id_error.'\',0)" >
                                <strong style="font-size:18px;font-weight:bold;color:#009e28" >  <i class="fa fa-check" title="Désactivé"></i></strong></a></td>';
                            }
                            else
							{
							    // CAS 2 XFS ERROR Désactivé

                                echo ' <td><a tabindex="-1"  data-toggle="modal" 
                                onClick="javascript:updateXFSErrors(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$ATM.'\',
                                \''.$idVacation.'\',
                                \''.$tableVacation.'\',
                                \''.$xfsErreur.'\',
                                \''.$xfsStatus.'\',
                                \''.$nameVacation.'\',
                                \'\',
                                \'\',
                                \'\',
                                \'\',
                                \''.$logical_name.'\',
                                \''.$paramAffichage.'\',
                                \''.$id_service.'\',											
                                \''.$id_error.'\',1)" >
                                <strong style="font-size:18px;font-weight:bold;color:#FF0040" >  <i class="fa fa-close" title="Activé"></i></strong></a></td>';											}
                        }

                    }

                }//while ($row = mysqli_fetch_assoc($result))
            }
            mysqli_free_result($result);
        }	//if ($result=mysqli_query(ma_db_connexion(),$SQL1) or die('Erreur   SQL1 getEtatPeripherique !<br>'.$SQL1.'<br>'.mysql_error()))
    }
    else if (($stat_verif==0) && ($supervised==1) )
    {
        $SQL1 = "SELECT `color_status` FROM `xfs_errors_STATUS` WHERE `id_status` =  0 ";
        $result=mysqli_query($conn,$SQL1);
        if (!$result)
        {
            error_log("Erreur SQL 1007:  ".$SQL1."  " .mysqli_error($conn));
            die(' ERREUR QUERY 1007 !');
        }
        if ($result)
        {
            if (mysqli_num_rows($result)>0)
            {
                while ($row = mysqli_fetch_assoc($result))
                {
                    echo "<td>".$msssg."</td>";
                    if ($category<>"fwType")
                    {
                        echo "<td>".$row["color_status"]."</td>";
                    }

                    //PARTIE ADMIN autorisé XFS erreur
                    if ($idprivilege==1 && $category<>"fwType")
                    { // CAS 1 XFS ERROR Désactivé
                        if (in_array($id_error, $tableXFSError))//Verifications xfs_erreur config
                        {
                            echo ' <td><a tabindex="-1"  data-toggle="modal" 
                            onClick="javascript:updateXFSErrors(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$ATM.'\',
                            \''.$idVacation.'\',
                            \''.$tableVacation.'\',
                            \''.$xfsErreur.'\',
                            \''.$xfsStatus.'\',
                            \''.$nameVacation.'\',
                            \'\',
                            \'\',
                            \'\',
                            \'\',
                            \''.$logical_name.'\',
                            \''.$paramAffichage.'\',
                            \''.$id_service.'\',											
                            \''.$id_error.'\',0)" >
                            <strong style="font-size:18px;font-weight:bold;color:#009e28" >  <i class="fa fa-check" title="Désactivé"></i></strong></a></td>';
                        }
                        else
                        {
                            // CAS 2 XFS ERROR Désactivé
                            echo '<td><a tabindex="-1"  data-toggle="modal" 
                            onClick="javascript:updateXFSErrors(\''.$paramettre.'\',\''.$idprivilege.'\',\''.$ATM.'\',
                            \''.$idVacation.'\',
                            \''.$tableVacation.'\',
                            \''.$xfsErreur.'\',
                            \''.$xfsStatus.'\',
                            \''.$nameVacation.'\',
                            \'\',
                            \'\',
                            \'\',
                            \'\',
                            \''.$logical_name.'\',
                            \''.$paramAffichage.'\',
                            \''.$id_service.'\',											
                            \''.$id_error.'\',1)" >
                            <strong style="font-size:18px;font-weight:bold;color:#FF0040" >  <i class="fa fa-close" title="Activé"></i></strong></a></td>';
                        }
                    }


                }
            }
        }
    }
    mysqli_close($conn);

}
/************************************************************************************************************/
// get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,
// $xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$module,mysql_result($result,$j ,'logical_name'),$paramAffichage);

function get_statut_cdm($category1,$category,$value_category)
{
			 if ($category=='montant')
					{
					   // var_dump("category : ".$category);
					echo "<tr><td><strong style='font-size:12px;font-weight:bold;color:#e7722c' >".$category1."  </strong></td><td colspan=2>".$value_category. " </td></tr>";
					}
			 if ($category=='ulDispensedCount')
					{
					echo "<tr><td><strong style='font-size:12px;font-weight:bold;color:#e7722c' >".$category1."  </strong></td><td colspan=2>".$value_category. "</td></tr>";	
					}	
			 if ($category=='ulPresentedCount')
					{
					echo "<tr><td><strong style='font-size:12px;font-weight:bold;color:#e7722c' >".$category1."  </strong></td><td colspan=2>".$value_category. "</td></tr>";	
					}
			 if ($category=='ulRetractedCount')
					{
					echo "<tr><td><strong style='font-size:12px;font-weight:bold;color:#e7722c' >".$category1."  </strong></td><td colspan=2>".$value_category. "</td></tr>";	
					}	
			 if ($category=='ulValues')
					{
					echo "<tr><td><strong style='font-size:12px;font-weight:bold;color:#e7722c' >".$category1."  </strong></td><td colspan=2>".$value_category. "</td></tr>";	
					}	
			 if ($category=='ulRejectCount')
					{
					echo "<tr><td><strong style='font-size:12px;font-weight:bold;color:#e7722c' >".$category1."  </strong></td><td colspan=2>".$value_category. "</td></tr>";	
					}	
					
}	
function get_statut_cim($category1,$category,$value_category)
{
 if ($category=='ulCashInCount')
 {
     echo "<tr><td><strong style='font-size:12px;font-weight:bold;color:#e7722c' >".$category1."  </strong></td><td colspan=2>".$value_category. "</td></tr>";
 }

 if ($category=='ulInitialCount')
 {
     echo "<tr><td> <strong style='font-size:12px;font-weight:bold;color:#e7722c' >".$category1." </strong></td><td colspan=2>".$value_category. "</td></tr>";
 }

}										
function get_statut_gab($paramettre,$idprivilege,$table,$cmd,$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$id_service,$logical_name,$paramAffichage)
{
    $link=ma_db_connexion();
    //echo "<pre>";print_r($EtatPeripheral);"</pre>";
    foreach($EtatPeripheral as $cle2 => $valeur2)
    {

        list($category1, $Etat_category) = explode('|',  $valeur2);
        list($category, $value_category) = explode('-',  $Etat_category);
        if ($category=="id_service")
        {
             /*$tableau_logical_autorise2=getListStatusLogicalNameATM($ATM,$value_category,$logical_name);
             echo $EtatPeripheral." ============== ".$value_category.' -- '.$ATM.'<br>';*/
        }
    }
    //var_dump($category);
   // $conn=ma_db_connexion();
    $tableau_logical_autorise2=getListStatusLogicalNameATM($ATM,$id_service,$logical_name);

    //var_dump($tableau_logical_autorise2[0]);
    echo ' <div class="table-responsive">
        <table class="table table-responsive-sm table-hover table-outline mb-0">';


            foreach ($EtatPeripheral AS $Etat)
            {

                list($category1, $Etat_category) = explode('|',  $Etat);
                list($category, $value_category) = explode('-',  $Etat_category);

           /*     var_dump("cmd : ".$cmd);echo "<br>";
                var_dump("Etat : ".$Etat);echo "<br>";
                var_dump("category1 : ".$category1);echo "<br>";
                var_dump("category : ".$category);echo "<br>";
                var_dump("Etat_category : ".$Etat_category);echo "<br><br>";*/

                if (($table=="xfs_errors_CIM") && ($nameVacation=="CIM2")){get_statut_cim($category1,$category,$value_category);}
                if (($table=="xfs_errors_CDM") && ($nameVacation=="CDM2")){get_statut_cdm($category1,$category,$value_category);}

                if($tableau_logical_autorise2[0]<>"")
                {
                    // echo "TEST";
                    $sql = "SELECT  `id_error`, `cmd`, `category`, `code_error`, `value`, `supervised`, `value_dec`, `message`, `message_fr` , `stat_verif` ,`code_error`
                    FROM `".  mysqli_real_escape_string($link,$table)."` 
                    WHERE  `cmd` ='".  mysqli_real_escape_string($link,addslashes($cmd))."' AND `category` ='".mysqli_real_escape_string($link,addslashes($category))."' 
                    AND  `value`  ='".mysqli_real_escape_string($link,intval($value_category,10))."'";

                    if ($idprivilege==0)
                    {
                        $sql = $sql." AND `id_error` IN(".$tableau_logical_autorise2[0].")";
                    }
                    //echo $sql; echo " ; <br>";

                    mysqli_query($link,"SET CHARACTER SET 'utf8'");

                    $result=mysqli_query($link,$sql);
                    if (!$result)
                    {
                        error_log("Erreur SQL 1008:  ".$sql."  " .mysqli_error($link));
                        die(' ERREUR QUERY 1008 !');
                    }

                    if ($result)
                    {
                        //var_dump(mysqli_num_rows($result)."<br>");
                        if (mysqli_num_rows($result)>0)
                        {
                            //var_dump(mysqli_num_rows($result));
                            while ($row = mysqli_fetch_assoc($result))
                            {
                                echo  getEtatPeripherique($paramettre,$idprivilege,$category1,$row["stat_verif"],$row["supervised"],$row["code_error"],$row["message"],$row["message_fr"],$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$id_service,$logical_name,$paramAffichage,$row["id_error"],$EtatPeripheral,$tableau_logical_autorise2[0]);
                            }
                        }
                        mysqli_free_result($result);
                    }

                }

            }// FIN foreach
        echo '</table>
	</div>';
 mysqli_close($link);
}
function get_statut_gab1($paramettre,$idprivilege,$table,$cmd,$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$id_service,$logical_name,$paramAffichage,$usType)
{
    include "../languages/" . $_SESSION['lang'] . ".php";

    $link=ma_db_connexion();
    $tableau_logical_autorise2=getListStatusLogicalNameATM($ATM,$id_service,$logical_name);
    $j=0;
    //echo "<pre>";print_r($EtatPeripheral);"</pre>";
    echo "<tr>";
    foreach ($EtatPeripheral AS $Etat)
    {
        $j++;
        list($category1, $Etat_category) = explode('|',  $Etat);
        list($category, $value_category) = explode('-',  $Etat_category);

       // var_dump($table);echo "<br>";
       // var_dump($nameVacation);echo "<br>";
        if (($table=="xfs_errors_CIM") && ($nameVacation=="CIM")){get_statut_cim($category1,$category,$value_category);}


        if ($category=='montant')
        {
            if ($usType==3)
            {
                echo " <td>" .number_format($value_category,2,'.',','). ' MGA'."</td>";
                //echo " <td>" .$value_category."</td>";
            }
            else
            {
                if ($value_category<>0)
                {
                    //echo " <td>" .$value_category."</td>";
                    echo " <td>" .number_format($value_category,2,'.',','). ' MGA'."</td>";
                }
                else
                {
                    echo "<td>---</td>";
                }
            }

        }
        if ($category=='ulValues')
        {
            if ($value_category==0)
            {
                $value_category=$lang['rejet'];
            }
            $value_category=$lang['cassettes']." ".$value_category;
            echo "<td >".$value_category. "</td>";
        }
        if ($category=='usStatus')
        {
            $cat=$category;
            $val_cat=$value_category;
        }


        //var_dump("EtatPeripheral : ".$EtatPeripheral[10]);echo "<br>";
        if ($category=='id_service')
        {
            if($tableau_logical_autorise2[0] <> "")
            {
                //echo 	"TEST <br>";
                $sql = "SELECT  `id_error`, `cmd`, `category`, `code_error`, `value`, `supervised`, `value_dec`, `message`, `message_fr` , `stat_verif` ,`code_error`
                FROM `".  mysqli_real_escape_string($link,$table)."` 
                WHERE  `cmd` ='".  mysqli_real_escape_string($link,addslashes($cmd))."' 	AND  `category` ='".mysqli_real_escape_string($link,addslashes($cat))."' 
                AND  `value`  ='".mysqli_real_escape_string($link,addslashes($val_cat))."'";

                //var_dump($sql);echo"<br><br>";
                if ($idprivilege==0)
                {
                    $sql = $sql." AND `id_error` IN(".$tableau_logical_autorise2[0].")";
                }

                mysqli_query($link,"SET CHARACTER SET 'utf8'");
                $result=mysqli_query($link,$sql);
                if (!$result)
                {
                    error_log("Erreur SQL 1008:  ".$sql."  " .mysqli_error($link));
                    die(' ERREUR QUERY 1008 !');
                }

                if ($result)
                {

                    if (mysqli_num_rows($result)>0)
                    {
                        while ($row = mysqli_fetch_assoc($result))
                        {
                            echo  getEtatPeripherique1($paramettre,$idprivilege,$category1,$row["stat_verif"],$row["supervised"],$row["code_error"],$row["message"],$row["message_fr"],$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$id_service,$logical_name,$paramAffichage,$row["id_error"],$EtatPeripheral,$tableau_logical_autorise2[0]);
                        }
                    }
                    mysqli_free_result($result);
                }
            }
        }

    }// FIN foreach
    echo '</tr>';
 mysqli_close($link);
}
/************************************************************************************************************/
function get_statut_gab2($paramettre,$idprivilege,$table,$cmd,$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$id_service,$logical_name,$paramAffichage)
{
    $link=ma_db_connexion();
    $tableau_logical_autorise2=getListStatusLogicalNameATM($ATM,$id_service,$logical_name);
    $j=0;
    //echo "<pre>";print_r($EtatPeripheral);"</pre>";
    echo "<tr>";
    foreach ($EtatPeripheral AS $Etat)
    {
        $j++;
        list($category1, $Etat_category) = explode('|',  $Etat);
        list($category, $value_category) = explode('-',  $Etat_category);

        // var_dump($table);echo "<br>";
        // var_dump($nameVacation);echo "<br>";

        if ($category=='ulCashInCount')
        {
            echo "<td >" .$value_category."</td>";
        }

        if($tableau_logical_autorise2[0] <> "")
        {
            //echo 	"TEST \n";
            $sql = "SELECT  `id_error`, `cmd`, `category`, `code_error`, `value`, `supervised`, `value_dec`, `message`, `message_fr` , `stat_verif` ,`code_error`
            FROM `".  mysqli_real_escape_string($link,$table)."` 
            WHERE  `cmd` ='".  mysqli_real_escape_string($link,addslashes($cmd))."' 	AND  `category` ='".mysqli_real_escape_string($link,addslashes($category))."' 
            AND  `value`  ='".mysqli_real_escape_string($link,addslashes($value_category))."'";

            //var_dump($sql);echo"<br><br>";
            if ($idprivilege==0)
            {
                $sql = $sql." AND `id_error` IN(".$tableau_logical_autorise2[0].")";
            }

            mysqli_query($link,"SET CHARACTER SET 'utf8'");
            $result=mysqli_query($link,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 1008:  ".$sql."  " .mysqli_error($link));
                die(' ERREUR QUERY 1008 !');
            }

            if ($result)
            {

                //var_dump(mysqli_num_rows($result));
                if (mysqli_num_rows($result)>0)
                {
                    while ($row = mysqli_fetch_assoc($result))
                    {
                        echo  getEtatPeripherique1($paramettre,$idprivilege,$category1,$row["stat_verif"],$row["supervised"],$row["code_error"],$row["message"],$row["message_fr"],$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$id_service,$logical_name,$paramAffichage,$row["id_error"],$EtatPeripheral,$tableau_logical_autorise2[0]);
                    }
                }
                mysqli_free_result($result);
            }
        }

    }// FIN foreach
    echo '</tr>';
    mysqli_close($link);
}

/************************************************************************************************************/
function getDetailPeripheralStatusPTR2($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
	
	/*
						$sql = "SELECT  `date_vacation`, `fwDevice` as DevicePTR,`fwMedia` as MediaPTR, `usRetractCount` as RetractCountPTR, `wRetractBin` as RetractBinPTR	, `id_logical_name` ,  `logical_name` , `id_service`						
								FROM `".$tableVacation."` 
								WHERE `id_atm` ='".$ATM."'
								AND `logical_name`   ='".$logical_name."'
								AND `fwDevice` <>3 ";							
								

						$result = mysql_query($sql) or die('Erreur SQL getDetailPeripheralStatusPTR2 !<br>'.$sql.'<br>'.mysql_error());
							 $k=0;
							 
							 
							 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Détails    peripheral <strong style="font-size:18px;font-weight:bold;color:#e7722c" >: '.$nameVacation.' ('.mysql_result($result,$j ,'date_vacation').')</strong></h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">';
												
												
							   if (mysql_num_rows($result)>0)
							   {	
								for ($j=0; $j < mysql_num_rows($result) ; $j++)
									{			
										$k++;			
									
									$EtatPeripheral = array("Device|fwDevice-".mysql_result($result,$j ,'DevicePTR'),"Media|fwMedia-".mysql_result($result,$j ,'MediaPTR'),
									"Retract Count|usRetractCount-".mysql_result($result,$j ,'RetractCountPTR'),"Retract Bin|wRetractBin-".mysql_result($result,$j ,'RetractBinPTR'));							
								
if ($module==2)
{
	// getModuleDeclaration($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$category,$code_error,$logical_name,$paramAffichage);
}	
							
if ($module==1)
{								
								echo '								
								<div class="card-body table-responsive">
								  <table class="table table-hover">
									<thead class="text-warning">
									  <th><strong style="font-size:18px;font-weight:bold;color:#ffffff" >'.$nameVacation.'</strong></th>
									</thead>
									<tbody>
								<tr>					
											<td>';
											
											get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$module,$logical_name,$paramAffichage); 
											
										echo'</td>										
											</tr>
										  </tbody>
										</table>										
									</div>
											
											';	
											
									}
							   }
}
							   
						echo '		</div>
																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';	   
							   
		*/
}
/************************************************************************************************************/
function getDetailPeripheralStatusPTR($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
    include "../languages/" . $_SESSION['lang'] . ".php";


    $conn=ma_db_connexion();
    $id_service=13;
    $val=get_name_terminal_gag($ATM);
    $sql = "SELECT `date_vacation` ,`id_vacation` , `vacations_PTR`.`fwDevice` as DevicePTR, `vacations_PTR`.`fwMedia` as MediaPTR, `vacations_PTR`.fwToner as TonerPTR, `vacations_PTR`.fwInk as InkPTR,
    `vacations_PTR`.fwPaper_WFS_PTR_SUPPLYSIZE as Paper_WFS_PTR_SUPPLYSIZEPTR, fwPaper_WFS_PTR_SUPPLYUPPER,fwPaper_WFS_PTR_SUPPLYLOWER, fwPaper_WFS_PTR_SUPPLYEXTERNAL,fwPaper_WFS_PTR_SUPPLYAUX,fwPaper_WFS_PTR_SUPPLYAUX2, fwPaper_WFS_PTR_SUPPLYPARK,
    `vacations_PTR`.fwLamp, `vacations_PTR`.wDevicePosition, wAntiFraudModule,wBlackMarkMode,
    `vacations_PTR`.`usRetractCount` as RetractCountPTR,  `vacations_PTR`.`wRetractBin` as RetractBinPTR, `id_logical_name` ,  `logical_name` , `id_service`
    FROM `".mysqli_real_escape_string($conn,$tableVacation)."`
    WHERE `id_atm` ='".mysqli_real_escape_string($conn,$ATM)."'
    AND `id_vacation` IN(".mysqli_real_escape_string($conn,$idVacation).")
    AND `fwDevice` <>3";

					/***************************************************/
    echo '<div class="modal-dialog modal-xl" role="document" >
            <div class="modal-content">																										  
                    <!-- Modal Header -->
                    <div class="modal-header">
                       <h4 class="modal-title">'.$lang['terminal'].' : '.$ATM.' - '.$val[0].' - '.$val[1].' -<strong>  '.$nameVacation.' ('.$histDateVacation.')</strong></h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                                                                            
                    <!-- Modal body -->
                    <div class="modal-body">
                    <div class="row">
                    <div class="col">
                        <div class="card" style="border: 0px;">
                       
                         <div class="card-body">
                         <div class="nav-tabs-boxed">';
    mysqli_query($conn,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($conn,$sql);
    $result2=mysqli_query($conn,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1009:  ".$sql."  " .mysqli_error($conn));
        die(' ERREUR QUERY 1009 !');
    }
    if($result)
    {
        if (mysqli_num_rows($result)>0)
        {
            $k=0;
            $jj=0;
            $tableau_logical_autorise=get_list_logical_names_atm($ATM,$id_service);
            echo '<ul class="nav nav-tabs" id="myTab1" role="tablist">';
            while ($rowG2 = mysqli_fetch_assoc($result2))
            {

                if (in_array($rowG2["id_logical_name"], $tableau_logical_autorise))
                {
                    if ($rowG2["DeviceCDM"]<>3)
                    {
                        if ($module==1)
                        {
                            echo '<li class="nav-item">';
                            echo ' <a class="nav-link';
                            if($jj==0){ echo ' active" aria-selected="true"';}else{echo '" aria-selected="false"';}
                            echo 'id="'.$rowG2["logical_name"].'_'.$jj.'" data-toggle="tab" role="tab" aria-controls="'.$rowG2["logical_name"].'" 
                             href="#'.$rowG2["logical_name"].'" >' . $rowG2["logical_name"] . '</a>';
                            echo '</li>';

                        }
                    }
                }
                $jj++;
            }
            echo '</ul>
            <div class="tab-content" id="myTab1Content">';
            while ($row = mysqli_fetch_assoc($result))
            {
                if (in_array($row["id_logical_name"], $tableau_logical_autorise))
                {
                    $EtatPeripheral = array("Device|fwDevice-".$row["DevicePTR"],"Media|fwMedia-".$row["MediaPTR"],
                    "Retract Count|usRetractCount-".$row["RetractCountPTR"],"Retract Bin|wRetractBin-".$row["RetractBinPTR"],
                    "Toner|fwToner-".$row["TonerPTR"],"Ink|fwInk-".$row["InkPTR"],
                    "Lamp|fwLamp-".$row["fwLamp"],"Device Position|wDevicePosition-".$row["wDevicePosition"],
                    "Anti Fraud Module|wAntiFraudModule-".$row["wAntiFraudModule"],
                    "Paper Suply Size|fwPaper [WFS_PTR_SUPPLYSIZE]-".$row["Paper_WFS_PTR_SUPPLYSIZEPTR"],"Paper Suply Upper|fwPaper_WFS_PTR_SUPPLYUPPER-".$row["fwPaper_WFS_PTR_SUPPLYUPPER"],
                    "Paper Suply Lower|fwPaper_WFS_PTR_SUPPLYLOWER-".$row["fwPaper_WFS_PTR_SUPPLYLOWER"],"Paper Suply External|fwPaper_WFS_PTR_SUPPLYEXTERNAL-".$row["fwPaper_WFS_PTR_SUPPLYEXTERNAL"],
                    "Paper Suply Aux|fwPaper_WFS_PTR_SUPPLYAUX-".$row["fwPaper_WFS_PTR_SUPPLYAUX"],"Paper Suply Aux2|fwPaper_WFS_PTR_SUPPLYAUX2-".$row["fwPaper_WFS_PTR_SUPPLYAUX2"],
                    "Logical name|logical_name-".$row["logical_name"],"Service|id_service-".$row["id_service"]);

                    if ($module==1)
                    {
                        echo '<div class="tab-pane fade';if($k==0){ echo ' show active';}echo '" 
                        id="'.$row["logical_name"].'" role="tabpanel" aria-labelledby="'.$row["logical_name"].'_'.$k.'">';
                        get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$row["id_service"],$row["id_logical_name"],$paramAffichage);
                        echo'</div>';
                    }
                    $k++;
                }
            }
        }
        mysqli_free_result($result);
    }//if($result)
    mysqli_close($conn);
							   
    echo '		</div>     
		        </div>
		        </div>
		        </div>
		        </div>
		        </div>
		        </div>                                                              
                <!-- Modal footer -->
                <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
                </div>
                                                                        
        </div>
    </div>';
							   
							   
}
/************************************************************************************************************/

function getDetailPeripheralStatusIDC($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
    include "../languages/" . $_SESSION['lang'] . ".php";


    $id_service=10;
    $connexion=ma_db_connexion();
    $val=get_name_terminal_gag($ATM);
						// list($Libelle_logical, $value_logical) = explode('-',  $logical_name);
    $sql = "SELECT  `date_vacation`, `fwDevice` as DeviceIDC, `fwMedia` as MediaIDC,  `fwRetainBin` as RetainBinIDC,  `fwSecurity` as SecurityIDC, `id_logical_name` ,  `logical_name` , `id_service`,
	`usCards` as CardsIDC, `fwChipPower` as ChipPowerIDC,  `dwGuidLights` as GuidLightsIDC,  `dwGuidLights_WFS_IDC_GUIDANCE_CARDUNIT` as GuidLights_WFS_IDC, 
	`fwChipModule` as ChipModuleIDC, `fwMagReadModule` as MagReadModuleIDC,  `fwMagWriteModule` as MagWriteModuleIDC,  `fwFrontImageModule` as FrontImageModuleIDC, 
	`fwBackImageModule` as BackImageModuleIDC, `wDevicePosition` as DevicePositionIDC,  `usPowerSaveRecoveryTime` as PowerSaveRecoveryTimeIDC,  `wAntiFraudModule` as AntiFraudModuleIDC						
	FROM `".mysqli_real_escape_string($connexion,$tableVacation)."`
	WHERE `id_atm` ='".$ATM."'
	AND `id_vacation` IN(".$idVacation.")
	AND `fwDevice` <>3 ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    $result2=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1010:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 1010 !');
    }
    if($result)
    {
        $k=0;
        echo '<div class="modal-dialog modal-xl" role="document" >
		    <div class="modal-content">																										  
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">'.$lang['terminal'].' : '.$ATM.' - '.$val[0].' - '.$val[1].' -<strong>  '.$nameVacation.' ('.$histDateVacation.')</strong></h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                                                                        
                <!-- Modal body -->
                <div class="modal-body">
                 <div class="row">
                    <div class="col">
                        <div class="card" style="border: 0px;">
                      
                         <div class="card-body">
                         <div class="nav-tabs-boxed">';
												
												
        if (mysqli_num_rows($result)>0)
        {
            $j=0;
            $jj=0;
            $tableau_logical_autorise=get_list_logical_names_atm($ATM,$id_service);
            echo '<ul class="nav nav-tabs" id="myTab1" role="tablist">';
            while ($rowG2 = mysqli_fetch_assoc($result2))
            {

                if (in_array($rowG2["id_logical_name"], $tableau_logical_autorise))
                {
                    if ($rowG2["DeviceCDM"]<>3)
                    {
                        if ($module==1)
                        {
                            echo '<li class="nav-item">';
                            echo ' <a class="nav-link';
                            if($jj==0){ echo ' active" aria-selected="true"';}else{echo '" aria-selected="false"';}
                            echo 'id="'.$rowG2["logical_name"].'_'.$jj.'" data-toggle="tab" role="tab" aria-controls="'.$rowG2["logical_name"].'" 
                             href="#'.$rowG2["logical_name"].'" >' . $rowG2["logical_name"] . '</a>';
                            echo '</li>';

                        }
                    }
                }
                $jj++;
            }
            echo '</ul>
            <div class="tab-content" id="myTab1Content">';
            while ($row = mysqli_fetch_assoc($result))
            {
                // if (in_array(mysql_result($result,$j ,'logical_name'), $tableau_logical_autorise))
                if (in_array($row["id_logical_name"], $tableau_logical_autorise))
                {
                    $k++;
									
                    $EtatPeripheral = array("Device|fwDevice-".$row["DeviceIDC"],"Media|fwMedia-".$row["MediaIDC"],
                        "Retain Bin|fwRetainBin-".$row["RetainBinIDC"],"Security|fwSecurity-".$row["SecurityIDC"],
                        "Cards|usCards-".$row["CardsIDC"],"Chip Power|fwChipPower-".$row["ChipPowerIDC"],
                        "GuidLights|dwGuidLights-".$row["GuidLights_WFS_IDC_GUIDANCE_CARDUNIT"],"Device|dwGuidLights_WFS_IDC_GUIDANCE_CARDUNIT-".$row["GuidLights_WFS_IDC"],
                        "Chip Module|fwChipModule-".$row["ChipModuleIDC"],"Mag Read Module|fwMagReadModule-".$row["MagReadModuleIDC"],
                        "Mag Write Module|fwMagWriteModule-".$row["MagWriteModuleIDC"],"Front Image Module|fwFrontImageModule-".$row["FrontImageModuleIDC"],
                        "Back Image Module|fwBackImageModule-".$row["BackImageModuleIDC"],"Device Position|wDevicePosition-".$row["DevicePositionIDC"],
                        "Power Save Recovery Time|usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTimeIDC"],"Anti Fraud Module|wAntiFraudModule-".$row["AntiFraudModuleIDC"],
                        "Service|id_service-".$row["id_service"]);


                    if ($module==1)
                    {
                        echo '<div class="tab-pane fade';if($j==0){ echo ' show active';}echo '" 
                            id="'.$row["logical_name"].'" role="tabpanel" aria-labelledby="'.$row["logical_name"].'_'.$j.'">';
						get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$row["id_service"],$row["id_logical_name"],$paramAffichage);
						echo'</div>';
													
                    }
                }
                $j++;
            }
        }

        mysqli_free_result($result);
    }//if($result = mysqli_query(ma_db_connexion(),$sql) or die('Erreur SQL getDetailPeripheralStatusIDC !<br>'.$sql.'<br>'.mysql_error()))
							   
    echo '</div>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
																																		
        <!-- Modal footer -->
        <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
        </div>
                                                            
    </div>
</div>';
							   
							   
}

/************************************************************************************************************/
function getDetailPeripheralStatusPIN($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
    include "../languages/" . $_SESSION['lang'] . ".php";

    $connexion=ma_db_connexion();
	$id_service=12;
    $val=get_name_terminal_gag($ATM);
    $sql = "SELECT  `date_vacation`, `fwDevice` as DevicePIN, `fwEncStat` as EncStaPIN,  `dwGuidLights` as GuidLightsPIN,  `fwAutoBeepMode` as AutoBeepModePIN, `id_logical_name` ,  `logical_name` , `id_service` ,
    `dwCertificateState` as CertificateStatePIN, `wDevicePosition` as DevicePositionPIN,  `usPowerSaveRecoveryTime` as PowerSaveRecoveryTimePIN,  `wAntiFraudModule` as AntiFraudModulePIN					
    FROM `".$tableVacation."`
    WHERE `id_atm` ='".$ATM."'
    AND `id_vacation` IN(".$idVacation.")
    AND `fwDevice` <>3 ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    $result2=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1011:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 1011 !');
    }
    if($result)
    {


        echo '<div class="modal-dialog modal-xl" role="document" >
		    <div class="modal-content" >																										  
			    <!-- Modal Header -->
			    <div class="modal-header">
				    <h4 class="modal-title">'.$lang['terminal'].' : '.$ATM.' - '.$val[0].' - '.$val[1].' -<strong>  '.$nameVacation.' ('.$histDateVacation.')</strong></h4>
				    <button type="button" class="close" data-dismiss="modal">&times;</button>
			    </div>																			
			    <!-- Modal body -->
				<div class="modal-body">
												
				<div class="row">
                    <div class="col">
                        <div class="card" style="border: 0px;">
                        
                         <div class="card-body">
                         <div class="nav-tabs-boxed">';
												
        if (mysqli_num_rows($result)>0)
        {
            $k=0;
            $jj=0;
            $tableau_logical_autorise=get_list_logical_names_atm($ATM,$id_service);
            echo '<ul class="nav nav-tabs" id="myTab1" role="tablist">';
            while ($rowG2 = mysqli_fetch_assoc($result2))
            {

                if (in_array($rowG2["id_logical_name"], $tableau_logical_autorise))
                {
                    if ($rowG2["DeviceCDM"]<>3)
                    {
                        if ($module==1)
                        {
                            echo '<li class="nav-item">';
                            echo ' <a class="nav-link';
                            if($jj==0){ echo ' active" aria-selected="true"';}else{echo '" aria-selected="false"';}
                            echo 'id="'.$rowG2["logical_name"].'_'.$jj.'" data-toggle="tab" role="tab" aria-controls="'.$rowG2["logical_name"].'" 
                             href="#'.$rowG2["logical_name"].'" >' . $rowG2["logical_name"] . '</a>';
                            echo '</li>';

                        }
                    }
                }
                $jj++;
            }
            echo '</ul>
            <div class="tab-content" id="myTab1Content">';
            // $tableau_logical_autorise=get_list_names_logical_names_atm($ATM,$row["id_service"]);
            while ($row = mysqli_fetch_assoc($result))
            {
                // if (in_array(mysql_result($result,$j ,'logical_name'), $tableau_logical_autorise))
                if (in_array($row["id_logical_name"], $tableau_logical_autorise))
                {
											
                    $EtatPeripheral = array("Device|fwDevice-".$row["DevicePIN"],"Enc Stat|fwEncStat-".$row["EncStaPIN"],
                        "GuidLights|dwGuidLights-".$row["GuidLightsPIN"],"Auto Beep Mode|fwAutoBeepMode-".$row["AutoBeepModePIN"],
                        "Certificate State|dwCertificateState-".$row["CertificateStatePIN"],"Device Position|wDevicePosition-".$row["DevicePositionPIN"],
                        "Power Save Recovery Time|usPowerSaveRecoveryTime-".$row["PowerSaveRecoveryTimePIN"],
                        "Anti Fraud Module|wAntiFraudModule-".$row["AntiFraudModulePIN"],"Service|id_service-".$row["id_service"]);
												
                    if ($module==1)
                    {
                        echo '<div class="tab-pane fade';if($k==0){ echo ' show active';}echo '" 
                         id="'.$row["logical_name"].'" role="tabpanel" aria-labelledby="'.$row["logical_name"].'_'.$k.'">';
                        get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$row["id_service"],$row["id_logical_name"],$paramAffichage);
						echo'</div>';
															
                    }
                    $k++;
                }
            }
        }
        mysqli_free_result($result);
    }//if ($result=mysqli_query(ma_db_connexion(),$sql) or die('Erreur   getDetailPeripheralStatusPIN !<br>'.$sql.'<br>'.mysql_error()))
    mysqli_close($connexion);
    echo '</div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
	    
																										
        <!-- Modal footer -->
        <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
        </div>
                                                                                                    
        </div>
    </div>';
							   
							   
}
/************************************************************************************************************/
function getVerifDeclaration($ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$category,$code_error,$logical_name,$paramAffichage)
{
    $connexion=ma_db_connexion();

    $sql = "SELECT  `id_incident` FROM `declarer_incident` 
    WHERE `xfs_error` ='".mysqli_real_escape_string($connexion,$xfsErreur)."'
    AND `xfs_status`   ='".mysqli_real_escape_string($connexion,$xfsStatus)."'
    AND `code_error`   ='".mysqli_real_escape_string($connexion,$code_error)."'
    AND `category`    ='".mysqli_real_escape_string($connexion,$category)."'
    AND `date_vacation`   ='".mysqli_real_escape_string($connexion,$histDateVacation)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1012:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 1012 !');
    }
    if ($result)
    {
        if (mysqli_num_rows($result)>0)
        {
            mysqli_close($connexion);
            return ' <strong style="font-size:14px;font-weight:bold;color:#1aff53" >==> Status already declared </strong>';
        }
        else
        {
            mysqli_close($connexion);
            return "";
        }
    }
}
/************************************************************************************************************/
function getBTNModuleDeclaration($ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$category,$code_error,$logical_name,$paramAffichage)
{ 

// echo " aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : ".$histNameFile."<br>";
list($part1, $part2, $part3) = explode("__",  $histNameFile);	
$part = explode("__",  $histNameFile);	
echo' <a tabindex="-1"  data-toggle="modal" 
onClick="javascript:getDeclarerPeripheralStatus(\''.$ATM.'\',\''.$idVacation.'\',\''.$tableVacation.'\',\''.$xfsErreur.'\',\''.$xfsStatus.'\',\''.$nameVacation.'\',\''.$histDateVacation.'\',\''.$histNameFile.'\',\''.$category.'\',\''.$code_error.'\',\''.$logical_name.'\',\''.$paramAffichage.'\')">
<strong style="font-size:18px;font-weight:bold;color:#FF0040" ><br><i class="fa  fa-arrow-circle-up"></i> Déclarer </strong></a>';	
echo getVerifDeclaration($ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$category,$code_error,$logical_name,$paramAffichage);	
}
/************************************************************************************************************/
function getModuleDeclaration($ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$EtatCDM,$category,$code_error,$logical_name,$paramAffichage)
{
echo' <a tabindex="-1"  data-toggle="modal" 
onClick="javascript:getDetailPeripheralStatus(\''.$ATM.'\',\''.$idVacation.'\',\''.$tableVacation.'\',\''.$xfsErreur.'\',\''.$xfsStatus.'\',\''.$nameVacation.'\',\''.$histDateVacation.'\',\''.$histNameFile.'\',\''.$category.'\',\''.$code_error.'\',\''.$logical_name.'\',\''.$paramAffichage.'\')">
<strong style="font-size:18px;font-weight:bold;color:#FF0040" ><br><i class="fa  fa-repeat"></i> Retour au détail '.$nameVacation.'  :  <br>';
// echo	'................'.$part[0].'................'.$part1.'................'.$part2.'................'.$part3.'................'.$histNameFile;
echo '</strong></a>';		

echo '
<form class="form-horizontal" role="form">

				<div  class="form-group">
					<label <for="text1" class="col-sm-2 control-label"></label>
					<div class="col-sm-10">
						<input  id="text1"  name="text1" type="hidden"   value="" class="form-control input-sm">
					</div>
				</div>	
				<div  class="form-group">
					<label <for="text2" class="col-sm-2 control-label"></label>
					<div class="col-sm-10">
						<input  id="text2"  name="text2" type="hidden"   value="" class="form-control input-sm">
					</div>
				</div>	
				<div  class="form-group">
					<label <for="text3" class="col-sm-2 control-label"></label>
					<div class="col-sm-10">
						<input  id="text3"  name="text3" type="hidden"   value="" class="form-control input-sm">
					</div>
				</div>	
				
				<div  class="form-group">
					<label <for="id_ATM" class="col-sm-2 control-label">ATM</label>
					<div class="col-sm-10">
						<input  id="id_ATM"  name="id_ATM" type="text"   value="'.$ATM.'" class="form-control input-sm">
					</div>
				</div>	
				<div  class="form-group">
					<label <for="name_ATM" class="col-sm-2 control-label">Name ATM</label>
					<div class="col-sm-10">
						<input  id="name_ATM"  name="name_ATM" type="text"   value="'.$idVacation.'" class="form-control input-sm">
					</div>
				</div>					
				<div  class="form-group">				
					<label <for="Vacation" class="col-sm-2 control-label">Vacation</label>
					<div class="col-sm-10">
						<input  id="Vacation" name="Vacation" type="text"   value="'.$nameVacation.'"    class="form-control input-sm">	    
					</div>
				</div>
				<div  class="form-group">				
					<label <for="Erreur" class="col-sm-2 control-label">XFS Error</label>
					<div class="col-sm-10">
						<input  id="Erreur" name="Erreur" type="text"   value="'.$xfsErreur.'"    class="form-control input-sm">	    
					</div>
				</div>
				<div  class="form-group">				
					<label <for="statusXFS" class="col-sm-2 control-label">Status XFS</label>
					<div class="col-sm-10">
						<input  id="statusXFS" name="statusXFS" type="text"   value="'.$xfsStatus.'"    class="form-control input-sm">	    
					</div>
				</div>
				<div  class="form-group">				
					<label <for="categoryXFS" class="col-sm-2 control-label">Category</label>
					<div class="col-sm-10">
						<input  id="categoryXFS" name="categoryXFS" type="text"   value="'.$category.'"    class="form-control input-sm">	    
					</div>
				</div>
				<div  class="form-group">				
					<label <for="codeError" class="col-sm-2 control-label">Code error</label>
					<div class="col-sm-10">
						<input  id="codeError" name="codeError" type="text"   value="'.$code_error.'"    class="form-control input-sm">	    
					</div>
				</div>				
				<div  class="form-group">				
					<label <for="dateVacation" class="col-sm-2 control-label">Date Vacation</label>
					<div class="col-sm-10">
						<input  id="dateVacation" name="dateVacation" type="text"   value="'.$histDateVacation.'"    class="form-control input-sm">	    
					</div>
				</div>					
				<div  class="form-group">				
					<label <for="buttonVaction" class="col-sm-2 control-label"></label>
					<div class="col-sm-10">
						<button type="button" class="btn btn-danger"  
						onClick="javascript:declarer_incident_gab(\''.$ATM.'\',\''.$idVacation.'\',\''.$tableVacation.'\',\''.$xfsErreur.'\',\''.$xfsStatus.'\',\''.$nameVacation.'\',\''.$histDateVacation.'\',\''.$histNameFile.'\',\''.$category.'\',\''.$code_error.'\',\''.$logical_name.'\',\''.$paramAffichage.'\')" 
						data-toggle="modal" >Déclarer</button>';						
					echo'</div>
				</div>				
						
				
</form> ';

}
function mysqli_result($search, $row, $field){
$i=0; while($results=mysqli_fetch_array($search)){
if ($i==$row){$result=$results[$field];}
$i++;}
return $result;} 
/************************************************************************************************************/
function getDetailPeripheralStatusCDM($paramettre,$idprivilege,$ATM,$idVacation,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,$category,$code_error,$logical_name,$paramAffichage)
{
    include "../languages/" . $_SESSION['lang'] . ".php";


    $conn=ma_db_connexion();
    $service=4;
    $val=get_name_terminal_gag($ATM);
    $sql = "SELECT  `date_vacation`,  `fwDevice` as DeviceCDM, `fwSafeDoor` as SafeDoorCDM,  `fwDispenser` as DispenserCDM,  `fwIntermediateStacker` as IntermediateStackerCDM,
    `fwPosition` as PositionCDM,  `fwPositionStatus` as PositionStatusCDM,  `fwShutter` as ShutterCDM,  `id_logical_name` ,  `logical_name` , `id_service`, 
    `fwTransport` as TransportCDM, `fwTransportStatus` as TransportStatusCDM,  `fwJammedShutterPosition` as JammedShutterPositionCDM,  `dwGuidLights` as GuidLightsCDM,
    `wDevicePosition` as DevicePositionCDM, `usPowerSaveRecoveryTime` as PowerSaveRecoveryTimeCDM, `id_vacation` as vacationCDM						
    FROM `".mysqli_real_escape_string($conn,$tableVacation)."`
    WHERE `id_atm` ='".mysqli_real_escape_string($conn,$ATM)."'							 
    AND `id_vacation` IN(".mysqli_real_escape_string($conn,$idVacation).")
    AND `fwDevice` <>3 ";


    /***************************************************/
    mysqli_query($conn,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($conn,$sql);
    $result2=mysqli_query($conn,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1013:  ".$sql."  " .mysqli_error($conn));
        die(' ERREUR QUERY 1013 !');
    }
    if ($result && $result2)
    {
        echo '<div class="modal-dialog modal-xl" role="document" >
            <div class="modal-content" >																									  
            <!-- Modal Header -->
            <div class="modal-header">
              <h4 class="modal-title">'.$lang['terminal'].' : '.$val[0].' - '.$val[1].' -<strong >  '.$nameVacation.' ('.$histDateVacation.')</strong></h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
                                                                                                
            <!-- Modal body -->
            <div class="modal-body">
                <div class="row">
                    <div class="col">
                        <div class="card" style="border: 0px;">
                         <div class="card-body">
                         <div class="nav-tabs-boxed">';


        $M=0;
        if(mysqli_num_rows($result)>0)
        {
            $j=0;
            $jj=0;

            $tableau_logical_autorise=get_list_logical_names_atm($ATM,$service);
            echo '<ul class="nav nav-tabs" id="myTab1" role="tablist">';
            while ($rowG2 = mysqli_fetch_assoc($result2))
            {
                if (in_array($rowG2["id_logical_name"], $tableau_logical_autorise))
                {
                    if ($rowG2["DeviceCDM"]<>3)
                    {
                        if ($module==1)
                        {
                            echo '<li class="nav-item">';
                            echo ' <a class="nav-link';
                            if($jj==0){ echo ' active" aria-selected="true"';}else{echo '" aria-selected="false"';}
                            echo 'id="'.$rowG2["logical_name"].'_'.$jj.'" data-toggle="tab" role="tab" aria-controls="'.$rowG2["logical_name"].'" 
                             href="#'.$rowG2["logical_name"].'" >' . $rowG2["logical_name"] . '</a>';
                            echo '</li>';
                        }
                    }
                }
                $jj++;
            }
            echo '</ul>
            <div class="tab-content" id="myTab1Content">';
            while ($rowG = mysqli_fetch_assoc($result))
            {
                if (in_array($rowG["id_logical_name"], $tableau_logical_autorise))
                {
                    /****************************************************** Début Verif Staus fwDevice ******************************************************/

                    if ($rowG["DeviceCDM"]<>3)
                    {

                        $EtatPeripheral = array("Device|fwDevice-".$rowG["DeviceCDM"],"Safe Door|fwSafeDoor-".$rowG["SafeDoorCDM"],
                        "Dispenser|fwDispenser-".$rowG["DispenserCDM"],"Intermediate Stacker|fwIntermediateStacker-".$rowG["IntermediateStackerCDM"],
                        "Position|fwPosition-".$rowG["PositionCDM"],
                        "Position Status|fwPositionStatus -".$rowG["PositionStatusCDM"],"Shutter|fwShutter-".$rowG["ShutterCDM"],
                        "Transport|fwTransport -".$rowG["TransportCDM"],"Transport Status|fwTransportStatus-".$rowG["TransportStatusCDM"],
                        "Shutter Position|fwJammedShutterPosition -".$rowG["JammedShutterPositionCDM"],"GuidLights|dwGuidLights-".$rowG["GuidLightsCDM"],
                        "Device Position|wDevicePosition -".$rowG["DevicePositionCDM"],"Power Save Recovery Time|usPowerSaveRecoveryTime-".$rowG["PowerSaveRecoveryTimeCDM"],"Service|id_service-".$rowG["id_service"]);

                        if ($module==1)
                        {
                            echo '<div class="tab-pane fade';if($j==0){ echo ' show active';}echo '" 
                            id="'.$rowG["logical_name"].'" role="tabpanel" aria-labelledby="'.$rowG["logical_name"].'_'.$j.'">';

                            get_statut_gab($paramettre,$idprivilege,'xfs_errors_'.$nameVacation,'WFS_INF_'.$nameVacation.'_STATUS',$EtatPeripheral,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$rowG["id_service"],$rowG["id_logical_name"],$paramAffichage);

                            //Cassette Logical
                            $SQLLogical = "SELECT `id_vacation_logical`, `jLoop`, `usNumber`, `usType`, `cUnitID`, `cCurrencyID`, `ulValues`,`ulValues`*`ulCount` as montant,
                            `ulInitialCount`, `ulCount`, `ulRejectCount`, `ulMinimum`, `bAppLock`, `usStatus`, `ulDispensedCount`, `ulPresentedCount`, `ulRetractedCount`,
                            `usNumPhysicalCUs`,`usType`
                            FROM `vacations_CDM_cash_unit_logical` 
                            WHERE `id_vacation` = '".mysqli_real_escape_string($conn,$rowG["vacationCDM"])."'  AND `usType` IN (2,3)";
                            // AND `usType`= 2

                            //echo $SQLLogical;

                            mysqli_query($conn,"SET CHARACTER SET 'utf8'");
                            $resLogical=mysqli_query($conn,$SQLLogical);
                            if (!$resLogical)
                            {
                                error_log("Erreur SQL 1014:  ".$SQLLogical."  " .mysqli_error($conn));
                                die(' ERREUR QUERY 1014 !');
                            }
                            if ($resLogical)
                            {
                                if (mysqli_num_rows($resLogical)>0)
                                {
                                    $k=1;
                                    echo ' <hr>
                                        <table class="table table-responsive-sm table-hover table-outline mb-0">
                                            <thead class="thead-light">
                                                <tr>
                                                <th>'.$lang['cassettes'].'</th>
                                                <th>'.$lang['mtn'].'</th>
                                                <th colspan="2">'.$lang['status'].'</th>';
                                    if($idprivilege==1)
                                    {
                                        echo '<th ></th>';
                                    }
                                    echo '</tr>
                                          </thead>';
                                    $som_value_category=0;

                                    while ($rowL = mysqli_fetch_assoc($resLogical))
                                    {
                                        $EtatCassetteLogical = array("Loop|jLoop-".$rowL["jLoop"],"Number|usNumber-".$rowL["usNumber"],
                                        "UnitID|cUnitID-".$rowL["cUnitID"],
                                        "CurrencyID|cCurrencyID-".$rowL["cCurrencyID"],"Values|ulValues-".$rowL["ulValues"],
                                        "Initial Count|ulInitialCount-".$rowL["ulInitialCount"],"Count|ulCount-".$rowL["ulCount"],
                                        "Reject Count|ulRejectCount-".$rowL["ulRejectCount"],"Minimum|ulMinimum-".$rowL["ulMinimum"],
                                        "AppLock|bAppLock-".$rowL["bAppLock"],"Status|usStatus-".$rowL["usStatus"],
                                        "Dispensed Count|ulDispensedCount-".$rowL["ulDispensedCount"],"Presented Count|ulPresentedCount-".$rowL["ulPresentedCount"],
                                        "Retracted Count|ulRetractedCount-".$rowL["ulRetractedCount"],"Num Physical CUs|usNumPhysicalCUs-".$rowL["usNumPhysicalCUs"],"Montant|montant-".$rowL["montant"],"Service|id_service-".$rowG["id_service"]);

                                        list($category1, $Etat_category) = explode('|',  $EtatCassetteLogical[15]);

                                        list($category, $value_category) = explode('-',  $Etat_category);

                                        if ($category=='montant')
                                        {
                                        //    echo "value_category : ".$value_category."<br>";
                                            $som_value_category=$som_value_category+$value_category;
                                        }

                                        get_statut_gab1($paramettre,$idprivilege,'xfs_errors_CDM','WFS_INF_CDM_CASH_UNIT_INFO',$EtatCassetteLogical,$idVacation,$ATM,$nameATM,$tableVacation,$xfsErreur,$xfsStatus,$nameVacation,$histDateVacation,$histNameFile,$module,'',$rowG["id_service"],$rowG["id_logical_name"],$paramAffichage,$rowL["usType"]);

                                        $k++;
                                    }
                                    echo '
                                    <tr class="alert alert-dark">
                                        <td><h6>'.$lang['mtn_total'].' : </h6></td>
                                        <td colspan="4"><h6>' .number_format($som_value_category,2,'.',','). " MGA".'</h6></td>
                                    </tr>
                                    </table>
                                    ';

                                } //if (mysql_num_rows($resLogical)>0)
                                mysqli_free_result($resLogical);
                            }//if ($resLogical=mysqli_query(ma_db_connexion(),$SQLLogical) or die('Erreur   SQLLogical 222222 !<br>'.$SQLLogical.'<br>'.mysql_error()))
                            echo '</div>';
                        }
                        $M++;
                    }
                }
                /****************************************************** Fin Verif Staus fwDevice ******************************************************/
                $j++;
            }// fin while ($rowG = mysqli_fetch_assoc($result))
        }// fin condition if (mysql_num_rows($result)>0)
        mysqli_free_result($result);

        echo '</div>
             </div>
             </div>
             </div>
             </div>
             </div>
             </div>
                                                                                        
            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">'.$lang['close'].'</button>
            </div>                                                                          
        </div>
    </div>';

    }////if ($result=mysqli_query(ma_db_connexion(),$sql) or die('Erreur  sql getDetailPeripheralStatusCDM 111 !<br>'.$sql.'<br>'.mysql_error()))
    mysqli_close($conn);
}

/************************************************************************************************************/


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
?>