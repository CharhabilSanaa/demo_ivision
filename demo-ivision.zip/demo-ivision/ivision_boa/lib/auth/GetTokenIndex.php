<?php


/*
 * this is an endpoint to generate a JWT Token
 */


//include('../../vendor/autoload.php');


include("../../lib/libAchraf.php");
include("../../lib/JWT/jwt.php");

//use \Firebase\JWT\JWT;

$config = file_get_contents("../../lib/auth/config.json");
$config = json_decode($config);

$response = [];

$jwtPayload = [


    'token' => gethardtokenind(),
    'sub' => "1234567890",
    'iat' => time(),
    'exp' => time()+600,

];

$jwt = JWT::encode($jwtPayload,$config->jwt_secret);

$response['status'] = true;
$response['jwt'] = [
    'payload' => $jwtPayload,
    'token' => $jwt
];




header("Content-Type: application/json");
//var_dump($response);die;
echo json_encode($response);