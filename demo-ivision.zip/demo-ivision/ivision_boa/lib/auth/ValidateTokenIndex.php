<?php


/*
 * include this file for every php script that requires token
 */

include("../../lib/JWT/jwt.php");

//use \Firebase\JWT\JWT;

$config = file_get_contents("../../lib/auth/config.json");
$config = json_decode($config);



if(isset($_SERVER['HTTP_X_ACCESS_TOKEN'])){
        // echo "VALUE : " . $valuehabilitation;
        try {

            $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];

            $payload = JWT::decode($token,$config->jwt_secret,(array)$config->jwt_signing_alg);



            $response['status'] = true;


            header("Content-Type: application/json");
            echo json_encode($response);


        } catch (Exception $e) {
            $response['status'] = false;
            $response['payload'] = [
                'message' => $e->getMessage()
            ];
            header("Content-Type: application/json");
            echo json_encode($response);
            exit();
        }

}
else
{
    $response['status'] = false;
    $response['payload'] = [
        'message' => 'token is required'
    ];
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
