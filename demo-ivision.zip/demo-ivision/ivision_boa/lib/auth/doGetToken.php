<?php

/* 
 * this is an endpoint to generate a JWT Token
 */


//include('../../vendor/autoload.php');
//var_dump('tt');die;

include("../../lib/userlib.php");
include("../../lib/JWT/jwt.php");

//use \Firebase\JWT\JWT;

$config = file_get_contents("../../lib/auth/config.json");
$config = json_decode($config);

$response = [];


if(isset($_POST['user']) && isset($_POST['mdp'])){

    //TODO: do check username and password below

    $user = $_POST['user'];
    $mdp = $_POST['mdp'];


    if (($user <> "")&&(verif_user($user,$mdp)==true)) {

        $userId=get_id_user($_POST['user']);
        $habilitation=charger_habilitation($_POST['user']);

        $jwtPayload = [
            'userId' => $userId,
            'habilitation' => $habilitation,
            'iat' => time(),
            'exp' => time() + $config->jwt_token_lifetime
        ];
        $jwt = JWT::encode($jwtPayload,$config->jwt_secret);

        $response['status'] = true;
        $response['jwt'] = [
            'payload' => $jwtPayload,
            'token' => $jwt
        ];

    }else{
        $response['status'] = false;
        $response['payload'] = [
            'message' => 'Login ou Mot de passe incorrect'
        ];
    }

}else{
    $response['status'] = false;
    $response['payload'] = [
        'message' => 'username & password is required'
    ];
}

header("Content-Type: application/json");
//var_dump($response);die;
echo json_encode($response);