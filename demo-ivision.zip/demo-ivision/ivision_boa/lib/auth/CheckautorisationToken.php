<?php

/*
 * include this file for every php script that requires token
 */

include("../../lib/JWT/jwt.php");

//use \Firebase\JWT\JWT;

$config = file_get_contents("../../lib/auth/config.json");
$config = json_decode($config);

$jwtPayload = [];

//validate is HTTP_X_ACCESS_TOKEN is exists then validate the token,
//otherwise, break the page and return an error message

if(isset($_SERVER['HTTP_X_ACCESS_TOKEN']) && isset($_GET['idhabilitation'])){
    try{

        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        $idhabilitation = $_GET['idhabilitation'];


        $payload = JWT::decode($token,$config->jwt_secret,(array)$config->jwt_signing_alg);
        $response['status'] = false;
        $response['message'] = [
            'message' => "30page 401"
        ];
        if ($payload->habilitation<>"")
        {
            foreach ($payload->habilitation as $value)
            {
               // echo "ID habilitation :   $value \n";
                if ($value==$idhabilitation)
                {
                     $response['status'] = true;
                    $response['message'] = [
                        'message' => "success"
                    ];
                }
            }
        }
        else
        {
             $response['status'] = false;
            $response['message'] = [
                'message' => "page 401"
            ];
        }

        header("Content-Type: application/json");
        echo json_encode($response);

    }catch(Exception $e){
        //if token is invalid, then return the error message
        $response['status'] = false;
        $response['message'] = [
            'message' => $e->getMessage().$_SERVER['HTTP_X_ACCESS_TOKEN'].'Get '.$_GET['idhabilitation']
        ];
        header("Content-Type: application/json");
        echo json_encode($response);
        exit();
    }
}else{
    $response['status'] = false;
    $response['message'] = [
        'message' => "73page 401"
    ];
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}


/**********************************************************************************************************************************/
