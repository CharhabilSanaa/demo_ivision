<?php
if (isset($_GET["email"]) && isset($_GET["mdp"]))
{
    $email=$_GET["email"];
    $mdp=$_GET["mdp"];
}
else
{
    $email="";
    $mdp="";
}

?>
<style rel="stylesheet">
    #wrapper {
        font-size: 1.5rem;
        text-align: center;
        box-sizing: border-box;
        color: #333;

    #dialog {
        border: solid 1px #ccc;
        margin: 10px auto;
        padding: 20px 30px;
        display: inline-block;
        box-shadow: 0 0 4px #ccc;
        background-color: #FAF8F8;
        overflow: hidden;
        position: relative;
        max-width: 450px;

    h3 {
        margin: 0 0 10px;
        padding: 0;
        line-height: 1.25;
    }

    span {
        font-size: 90%;
    }

    #form {
        max-width: 240px;
        margin: 25px auto 0;

    input {
        margin: 0 5px;
        text-align: center;
        line-height: 80px;
        font-size: 50px;
        border: solid 1px #ccc;
        box-shadow: 0 0 5px #ccc inset;
        outline: none;
        width: 20%;
        transition: all .2s ease-in-out;
        border-radius: 3px;

    input:focus {
        border-color: #fa07fa;
        box-shadow: 0 0 5px #800080 inset;
    }

    input::selection {
        background: transparent;
    }
    }

    button {
        margin:  30px 0 50px;
        width: 100%;
        padding: 6px;
        background-color: #B85FC6;
        border: none;
        text-transform: uppercase;
    }
    }

    div {
        position: relative;
        z-index: 1;
    }

    img {
        position: absolute;
        bottom: -70px;
        right: -63px;
    }
    }
    }
</style>

<div class="container">
    <br>
    <div class="row col-12" >
        <div class="col-sm-3"></div>
        <div class="col-sm" style="text-align: center">
            <div class="row"><br></div>
            <div class="row"><br></div>
            <div class="row"><br></div>
            <div class="row"><br></div>

            <div class="row">
                <div class="col-sm-1"></div>
                <div class="col-sm-10">
                    <img align="center" class="col-12" src="img/Logo_noir_500.png" alt="logo IPRC " >
                </div>

            </div>
        </div>
        <div class="col-sm-3"></div>
    </div>
    <div class="row"><br></div>
    <div class="row"><br></div>
    <div class="row"><br></div>
    <div class="row"><br></div>

    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm">
            <aside class="col-sm-12">

                <div class="card shadow-lg panel panel-default">
                    <article class="card-body">
                        <h4 class="card-title text-center mb-3 mt-1"><?php echo $lang['Login'] ?>
                            <div align="right" >
                                <a style="text-decoration: none;" href="index.php?lang=en">
                                    <svg class="c-icon c-icon-xl">
                                        <use xlink:href="vendors/@coreui/icons/svg/flag.svg#cif-gb"></use>
                                    </svg>
                                </a>
                                |
                                <a style="text-decoration: none;" href="index.php?lang=fr">
                                    <svg class="c-icon c-icon-xl">
                                        <use xlink:href="vendors/@coreui/icons/svg/flag.svg#cif-fr"></use>
                                    </svg>
                                </a>
                            </div>
                        </h4>
                        <hr>

                        <form id="form_login" method="post">
                            <input hidden type="text" id="visitorId" name="visitorId" value="">
                            <input type="hidden" id="hdnJWT"/>
                            <div class="input-group mb-3">
                                <input class="form-control" id="user"  name="user" type="email" value ="<?php echo $email; ?>" required placeholder="<?php echo $lang['Login_inp'] ?>">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <svg class="c-icon">
                                            <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-user"></use>
                                        </svg>
                                    </span>
                                </div>

                            </div>

                            <div class="input-group mb-4" id="show_hide_password">
                                <input class="form-control" id="mdp" type="password" name="mdp" value="<?php echo $mdp; ?>" required placeholder="<?php echo $lang['Password'] ?>"  >
                                <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <svg class="c-icon">
                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-lock-locked"></use>
                                            </svg>
                                        </span>
                                </div>
                            </div>


                            <div class="form-group">
                                <button type="submit" class="btn btn-lg btn-default btn-block" style="background-color:#d9edf7;"><?php echo $lang['Login_btn'] ?></button>

                            </div> <!-- form-group// -->
                        </form>
                        <div id="formMessage" > </div>
                    </article>
                </div> <!-- card.// -->

            </aside> <!-- col.// -->
        </div> <!-- row.// -->
        <div class="col-sm-3"></div>
    </div>

</div>


<!-- /#wrapper -->
<?php
//header NAV Bar
include 'footerAcceuil.php';
ajouter_historique_connexion(get_id_user($email), $email, get_ip(),date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))),'PROJET IVISION GAB','Connexion Echoué');
?>
