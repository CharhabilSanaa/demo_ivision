<?php
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getHistoriqueEtatParcATM($IdATMHisto,$paramettre,$idprivilege,$date_debut_inp,$date_fin_inp)
{
	$val=get_name_terminal_gag($IdATMHisto);
    $connexion=ma_db_connexion();

    $date_debut_s = new DateTime($date_debut_inp);
    $date_fin_s = new DateTime($date_fin_inp);
    $date_debut =  $date_debut_s->format('Y-m-d H:i:s');
    $date_fin = $date_fin_s->format('Y-m-d H:i:s');



    include "languages/" . $_SESSION['lang'] . ".php";

    // echo '<div class="table-responsive" >';
    echo '<div>';
    echo '  <table class="table table-responsive-sm table-hover table-outline mb-0">
	    <thead class="thead-light">
            <th class="text-center">#</th>
            <th class="text-center">'.$lang["date_vacation"].'</th>
            <th class="text-center">'.$lang["dev_stat"].'</th>
          
         
		</thead>
		<tbody>';

    $sql="SELECT `id_vacation_alm`,`id_vacation_bcr`, `id_vacation_cam`, `id_vacation_cdm`, `id_vacation_ceu`, 
    `id_vacation_chk`, `id_vacation_cim`, `id_vacation_crd`, `id_vacation_dep`, `id_vacation_idc`,
    `id_vacation_ipm`, `id_vacation_pin`, `id_vacation_ptr`, `id_vacation_siu`, `id_vacation_ttu`, `id_vacation_vdm`,`vacation_date`, `name_file`	   
    FROM `hist_vacations`
    WHERE `hist_vacations`.`id_atm` = '".mysqli_real_escape_string($connexion,$IdATMHisto)."'  AND if_load = '1' ";
    if((!empty($date_debut))&&(!empty($date_fin)))
    {
        if((strtotime($date_debut) == strtotime($date_fin)))
        {
            $sql = $sql." AND `vacation_date` ='".mysqli_real_escape_string($connexion,$date_debut)."' ";
        }
        else
        {
            $sql = $sql." AND `vacation_date`  BETWEEN '".mysqli_real_escape_string($connexion,$date_debut)."' AND '".mysqli_real_escape_string($connexion,$date_fin)."'  ";
        }
    }
    $sql= $sql. "ORDER BY `id_global_vacation` DESC";

    $param="idATM=".$IdATMHisto."&";
    if (!empty($date_debut)){$param= $param."date_debut=".$date_debut."&";}
    if (!empty($date_fin)){$param= $param."date_fin=".$date_fin."&";}

    //echo $sql;
    $page = new Pagination($sql, 15);
    $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
    $lien = $page->liens(5,$param);
    $SQL = $page->req();
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 050 histdetailvaca :  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 050 !');
    }
    /***************************************************/
    if ($result)
    {
        // Verifications Services autorisé.
        $serviceATMAutorise = explode(',', get_list_service_atm($IdATMHisto));
        foreach($serviceATMAutorise as $service)
        {
            $tableService[] = $service;
        }
        $k=0;
        if(mysqli_num_rows($result)>0)
        {
            $j=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $k++;
                echo '<tr>
				    <td class="text-center">'.$k.'</td>
					<td class="text-center">'. $row["vacation_date"] .'</td>';
                    echo '<td class="text-center">
                    <div class="btn-group">
                        <ul class="list-group list-group-horizontal mb-1">
                            <li class="list-group-item" style="border: none;">
                                <div class="btn-group"> ';
                                    $service = 4;
                                    if (in_array($service, $tableService))//Verifications Services autorisation services
                                    {
                                        getStatusVacation($idprivilege,$service,$paramettre,$IdATMHisto,$row["id_vacation_cdm"],'vacations_CDM','xfs_errors_CDM','CDM',$row["vacation_date"],'WFS_INF_CDM_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                                    }
                                    $service = 7;
                                    if (in_array($service, $tableService))//Verifications Services autorisation services
                                    {
                                        getStatusVacation($idprivilege,$service,$paramettre,$IdATMHisto,$row["id_vacation_cim"],'vacations_CIM','xfs_errors_CIM','CIM',$row["vacation_date"],'WFS_INF_CIM_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                                    }
                                    $service = 12;
                                    if (in_array($service, $tableService))//Verifications Services autorisation services
                                    {
                                        getStatusVacation($idprivilege,$service,$paramettre,$IdATMHisto,$row["id_vacation_pin"],'vacations_PIN','xfs_errors_PIN','PIN',$row["vacation_date"],'WFS_INF_PIN_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                                    }
                                    $service = 13;
                                    if (in_array($service, $tableService))//Verifications Services autorisation services
                                    {
                                        getStatusVacation($idprivilege,$service,$paramettre,$IdATMHisto,$row["id_vacation_ptr"],'vacations_PTR','xfs_errors_PTR','PTR',$row["vacation_date"],'WFS_INF_PTR_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                                    }
                                    $service = 10;
                                    if (in_array($service, $tableService))//Verifications Services autorisation services
                                    {
                                        getStatusVacation($idprivilege,$service,$paramettre,$IdATMHisto,$row["id_vacation_idc"],'vacations_IDC','xfs_errors_IDC','IDC',$row["vacation_date"],'WFS_INF_IDC_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                                    }
                                    /*$service = 14;
                                    if (in_array($service, $tableService))//Verifications Services autorisation services
                                    {
                                        getStatusVacation($idprivilege,$service,$paramettre,$IdATMHisto,$row["id_vacation_siu"],'vacations_SIU','xfs_errors_SIU','SIU',$row["vacation_date"],'WFS_INF_SIU_STATUS',mysqli_real_escape_string($connexion,$row["name_file"]));
                                    }*/

                                    $varcolor=getColorDashboard($IdATMHisto) ;
                                    if($varcolor != "#888683")
                                    {
                                        echo '<a class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                            onClick="javascript:getDashboardATM(\''.$IdATMHisto.'\')" 
                                            data-target="#moduleDashboardATM"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-2x" title="CPU,RAM"></i></strong></a> ';
                                    }
                                    else
                                    {
                                        echo '<a class="text-center dropdown-item " tabindex="-1"><strong style="color:'.$varcolor.'"><i class="fa fa-heartbeat fa-2x" title="CPU,RAM"></i></strong></a>';
                                    }
                                    echo '<a class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                            onClick="javascript:getjournalATM(\'' . $IdATMHisto . '\',\'' . $val[0] . '\')"    
                                            data-target="#detailjournalATM"> <strong style="color:#52c322" ><i class="fa fa-newspaper-o fa-2x" title="E-J"> </i></strong></a>';

                                    echo '<a  title="'.$lang['cmd_hist'].'" class="text-center dropdown-item " tabindex="-1" data-toggle="modal"
                                            onClick="javascript:getcommandeATM(\'' . $IdATMHisto . '\',\'' . $val[0] . '\',\''.$idprivilege.'\')"
                                            data-target="#detailcommandeATM"> <strong style="color:#52c322" >
                                            <svg class="icon x128" height="30" width="30">
                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-monitor"></use>
                                            </svg>
                                            </strong>
                                    </a>';

                                    echo '<a title="'.$lang["det_con_gab"].'" class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                                            onClick="javascript:getdeconATM(\'' . $IdATMHisto . '\')"    
                                            data-target="#detaildeconATM"> <strong style="color:#52c322;">
                                            <svg class="icon x128" height="30" width="30">
                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-link"></use>
                                            </svg>
                                         </strong>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </div>
                   
                    </td>
                    
                </tr>';
                $j++;
                }
                echo '<tr><td colspan="9" class="text-center">';
                echo   '<ul class="pagination justify-content-center">'.$lien.'</ul>';
                echo   '<div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>';
                echo'</td></tr>';
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    echo '  </tbody>
	    </table>
	</div>';
}

?>