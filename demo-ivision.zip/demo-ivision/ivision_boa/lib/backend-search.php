<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */


include("connexion.php");
$connexion=ma_db_connexion();


if(isset($_REQUEST["term"]))
{
    // Prepare a select statement
    $sql = "SELECT `new_list_gab`.`terminal`,`new_list_gab`.`nom_gab` FROM `new_list_gab`,`list_atm_confirmed` 
    WHERE `list_atm_confirmed`.`id_atm` = `new_list_gab`.`id_terminal_xfs`                                                               
    AND (`new_list_gab`.`terminal` LIKE '%".mysqli_real_escape_string($connexion,$_REQUEST["term"])."%' or `new_list_gab`.`nom_gab` LIKE '%".mysqli_real_escape_string($connexion,$_REQUEST["term"])."%')
    AND `list_atm_confirmed`.`state`=1 LIMIT 3";

    //var_dump($sql);
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 000001:  ".$sql."  " .mysqli_error($connexion));
        die('Erreur SQL 000001!'.mysqli_error($connexion));
    }
    if ($result)
    {

        echo '<div class="dropdown-menu show" aria-labelledby="navbarDropdown" >';
        if(mysqli_num_rows($result) > 0)
        {
            // Fetch result rows as an associative array
            while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
            {
                echo "<li class='nav-item active' value='".$row["terminal"]."'>" . $row["terminal"] . " - "  . $row["nom_gab"] . "</li>";
                echo "<div class='dropdown-divider'></div>";
            }

        }
        else
        {
            echo "<li>Aucune résultat trouvé. </li>";
        }
        echo '</div>';
        mysqli_free_result($result);
    }


    // Close statement

}

// close connection
mysqli_close($connexion);
?>