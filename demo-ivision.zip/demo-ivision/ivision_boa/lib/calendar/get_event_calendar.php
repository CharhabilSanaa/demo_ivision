<?php
header('Content-Type: application/json');
$ord="Orders of ";
$ord_fund="Total amount ";
$ord_fund_extr="Outsourced ";
$ord_fund_hyb="Hybrid ";
$devise="MAD";
$lang="en";

if ( $_GET["mylang"]==="fr")
{
    $lang="fr";
    $ord="Commandes du ";
    $ord_fund="Montant total ";
    $ord_fund_extr="Externalisés ";
    $ord_fund_hyb="Hybride ";
    $devise="MAD";
}




include("../lib.php");
$date_tomorrow= date("Y-m-d", strtotime("+1 day"));
$date= date("Y-m-d");
$conn= ma_db_connexion();
$region_sql="";
//var_dump();
if ($_GET["region"]<>0)
{
    $region_sql=" AND `code_bank` = '".$_GET["region"]."' ";
}
if ($_GET["code_agence"]<>0)
{
    $region_sql=" AND `code_agence` = '".$_GET["code_agence"]."' ";
}
if ($_GET["terminal"]<>0)
{
    $region_sql=" AND `terminal` = '".$_GET["terminal"]."' ";
}


$sqlQuery = "SELECT `id_data`,`id_gab`,`date_data`,SUM((`result_packages_100`*100000)+(`result_packages_200`*200000)) as `Total` FROM `cash_data_final`
WHERE calculated_amount_supply>0 and `id_gab` in(select `terminal` from `new_list_gab` WHERE `state_calcul` = 1 $region_sql ) GROUP by `date_data`";
//`result_if_supply_cash` = 1 AND  `date_data` >= '2020-06-12' AND  `date_data` <= '".$date."' and
/*$sqlQuery2 = " SELECT `id_data`,`id_gab`,`date_data`,sum(`calculated_amount_supply`) as `calculated_amount_supply` FROM `cash_data_final`
WHERE `calculated_amount_supply` > 0  AND  `date_data` >= '".$date_tomorrow."' AND  `date_data` BETWEEN '".$_GET['start']."' AND '".$_GET['end']."'
and `id_gab` in(select `terminal` from `new_list_gab` WHERE `state_calcul` = 1 $region_sql ) GROUP by `date_data`";*/


$result = mysqli_query($conn,$sqlQuery);
if (!$result)
{
    error_log("Erreur SQL 1000:  ".$sqlQuery."  " .mysqli_error($conn));
    die("Erreur SQL 1000".mysqli_error($conn));
}
if ($result)
{
    $result_packages=0;
    // var_dump(mysqli_num_rows($result));
    $data = array();
    foreach ($result as $row)
    {
        $extrnalises=number_format_short_devis(get_comm_gestionnaire(1,1,$_GET["region"],$_GET["code_agence"],$_GET["terminal"],$row["date_data"]),$lang,$devise);
        $hybride=number_format_short_devis(get_comm_gestionnaire(1,2,$_GET["region"],$_GET["code_agence"],$_GET["terminal"],$row["date_data"]),$lang,$devise);
        $result_packages=number_format_short_devis($row["Total"],$lang,$devise);
        $data[] = array(
            'id' => $row["id_data"],
            'title' => ' '.$ord.' '.convert_to_jjmmaa($row["date_data"],$_GET["mylang"]),
            'description' =>' <br>
                        <table class="table-bordered table-hover table-striped">
                            <tr class="container">
                                    <th class="col-sm">
                                     ' .$ord_fund.' 
                                    </th>
                                    <td class="col-sm">
                                    '.$result_packages.'
                                    </td>
                            </tr>
                            <tr class="container">
                                
                                    <th class="col-sm">
                                        ' .$ord_fund_extr.' 
                                    </th>
                                    <td class="col-sm">
                                        '.$extrnalises.'
                                    </td>
                              
                            </tr> 
                            <tr class="container">
                               
                                    <th class="col-sm">
                                        '.$ord_fund_hyb.'  
                                    </th>
                                    <td class="col-sm" >
                                        '.$hybride.'
                                    </td>
                               
                            </tr>
                            </table>',
            'start' => $row["date_data"],
            'end' => $row["date_data"],
            'className'=> 'fc-bg-default',
            'icon' => 'calendar',
            'href' => "javascript:ShowDetaiCommande('".$row["date_data"]."','".$_GET["region"]."','".$_GET["code_agence"]."','".$_GET["terminal"]."',1,'".$_GET["mylang"]."')"

        );

    }
}
/*$result2 = mysqli_query($conn,$sqlQuery2);
if (!$result2)
{
    error_log("Erreur SQL 1000:  ".$sqlQuery."  " .mysqli_error($conn));
    die("Erreur SQL 1000".mysqli_error($conn));
}
if ($result2)
{
    $result_packages=0;
    // var_dump(mysqli_num_rows($result));

    foreach ($result2 as $row) {
        $extrnalises=number_format_short2(get_comm_gestionnaire(2,1,$_GET["region"],$_GET["code_agence"],$_GET["terminal"],$row["date_data"]))." ".$devise;
        $hybride=number_format_short2(get_comm_gestionnaire(2,2,$_GET["region"],$_GET["code_agence"],$_GET["terminal"],$row["date_data"]))." ".$devise;
        $data[] = array(
            'id' => $row["id_data"],
            'title' => ' '.$ord.' '.$row["date_data"],
            'description' =>' <br>
                        <table class="table-bordered table-hover table-striped">
                            <tr class="container">
                                    <th class="col-sm">
                                     '.$ord_fund.'
                                    </th>
                                    <td class="col-sm">
                                    '.number_format_short2($row["calculated_amount_supply"]). ' '.$devise.'
                                    </td>
                            </tr>
                            <tr class="container">
                                
                                    <th class="col-sm">
                                    '.$ord_fund_extr.'
                                    </th>
                                    <td class="col-sm">
                                    '.$extrnalises.'
                                    </td>
                              
                            </tr> 
                            <tr class="container">
                               
                                    <th class="col-sm">
                                     '.$ord_fund_hyb.' 
                                    </th>
                                    <td class="col-sm" >
                                    '.$hybride.'
                                    </td>
                               
                            </tr>
                            </table>',
            'start' => $row["date_data"],
            'end' => $row["date_data"],
            'className'=> 'fc-bg-default',
            'icon' => 'calendar',
            'href' => "javascript:ShowDetaiCommande('".$row["date_data"]."','".$_GET["region"]."','".$_GET["code_agence"]."','".$_GET["terminal"]."',2,'".$_GET["mylang"]."')"


        );

    }
}*/

mysqli_free_result($result);

mysqli_close($conn);
$date= date("Y");
$connexion= ma_db_connexion33();
$date_ferie =array();

$sqlQuery3="SELECT `id_ferie`,`nom_ferie`,`date_ferie` FROM `iprc_authentification`.`ferie` WHERE DATE_FORMAT(`date_ferie`, '%Y') = '".mysqli_real_escape_string($connexion,$date)."'";

$result3 = mysqli_query($connexion,$sqlQuery3);
if (!$result3)
{
    error_log("Erreur SQL 1020354:  ".$sqlQuery3."  " .mysqli_error($connexion));
    die("Erreur SQL 1020354".mysqli_error($connexion));
}
if ($result3)
{

    if(mysqli_num_rows($result3)>0)
    {
        while ($row = mysqli_fetch_assoc($result3))
        {
            $data[]=array('id' => $row["id_ferie"],
                'title' => $row["nom_ferie"],
                'start' => $row["date_ferie"],
                'end' => $row["date_ferie"],
                'holiday' =>$row["date_ferie"]);
        }
    }
}

mysqli_free_result($result3);

mysqli_close($connexion);

echo json_encode($data);

?>