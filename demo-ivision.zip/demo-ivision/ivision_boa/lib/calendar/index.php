<?php
header("location: ../index.php");
?><?php
