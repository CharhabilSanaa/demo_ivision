<?php
function getDeclarer2($porteur,$numCarte,$numCompte,$cin,$tel,$etatTel,$dureeRappel,$typeProduit,$typeAppel,$typeBlocage,$remarque)
{

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_etat_tel($id)
{
    $connexion=ma_db_connexion();
    $libelle="";
    $sql = "SELECT  `libelle` FROM `new_etat_tel` WHERE idEtat = '".$id."' ";
    mysqli_query(ma_db_connexion(),"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 10:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 10 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            $libelle = $row["libelle"];
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return $libelle;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_select_etat_tel()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `idEtat`, `libelle` FROM `new_etat_tel` ORDER BY `libelle` ASC";
    mysqli_query(ma_db_connexion(),"SET CHARACTER SET 'utf8'");

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 11:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 11 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["idEtat"].'">'.$row["libelle"].'</option>';
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_select_etat_contact()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `idEtat`, `libelle` FROM `new_etat_contact`";
    mysqli_query(ma_db_connexion(),"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 12:  ".$sql."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 12 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["idEtat"].'">'.$row["libelle"].'</option>';
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDeclarer1($porteur,$numCarte,$numCompte,$cin,$tel,$etatTel,$dureeRappel,$typeProduit,$typeAppel,$typeBlocage,$remarque)
{
echo '										<div class="row">
												<div class="col-lg-6">	
                                                  												
														<div class="form-group">
															<label>Porteur</label>
															<input type="text" name="porteur" id="porteur1" placeholder="Porteur"   value="';if($porteur<>""){echo $porteur;}echo '"  required  class="form-control">
														</div>
														
														<div class="form-group">
															<label>N° Carte</label>
															<input type="text" name="numCarte" id="numCarte1"  placeholder="Num Carte"   value="';if($numCarte<>""){echo $numCarte;}echo '" required  class="form-control">
														</div>
												</div>
											</div>

';	
}
?>