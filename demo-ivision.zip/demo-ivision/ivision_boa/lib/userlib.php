<?php

include("connexion.php");
ma_db_connexion();
// error_reporting(E_ALL);
// ini_set('display_errors', '1');

//verif_habilitation
//verif_user
//charger_habilitation
//charger_habilitation_sous_menu
//charger_habilitation_action
//chager_ip_adresse
//chager_id_option_projet
//chager_id_option_backoffice
//get_utilisateur
//get_heure_backoffice
//get_ip_adresse
//get_ip
//user_online
//chager_id_option_messagerie_projet
//charger_habilitation_backoffice
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function verif_habilitation($habilitation, $id_habilitation)
{
    if ($habilitation<>"")
    {
        for ($i=0; $i < count($habilitation) ; $i++)
        {
            if ($habilitation[$i]==$id_habilitation)
            {
                return true;
            }
        }
    }
    else
    {
        return false;
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function get_id_user($user)
{
	$connexion=ma_db_connexion_user();
	$sql = "SELECT  `id_utilisateur` FROM `new_utilisateur`		WHERE email like '".mysqli_real_escape_string($connexion,$user)."'";

	$result=mysqli_query($connexion,$sql);
	if (!$result)
	{
	    error_log("Erreur sql 600:  ".$sql."   ".mysqli_error($connexion));
		// echo mysqli_error($connexion);
	    die('ERREUR QUERY 600 !'.mysqli_error($connexion));
		
	}
						
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                return	$row["id_utilisateur"];
            }
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_last_connexion($user)
{

    $connexion=ma_db_connexion_user();
    $sql = "UPDATE  `new_utilisateur` SET  `date_last_con` =  now() WHERE  `new_utilisateur`.`email` like '".mysqli_real_escape_string($connexion,$user)."';";
    $result=mysqli_query($connexion,$sql);
	if (!$result)
	{
	    error_log("Erreur sql 601:  ".$sql."   ".mysqli_error($connexion));
	    die('ERREUR QUERY 601 !');
	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////
function regle_heure_backoffice()
{ 
  $connexion=ma_db_connexion_user();
  $sql="SELECT `id_regle_heure`, `fusion_horaie` FROM `new_regle_heure`  WHERE `id_regle_heure`='1'";

	$result=mysqli_query($connexion,$sql);
	if (!$result)
			{
				error_log("Erreur sql 602:  ".$sql."   ".mysqli_error($connexion));
				die('ERREUR QUERY 602 !');
			}
			
if ($result) 
	{$i=0;	
		if(mysqli_num_rows($result)>0)
			{   
				while ($row = mysqli_fetch_assoc($result)) 
					{						
						return $row["fusion_horaie"];
					}
			}
		else
			{	
					return 0;
			}				
		mysqli_free_result($result);
	}



    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function antixss($input)
{
	$connexion=ma_db_connexion();
    $new=strip_tags($input);
    $new1 = htmlspecialchars($new, ENT_QUOTES);
    $new = mysqli_real_escape_string($connexion,$new1);
    mysqli_close($connexion);
    return $new;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getlenght($keyword) {
return strlen($keyword);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function ajouter_historique_connexion($id_user,$mail,$ip_adresse,$date_connexion,$projet,$etat_connexion)
{
    $connexion=ma_db_connexion_user();
    $s = "SELECT `id_connexion`
	FROM `historique_connexion_user` 
	WHERE `date_connexion` = '".mysqli_real_escape_string($connexion,$date_connexion)."'";

    $rs=mysqli_query($connexion,$s);
    if (!$rs)
    {
        error_log("Erreur sql 603:  ".$s."   ".mysqli_error($connexion));
        die('ERREUR QUERY 603 !');
    }
    if((mysqli_num_rows($rs)==0) && ($mail<>""))
    {
        $sql = "INSERT INTO `historique_connexion_user` (`id_connexion`, `id_utilisateur`, `email`, `adresse_ip`,`date_connexion` , `projet`, `etat_connexion`) 
		VALUES (NULL, '".$id_user."', '".$mail."', '".$ip_adresse."','".$date_connexion."', '".$projet."', '".$etat_connexion."')";
		$result=mysqli_query($connexion,$sql);
		if (!$result)
		{
		    error_log("Erreur sql 604:  ".$sql."   ".mysqli_error($connexion));
		    die('ERREUR QUERY 604 !');
		}
				
    }
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////////////////////////////   
function get_ip()
{
	$connexion=ma_db_connexion();
    if ( isset ( $_SERVER['HTTP_X_FORWARDED_FOR'] ) )
    {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    elseif ( isset ( $_SERVER['HTTP_CLIENT_IP'] ) )
    {
        $ip  = $_SERVER['HTTP_CLIENT_IP'];
    }
    else
    {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return htmlspecialchars(mysqli_real_escape_string($connexion,$ip));
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_heure_backoffice()
{
echo '<table class="table  table-striped">
<tr><th colspan=3><strong><p class="text-center">Date et l\'heure  : </p></strong></th></tr>
<tr><th><strong><p class="text-right"><a href="javascript:modifier_heure_backoffice(\'1\',\'0\')"><span class="fa fa-minus"></span></a> Heure </p></strong></th><th><strong><p class="text-center">'.date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))).'</p> </strong></th><th><strong><p class="text-left"><a href="javascript:modifier_heure_backoffice(\'1\',\'1\')"><span class="glyphicon glyphicon-plus"></span></a> Heure </p> </strong></th></tr></table>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_ip_adresse()
{
echo '<table class="table  table-striped"><tr><th><strong><p class="text-center">Votre adresse IP est </p></tr><tr> </strong></th><th><strong><p class="text-center">' . get_ip ().'</p> </strong></th></tr></table>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_utilisateur($id)
{
    $connexion = ma_db_connexion_user();
    $sql = "SELECT  `email` FROM `new_utilisateur`    WHERE `id_utilisateur` = '".$id."'";

    $result=mysqli_query($connexion,$sql);
	if (!$result)
	{
	    error_log("Erreur sql 605:  ".$sql."   ".mysqli_error($connexion));
	    die('ERREUR QUERY 605 !');
	}
 
 
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
				while ($row = mysqli_fetch_assoc($result)) 
  				{
  				    if(preg_match('`[-_.]`',substr($row["email"],1, 1)))
  				    {
  				        return substr(strtoupper(str_replace('@iprc.ma' ,'',($row["email"]))),2);
  				    }
					else
					{
					    return strtoupper(str_replace('@iprc.ma' ,'',($row["email"])));
					}

                }
          }
			mysqli_free_result($result);	  
	}
	mysqli_close($connexion);
	
} 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function verif_user($user,$mdp)
{
$ipadr=get_ip();

$sql = "SELECT `email`,`password`  
FROM `new_utilisateur`,`new_utilisateur_ip_adresse`,`new_adressage_ip` 
WHERE `new_utilisateur`.`id_utilisateur`=`new_utilisateur_ip_adresse`.`id_utilisateur`
AND `new_adressage_ip`.`id_ipadresse`=`new_utilisateur_ip_adresse`.`id_ip_adress`
AND  (`commentaire` = LOWER('".$ipadr."') OR `commentaire` = LOWER('0.0.0.0'))
AND `new_utilisateur_ip_adresse`.`etat`='1'
AND email = LOWER('".$user."') 
AND `password` = AES_ENCRYPT('IPRC','".$mdp."') 
AND `new_utilisateur`.`etat`=1";

$connexion = ma_db_connexion_user();
 $result=mysqli_query($connexion,$sql);
	if (!$result)
			{
				error_log("Erreur sql 606:  ".$sql."   ".mysqli_error($connexion));
				die('ERREUR QUERY 606 !');
			}

if ($result) 
	{	
		if(mysqli_num_rows($result)>0)
			{
				while ($row = mysqli_fetch_assoc($result)) 
					{
						if ($row["email"] == mb_strtolower($user)) 
							{
							return true;
							}
						else
							{
							return false;
							}						
					}
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function charger_habilitation_menu($user)
{
$habilitation = array();	
$sql = "SELECT `id_habili_user`
FROM `new_habilitation_utilisateur`,  `new_utilisateur`
WHERE `new_utilisateur`.`id_utilisateur`=`new_habilitation_utilisateur`.`id_utilisateur`
AND `email` like '".$user."'
and `new_habilitation_utilisateur`.`etat`=1";

 $connexion = ma_db_connexion_user();
  $result=mysqli_query($connexion,$sql);
	if (!$result)
			{
				error_log("Erreur sql 607:  ".$sql."   ".mysqli_error($connexion));
				die('ERREUR QUERY 607 !');
			}
			
if ($result) 
	{$i=0;	
		if(mysqli_num_rows($result)>0)
			{   
				while ($row = mysqli_fetch_assoc($result)) 
  				{
						$habilitation[$i]=$row["id_habili_user"];
						$i++;
				}
			}
		mysqli_free_result($result);
	}	
mysqli_close($connexion);
return $habilitation;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function charger_habilitation($user)
{
$habilitation = array();	
  $sql = "SELECT `id_habili_user`
FROM `new_habilitation_utilisateur`,  `new_utilisateur`
WHERE `new_utilisateur`.`id_utilisateur`=`new_habilitation_utilisateur`.`id_utilisateur`
AND `email` like '".$user."'
and `new_habilitation_utilisateur`.`etat`=1";

$connexion = ma_db_connexion_user();
  $result=mysqli_query($connexion,$sql);
	if (!$result)
			{
				error_log("Erreur sql 608:  ".$sql."   ".mysqli_error($connexion));
				die('ERREUR QUERY 608 !');
			}
			
if ($result) 
	{$i=0;	
		if(mysqli_num_rows($result)>0)
			{   
				while ($row = mysqli_fetch_assoc($result)) 
					{
						
						$habilitation[$i]=$row["id_habili_user"];
						$i++;
					}
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
return $habilitation;


}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function charger_habilitation_sous_menu($user)
{
$habilitations = array();	
$sql = "SELECT `id_habili_user`
FROM `new_habilitation_utilisateur_sous_menu`,  `new_utilisateur`
WHERE `new_utilisateur`.`id_utilisateur`=`new_habilitation_utilisateur_sous_menu`.`id_utilisateur`
AND `email` like '".$user."'
and `new_habilitation_utilisateur_sous_menu`.`etat`=1";

$connexion = ma_db_connexion_user();
  $result=mysqli_query($connexion,$sql);
	if (!$result)
			{
				error_log("Erreur sql 609:  ".$sql."   ".mysqli_error($connexion));
				die('ERREUR QUERY 609 !');
			}

if ($result) 
	{$i=0;	
		if(mysqli_num_rows($result)>0)
			{   
				while ($row = mysqli_fetch_assoc($result)) 
					{
						
						$habilitations[$i]=$row["id_habili_user"];
						$i++;
					}
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
return $habilitations;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function charger_habilitation_action($user)
{

$habilitations = array();	
$sql = "SELECT `id_habili_user`
FROM `new_habilitation_utilisateur_action`,  `new_utilisateur`
WHERE `new_utilisateur`.`id_utilisateur`=`new_habilitation_utilisateur_action`.`id_utilisateur`
AND `email` like '".$user."'
and `new_habilitation_utilisateur_action`.`etat`=1";

$connexion = ma_db_connexion_user();
$result=mysqli_query($connexion,$sql);
	if (!$result)
			{
				error_log("Erreur sql 610:  ".$sql."   ".mysqli_error($connexion));
				die('ERREUR QUERY 610 !');
			}
			
if ($result) 
	{$i=0;	
		if(mysqli_num_rows($result)>0)
			{   
				while ($row = mysqli_fetch_assoc($result)) 
					{
						
						$habilitations[$i]=$row["id_habili_user"];
						$i++;
					}
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
return $habilitations;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function chager_ip_adresse($user)
{

$ip_adresse = array();	
$sql = "SELECT `id_ip_adress`
FROM `new_utilisateur_ip_adresse`,  `new_utilisateur`
WHERE `new_utilisateur`.`id_utilisateur`=`new_utilisateur_ip_adresse`.`id_utilisateur`
AND `email` like '".$user."'
and `new_utilisateur_ip_adresse`.`etat`=1";

$connexion = ma_db_connexion_user();
$result=mysqli_query($connexion,$sql);
	if (!$result)
			{
				error_log("Erreur sql 611:  ".$sql."   ".mysqli_error($connexion));
				die('ERREUR QUERY 611 !');
			}
			

if ($result) 
	{$i=0;	
		if(mysqli_num_rows($result)>0)
			{   
				while ($row = mysqli_fetch_assoc($result)) 
					{
						
						$ip_adresse[$i]=$row["id_ip_adress"];
						$i++;
					}
			}
		mysqli_free_result($result);
	}

    mysqli_close($connexion);
return $ip_adresse;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function chager_id_option_projet($user)
{

$id_projet = array();	
$sql = "SELECT `id_habili_user`
FROM `new_habilitation_utilisateur_projet`,  `new_utilisateur`
WHERE `new_utilisateur`.`id_utilisateur`=`new_habilitation_utilisateur_projet`.`id_utilisateur`
AND `email` like '".$user."'
and `new_habilitation_utilisateur_projet`.`etat`=1";

$connexion = ma_db_connexion_user();
$result=mysqli_query($connexion,$sql);
	if (!$result)
			{
				error_log("Erreur sql 612:  ".$sql."   ".mysqli_error($connexion));
				die('ERREUR QUERY 612 !');
			}
			
if ($result) 
	{$i=0;	
		if(mysqli_num_rows($result)>0)
			{   
				while ($row = mysqli_fetch_assoc($result)) 
					{
						
						$id_projet[$i]=$row["id_habili_user"];
						$i++;
					}
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
return $id_projet;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function chager_id_option_backoffice($user)
{
    $connexion = ma_db_connexion_user();
    $id_projet = array();
    if ($user<>'')
    {
        $sql = "SELECT `id_backoffice`
        FROM `new_backoffice_utilisateur`,  `new_utilisateur`
        WHERE `new_utilisateur`.`id_utilisateur`=`new_backoffice_utilisateur`.`id_utilisateur`
        AND `email` like '".$user."'
        and `new_backoffice_utilisateur`.`etat`=1";

        $result=mysqli_query($connexion,$sql);
        if (!$result)
        {
            error_log("Erreur sql 613:  ".$sql."   ".mysqli_error($connexion));
            die('ERREUR QUERY 613 !');
        }

        if ($result)
        {
            $i=0;
            if(mysqli_num_rows($result)>0)
			{
			    while ($row = mysqli_fetch_assoc($result))
                {
                    $id_projet[$i]=$row["id_backoffice"];
                    $i++;
                }
			}
		mysqli_free_result($result);
        }
			
		
    }
    mysqli_close($connexion);
    return $id_projet;
}

function verif_etat_blocage($id_utilisateur)
{
    $connexion = ma_db_connexion_user();
    $bol_etat_bloc=false;
    $sql = "SELECT  `etat_blocage` FROM `new_utilisateur`  WHERE `id_utilisateur` = '". mysqli_real_escape_string($connexion,$id_utilisateur)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 614:  ".$sql."   ".mysqli_error($connexion));
        die('ERREUR QUERY 614 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            $etat_bloc = $row["etat_blocage"];
            if($etat_bloc==0)
            {
                $bol_etat_bloc=false;
            }
            else
            {
                $bol_etat_bloc=true;
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

    return $bol_etat_bloc;
}

function verif_existe_user($user)
{
    $connexion = ma_db_connexion_user();
    $bol_existe_user=false;
    $ipadr=get_ip();

    $sql = "SELECT `email` 
    FROM `new_utilisateur`,`new_utilisateur_ip_adresse`,`new_adressage_ip` 
    WHERE `new_utilisateur`.`id_utilisateur`=`new_utilisateur_ip_adresse`.`id_utilisateur`
    AND `new_adressage_ip`.`id_ipadresse`=`new_utilisateur_ip_adresse`.`id_ip_adress`
    AND  (`commentaire` = LOWER('".mysqli_real_escape_string($connexion,$ipadr)."') OR `commentaire` = LOWER('0.0.0.0'))
    AND `new_utilisateur_ip_adresse`.`etat`='1'
    AND email = LOWER('".mysqli_real_escape_string($connexion,$user)."') 
    AND `new_utilisateur`.`etat`=1";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 615:  ".$sql."   ".mysqli_error($connexion));
        die('ERREUR QUERY 615 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            if ($row["email"] === mb_strtolower($user))
            {
                $bol_existe_user=true;
            }
            else
            {

                $bol_existe_user= false;
            }

        }
        else
        {
            $bol_existe_user= false;
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

    return $bol_existe_user;
}
function verif_duree_blocage($id_utilisateur)
{
    $connexion = ma_db_connexion_user();
    $bol_duree_bloc=false;
    $sql = "SELECT  `date_blocage` FROM `new_utilisateur`  WHERE `id_utilisateur` = '". mysqli_real_escape_string($connexion,$id_utilisateur)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 616:  ".$sql."   ".mysqli_error($connexion));
        die('ERREUR QUERY 616 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            $today = date("Y-m-d H:i:s");
            $date_bloc = $row["date_blocage"];

            $dateDiff=dateDiff($today, $date_bloc);
            if($dateDiff>=10)
            {
                //echo "today : $today </br>";
                //echo "date_bloc : $date_bloc </br>";
                //echo "dateDiff : $dateDiff";die();
                $bol_duree_bloc=true;
            }
            else
            {
                //echo "dateDiff";die();
                $bol_duree_bloc=false;
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

    return $bol_duree_bloc;
}

function update_tent_date_up($id_utilisateur)
{
    $connexion = ma_db_connexion_user();

    $sql = "SELECT  `nbr_tentative` FROM `new_utilisateur`  WHERE `id_utilisateur` = '". mysqli_real_escape_string($connexion,$id_utilisateur)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 617:  ".$sql."   ".mysqli_error($connexion));
        die('ERREUR QUERY 617 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            $nbr_tentative = $row["nbr_tentative"]+1;
            $sql1 = "UPDATE  `new_utilisateur` SET  `date_blocage` =  now(),
            `nbr_tentative` =  '".mysqli_real_escape_string($connexion,$nbr_tentative)."'
            WHERE  `id_utilisateur` = '". mysqli_real_escape_string($connexion,$id_utilisateur)."'";

            $result2=mysqli_query($connexion,$sql1);
            if (!$result2)
            {
                error_log("Erreur sql 618:  ".$sql1."   ".mysqli_error($connexion));
                die('ERREUR QUERY 618 !');
            }

        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

}

function update_tent_date_initial_value($id_utilisateur)
{
    $connexion = ma_db_connexion();
    $sql = "UPDATE  `new_utilisateur` SET  `etat_blocage` = 0 ,
            `date_blocage` =  '0000-00-00 00:00:00',
            `nbr_tentative` =  0
            WHERE  `id_utilisateur` = '". mysqli_real_escape_string($connexion,$id_utilisateur)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        return true;
        error_log("Erreur sql 619:  ".$sql."   ".mysqli_error($connexion));
        die('ERREUR QUERY 619 !');
    }
    mysqli_close($connexion);
}

function getnbr_tentative($id_utilisateur)
{
    $connexion = ma_db_connexion_user();
    $nbr_tentative=0;
    $sql = "SELECT  `nbr_tentative` FROM `new_utilisateur`  WHERE `id_utilisateur` = '". mysqli_real_escape_string($connexion,$id_utilisateur)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 620:  ".$sql."   ".mysqli_error($connexion));
        die('ERREUR QUERY 620 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);

            $nbr_tentative = $row["nbr_tentative"];
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

    return $nbr_tentative;
}

function update_block_tent_date_($id_utilisateur)
{
    $connexion = ma_db_connexion_user();

    $sql = "SELECT  `nbr_tentative` FROM `new_utilisateur`  WHERE `id_utilisateur` = '". mysqli_real_escape_string($connexion,$id_utilisateur)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur sql 617:  ".$sql."   ".mysqli_error($connexion));
        die('ERREUR QUERY 617 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            $nbr_tentative = $row["nbr_tentative"]+1;
            $sql1 = "UPDATE  `new_utilisateur` SET  `etat_blocage` = 1 ,
            `date_blocage` =  now(),
            `nbr_tentative` =  '".mysqli_real_escape_string($connexion,$nbr_tentative)."'
            WHERE  `id_utilisateur` = '". mysqli_real_escape_string($connexion,$id_utilisateur)."'";

            $result2=mysqli_query($connexion,$sql1);
            if (!$result2)
            {
                error_log("Erreur sql 618:  ".$sql1."   ".mysqli_error($connexion));
                die('ERREUR QUERY 618 !');
            }

        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

}

function dateDiff($d1, $d2)
{
    $d1 = (is_string($d1) ? strtotime($d1) : $d1);
    $d2 = (is_string($d2) ? strtotime($d2) : $d2);
    $diff_secs = abs($d1 - $d2);
    return floor($diff_secs / 60);
}

?>