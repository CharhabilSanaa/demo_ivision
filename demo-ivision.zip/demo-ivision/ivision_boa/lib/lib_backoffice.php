<?php
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function return_sexe_user($id_user)
{
    $sexe="M";
    $connexion = ma_db_connexion();
    $sql="SELECT  `sexe` from  `iprc_authentification_cfg`.`new_utilisateur` where id_utilisateur = '".mysqli_real_escape_string($connexion,$id_user)."' ";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1234524:  ".$sql."  " .mysqli_error($connexion));
        die('Erreur SQL 1234524!');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            $sexe = $row["sexe"];
        }
    }
    mysqli_close($connexion);
    return $sexe;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_array_information_gab($id_gab)
  {
      $connexion=ma_db_connexion();

        $sql = "SELECT `nom_gab`, `ip_adresse_gab`, `id_fournisseur`, `id_prestataire`, `gestion`, `code_group`, `emplacement`, `type_emplacement`, `numero_serie` 
                FROM `new_list_gab`	WHERE 	`new_list_gab`.`terminal`  like '".mysqli_real_escape_string($connexion,$id_gab)."'";
      $result=mysqli_query($connexion,$sql);
      if (!$result)
      {
          error_log("Erreur SQL 800: ".$sql."  ".mysqli_error($connexion));
          die('ERREUR QUERY 800 !');
      }

if ($result)
	{
         if (mysqli_num_rows($result)>0)
          {
			  $i=0;
          while ($row = mysqli_fetch_assoc($result)) 
            {
                $nom_gab[$i] = $row["nom_gab"];
                $ip_adresse_gab[$i] = $row["ip_adresse_gab"];
                $id_prestataire[$i] = $row["id_prestataire"];
                $id_fournisseur[$i] = $row["id_fournisseur"];
                $gestion[$i] = $row["gestion"];
                $code_group[$i] = $row["code_group"];
                $emplacement[$i] = $row["emplacement"];
                $type_emplacement[$i] = $row["type_emplacement"];
                $numero_serie[$i] = $row["numero_serie"];
				$i++;
            }
     
				return  array($nom_gab[0], $ip_adresse_gab[0], $id_prestataire[0], $id_fournisseur[0], $gestion[0], $code_group[0], $emplacement[0], $type_emplacement[0], $numero_serie[0]); 
          }  
		  mysqli_free_result($result);	
	}//if ($result)
    else
    {
        return  array(" ", " ", " ", " ", " ", " ", " ", " ", " ");
    }
      mysqli_close($connexion);
   }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nom_personne_avise($id_incident)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT count(`id_incident`) AS idincident FROM `new_intevention_incident` 
    WHERE  `new_intevention_incident`.`id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $req=mysqli_query($connexion,$sql);
    if (!$req)
    {
        error_log("Erreur SQL 801: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 801 !');
    }
if ($req)
	{
	if(mysqli_num_rows($req)>0)
	{	
			while ($row = mysqli_fetch_assoc($req))
					{
						if ($row["idincident"]<2) 
						{
										return '';
						}
						else if (($row["idincident"]>2) && ($row["idincident"]<8))
						{
                            $s = "SELECT `nom_contact` FROM `new_contact_relance` WHERE `id_contact` = '".mysqli_real_escape_string($connexion,$row["idincident"])."'";
                            $r=mysqli_query($connexion,$s);
                            if (!$r)
                            {
                                error_log("Erreur SQL 802: ".$s."  ".mysqli_error($connexion));
                                die('ERREUR QUERY 802 !');
                            }
                            if ($r)
                                {
                                    if(mysqli_num_rows($r)>0)
                                        {
                                            while ($row1 = mysqli_fetch_assoc($r))
                                                    {
                                                        $row["nom_contact"];
                                                    }
                                        }
                                mysqli_free_result($r);
                                }
						}
						else
						{
                            $s = "SELECT `nom_contact` FROM `new_contact_relance` WHERE `id_contact` = 8 ";
                            $r=mysqli_query($connexion,$s);
                            if (!$r)
                            {
                                error_log("Erreur SQL 803: ".$s."  ".mysqli_error($connexion));
                                die('ERREUR QUERY 803 !');
                            }
                            if ($r)
                            {
                                if(mysqli_num_rows($r)>0)
                                    {
                                        while ($row1 = mysqli_fetch_assoc($r))
                                                {
                                                    $row["nom_contact"];
                                                }
                                    }
                            mysqli_free_result($r);
                            }
						}
					}
			 

			
	}
	else
	{	
			return '';
	}
mysqli_free_result($req);
	}
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_intervention_id($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	id_intevention, libelle_intevention FROM  `new_action_intervention`  WHERE `new_action_intervention`.`id_intevention` = '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 804: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 804 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
        while ($row = mysqli_fetch_assoc($result))
                {
                        echo '<option value="'.$row["id_intevention"].'">'.$row["libelle_intevention"].'</option>';
                }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_intervention_prestataire()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	id_intevention, libelle_intevention FROM  `new_action_intervention`";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 805: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 805 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["id_intevention"].'">'.$row["libelle_intevention"].'</option>';
            }
        }
		else
        {
            echo '<option value=""></option>';
        }
    mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_type_contact($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`id_type`,	`libelle` FROM  `new_libelle_type_contact`	WHERE `new_libelle_type_contact`.`id_type` =  '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 806: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 806 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						echo '<option value="'.$row["id_type"].'">'.$row["libelle"].'</option>';			
					}
			}	

    mysqli_free_result($result);
	}
    mysqli_close($connexion);

}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_etat_contact($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`id_type`,	`libelle` FROM  `new_type_contact`	WHERE `new_type_contact`.`id_type` =  '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 807: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 807 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["id_type"].'">'.$row["libelle"].'</option>';
            }
        }
    mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function html_entity_decode_outlouk($texte) 
	{

    $texte = str_replace("&lt;p&gt;","%0D", $texte);
	$texte = str_replace("&lt;/p&gt;","%0D", $texte);
	$texte=nl2br(strip_tags($texte,"&amp;<p><br><i><u><img>&nbsp;&nbsp;"));
    $texte = str_replace("es&amp;op=","es%26op%3D", $texte);

	$texte = str_replace("&lt;span style=&quot;line-height:1.6em&quot;&gt;","", $texte);
	$texte = str_replace("&lt;/span&gt;","%0D", $texte);
    $texte = str_replace("<br>","%0D", $texte);	
	$texte = str_replace("<br />","%0D", $texte);	
	$texte = str_replace("<br/>","%0D", $texte);
//   $str = mb_convert_encoding($str, 'UTF-16', 'UTF-8');
/*	$texte = str_replace("‘","%91", $texte);
	$texte = str_replace("’","%92", $texte);
	$texte = str_replace("“","%93", $texte);
	$texte = str_replace("”","%94", $texte);
	$texte = str_replace("°","%b0", $texte);
	$texte = str_replace("º","%ba", $texte);
	$texte = str_replace("Ç","%c7", $texte);
	$texte = str_replace("È","%c8", $texte);
	$texte = str_replace("É","%c9", $texte);
    $texte = str_replace("Ê","%ca", $texte);
	$texte = str_replace("Ë","%cb", $texte);
	$texte = str_replace("Ö","%d6", $texte);
	$texte = str_replace("à","%e0", $texte);
	$texte = str_replace("á","%e1", $texte);
	$texte = str_replace("â","%e2", $texte);
	$texte = str_replace("ã","%e3", $texte);
	$texte = str_replace("ç","%e7", $texte);
	$texte = str_replace("è","%e8", $texte);
	$texte = str_replace("é","%e9", $texte);
	$texte = str_replace("ê","%ea", $texte);
	$texte = str_replace("ë","%eb", $texte);
	$texte = str_replace("ô","%f4", $texte);
	$texte = str_replace("õ","%f5", $texte);
	$texte = str_replace("ö","%f6", $texte);
	$texte = str_replace("ù","%f9", $texte);
	$texte = str_replace("ú","%fa", $texte);
	$texte = str_replace("û","%fb", $texte);
	$texte = str_replace("&","%26", $texte);
	$texte = str_replace("+","%2b", $texte);
	$texte = str_replace(",","%2c", $texte);
	$texte = str_replace(":","%3a", $texte);
	$texte = str_replace("@","%40", $texte);
	$texte = str_replace("%","%25", $texte);
	$texte = str_replace("#","%23", $texte);
	$texte = str_replace("[","%5b", $texte);
	$texte = str_replace("]","%5d", $texte);
	$texte = str_replace("`","%60", $texte);
	$texte = str_replace("?","%3f", $texte);
	$texte = str_replace("·","%b7", $texte);
	*/

	 return $texte;
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_cd_agence($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `code_agence`  FROM  `new_list_gab`	WHERE `terminal` like '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 808: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 808 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["code_agence"];
            }
        }
		else
        {
            return 0;
        }
    mysqli_free_result($result);
	}
    mysqli_close($connexion);
}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getContactGABAstreinte($id,$gestionnaire)
{
    $connexion=ma_db_connexion();
    $astreinte="";
    if (getEtatActivationGestionnaire(trim($gestionnaire))==1)
    {
        $sql = "SELECT  `affectation_contact`   FROM  `new_contact_agence`	
            WHERE  nom_contact <> '' AND `code_agence` = '".mysqli_real_escape_string($connexion,$id)."' 	AND `affichage_mail`=1 
            GROUP BY `affectation_contact` ";
        $result=mysqli_query($connexion,$sql);
        if (!$result)
        {
            error_log("Erreur SQL 809: ".$sql."  ".mysqli_error($connexion));
            die('ERREUR QUERY 809 !');
        }
        if ($result)
        {
            if(mysqli_num_rows($result)>0)
            {
                while ($row = mysqli_fetch_assoc($result))
                {
                    $astreinte=$astreinte." || ".getAffectationContactGABAstreinte($row["affectation_contact"]);
                }
            }
            mysqli_free_result($result);
        }
    }
    mysqli_close($connexion);
    return $astreinte;
	
}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getContactGABAstreinte2($id,$gestionnaire)
{
    $connexion=ma_db_connexion();
    $astreinte="";
    if (getEtatActivationGestionnaire(trim($gestionnaire))==1)
	{
	    $sql = "SELECT `nom_contact`,`tel1`, `affectation_contact`   FROM  `new_contact_agence`	WHERE  nom_contact <> '' 
		AND `code_agence` = '".mysqli_real_escape_string($connexion,$id)."' 	AND `affichage_mail`=1 ";
        $result=mysqli_query($connexion,$sql);
        if (!$result)
        {
            error_log("Erreur SQL 810: ".$sql."  ".mysqli_error($connexion));
            die('ERREUR QUERY 810 !');
        }
	    if ($result)
		{	
			if(mysqli_num_rows($result)>0)
            {
                $i=0;
                while ($row = mysqli_fetch_assoc($result))
                {
                    if ($i==0){$astreinte=$astreinte." ".$row["nom_contact"]." - ".$row["tel1"];}
                    else{$astreinte=$astreinte." || ".$row["nom_contact"]." - ".$row["tel1"];}
                    $i++;
                }
            }
	        mysqli_free_result($result);
		}	

	}
    mysqli_close($connexion);
    return $astreinte;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_verif_mail_relance_incident_gab($id_frss,$cause_inter)
{
    $titre="";
    if($id_frss===1 && $cause_inter===2 )
    {
        $titre="Relances N2 G4S";
    }
    if($id_frss===1 && $cause_inter===3 )
    {
        $titre="Relances N3 G4S";
    }
    if($id_frss===2 && $cause_inter===2 )
    {
        $titre="Relances N2 NCR";
    }
    if($id_frss===2 && $cause_inter===3 )
    {
        $titre="Relances N3 NCR";
    }
    if($id_frss===3 && $cause_inter===2 )
    {
        $titre="Relances N2 Telecom";
    }
    if($id_frss===3 && $cause_inter===3 )
    {
        $titre="Relances N3 Telecom";
    }
    if($id_frss===4 && $cause_inter===2 )
    {
        $titre="Relances N2 Logistique";
    }
	
    $connexion=ma_db_connexion();
    $sql = "SELECT `objet`, `adresse_mail_aa`, `adresse_mail_cc`, `corps_messagerie` FROM  `new_mail_messagerie` 
    WHERE   `new_mail_messagerie`.`niveau_messagenie`= 'RAPPEL' AND `titre` like '".mysqli_real_escape_string($connexion,$titre)."'";
	// echo $sql;
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 811: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 811 !');
    }
	if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $i=0;
            while ($row = mysqli_fetch_assoc($result))
            {
				// echo "ok<br>".$row["corps_messagerie"];
                $adresse_mail_aa[$i] = $row["adresse_mail_aa"];
                $adresse_mail_cc[$i] = $row["adresse_mail_cc"];
                $corps_messagerie[$i] = $row["corps_messagerie"];
                $objet[$i] = $row["objet"];
                $i++;
            }
			mysqli_close($connexion);
			return  array($adresse_mail_aa[0], $adresse_mail_cc[0], $corps_messagerie[0], $objet[0]); 
        }
        else
        {
            mysqli_close($connexion);
			return  array(" ", " ", " ");
        }

        mysqli_free_result($result);
    }
    
	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nom_filiale($id_filiale)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `nom_filiale` FROM   `new_filiale` WHERE `id_filiale`='".mysqli_real_escape_string($connexion,$id_filiale)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 812: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 812 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["nom_filiale"];
            }
        }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_code_filiale($terminal)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `code_bank` FROM   `new_list_gab` WHERE `terminal`='".mysqli_real_escape_string($connexion,$terminal)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 813: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 813 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["code_bank"];
            }
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_nom_gab_declarer($id)
{
    $connexion=ma_db_connexion();
    $dist_gab = array("GAB", "Gab", "gab");
    $sql = "SELECT  `nom_gab` FROM  `new_list_gab` 	WHERE     `new_list_gab`.`terminal`  like '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 814: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 814 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return	trim(str_replace($dist_gab, "", $row["nom_gab"]));
            }
        }
        else
        {
            return '';
        }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getEtatActivationGestionnaire($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `etat_mail_auto`  FROM  `new_libelle_type_contact`	WHERE `libelle` = '".mysqli_real_escape_string($connexion,strtoupper($id))."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 815: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 815 !');
    }
    if ($result)
	{	
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["etat_mail_auto"];
            }
        }
        else
        {
            return 0;
        }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_code_agence_agence($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`code_agence` 	FROM  `new_list_gab` WHERE `new_list_gab`.`terminal` like '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 816: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 816 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["code_agence"];
            }
		}
		else
        {
            return "";
        }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
///////////////////////////////////////////////////////////////////////////////////////		 
function get_aa_mail_gab($id_gab)
{
    $connexion=ma_db_connexion();
    $contact="";
    $sql="SELECT  `adresse_mail`,`nom_contact`    FROM `new_list_contact_agence`   
     WHERE `nbr_contact` = 1 AND `code_filiale` LIKE '".mysqli_real_escape_string($connexion,get_code_agence_agence($id_gab))."' 
     GROUP BY `adresse_mail`
     ORDER BY `nbr_contact` ASC";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 817: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 817 !');
    }
   
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                if ($row["adresse_mail"]==""){$adresse_mail=$row["nom_contact"];}else{$adresse_mail=$row["adresse_mail"];}
                $contact=$adresse_mail.';'.$contact;
            }
        }
		else
        {
             $contact="";
        }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
    return $contact;
 }
  
///////////////////////////////////////////////////////////////////////////////////////
function get_cc_mail_gab($id_gab)
{
    $connexion=ma_db_connexion();
	$contact="";
    $sql="SELECT  `adresse_mail`,`nom_contact`  FROM `new_list_contact_agence`   
         WHERE `nbr_contact` = 2 AND `code_filiale` LIKE '".mysqli_real_escape_string($connexion,get_code_agence_agence($id_gab))."' 
		 GROUP BY `adresse_mail`
         ORDER BY `nbr_contact` ASC";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 818: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 818 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                if ($row["adresse_mail"]==""){$adresse_mail=$row["nom_contact"];}else{$adresse_mail=$row["adresse_mail"];}
                $contact=$adresse_mail.';'.$contact;
            }
        }
		else
        {
            $contact="";
        }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
    return $contact;
 }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
function get_mail_relance($id_gab,$gab,$cause_inter,$id_incident,$id_frss,$hour)
{
    //var_dump("cause_inter : ".$cause_inter);
    //var_dump("id_frss : ".$id_frss);
    $fourn="";
    $N="";
    if($id_frss===1)
    {
        if($cause_inter==2)
        {
            $N="N2";
        }
        else
        {
            $N="N3";
        }
        $fourn="G4S";
    }
    if($id_frss===2)
    {
        if($cause_inter==2)
        {
            $N="N2";
        }
        else
        {
            $N="N3";
        }
        $fourn="NCR";
    }
    if($id_frss===3)
    {
        if($cause_inter==2)
        {
            $N="N2";
        }
        else
        {
            $N="N3";
        }
        $fourn="Telecome";
    }
    if($id_frss===4)
    {
        if($cause_inter==2)
        {
            $N="N2";
        }
        else
        {
            $N="N3";
        }
        $fourn="Logistique";
    }
$gestionnaire="";
$codeAgence=get_cd_agence($id_gab);
$astreinteGAB=getContactGABAstreinte($codeAgence,$gestionnaire);	
//array($de[0], $aa[0], $cc[0]); 
$param=get_verif_mail_relance_incident_gab($id_frss,$cause_inter);
// $param=get_array_param_adresse_prestataire($id_prestataire,$nbr_tentative);
$obj=str_replace("num_terminal",$id_gab,$param[3]);
$obj=str_replace("nom_filiale",get_nom_filiale(get_id_code_filiale($id_gab)),$obj);
$obj=str_replace("nom_terminal",get_return_nom_gab_declarer($id_gab),$obj);
$obj=str_replace("X",get_count_nbr_intervention($id_incident),$obj);
$obj=str_replace("responsable_gab",$astreinteGAB,$obj);
echo '

<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingThree" style="font-size:13px;font-weight:bold;color:#fff;background-color:#e98731">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse'.$N.''.$fourn.'" aria-expanded="false" aria-controls="collapseThree">
         <strong> Afficher E-mail '.$N.' '.$fourn.'</strong>
        </a>
      </h4>
    </div>
    <div id="collapse'.$N.''.$fourn.'"  class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
      <div class="panel-body">
<table class="table" style="border-left: 2px solid #F96464;border-right: 2px solid #F96464;;border-top: 2px solid #F96464;border-bottom: 2px solid #F96464;">
	<tr>
		<th colspan="2">
		<p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> AA :  '.$param["0"].'</p>
		<p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> CC :  '.$param["1"].'</p>
		<strong>
		<p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> OBJET : '.$obj.'</p>
		</strong>
		
		<div id="code1'.$N.''.$fourn.'">
		<strong>
		<p style="margin-left: 14px;font-family: Calibri;font-size: small;font-weight:normal;">'.nl2br($param["2"]).'</p>
		</strong>
		</div>		
		</th>		
	</tr>	
	<tr>
	
		<th><a onClick="javascript:Select_code(\'code1'.$N.''.$fourn.'\');"class="btn btn-info btn-xs btn-block"> Sélectionné</a></th>
		<th>';
		$message=html_entity_decode_outlouk($param["2"]); 
		// $a_mail=$param["0"];
		// $cc_mail=$param["1"];
		$a_mail=$param["0"];
		$cc_mail=$param["1"];
		$de_mail="supervision_GAB@cfgbank.com";

		$bcc="";

				  ?>
						 <a  class="btn btn-success btn-xs btn-block" href="mailto:<?php echo $a_mail;?>
						 ?From=<?php echo $de_mail;?>
						 &cc=<?php echo $cc_mail;?><?php echo $bcc;?>
						 &subject=<?php echo $obj?>
						 &body=<?php echo  ($message);?>"><?php echo "Générer mail";?></a>
				  <?php
	echo '</th>
	</tr>
</table>

    </div>
  </div>

</div>



';	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function  get_mail_gab($date_arret,$id_gab,$gab,$cause_inter,$id_incident,$id_frss,$action_inter)
{
  list($d2, $h2) = explode(' ',str_replace("  "," ",$date_arret));
  list($hh, $mn, $ss) = explode(':', $h2);
  $hour=$hh.":".$mn;
  get_mail_relance($id_gab,$gab,2,$id_incident,1,$hour);
  get_mail_relance($id_gab,$gab,3,$id_incident,1,$hour);
  get_mail_relance($id_gab,$gab,2,$id_incident,2,$hour);
  get_mail_relance($id_gab,$gab,3,$id_incident,2,$hour);
  get_mail_relance($id_gab,$gab,2,$id_incident,3,$hour);
  get_mail_relance($id_gab,$gab,3,$id_incident,3,$hour);
  get_mail_relance($id_gab,$gab,2,$id_incident,4,$hour);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_ajouter_rappel_detail_prestataire($terminal0,$id_incident,$id_intervention,$id_degre)
{
    include "../languages/" . $_SESSION['lang'] . ".php";

    $terminal=get_return_information_terminal($id_incident)	;

    //array($nom_gab[0], $ip_adresse_gab[0], $id_prestataire[0], $id_fournisseur[0]);
    //$gab=get_array_information_gab(get_return_information_gab($id_intervention));
    //return    array($id_action_intervention[0], $degre_intervention[0], $id_action[0]);
    $act=get_array_information_action_intervention(($id_intervention));
			
echo '
<form class="form-horizontal" role="form">
<div  class="form-group row">
<label for="input_terminal" class="col-sm-3 control-label">'.$lang['atm'].'</label>
				<div class="col-sm-9">
					<input placeholder="terminal" id="terminal" disabled name="terminal" type="text"   value="'.$terminal[0].'  -  '.$terminal[1].'" class="form-control input-sm">
					<input  id="id_terminal_3"  name="id_terminal_3" type="hidden"   value="'.$terminal0.'" class="form-control input-sm">
					<input  id="id_cloturer_3"  name="id_cloturer_3" type="hidden"   value="0" class="form-control input-sm">
					<input  id="id_incident_3"  name="id_incident_3" type="hidden"   value="'.$id_incident.'"class="form-control input-sm">
					<input  id="id_degre_3"  name="id_degre_3" type="hidden"   value="'.$act[1].'" class="form-control input-sm">
					<input  id="id_appel_3"  name="id_appel_3" type="hidden"   value="'.$act[4].'" class="form-control input-sm">
					<input  id="id_note_3"  name="id_note_3" type="hidden"   value="" class="form-control input-sm">
					<input  id="id_remarque_3"  name="id_remarque_3" type="hidden"   value="" class="form-control input-sm">
				</div>
				</div>
		

<div  class="form-group row">				
<label for="inputrappel" class="col-sm-3 control-label">'.$lang['dur_rapp'].'</label>
				<div class="col-sm-9">
				    			<select '.enabling_button($id_incident,0).' class="form-control" id="date_rappel_3" required name="date_rappel_3" >';
						  
								  echo '    <option value="3600">1h</option>
										    <option value="5400">1h30</option>
											<option value="7200">2h</option>
											<option value="14400">4h</option>';
								            if ($_SESSION['lang']=='fr')
								            {
                                                echo '<option value="JO7">Jour ouvrable</option>
											<option value="86400">24h (1 Jour)</option>
											<option value="172800">48h (2 Jours)</option>
											<option value="259200">72h (3 Jours)</option>					
											<option value="345600">96h (4 Jours)</option>';
                                            }
								            else
								            {
                                                echo '<option value="JO7">Business day</option>
											<option value="86400">24h (1 Day)</option>
											<option value="172800">48h (2 Day)</option>
											<option value="259200">72h (3 Day)</option>					
											<option value="345600">96h (4 Day)</option>';
                                            }

			                    echo '</select>     
				</div>
				</div>';


echo '<div  class="form-group row">				
<label for="id_action_interv" class="col-sm-3 control-label">'.$lang['cause_default'].' </label>
				<div class="col-sm-9">
				<select  '.enabling_button($id_incident,0).'  class="form-control" id="id_action_interv_3"  name="id_action_interv_3">';
				get_select_intervention_id($act[2]);
				get_select_intervention_prestataire();
				echo ' </select>					
         	</div>
				</div>
				
<div  class="form-group row">					
<label for="id_action_interv" class="col-sm-3 control-label">'.$lang['affec'].'</label>
				<div class="col-sm-9">
				<select  '.enabling_button($id_incident,0).'  class="form-control" id="id_affecter_3"  name="id_affecter_3">';
				get_libelle_type_contact($act[3]);
				get_select_affectation($terminal[0]);
				// get_libelle_type_contact2();
				echo ' </select>					
         	</div>
				</div>	



<div  class="form-group row">
<label for="input_id_etat" class="col-sm-3 control-label">'.$lang['eta_cont'].'</label>
				<div class="col-sm-9">';
	echo '<select '.enabling_button($id_incident,0).'   class="form-control" id="id_etat_3"  name="id_etat_3">';
				get_libelle_etat_contact($act[4]);
				get_libelle_etat_contact2();
				echo ' </select>		';
				echo '</div>
				</div>
				
				';

//$dist_gab = array("GAB", "Gab", "gab");
//get_mail_gab(str_replace("   "," ",$date_arret),$terminal0,str_replace($dist_gab, "", $gab["0"]),$cause_intervention,$id_incident,$gab["3"],$intervention);

//get_return_prestataire_gab($id_gab)
echo '</form> ';
}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_niveau_intervention_technique($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `degre`  FROM  `new_action_intervention`	WHERE `degre`<>1  and	`new_action_intervention`.`id_intevention`  =  '".mysqli_real_escape_string($connexion,$id)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 819: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 819 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["degre"];  	
					}
			}	
		else
			{
				return 0;
			}
        mysqli_free_result($result);
	}

    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_etat_disponibilite_intervention($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `indisponibilite`  FROM  `new_action_intervention`
		WHERE 	`new_action_intervention`.`id_intevention`  =  '".mysqli_real_escape_string($connexion,$id)."'";
	

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 820: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 820 !');
    }

    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["indisponibilite"];
            }
        }
		else
        {
            return 0;
        }
		mysqli_free_result($result);
	}
    mysqli_close($connexion);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_gab_sensible($terminal)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_gab_type_gab` FROM `new_gab_type_gab` 
		WHERE 	`ternimal`   = '".mysqli_real_escape_string($connexion,$terminal)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 821: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 821 !');
    }
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return 1;
            }
		}
		else
		{
		    return 0;
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
			
}
	//////////////////////////////////////////////////////////////////////////////////////////////////////
function get_code_filiale($terminal)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `code_bank` FROM `new_list_gab` 
    WHERE  `new_list_gab`.`terminal` = '".mysqli_real_escape_string($connexion,$terminal)."'";
    
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 822: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 822 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["code_bank"];
            }
		}
		else
		{
		    return 0;
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}

/**************************************************/
function MaxIdIncident($id,$table)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  MAX(`".$id."`) as idMax FROM `".$table."`";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 823: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 823 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result))
            {
                return $row["idMax"];
            }
		}
		else
		{
		    return "";
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/*******************************************************************************************/
function get_detail_gab_declarer($id_terminal,$id,$lang)
{
    $info=get_array_information_gab($id_terminal);
    ?>
    <div class="row">

        <div class="col-sm-12 col-lg-12">
            <div class="card shadow-lg p-3 mb-5 bg-white rounded">
                <div class="card text-white bg-facebook mb-3" style="text-align: center;">
                    <div class="text-value-xl  c-icon-3xl text-white my-2 text-white"><?php echo $lang['det_decl'];?><?php echo $terminal." - ".$info["0"]; ?></div>
                </div>
                <div class="card-body row text-left">
                    <div class="col">
                        <div class="text-muted small">
                            <div class="panel-body" id="div_declarer">
                                <div class="row">
                                    <div class="col-sm-6 col-md-4">
                                        <div class="card">
                                            <div class="card-header bg-secondary "><h6><?php echo $lang['info_gab'];?></h6></div>
                                                <div class="card-body">
                                                    <div id="div_incidnet_ouvert"  class="table-responsive">
                                                        <?php
                                                        if (get_verif_gab($id_terminal)>="1")
                                                        {
                                                            get_list_information_detail_terminal($id_terminal,$id);
                                                        }
                                                        else
                                                        {
                                                            get_info_gab_introuvable();
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-6 col-md-4">
                                        <div class="card">
                                            <div class="card-header bg-secondary"><h6><?php echo $lang['inf_inc'];?></h6></div>
                                            <div class="card-body">
                                                <div id="div_rappels"  class="table-responsive">
                                                    <?php
                                                    if (get_verif_gab($id_terminal)>="1")
                                                    {
                                                        get_return_date_arret_gab($id);
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-4">
                                        <div class="card">
                                            <div class="card-header bg-secondary"><h6><?php echo $lang['dur_inter'];?></h6></div>
                                            <div class="card-body">
                                                <div id="div_incidnet_ouvert"  class="table-responsive">
                                                    <?php
                                                    if (get_verif_gab($id_terminal)>="1")
                                                    {
                                                        get_duree_prise_charge($id);
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6 col-md-12">
                                        <div class="card">
                                            <div class="card-header bg-secondary"><h6>Actions</h6></div>
                                            <div class="card-body">
                                                <div id="div_rappels"  class="table-responsive" style="margin:0 1px 0 1px;">
                                                    <?php
                                                        get_list_intervention_gab_detail_declarer($id_terminal,$id);
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php /************************* Déclaration GAB *****************************/?>

        <?php /**********************************************************************/?>

    </div>



<?php
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_last_vacation_date($id_atm)
{
    $connexion=ma_db_connexion();

    $date_up_atm=601;
    $SQL = "SELECT TIMESTAMPDIFF(SECOND ,vacation_date,now()) as date_up_atm 
    FROM `hist_vacations`
    WHERE `hist_vacations`.`id_atm` = '".mysqli_real_escape_string($connexion,$id_atm)."'
    AND `hist_vacations`.`if_last_vacation` = 1 ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 009999999:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 009999999 !');
    }
    if ($result)
    {

        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $date_up_atm= $row["date_up_atm"];
            }
        }
        mysqli_free_result($result);
    }
    return $date_up_atm ;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_value_Peripheral_arret($terminal)
{
    $connexion=ma_db_connexion();
    $id_atm="0";

    $idVacation="0";
    $date_up_atm="";
    $SQL = "SELECT list_atm_confirmed.`id_atm`,list_atm_confirmed.`terminal` ,
    hist_vacations.id_global_vacation as idVacation,
    TIMESTAMPDIFF(SECOND ,atm_logical_names.date_up_atm,now()) as date_up_atm 
    FROM `list_atm_confirmed` , hist_vacations ,atm_logical_names 
    WHERE `atm_logical_names`.`id_atm` = `list_atm_confirmed`.`id_atm` 
    AND list_atm_confirmed.id_atm=hist_vacations.id_atm 
    AND list_atm_confirmed.terminal= '".mysqli_real_escape_string($connexion,$terminal)."' 
    GROUP BY list_atm_confirmed.`id_atm`";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 9999999:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 9999999 !');
    }
    if ($result)
    {

        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_atm= $row["id_atm"];
                $terminal= $row["terminal"];
                $idVacation= $row["idVacation"];
                $date_up_atm= $row["date_up_atm"];
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return array($id_atm,$terminal,$idVacation,$date_up_atm);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_information_detail_terminal($id_gab,$id)
{
    $info=get_array_information_agence_gab($id_gab);
    $gab=get_array_information_gab($id_gab);

    $atm='GAB';
    $libel_gab='Libellé GAB	';
    $ip='Adresse IP';
    $type_gab='Type GAB';
    $n_ser='N° Série';
    $gest='Gestion';
    $gestion='Gestionnaire';
    $cd_agc='Code Agence';
    $agen='Agence';
    $tel_agen='Tel Agence';
    $region='Région';
    $ville='Ville';
    $constructeur='Constructeur';

    if ($_SESSION['lang']=='en')
    {
        $atm='Cashpoint ID';
        $libel_gab='Cashpoint Name	';
        $ip='IP adress';
        $type_gab='Cashpoint type';
        $n_ser='Serial number';
        $gest='Management type';
        $gestion='Manager';
        $cd_agc='Branch code';
        $agen='Branch';
        $tel_agen='Phone Num';
        $region='Area';
        $ville='City';
        $constructeur='Builder';

    }

echo '<table style="font-size:9pt;font-weight:bold;"  class="table table-striped" style="font-size:12px;font-weight:bold;" >
    <tr>
	    <th>'.$atm.' </th><th>:</th><th style="font-weight:bold;color:#000;font-size:11pt;">'.$id_gab.'</th>';
    echo'</tr>
			
    <tr>		
        <th>'.$libel_gab.'</th><th>:</th><th><div id="div_nom_gab'.$id_gab.'">';
        echo get_nom_gab($id_gab,trim($gab[0]));
        echo '</div></th>
    </tr>
			
    <tr>
        <th>'.$ip.'</th><th>:</th><th><div id="div_adresse_ip'.$id_gab.'">';
        echo get_adresse_ip2($id_gab,trim($gab[1]));
        echo '</div></th>				  
    </tr>
			
    <tr>
        <th>'.$n_ser.' </th><th>:</th><th><div id="div_adresse_serie'.$id_gab.'">';
        echo getNumSerie($id_gab,trim($gab[8]));
        echo '</div></th>				  
    </tr>	
			
    <tr>			
        <th>'.$constructeur.'</th><th>:</th><th style="font-weight:bold;color:#000;font-size:12px;">';
        echo  get_select_gab_type_terminal_abi($id_gab);
        echo '</th>
    </tr>				

    <tr>			
        <th>'.$cd_agc.'</th><th>:</th><th style="font-weight:bold;color:#000;font-size:12px;">';
        echo get_select_return_id_agence_gab($id_gab);
        echo'</th>		
    </tr>	

    <tr >			
        <th>'.$agen.'</th><th>:</th><th style="font-weight:bold;color:#000;font-size:12px;">';echo get_select_return_nom_agence_gab(($id_gab));echo '</th>			
    </tr>			

	
    <tr>			
        <th>'.$tel_agen.'</th><th>:</th><th style="font-weight:bold;color:#000;font-size:12px;"><div id="div_tel_gab'.$id_gab.'">';
        echo get_tel_agence(get_select_return_id_agence_gab($id_gab),$id_gab);
        echo '</div></th>		
    </tr>	
				
    <tr>			
        <th>'.$region.'</th><th>:</th><th>';
        echo get_information_nom_banque_agence_gab($id_gab);
        echo '</th>			
    </tr>	
    			
    <tr>
        <th>'.$gest.'</th><th>:</th><th>';
        echo get_select_return_fornisseur_terminal($id_gab);
        echo '</th>				
    </tr>
    </table>';
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_duree_prise_charge($id)
{
    $dur='Durée de prise en charge IPRC :';
    if ($_SESSION['lang']=='en')
    {
        $dur='IPRC Duration of support :';
    }
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_incident`  FROM  `new_incident_gab`  WHERE `id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
	
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 824: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 824 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
			    echo '
				<table style="font-size:9pt;font-weight:bold;"  class="table table-striped" style="font-size:11px;font-weight:bold;" >
				    <tr>
						<th COLSPAN=5 style="font-weight:bold;color:#000;font-size:11pt;text-align:center">'.$dur.'</th>			
					</tr>	
					<tr>
						<th>IPRC</th><th>:</th><th  COLSPAN=2>'.get_duree__prendre_en_charge_iprc($id).'</th><th>1h</th>		
					</tr>';
			    echo	get_duree__prendre_en_charge_prestataire($id);
			    echo '	</table>';
            }
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_duree__prendre_en_charge_prestataire($id)
{
    $dur='Durée de prise en charge Prestataire :';
    $iter_pre='Intervenant / Prestataire';
    $n_cal='N° Call';
    $num_call='Number call';
    $durr='Duration';
    if ($_SESSION['lang']=='en')
    {
        $dur='Duration of support service provider :';
        $iter_pre='interfering / Service provider';
        $n_cal='N° Call';
        $num_call='Number call';
        $durr='Duration';
    }
    $connexion=ma_db_connexion();
     $sql ="SELECT MAX(date_rappel) max_date, count(`id_affectation`) nbr_appel, `id_affectation`,`degre_appel`, round( TIME_TO_SEC( TIMEDIFF(NOW() , MIN(`date_prise_en_charge`) ) ) /60 ) AS DUREE2 , 
	 round( TIME_TO_SEC( TIMEDIFF(MAX(date_rappel) , MIN(`date_prise_en_charge`) ) ) /60 ) AS DUREE 
     FROM `new_intevention_incident` 
     WHERE  `id_incident`=  ".mysqli_real_escape_string($connexion,$id)."
     GROUP BY `degre_appel`,`id_affectation`
     ORDER BY `degre_appel` ASC";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 825: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 825 !');
    }
    if ($result)
	{	
	    if(mysqli_num_rows($result)>0)
	    {
	        echo '
            <tr>
				<th COLSPAN=5 style="font-weight:bold;color:#000;font-size:11pt;text-align:center">'.$dur.'</th>			
			</tr>
			<tr>
				<th COLSPAN=5 style="text-align:center"></th>			
			</tr>
			<tr>
				<th>'.$iter_pre.'</th>
				<th>'.$n_cal.'</th>
				<th>'.$num_call.'</th>
				<th>'.$durr.' </th>
				<th>SLA</th>			
			</tr>			';		
		    while ($row = mysqli_fetch_assoc($result))
            {
	            echo '	<tr>
				<th>'.get_libelle_prestataire($row["id_affectation"]).'</th>
				<th>'.$row["degre_appel"].'</th>
				<th>'.$row["nbr_appel"].'</th>
				<th>';
				if(strtotime($row["max_date"]) >= strtotime(date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))))) 
					{
						$t =  $row["DUREE2"];

						if($t<0){echo $row["DUREE2"].'min';}
						else {
								$h = floor($t/60) ? floor($t/60) .' h' : '';
								$m = $t%60 ? $t%60 .' min' : '';
								echo $h && $m ? $h.'  '.$m : $h.$m.'<br>';

						}								
					}
					else
					{
						$t =  $row["DUREE"];
						if($t<0){echo $row["DUREE"].'min';}
						else {	
								$h = floor($t/60) ? floor($t/60) .' h' : '';
								$m = $t%60 ? $t%60 .' min' : '';
								echo $h && $m ? $h.'  '.$m : $h.$m.'<br>';
						}			
					}
			    	echo '</th>
			    	<th>'.get_duree_sla($row["id_affectation"]).'</th>				
			    </tr>';
            }
			
	    }

	    mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_date_arret_gab($id_incident)
{
    $num_dos='N° Dossier';
    $num_afec='N° Affectation';
    $date_arr='Date d\'arrêt';
    $date_pris='Date prise en charge';
    $der_dat_rap='Dernière Date rappel';
    $date_clo='Date Clôture';
    $factu='Facturable';
    $scren='Capture d\'écran';
    $tau_dispo_re='Taux de disponibilité réel';
    $tau_dispo_cont='Taux de disponibilité contractuel';
    $rema='Remarque';
    $aff_rapp='Afficher dans le rapport';

    if ($_SESSION['lang']=='en')
    {
        $num_dos='File number';
        $num_afec='N ° Assignment';
        $date_arr='Stop date';
        $date_pris='Pick up date';
        $der_dat_rap='Last Date Reminder';
        $date_clo='Closing Date';
        $factu='Billable';
        $scren='Screenshot';
        $tau_dispo_re='Actual availability rate';
        $tau_dispo_cont='Contractual availability rate';
        $rema='Comment';
        $aff_rapp='Show in report';

    }

    $connexion=ma_db_connexion();
    $sql = "SELECT 	`id_incident`, `id_gab`,clo_auto ,num_paradigme,  `remarque_press`, `date_arrete`, `date_prise_en_charge`, `date_prise_charge_gestionnaire`, `num_tiket`, `date_remise`, `date_derniere_interv`, `date_derniere_rappel` , `etat_incident` , `id_facturable` , `id_activation` , `num_affectation`,`etat_stat` ,`code_screenshot` 
		FROM  `new_incident_gab` 
		WHERE `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 826: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 826 !');
    }
    if ($result)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
            list($d, $h) = explode(' ', $row["date_arrete"]);
            echo '<table style="font-size:9pt;font-weight:bold;"  class="table table-striped" style="font-size:12px;font-weight:bold;" >
                <tr>
                    <th>'.$num_dos.'</th><th>'.$id_incident.'</th>
                </tr>
                <tr>  
                    <th>'.$num_afec.' </th><th><div id="div_num_affectation'.$row["id_incident"].'">';
                    echo get_num_affectation($row["id_incident"],$row["num_affectation"]);
                    echo '</div>
                    </th>
                </tr>
            
                <tr>
                    <th>'.$date_arr.'</th><th><div id="div_date_arrete'.$row["id_incident"].'">';
                        echo get_date_arrete($row["id_incident"],trim($row["date_arrete"]));
                        echo '</div>
                    </th>
                </tr>
                <tr>  
                <th>'.$date_pris.'</th><th><div id="div_date_charge'.$row["id_incident"].'">';
                    echo get_date_prise_charge($row["id_incident"],$row["date_prise_en_charge"]);echo' </div>
                </th>
                </tr>';
           if($row["date_remise"]=="0000-00-00 00:00:00")
           {
               echo'<tr>  
                         <th>'.$der_dat_rap.'</th><th><div id="div_date_rappel'.$row["id_incident"].'">';
               echo get_date_derniere_rappel($row["id_incident"],$row["date_derniere_rappel"]);
               echo'</div></th>
                    </tr>';
           }
           echo '<tr><th>'.$date_clo.' </th><th>';
           echo get_date_date_remise($row["id_incident"],$row["etat_incident"]);
           echo '</th></tr>';
           echo'<tr>    
            <th>'.$factu.' </th><th><div id="div_id_facturation'.$row["id_incident"].'">';

            echo get_num_facturation($row["id_incident"],$row["id_facturable"]);
            echo '</div></th>
            </tr>';
            if($row["code_screenshot"]<>0)
            {
                $id_gab=get_IdAtm_Terminal($row["id_gab"]);
                echo'			
                <tr>    
                        <th>'.$scren.' </th><th><div id="div_id_screenshot'.$row["code_screenshot"].'">
                    <a tabindex="-1" data-toggle="modal" onclick="javascript:ShowScreenshotATM(\''.$id_gab.'\',\''.$row["code_screenshot"].'\')" data-target="#showScreenshotATM"><i class="fa fa-eye" title="Capture écran"></i>
                    </a>';
                echo '</div></th>
                </tr>';
            }


                echo'<tr><th>'.$tau_dispo_re.'</th><th>';
                echo gest_taux_disponibilite_detail_gab($d,$row["id_gab"],"1");
                echo '</th></tr>
                
                <tr><th>'.$tau_dispo_cont.'</th><th>';
                echo gest_taux_disponibilite_detail_gab($d,$row["id_gab"],"2");
                echo'</th></tr>
                
                <tr>  
                     <th>'.$rema.'</th><th><div id="div_remarque'.$row["id_incident"].'">';
                     echo get_remarque_incident($row["id_incident"],$row["remarque_press"]);
                     echo '</div></th>
                 </tr>
                <tr>    
                        <th>'.$aff_rapp.' </th><th><div id="div_id_etat_stat'.$row["id_incident"].'">';
                          echo get_num_etat_stat($row["id_incident"],$row["etat_stat"]);
                          echo '</div></th>
                </tr>			 
                ';
                echo '</table >';
        }
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_date_arrete2($date_arrete,$id)     
{
    $connexion=ma_db_connexion();
    /***Corbeille Modif****/
	$gab = get_gab_by_id_incid($id);
	$sql = "INSERT INTO `corbeille_modified_incident` (id_inc, id_gab ,user_modified, action_modified, type_modified, date_arret_a, date_arret_n) 
	VALUES ('".mysqli_real_escape_string($connexion,$id)."','".mysqli_real_escape_string($connexion,$gab)."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',
	NOW(),'2','".mysqli_real_escape_string($connexion,get_date_arret_by_id_incid($id))."','".mysqli_real_escape_string($connexion,$date_arrete)."' ) ";
    $corb=mysqli_query($connexion,$sql);
    if (!$corb)
    {
        error_log("Erreur SQL 827: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 827 !');
    }

    /********************/
    $sql1 = "UPDATE `new_incident_gab` SET `date_arrete`='".mysqli_real_escape_string($connexion,$date_arrete)."' WHERE `new_incident_gab`.`id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
    $result1=mysqli_query($connexion,$sql1);
    if (!$result1)
    {
        error_log("Erreur SQL 828: ".$sql1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 828 !');
    }

    /********************/
    $sql2 = "UPDATE `new_incident_gab_ouvert` SET `date_arrete`='".mysqli_real_escape_string($connexion,$date_arrete)."' WHERE `new_incident_gab_ouvert`.`id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
    $result2=mysqli_query($connexion,$sql2);
    if (!$result2)
    {
        error_log("Erreur SQL 829: ".$sql2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 829 !');
    }


    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_num_paradigm($id,$num_paradigm)    
{
	if ($num_paradigm==""){$num_paradigm="----";}	
	echo '<span  onclick="get_update_num_paradigm(\''.$id.'\',\''.$num_paradigm.'\')"><a>'.$num_paradigm.'</a></span>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_arrete($id,$date_arrete)
{
	if ($date_arrete==""){$date_arrete="----";}	
	echo '<span  onclick="get_update_date_arrete(\''.$id.'\',\''.$date_arrete.'\')"><a>'.$date_arrete.'</a></span>';
}
/////////////////////////////////////////////////////////////
function get_update_date_arrete($id,$date_arrete)
{
	
echo '<input size="10"  align="center" 	onChange="javascript:modifier_date_arrete2(\''.$id.'\')" id="date_arrete'.$id.'"  name="date_arrete'.$id.'" type="text"   
	value="'.$date_arrete.'"  class="form-control input-sm">';
	 echo '<a onClick="javascript:get_annuler_update_date_arrete2(\''.$id.'\',\''.$date_arrete.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_prise_charge($id,$date_prise_en_charge)
{
	if ($date_prise_en_charge==""){$date_prise_en_charge="----";}	
	echo '<span  onclick="get_update_date_prise_charge(\''.$id.'\',\''.$date_prise_en_charge.'\')"><a>'.$date_prise_en_charge.'</a></span>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_info_gab_introuvable()
{
    $cli_to_decl_atm='Click here to declare a new cashpoint';
    if($_SESSION['lang']=='fr')
    {
        $cli_to_decl_atm= "Cliquez ici pour déclarer nouveau terminal";
    }
   echo'<br>
    <div class="col-sm-12" >
    <div class="alert alert-danger" align="center" > <span class="glyphicon glyphicon-hand-down"></span><br>
    <a tabindex="-1"   data-toggle="modal" onClick="javascript:get_declarer_terminal()"   data-target="#ajouter_nouveau_terminal2"><strong style="font-size:14px;color: #F90008;">>>> '.$cli_to_decl_atm.' <<< </strong></a><br>
    </div>
    </div>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_prise_charge_by_id_incid($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT date_prise_en_charge FROM `new_incident_gab` WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 830: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 830 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["date_prise_en_charge"];
            }
        }
		else
        {
            return "";
        }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_mim_id_action_intervention($id)
 {
     $connexion=ma_db_connexion();
     $sql="SELECT    MIN(`id_action_interv`) as idaction  FROM `new_intevention_incident`       WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
     $result=mysqli_query($connexion,$sql);
     if (!$result)
     {
         error_log("Erreur SQL 831: ".$sql."  ".mysqli_error($connexion));
         die('ERREUR QUERY 831 !');
     }
     if ($result)
     {
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["idaction"];
            }
		}
		else
			{
				return "";
			}
		mysqli_free_result($result);
     }
     mysqli_close($connexion);
 } 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_date_prise_charge_iprc($up_date,$id_incident)
{
    $connexion=ma_db_connexion();
    /***Corbeille Modif****/

    echo "ok";
    $gab = get_gab_by_id_incid($id_incident);
    $corb="INSERT INTO `corbeille_modified_incident` (id_inc, id_gab ,user_modified, action_modified, type_modified, prise_en_charge_a, prise_en_charge_n) 
    VALUES ('".mysqli_real_escape_string($connexion,$id_incident)."',
	'".mysqli_real_escape_string($connexion,$gab)."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',NOW(),
	'3','".mysqli_real_escape_string($connexion,get_date_prise_charge_by_id_incid($id_incident))."','".mysqli_real_escape_string($connexion,$up_date)."' ) ";
    $resultcorb=mysqli_query($connexion,$corb);
    if (!$resultcorb)
    {
        error_log("Erreur SQL 832: ".$corb."  ".mysqli_error($connexion));
        die('ERREUR QUERY 832 !');
    }

    //incident_modifier_date_prise_en_charge($up_date,$id_incident);
    $sql = "UPDATE `new_incident_gab` SET `date_prise_en_charge`='".mysqli_real_escape_string($connexion,$up_date)."'
    WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 833: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 833 !');
    }


    $sql3 = "UPDATE `new_incident_gab_ouvert` SET `date_prise_en_charge`='".mysqli_real_escape_string($connexion,$up_date)."'
    WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result3=mysqli_query($connexion,$sql3);
    if (!$result3)
    {
        error_log("Erreur SQL 834: ".$sql3."  ".mysqli_error($connexion));
        die('ERREUR QUERY 834 !');
    }


    $sql2 = "UPDATE `new_intevention_incident` SET 
                    `date_action`='".mysqli_real_escape_string($connexion,$up_date)."', 
                    `date_prise_en_charge`='".mysqli_real_escape_string($connexion,$up_date)."'
            WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,get_mim_id_action_intervention($id_incident))."'";
    $result2=mysqli_query($connexion,$sql2);
    if (!$result2)
    {
        error_log("Erreur SQL 835: ".$sql2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 835 !');
    }

    /****UPDATE TABLE TEMPO NEW INTERVENTION INCIDENT**/
    $sql2temp = "UPDATE `new_intevention_incident_tmp` SET 
                    `date_action`='".mysqli_real_escape_string($connexion,$up_date)."', 
                    `date_prise_en_charge`='".mysqli_real_escape_string($connexion,$up_date)."'
            WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,get_mim_id_action_intervention($id_incident))."'";
    $resulttemp=mysqli_query($connexion,$sql2temp);
    if (!$resulttemp)
    {
        error_log("Erreur SQL 836: ".$sql2temp."  ".mysqli_error($connexion));
        die('ERREUR QUERY 836 !');
    }
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////
function get_update_date_prise_charge($id,$date_prise_charge_iprc)
{
echo '<input size="10"  align="center" 	onChange="javascript:modifier_date_prise_charge_iprc(\''.$id.'\')" id="date_prise_charge_iprc'.$id.'"  name="date_prise_charge_iprc'.$id.'" type="text"   
	value="'.$date_prise_charge_iprc.'"  class="form-control input-sm">';
	 echo '<a onClick="javascript:get_annuler_update_date_prise_charge_iprc2(\''.$id.'\',\''.$date_prise_charge_iprc.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_derniere_rappel($id,$date_rappel)
{
	if ($date_rappel==""){$date_rappel="----";}	
	echo '<span  onclick="get_update_date_derniere_rappel(\''.$id.'\',\''.$date_rappel.'\')"><a>'.$date_rappel.'</a></span>';
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_statut_auto_clo($id,$auto_clo,$id_gab)
{
	if($auto_clo==0){
	echo '<span onclick="get_update_etat_auto_clo(\''.$id.'\',\''.$auto_clo.'\',\''.$id_gab.'\')"><a>Activé</a></span>';
	} else
	echo '<span onclick="get_update_etat_auto_clo(\''.$id.'\',\''.$auto_clo.'\',\''.$id_gab.'\')"><a>Désactivé</a></span>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_num_facturation($id,$id_facturation)
{

    if($id_facturation==0)
    {
        echo '<span class="fa fa-check-circle fa-fw" style="color: red" onclick="get_update_id_facturation(\''.$id.'\',\''.$id_facturation.'\')"></span>';
    }
    else
    {
        echo '<span class="fa fa-check-circle fa-fw " style="color:green" onclick="get_update_id_facturation(\''.$id.'\',\''.$id_facturation.'\')"></span>';
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_remarque_incident($id,$remarque)
{

	echo '<span  onclick="get_update_remarque_incident(\''.$id.'\',\''.$remarque.'\')"><a>';
		if ($remarque==""){echo "<span class='glyphicon glyphicon-plus'></span>";}else{echo $remarque;}	
	echo '</a></span>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_num_etat_stat($id,$etat_stat)
{
	echo '<span onclick="get_update_id_etat_stat(\''.$id.'\',\''.$etat_stat.'\')"><a>'.get_libelle_etat_stat($etat_stat).'</a></span>';
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_etat_stat($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`libelle` FROM  `new_etat_stat` WHERE `id_etat` = '".mysqli_real_escape_string($connexion,$id)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 837: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 837 !');
    }

    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["libelle"];
            }
			}	
		else
		{
				return "";
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
			
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_intervention_gab_detail_declarer($id_terminal,$id_incident)
{
    $prob='Probléme';
    $date_pris='Date prise en charge';
    $der_dat_rap='Date rappel';
    $date_clo='Date Clôture';
    $cont='Contacté';
    $per_avi='Personne avisée';
    $eta_cont='État contact';
    $nbr_esc='NB Escalade';
    $nbr_app='N° Appel';
    $user='Utilisateur';

    if ($_SESSION['lang']=='en')
    {
        $prob='Problem';
        $date_arr='Stop date';
        $date_pris='Pick up date';
        $der_dat_rap='Reminder date';
        $date_clo='Closing Date';
        $cont='Contacted';
        $per_avi='Informed person';
        $eta_cont='Contact state';
        $nbr_esc='NB Climbing';
        $nbr_app='N° Call';
        $user='User';
    }
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`id_action_interv`, `id_incident`, `date_action`, `personne_avisee`,`date_prise_en_charge`,`etat_contact`, 
	`id_action_intervention`, `id_affectation`, `nbr_escalade`,  `date_rappel`, `nbr_tentative`, `id_utilisateur`, `etat_cloture`, 
	`remarque`, `note`, `degre_intervention`, `date_cloture`, `degre_appel`, `auto_cloture`
		FROM  `new_intevention_incident` 
		WHERE id_incident = '".mysqli_real_escape_string($connexion,$id_incident)."'
		ORDER BY `degre_appel`,nbr_escalade ASC ";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 838: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 838 !');
    }
    if ($result)
	{
	echo '<div class="table-responsive">';
	if(mysqli_num_rows($result)>0)
	{
	echo '
	<table style="font-size:9pt;font-weight:bold;"  class="table table-striped"  >';

echo '		<tr>
				<th>NB Action</th>
				<th>'.$prob.'</th>
				<th>'.$date_pris.'</th>
				<th>'.$der_dat_rap.'</th>
				<th>'.$date_clo.'</th>
				<th>'.$cont.'</th>
				<th>'.$per_avi.'</th>
				<th>'.$eta_cont.'</th>
				<th>'.$nbr_esc.'</th>
				<th>'.$nbr_app.'</th>
				<th>'.$user.'</th>

			</tr>';
			while ($row = mysqli_fetch_assoc($result)) 
			{

				//array($dateMancloture,$dateaMinction,$Maxnbrtentative,$Minnbrtentative)
				$info_technique=get_information_intevention_technique($row["id_incident"]);
				$date_cloture_intevention_technique=$info_technique[0][0];
				$min_date_intevention_technique=$info_technique[1][0];
				$min_nbr_tentative_technique =$info_technique[3][0];
			    $id_action_interv=$row["id_action_interv"];
			    $degre=$row["degre_intervention"];
				$count_nbr_tentative_technique=get_count_intervention_technique($row["id_incident"]);
		  			// if ($i % 2) 
					{
                echo '<tr>';
                            }
                // else
                            {
                // echo '<tr>';
                            }			
				echo '
				<th><div id="div_nbr_tentative'.$row["id_action_interv"].'">';
					echo get_nbr_tentative($row["id_action_interv"],$row["nbr_tentative"]);
					
				echo '</div></th>
				
					<th><div id="div_id_action_intervention'.$row["id_action_interv"].'">';
					echo get_libelle_action_intervention1($row["id_action_interv"],$row["id_action_intervention"]);
				echo '</div></th>			
                     
					 <th><div id="div_date_charge2'.$row["id_action_interv"].'">';
					  echo get_date_prise_charge2($row["id_action_interv"],$row["date_prise_en_charge"]);

					  echo' </div></th>	

					 <th><div id="div_date_rappel2'.$row["id_action_interv"].'">';
					 if (enabling_button($id_incident,0)=='disabled'){
						 echo get_date_rappel_sans_modif($row["id_action_interv"],$row["date_rappel"]);
					 } else {
					  echo get_date_rappel2($row["id_action_interv"],$row["date_rappel"]);
					 }
					  echo' </div></th>	
					 
					  
					  
				<th>';//get_date_rappel_sans_modif $row["nbr_tentative"]
				
			echo get_date_cloture_intervention($row["id_incident"],$row["id_action_interv"],$row["id_affectation"],$row["degre_appel"],$row["nbr_tentative"]);	

				echo '</th>
				
				<th><div id="id_affectation'.$row["id_action_interv"].'">';
					echo get_libelle_id_affectation($row["id_action_interv"],$row["id_affectation"]);
				echo '</div></th>
				
				<th><div id="personne_avisee'.$row["id_action_interv"].'">';
					echo get_libelle_personne_avisee($row["id_action_interv"],$row["personne_avisee"]);
				echo '</div></th>	
				
				<th><div id="id_etat_contact'.$row["id_action_interv"].'">';
					echo get_libelle_etat_contact1($row["id_action_interv"],$row["etat_contact"]);
				echo '</div></th>
				';

				echo '<th><div id="div_nbr_escalade'.$row["id_action_interv"].'">';
					echo get_nbr_escalade($row["id_action_interv"],$row["nbr_escalade"]);
				echo '</div></th>
				<th><div id="div_nbr_appel'.$row["id_action_interv"].'">';
					echo get_nbr_degre_appel($row["id_action_interv"],$row["degre_appel"]);
				echo '</div></th>
				<th>'.get_utilisateur($row["id_utilisateur"]).'  </th>

			</tr>';

			}
 echo '			
		</table>';
		}
    mysqli_free_result($result);
	}		
     echo '	</div>';
    mysqli_close($connexion);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
function get_action_nasser()
{
    $connexion=ma_db_connexion();
    $libelle=array();
    $sql = "SELECT id_intevention, libelle_intevention 	FROM  `new_action_intervention`  ;";
			
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 838: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 838 !');
    }
    if ($result)
	{
	    if (mysqli_num_rows($result)>0)
	    {
	        while ($row = mysqli_fetch_assoc($result))
            {
                $libelle[$row["id_intevention"]]=$row["libelle_intevention"];
			}
	    }
        else
        {
            $libelle="";
        }
	    mysqli_free_result($result);
	}
    mysqli_close($connexion);
    //print_r($libelle);
    return  $libelle;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_date_cloture_gab($id_incident)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`date_remise` 
    FROM  `new_incident_gab` 
    WHERE `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 839: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 839 !');
    }
    if($result)
    {
            if(mysqli_num_rows($result)>0)

            {

                while ($row = mysqli_fetch_assoc($result))
                    {

                    return $row["date_remise"];

                    }

            }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_count_nbr_intervention($id_incident)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  count(`id_action_interv`) as nbrtentative
    FROM `new_intevention_incident`
    WHERE   `id_incident`  =  '".$id_incident."'";
		// echo  $sql."<br>";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 840: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 840 !');
    }
    if($result)
		{	
				if(mysqli_num_rows($result)>0)
				
				{
		
					while ($row = mysqli_fetch_assoc($result)) 
  						{

  						return $row["nbrtentative"];
  					
						}	
				
				}
				else
						{
						return 0;
						}				
			mysqli_free_result($result);
		}//	if($result)
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_prise_charge_by_id_interve($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT id_incident ,date_prise_en_charge FROM `new_intevention_incident` WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 841: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 841 !');
    }
    if($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["date_prise_en_charge"];  	
					}
			}	
		else
			{
				return 0;
			}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
			
}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nombre_tentative($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT    `nbr_tentative` FROM `new_intevention_incident`  WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 842: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 842 !');
    }
    if($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                return $row["nbr_tentative"];
            }
        }
		else
		{
		    return 0;
		}
        mysqli_free_result($result);
     }
     mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_date_prise_charge_iprc2($up_date,$id_action)
{
    $connexion=ma_db_connexion();
	if (get_nombre_tentative($id_action)==1)
		{
			/***Corbeille Modif***(Motif Interv )*/
            $gab = get_gab_by_id_interve($id_action);
            $corb="INSERT INTO `corbeille_modified_intervention` (id_inc, id_int, gab , original_user,user_modified, action_modified, type_modified, prise_en_charge_a, prise_en_charge_n) 
            VALUES ('".mysqli_real_escape_string($connexion,get_id_incident($id_action))."','".mysqli_real_escape_string($connexion,$id_action)."',
			'".mysqli_real_escape_string($connexion,$gab)."', 
			'".mysqli_real_escape_string($connexion,get_user_by_id_interve($id_action))."',
			'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',NOW(),'11','".mysqli_real_escape_string($connexion,get_date_prise_charge_by_id_interve($id_action))."',
			'".mysqli_real_escape_string($connexion,$up_date)."' ) ";
            $resultcorb=mysqli_query($connexion,$corb);
            if (!$resultcorb)
            {
                error_log("Erreur SQL 843: ".$corb."  ".mysqli_error($connexion));
                die('ERREUR QUERY 843 !');
            }
			/////////////////////////////////////////////////////
			$sql = "UPDATE `new_incident_gab` SET `date_prise_en_charge`='".mysqli_real_escape_string($connexion,$up_date)."'		
			WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,get_id_incident($id_action))."'";
            $result=mysqli_query($connexion,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 844: ".$sql."  ".mysqli_error($connexion));
                die('ERREUR QUERY 844 !');
            }
            /////////////////////////////////////////////////////
            $sql3 = "UPDATE `new_incident_gab_ouvert` SET `date_prise_en_charge`='".$up_date."'		
			WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,get_id_incident($id_action))."'";
            $result3=mysqli_query($connexion,$sql3);
            if (!$result3)
            {
                error_log("Erreur SQL 844: ".$sql3."  ".mysqli_error($connexion));
                die('ERREUR QUERY 844 !');
            }
            /////////////////////////////////////////////////////
            $sql2 = "UPDATE `new_intevention_incident` SET 	`date_action`='".mysqli_real_escape_string($connexion,$up_date)."', 	
			`date_prise_en_charge`='".mysqli_real_escape_string($connexion,$up_date)."'	WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id_action)."'";
            $result2=mysqli_query($connexion,$sql2);
            if (!$result2)
            {
                error_log("Erreur SQL 845: ".$sql2."  ".mysqli_error($connexion));
                die('ERREUR QUERY 845 !');
            }
            /////////////////////////////////////////////////////
			$sql2tempo = "UPDATE `new_intevention_incident_tmp` SET 	`date_action`='".mysqli_real_escape_string($connexion,$up_date)."', 	
			`date_prise_en_charge`='".mysqli_real_escape_string($connexion,$up_date)."'	WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id_action)."'";
            $result2tempo=mysqli_query($connexion,$sql2tempo);
            if (!$result2tempo)
            {
                error_log("Erreur SQL 846: ".$sql2tempo."  ".mysqli_error($connexion));
                die('ERREUR QUERY 846 !');
            }
		}	
	else
		{
			/***Corbeille Modif***(Motif Interv )*/
            $gab = get_gab_by_id_interve($id_action);
            $corb="INSERT INTO `corbeille_modified_intervention` (id_inc, id_int, gab , original_user,user_modified, action_modified, type_modified, prise_en_charge_a, prise_en_charge_n) 
            VALUES ('".mysqli_real_escape_string($connexion,get_id_incident($id_action))."','".mysqli_real_escape_string($connexion,$id_action)."','".mysqli_real_escape_string($connexion,$gab)."',
			'".mysqli_real_escape_string($connexion,get_user_by_id_interve($id_action))."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',NOW(),'5',
			'".mysqli_real_escape_string($connexion,get_date_prise_charge_by_id_interve($id_action))."','".mysqli_real_escape_string($connexion,$up_date)."' ) ";
            $resultcorb=mysqli_query($connexion,$corb);
            if (!$resultcorb)
            {
                error_log("Erreur SQL 847: ".$corb."  ".mysqli_error($connexion));
                die('ERREUR QUERY 847 !');
            }
            /////////////////////////////////////////////////////

            $nbr_tentative=get_nombre_tentative($id_action)-1;
			$sql2 = "UPDATE `new_intevention_incident` SET 	`date_action`='".mysqli_real_escape_string($connexion,$up_date)."', 	
			`date_prise_en_charge`='".mysqli_real_escape_string($connexion,$up_date)."'	
			WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id_action)."'";
            $result2=mysqli_query($connexion,$sql2);
            if (!$result2)
            {
                error_log("Erreur SQL 848: ".$sql2."  ".mysqli_error($connexion));
                die('ERREUR QUERY 848 !');
            }

            /////////////////////////////////////////////////////

            $sql3 = "UPDATE `new_intevention_incident` SET 
			`date_rappel`='".mysqli_real_escape_string($connexion,$up_date)."' 
			WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,get_id_incident($id_action))."' 
			AND  `nbr_tentative` = '".mysqli_real_escape_string($connexion,$nbr_tentative)."'";
            $result3=mysqli_query($connexion,$sql3);
            if (!$result3)
            {
                error_log("Erreur SQL 849: ".$sql3."  ".mysqli_error($connexion));
                die('ERREUR QUERY 849 !');
            }
            /////////////////////////////////////////////////////

					/*****UPDATE TABLE TEMPO NEW INTERVENTION INCIDENT***/
			$sql2temp = "UPDATE `new_intevention_incident_tmp` 
			SET 	`date_action`='".mysqli_real_escape_string($connexion,$up_date)."', 	
			`date_prise_en_charge`='".mysqli_real_escape_string($connexion,$up_date)."'	WHERE  `id_action_interv` = '".$id_action."'";
            $resulttemp=mysqli_query($connexion,$sql2temp);
            if (!$resulttemp)
            {
                error_log("Erreur SQL 850: ".$sql2temp."  ".mysqli_error($connexion));
                die('ERREUR QUERY 850 !');
            }

            /////////////////////////////////////////////////////

            $sql3temp = "UPDATE `new_intevention_incident_tmp`
			SET `date_rappel`='".mysqli_real_escape_string($connexion,$up_date)."' 
			WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,get_id_incident($id_action))."' 
			AND  `nbr_tentative` = '".mysqli_real_escape_string($connexion,$nbr_tentative)."'";
            $result3temp=mysqli_query($connexion,$sql3temp);
            if (!$result3temp)
            {
                error_log("Erreur SQL 851: ".$sql3temp."  ".mysqli_error($connexion));
                die('ERREUR QUERY 851 !');
            }
		}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_action_intervention($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `libelle_intevention`    FROM `new_action_intervention`  
	WHERE `id_intevention`  =  '".mysqli_real_escape_string($connexion,$id)."'";

	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
	if (!$result)
	{
	    error_log("Erreur SQL 852: ".$sql."  ".mysqli_error($connexion));
	    die('ERREUR QUERY 852 !');
	}
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["libelle_intevention"];  	
					}
			}	
		else
			{
				return "";
			}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function incident_modifier_date_rappel($up_date,$id_incident)
{
    $connexion=ma_db_connexion();
    $sql="SELECT * FROM  `new_incident_gab`  WHERE `id_incident`  =  '".mysqli_real_escape_string($connexion,$id_incident)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 853: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 853 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                $sql2 = "INSERT INTO `new_incident_gab_modifier`(`id_incident`, `id_incident2`, `id_gab`, 
				`date_modification`,`date_arrete`, `date_arrete2`, `date_prise_en_charge`, 
				`date_prise_en_charge2`, `date_rappel`, `date_rappel2`, `date_remise`, `date_remise2`,
				`num_affectation`, `num_affectation2`, `id_user`)
                VALUES (
                '', 
                '".mysqli_real_escape_string($connexion,$id_incident)."',  
                '".mysqli_real_escape_string($connexion,$row["id_gab"])."',  
                NOW(),
                '".mysqli_real_escape_string($connexion,$row["date_arrete"])."',  
                '".mysqli_real_escape_string($connexion,$row["date_arrete"])."',  
                '".mysqli_real_escape_string($connexion,$row["date_prise_en_charge"])."',  					
                '".mysqli_real_escape_string($connexion,$row["date_prise_en_charge"])."',  		
                '".mysqli_real_escape_string($connexion,$row["date_derniere_rappel"])."',  
                '".mysqli_real_escape_string($connexion,$up_date)."',
                '".mysqli_real_escape_string($connexion,$row["date_remise"])."',  
                '".mysqli_real_escape_string($connexion,$row["date_remise"])."',  
                '".mysqli_real_escape_string($connexion,$row["num_affectation"])."',  
                '".mysqli_real_escape_string($connexion,$row["num_affectation"])."',  
                '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."')";
                $result2=mysqli_query($connexion,$sql2);
                if (!$result2)
                {
                    error_log("Erreur SQL 854: ".$sql2."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 854 !');
                }
            }
		}
        mysqli_free_result($result);
	}

    mysqli_close($connexion);
} 
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function modifier_dernier_rappel($up_date,$id_incident)
{
    $connexion=ma_db_connexion();
    $date_last_rappel_anc=get_date_rappel_by_id_incid($id_incident);
    /***Corbeille Modif****/
	$gab = get_gab_by_id_incid($id_incident);
	$corb="INSERT INTO `corbeille_modified_incident` (id_inc, id_gab ,user_modified, action_modified,
	type_modified, date_last_rappel_a, date_last_rappel_n) 
	VALUES ('".$id_incident."','".mysqli_real_escape_string($connexion,$gab)."',
	'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',NOW(),'15',
	'".mysqli_real_escape_string($connexion,get_date_rappel_by_id_incid($id_incident))."',
	'".mysqli_real_escape_string($connexion,$up_date)."' ) ";
    $resultcorb=mysqli_query($connexion,$corb);
    if (!$resultcorb)
    {
        error_log("Erreur SQL 855: ".$corb."  ".mysqli_error($connexion));
        die('ERREUR QUERY 855 !');
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    incident_modifier_date_rappel($up_date,$id_incident);
    $sql = "UPDATE `new_incident_gab` SET `date_derniere_rappel`='".mysqli_real_escape_string($connexion,$up_date)."'
    WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 856: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 856 !');
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    $sql3 = "UPDATE `new_incident_gab_ouvert` SET `date_derniere_rappel`= '".mysqli_real_escape_string($connexion,$up_date)."'
    WHERE  `id_incident`= '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result3=mysqli_query($connexion,$sql3);
    if (!$result3)
    {
        error_log("Erreur SQL 857: ".$sql3."  ".mysqli_error($connexion));
        die('ERREUR QUERY 857 !');
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    $sql2 = "UPDATE `new_intevention_incident` SET `date_rappel`='".mysqli_real_escape_string($connexion,$up_date)."'
    WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,get_max_id_action_intervention($id_incident))."'";
    $result2=mysqli_query($connexion,$sql2);
    if (!$result2)
    {
        error_log("Erreur SQL 858: ".$sql2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 858 !');
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    $sql2tempo = "UPDATE `new_intevention_incident_tmp`
	SET `date_rappel`='".mysqli_real_escape_string($connexion,$up_date)."'
    WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,get_max_id_action_intervention($id_incident))."'";
    $result2tempo=mysqli_query($connexion,$sql2tempo);
    if (!$result2tempo)
    {
        error_log("Erreur SQL 859: ".$sql2tempo."  ".mysqli_error($connexion));
        die('ERREUR QUERY 859 !');
    }
    mysqli_close($connexion);
} 
 /////////////////////////////////////////////////////////////
function get_update_date_derniere_rappel($id,$date_rappel)
{
echo '<input size="10"  align="center" 	onChange="javascript:modifier_dernier_rappel(\''.$id.'\')" id="dernier_dtrappel'.$id.'"  name="dernier_dtrappel'.$id.'" type="text"   
	value="'.$date_rappel.'"  class="form-control input-sm">';
echo '<a onClick="javascript:get_annuler_update_date_derniere_rappel2(\''.$id.'\',\''.$date_rappel.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}  
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_prise_charge2($id,$date_prise_en_charge2)
{
	if ($date_prise_en_charge2==""){$date_prise_en_charge2="----";}	
	echo '<span  onclick="get_update_date_prise_charge2(\''.$id.'\',\''.$date_prise_en_charge2.'\')"><a>'.$date_prise_en_charge2.'</a></span>';
}
/////////////////////////////////////////////////////////////
function get_update_date_prise_charge2($id,$date_prise_charge_iprc2)
{
echo '<input size="10"  align="center" 	onChange="javascript:modifier_date_prise_charge_iprc2(\''.$id.'\')" id="date_prise_charge_iprc2'.$id.'"  name="date_prise_charge_iprc2'.$id.'" type="text"   
	value="'.$date_prise_charge_iprc2.'"  class="form-control input-sm">';
	 echo '<a onClick="javascript:get_annuler_update_date_prise_en_charge2(\''.$id.'\',\''.$date_prise_charge_iprc2.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_max_nombre_tentative($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT max(`nbr_tentative`) as max_tentative FROM `new_intevention_incident` 
	WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id)."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 860: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 860 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["max_tentative"];
            }
		}
		else
		{
		    return 0;
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_rappel_by_id_interve($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT id_incident ,date_rappel FROM `new_intevention_incident` WHERE  `id_action_interv` =  '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 861: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 861 !');
    }
    if ($result)
	{
	    if(mysqli_num_rows($result)>0)
	    {
	        while ($row = mysqli_fetch_assoc($result))
            {
                return $row["date_rappel"];
            }
	    }
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_situation_incident($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT    `etat_incident` FROM `new_incident_gab`  WHERE  `id_incident`=   '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 862: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 862 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
           while ($row = mysqli_fetch_assoc($result))
            {
                $row["etat_incident"];
            }
          }
        else
        {
          return 0;
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_auto_cloture($id)
{
	if ($id==185){return "CA";}else{return "";}
}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_rappel2($id,$date_rappel2)
{
	if ($date_rappel2==""){$date_rappel2="----";}	
	echo '<span  onclick="get_update_rappel2(\''.$id.'\',\''.$date_rappel2.'\')"><a>'.$date_rappel2.'</a></span>';
}
/////////////////////////////////////////////////////////////
function get_date_rappel_sans_modif($id,$date_rappel2)
{
	if ($date_rappel2==""){$date_rappel2="----";}	
	echo '<a>'.$date_rappel2.'</a>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_date_rappel2($up_date,$id_action)
{
    $connexion=ma_db_connexion();
	if (get_nombre_tentative($id_action)==get_max_nombre_tentative(get_id_incident($id_action)))
	{
        /***Corbeille Modif****/
        $gab = get_gab_by_id_interve($id_action);
        $corb="INSERT INTO `corbeille_modified_intervention` 
		(id_inc, id_int, gab , original_user,user_modified, action_modified, type_modified, rappel_a, rappel_n) 
        VALUES ('".mysqli_real_escape_string($connexion,get_id_incident($id_action))."',
		'".mysqli_real_escape_string($connexion,$id_action)."','".mysqli_real_escape_string($connexion,$gab)."', 
		'".mysqli_real_escape_string($connexion,get_user_by_id_interve($id_action))."',
		'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',NOW(),'6',
		'".mysqli_real_escape_string($connexion,get_date_rappel_by_id_interve($id_action))."',
		'".mysqli_real_escape_string($connexion,$up_date)."' ) ";
        $resultcorb=mysqli_query($connexion,$corb);
        if (!$resultcorb)
        {
            error_log("Erreur SQL 863: ".$corb."  ".mysqli_error($connexion));
            die('ERREUR QUERY 863 !');
        }

        if (get_situation_incident(get_id_incident($id_action))==1)//si  l'incident est déja cloturer
        {
            echo'
            <div class="alert alert-danger" >
                <strong style="color:#b70101" >Attention!: l/incident est déjà clôturé</strong> 
            </div>';

        }
        else // c'est incident est ouvert
        {
            $sql = "UPDATE `new_incident_gab` SET `date_derniere_rappel`='".mysqli_real_escape_string($connexion,$up_date)."' 
			WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,get_id_incident($id_action))."'";
            $result=mysqli_query($connexion,$sql);
            if (!$result)
            {
                error_log("Erreur SQL 864: ".$sql."  ".mysqli_error($connexion));
                die('ERREUR QUERY 864 !');
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            $sql11 = "UPDATE `new_incident_gab_ouvert` SET `date_derniere_rappel`='".mysqli_real_escape_string($connexion,$up_date)."'  
			WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,get_id_incident($id_action))."'";
            $result1=mysqli_query($connexion,$sql11);
            if (!$result1)
            {
                error_log("Erreur SQL 865: ".$sql11."  ".mysqli_error($connexion));
                die('ERREUR QUERY 865 !');
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            $sql2 = "UPDATE `new_intevention_incident` SET 	`date_rappel`= '".mysqli_real_escape_string($connexion,$up_date)."', 	
			`date_cloture`= '".mysqli_real_escape_string($connexion,$up_date)."'	WHERE  `id_action_interv` = '".$id_action."'";
            $result2=mysqli_query($connexion,$sql2);
            if (!$result2)
            {
                error_log("Erreur SQL 866: ".$sql2."  ".mysqli_error($connexion));
                die('ERREUR QUERY 866 !');
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            $sqltemp = "UPDATE `new_intevention_incident_tmp` SET 	`date_rappel`='".mysqli_real_escape_string($connexion,$up_date)."', 	
			`date_cloture`='".mysqli_real_escape_string($connexion,$up_date)."'	
			WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id_action)."'";
            $resulttemp=mysqli_query($connexion,$sqltemp);
            if (!$resulttemp)
            {
                error_log("Erreur SQL 867: ".$sqltemp."  ".mysqli_error($connexion));
                die('ERREUR QUERY 867 !');
            }
        }
			
	}
	else
	{
        /***Corbeille Modif****/
        $gab = get_gab_by_id_interve($id_action);
        $corb="INSERT INTO `corbeille_modified_intervention` (id_inc, id_int, gab , 
		original_user,user_modified, action_modified, type_modified, rappel_a, rappel_n) 
        VALUES ('".mysqli_real_escape_string($connexion,get_id_incident($id_action))."',
		'".mysqli_real_escape_string($connexion,$id_action)."','".mysqli_real_escape_string($connexion,$gab)."',
		'".mysqli_real_escape_string($connexion,get_user_by_id_interve($id_action))."',
		'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',NOW(),
		'6','".mysqli_real_escape_string($connexion,get_date_rappel_by_id_interve($id_action))."',   
		'".mysqli_real_escape_string($connexion,$up_date)."' ) ";
        $resultcorb=mysqli_query($connexion,$corb);
        if (!$resultcorb)
        {
            error_log("Erreur SQL 868: ".$corb."  ".mysqli_error($connexion));
            die('ERREUR QUERY 868 !');
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        // echo    get_nombre_tentative($id_action)."==========222222222222222222=========".get_max_nombre_tentative(get_id_incident($id_action));
        $nbr_tentative=get_nombre_tentative($id_action)+1;
        $sql2 = "UPDATE `new_intevention_incident` SET 	`date_rappel`=   '".mysqli_real_escape_string($connexion,$up_date)."', 	
		`date_cloture`=   '".mysqli_real_escape_string($connexion,$up_date)."'	
		WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id_action)."'";
        $result2=mysqli_query($connexion,$sql2);
        if (!$result2)
        {
            error_log("Erreur SQL 869: ".$sql2."  ".mysqli_error($connexion));
            die('ERREUR QUERY 869 !');
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $sql3 = "UPDATE `new_intevention_incident` SET 	
		`date_action`='".mysqli_real_escape_string($connexion,$up_date)."',
		`date_prise_en_charge`='".mysqli_real_escape_string($connexion,$up_date)."'
		WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,get_id_incident($id_action))."' 
		AND  `nbr_tentative` = '".mysqli_real_escape_string($connexion,$nbr_tentative)."'";
        $result3=mysqli_query($connexion,$sql3);
        if (!$result3)
        {
            error_log("Erreur SQL 870: ".$sql3."  ".mysqli_error($connexion));
            die('ERREUR QUERY 870 !');
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /*****UPDATE TABLE TEMPO NEW INTERVENTION INCIDENT***/
        $sqltemp2 = "UPDATE `new_intevention_incident_tmp` SET 	
		`date_rappel`='".mysqli_real_escape_string($connexion,$up_date)."', 
		`date_cloture`='".mysqli_real_escape_string($connexion,$up_date)."'	
		WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id_action)."'";
        $result2temp2=mysqli_query($connexion,$sqltemp2);
        if (!$result2temp2)
        {
            error_log("Erreur SQL 871: ".$sqltemp2."  ".mysqli_error($connexion));
            die('ERREUR QUERY 871 !');
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $sqltemp3 = "UPDATE `new_intevention_incident_tmp` SET 	`date_action`=   '".mysqli_real_escape_string($connexion,$up_date)."',
		`date_prise_en_charge`=   '".mysqli_real_escape_string($connexion,$up_date)."'
		WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,get_id_incident($id_action))."' 
		AND  `nbr_tentative` = '".mysqli_real_escape_string($connexion,$nbr_tentative)."'";
        $result2temp3=mysqli_query($connexion,$sqltemp3);
        if (!$result2temp3)
        {
            error_log("Erreur SQL 872: ".$sqltemp3."  ".mysqli_error($connexion));
            die('ERREUR QUERY 872 !');
        }

	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////
function get_update_rappel2($id,$date_rappel2)
{
echo '<input size="10"  align="center" 	onChange="javascript:modifier_date_rappel2(\''.$id.'\')" id="daterappel2'.$id.'"  name="daterappel2'.$id.'" type="text"   
	value="'.$date_rappel2.'"  class="form-control input-sm">';
	 echo '<a onClick="javascript:get_annuler_update_rappel2(\''.$id.'\',\''.$date_rappel2.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
		
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_cloture_intervention($id_incident,$id_action,$id_affectation,$degre_appel,$nbr_tentative)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	count(`id_action_interv`) id_action, max(`date_rappel`) max_date_rappel,
	max(`nbr_tentative`) max_nbr_tentative, `etat_cloture` FROM  `new_intevention_incident` 
    WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'
    AND   `id_affectation` = '".mysqli_real_escape_string($connexion,$id_affectation)."'
    AND  `degre_appel` = '".mysqli_real_escape_string($connexion,$degre_appel)."'";

	
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 873: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 873 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                if ($row["max_nbr_tentative"]<>$nbr_tentative)
                {
                    return '<span class="fa fa-minus" aria-hidden="true"></span>';
                }
                else
                {
                    if ((get_max_etat_action($id_incident) <> $row["max_nbr_tentative"]))
                    {
                            if ($nbr_tentative == $row["max_nbr_tentative"]) {return $row["max_date_rappel"];}
                    }
                    else
                    {
                        if ((get_max_etat_cloture($id_action)==0) && get_info_etat_gab2($id_incident)==0)
                        {
                            // echo  get_info_etat_gab2($id_incident);
                            return '<span class="fa fa-minus" aria-hidden="true"></span>';
                        }
                        else
                        {
                            return $row["max_date_rappel"];
                        }
                    }
                }
            }
		}

    mysqli_free_result($result);
	}
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_max_etat_action($id_incident)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT max(`nbr_tentative`) max_nbr_tentative FROM  `new_intevention_incident`	
	WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 874: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 874 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["max_nbr_tentative"];
            }
		}
		else
		{
		    return "";
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_max_etat_cloture($id_action)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `etat_cloture` FROM  `new_intevention_incident`	WHERE 
	`id_action_interv` = '".mysqli_real_escape_string($connexion,$id_action)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 875: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 875 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                return $row["etat_cloture"];
            }
		}
		else
		{
		    return "";
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_personne_avisee_by_id_interve($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT id_incident ,personne_avisee FROM `new_intevention_incident` 
	WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 876: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 876 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["personne_avisee"];
            }
		}
		else
		{
		    return "";
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////
function update_personne_avisee($id,$personne_avisee)
{
    $connexion=ma_db_connexion();
    /***Corbeille Modif***(Motif Interv )*/
	$gab = get_gab_by_id_interve($id);
	$corb="INSERT INTO `corbeille_modified_intervention` (id_inc, id_int, gab , original_user,user_modified, 
	action_modified, type_modified, avissee_a, avissee_n) 
	
	VALUES ('".mysqli_real_escape_string($connexion,get_id_incident($id))."',
	'".mysqli_real_escape_string($connexion,$id)."','".mysqli_real_escape_string($connexion,$gab)."', 
	'".mysqli_real_escape_string($connexion,get_user_by_id_interve($id))."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',
	NOW(),'8','".mysqli_real_escape_string($connexion,get_personne_avisee_by_id_interve($id))."','".mysqli_real_escape_string($connexion,$personne_avisee)."' ) ";
	
    $resultcorb=mysqli_query($connexion,$corb);
    if (!$resultcorb)
    {
        error_log("Erreur SQL 877: ".$corb."  ".mysqli_error($connexion));
        die('ERREUR QUERY 877 !');
    }

    /////////////////////////////////////////////////////////////

    $sql = "UPDATE  `new_intevention_incident` SET  `personne_avisee` =  '".mysqli_real_escape_string($connexion,$personne_avisee)."' 
	WHERE  `new_intevention_incident`.`id_action_interv` = '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 878: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 878 !');
    }

    /////////////////////////////////////////////////////////////

    $sqltemp = "UPDATE  `new_intevention_incident_tmp` SET  `personne_avisee` =  '".mysqli_real_escape_string($connexion,$personne_avisee)."' 
	WHERE  `new_intevention_incident_tmp`.`id_action_interv` = '".mysqli_real_escape_string($connexion,$id)."'";
    $resulttemp=mysqli_query($connexion,$sqltemp);
    if (!$resulttemp)
    {
        error_log("Erreur SQL 879: ".$sqltemp."  ".mysqli_error($connexion));
        die('ERREUR QUERY 879 !');
    }

    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_info_etat_gab2($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `etat_incident`  FROM  `new_etat_gab`, `new_incident_gab` 
            WHERE `new_incident_gab`.`etat_incident`= `new_etat_gab`.`id_etat` 
            AND `id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
    
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 880: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 880 !');
    }
    if ($result)
	{	
	    if(mysqli_num_rows($result)>0)
	    {
	        while ($row = mysqli_fetch_assoc($result))
            {
                return $row["etat_incident"];
            }
	    }
		else
		{
				return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}

/////////////////////////////////////////////////////////////
function get_update_personne_avisee($id,$personne_avisee)
{
echo '<input size="30" align="center" 	onChange="javascript:update_personne_avisee(\''.$id.'\')" id="personneavisee'.$id.'"  name="personneavisee'.$id.'" type="text"   
	value="'.$personne_avisee.'"  class="form-control input-sm">';
	echo '<a onClick="javascript:get_annuler_update_personne_avisee2(\''.$id.'\',\''.$personne_avisee.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}
/////////////////////////////////////////////////////////////
function update_nbr_degre_appel($id,$degre_appel)
{
    $connexion=ma_db_connexion();
    $sql = "UPDATE  `new_intevention_incident` 
	SET  `degre_appel` =  '".mysqli_real_escape_string($connexion,$degre_appel)."' 
	WHERE  `new_intevention_incident`.`id_action_interv` ='".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 881: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 881 !');
    }

    $sqltemp = "UPDATE  `new_intevention_incident_tmp` 
	SET  `degre_appel` =  '".mysqli_real_escape_string($connexion,$degre_appel)."' 
	WHERE  `new_intevention_incident_tmp`.`id_action_interv` = '".mysqli_real_escape_string($connexion,$id)."'";
    $resulttemp=mysqli_query($connexion,$sqltemp);
    if (!$resulttemp)
    {
        error_log("Erreur SQL 882: ".$sqltemp."  ".mysqli_error($connexion));
        die('ERREUR QUERY 882 !');
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nbr_degre_appel($id,$degre_appel)
{
	if ($degre_appel==""){$degre_appel="----";}	
	echo '<span  onclick="get_update_nbr_degre_appel(\''.$id.'\',\''.$degre_appel.'\')"><a>'.$degre_appel.'</a></span>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nbr_escalade($id,$nbr_escalade)
{
	if ($nbr_escalade==""){$nbr_escalade="----";}	
	echo '<span  onclick="get_update_nbr_escalade(\''.$id.'\',\''.$nbr_escalade.'\')"><a>'.$nbr_escalade.'</a></span>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_personne_avisee($id,$personne_avisee)
{
	if ($personne_avisee==""){$personne_avisee="----";}	
	echo '<span  onclick="get_update_personne_avisee(\''.$id.'\',\''.$personne_avisee.'\')"><a>'.$personne_avisee.'</a></span>';

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_etat_contact3($id_contact,$id_incident,$cd_agence,$id_intervention,$etat_contact)
{
	
	echo '<span style="text-align: center;font-size:14px;"  onclick="get_update_id__etat_contact3(\''.$id_contact.'\',\''.$id_incident.'\',\''.$cd_agence.'\',\''.$id_intervention.'\',\''.$etat_contact.'\')"><a>'.get_libelle_etat_contact33($id_contact,$id_incident,$cd_agence,$id_intervention,$etat_contact).'</a></span>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_id_affectation($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_type`, `libelle` FROM `new_libelle_type_contact` 
	WHERE  `id_type` = '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 883: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 883 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["id_type"].'">'.$row["libelle"].'</option>';
            }
		}
		else
		{
		    echo '<option value=""></option>';
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
	
} 
/////////////////////////////////////////////////////////////
function get_update_nbr_degre_appel($id,$degre_appel)
{
echo '<input size="10"  align="center" 	onChange="javascript:update_nbr_degre_appel(\''.$id.'\')" id="degreappel'.$id.'"  name="degreappel'.$id.'" type="text"   
	value="'.$degre_appel.'"  class="form-control input-sm">';
	 echo '<a onClick="javascript:get_annuler_update_degre_appel2(\''.$id.'\',\''.$degre_appel.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}
/////////////////////////////////////////////////////////////
function update_nbr_escalade($id,$nbr_escalade)
{
    $connexion=ma_db_connexion();
    $sql = "UPDATE  `new_intevention_incident`
	SET  `nbr_escalade` =  '".mysqli_real_escape_string($connexion,$nbr_escalade)."' 
	WHERE  `new_intevention_incident`.`id_action_interv` = '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 883: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 883 !');
    }


    $sqltempo = "UPDATE  `new_intevention_incident_tmp` SET  `nbr_escalade` =  '".mysqli_real_escape_string($connexion,$nbr_escalade)."' 
	WHERE  `new_intevention_incident_tmp`.`id_action_interv` = '".mysqli_real_escape_string($connexion,$id)."'";
    $resulttemp=mysqli_query($connexion,$sqltempo);
    if (!$resulttemp)
    {
        error_log("Erreur SQL 884: ".$sqltempo."  ".mysqli_error($connexion));
        die('ERREUR QUERY 884 !');
    }

    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////
function get_update_nbr_escalade($id,$nbr_escalade)
{
echo '<input size="10"  align="center" 	onChange="javascript:update_nbr_escalade(\''.$id.'\')" id="nbrescalade'.$id.'"  name="nbrescalade'.$id.'" type="text"   
	value="'.$nbr_escalade.'"  class="form-control input-sm">';
echo '<a onClick="javascript:get_annuler_update_nbr_escalade2(\''.$id.'\',\''.$nbr_escalade.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
function updateEtatAppelAgence($id_incident,$etat)
{
    $connexion=ma_db_connexion();
    $sql = "UPDATE  `new_etat_appel_agence` SET  `etat_appel` =  '".mysqli_real_escape_string($connexion,$etat)."', 
	`date_prise_charge` =NOW() WHERE  `id_incident` ='".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 885: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 885 !');
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
function InsertEtatAppelAgence($id_incident,$etat)
{
    $connexion=ma_db_connexion();
    $sql = "INSERT INTO  `new_etat_appel_agence` (`id_appel`, `id_incident`, `etat_appel`, `date_prise_charge`) 	
	VALUES ('', '".mysqli_real_escape_string($connexion,$id_incident)."',  '".mysqli_real_escape_string($connexion,$etat)."',NOW())";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 886: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 886 !');
    }
    mysqli_close($connexion);
}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function updateListContact2($id_incident,$etat)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_incident` FROM `new_etat_appel_agence`
	WHERE  `id_incident` = '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 887: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 887 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    updateEtatAppelAgence($id_incident,$etat);
		}
		else
		{
		    InsertEtatAppelAgence($id_incident,$etat);
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////
function update_id_etat_contact($id,$etat_contact)
{
    $connexion=ma_db_connexion();
    $sql = "UPDATE  `new_intevention_incident` 
	SET  `etat_contact` =  '".mysqli_real_escape_string($connexion,$etat_contact)."' 
	WHERE  `new_intevention_incident`.`id_action_interv`  =    '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 888: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 888 !');
    }
    mysqli_close($connexion);
/////////////////////////////////////////////////////////////

updateListContact2(get_id_incident($id),$etat_contact);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_select_id_etat_contact($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_type`, `libelle` FROM  `new_type_contact`  WHERE  `id_type` <>  '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 889: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 889 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                echo '<option value="'.$row["id_type"].'">'.$row["libelle"].'</option>';
            }
		}
		else
		{
		    echo '<option value=""></option>';
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
} 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_id_etat_contact($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_type`, `libelle` FROM  `new_type_contact`  
	WHERE  `id_type` =    '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 890: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 890 !');
    }
    if ($result)
	{
	    if(mysqli_num_rows($result)>0)
	    {
	        while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["id_type"].'">'.$row["libelle"].'</option>';
            }
	    }
		else
		{
		    echo '<option value=""></option>';
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////
function get_update_id__etat_contact($id,$etat_contact)
{
			echo '<select style="font-weight:bold;color:#000;font-size:12px;"   class="form-control" id="etatcontact'.$id.'"  required name="etatcontact'.$id.'" 
			onChange="javascript:update_id_etat_contact(\''.$id.'\')">';				
			get_select_id_etat_contact($etat_contact);	
			get_all_select_id_etat_contact($etat_contact);
			echo '</select>';	
	 echo '<a onClick="javascript:get_annuler_update_etat_contact2(\''.$id.'\',\''.$etat_contact.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_affectation_by_id_interve($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT id_incident ,id_affectation FROM `new_intevention_incident`
	WHERE  `id_action_interv` =  '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 891: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 891 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["id_affectation"];
            }
		}
		else
		{
		    return "";
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////
function update_id_affectation($id,$id_affectation)
{
    $connexion=ma_db_connexion();
/***Corbeille Modif****/
	$gab = get_gab_by_id_interve($id);
	$corb="INSERT INTO `corbeille_modified_intervention` (id_inc, id_int, gab , original_user,user_modified, action_modified, type_modified, contacte_a, contacte_n) 
	VALUES ('".get_id_incident($id)."','$id','$gab', '".get_user_by_id_interve($id)."','".$_SESSION['id_utilisateur']."',NOW(),'7','".get_affectation_by_id_interve($id)."','$id_affectation' )";
    $resultcorb=mysqli_query($connexion,$corb);
    if (!$resultcorb)
    {
        error_log("Erreur SQL 892: ".$corb."  ".mysqli_error($connexion));
        die('ERREUR QUERY 892 !');
    }

    /////////////////////////////////////////////////////////////

    $sql = "UPDATE  `new_intevention_incident`
	SET  `id_affectation` =  '".mysqli_real_escape_string($connexion,$id_affectation)."' 
	WHERE  `new_intevention_incident`.`id_action_interv` =   '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 893: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 893 !');
    }

    /////////////////////////////////////////////////////////////

    $sqltemp = "UPDATE  `new_intevention_incident_tmp` 
	SET  `id_affectation` =  '".mysqli_real_escape_string($connexion,$id_affectation)."' 
	WHERE  `new_intevention_incident_tmp`.`id_action_interv` =  '".mysqli_real_escape_string($connexion,$id)."'";
    $resultemp=mysqli_query($connexion,$sqltemp);
    if (!$resultemp)
    {
        error_log("Erreur SQL 894: ".$sqltemp."  ".mysqli_error($connexion));
        die('ERREUR QUERY 894 !');
    }

    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_select_id_affectation($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_type`, `libelle` FROM `new_libelle_type_contact` 
	WHERE  `id_type` <> '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 895: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 895 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                echo '<option value="'.$row["id_type"].'">'.$row["libelle"].'</option>';
            }
		}
		else
		{
				echo '<option value=""></option>';
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////
function get_update_id_affectation($id,$id_affectation)
{
			echo '<select   class="form-control" id="idaffectation'.$id.'"  required name="idaffectation'.$id.'" 
			onChange="javascript:update_id_affectation(\''.$id.'\')">';				
			get_select_id_affectation($id_affectation);	
			get_all_select_id_affectation($id_affectation);
			echo '</select>';	
			echo '<a onClick="javascript:get_annuler_update_id_affectation2(\''.$id.'\',\''.$id_affectation.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_etat_contact1($id,$etat_contact)
{
	
	echo '<span  onclick="get_update_id__etat_contact(\''.$id.'\',\''.$etat_contact.'\')"><a>'.get_libelle_etat_contacts($etat_contact).'</a></span>';
}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_id_affectation($id,$id_affectation)
{
	echo '<span  onclick="get_update_id_affectation(\''.$id.'\',\''.$id_affectation.'\')"><a>'.get_libelle_type_contacts($id_affectation).'</a></span>';
}
 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_etat_contacts($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `libelle`    FROM `new_type_contact`  
	WHERE `id_type`  =   '".mysqli_real_escape_string($connexion,$id)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 896: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 896 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["libelle"];
            }
		}
		else
		{
		    return "";
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_type_contacts($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `libelle`    FROM `new_libelle_type_contact`  
	WHERE `id_type`  =   '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 897: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 897 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["libelle"];
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_select_action_intervention($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_intevention`, `libelle_intevention` FROM `new_action_intervention` 
	WHERE  `id_intevention` <>   '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 898: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 898 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                echo '<option value="'.$row["id_intevention"].'">'.$row["libelle_intevention"].'</option>';
            }
		}
		else
		{
		    echo '<option value=""></option>';
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
} 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_action_intervention($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_intevention`, `libelle_intevention` FROM `new_action_intervention` 
	WHERE  `id_intevention`  =   '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 899: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 899 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
				echo '<option value="'.$row["id_intevention"].'">'.$row["libelle_intevention"].'</option>';
            }
		}
		else
		{
				echo '<option value=""></option>';
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
	//////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_categorie_intervention($intervention)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_categories` FROM `new_action_intervention` 
	WHERE `id_intevention` = '".mysqli_real_escape_string($connexion,$intervention)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 900: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 900 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["id_categories"];
            }
		}
		else
		{
				return 0;
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_incident($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT `id_incident` FROM `new_intevention_incident`
	WHERE  `id_action_interv` =   '".mysqli_real_escape_string($connexion,$id)."'"; 
	
	$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 901: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 901 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["id_incident"];
            }
		}
		else
		{
		    return "";
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_motif_by_id_interve($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT id_incident ,id_action_intervention FROM `new_intevention_incident` 
	WHERE  `id_action_interv` =  '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 902: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 902 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["id_action_intervention"];
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_user_by_id_interve($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT id_incident ,id_utilisateur FROM `new_intevention_incident`
	WHERE  `id_action_interv` =  '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 903: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 903 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["id_utilisateur"];
            }
			}	
		else
		{
		    return "";
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_arret_by_incident($idInci)
{
	$dateArret="";
    $connexion=ma_db_connexion();
    $sql = "SELECT  *   FROM `new_incident_gab`   WHERE `id_incident`  =   '".mysqli_real_escape_string($connexion,$idInci)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 904: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 904 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                $dateArret = $row["date_arrete"];
            }
		}
		else
		{
		     $dateArret="";
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
    return $dateArret;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_gab_by_id_interve($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT `id_incident`,id_gab FROM `new_intevention_incident` 
	WHERE  `id_action_interv` =  '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 905: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 905 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                return $row["id_gab"];
            }
		}
		else
		{
		    return "";
		}

		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_id_action_intervention($id_action,$id_motif)
{
    $connexion=ma_db_connexion();
	/***Corbeille Modif***/
	$gab = get_gab_by_id_interve($id_action);
	$idIncid=get_id_incident($id_action);
	$dateArret=get_date_arret_by_incident($idIncid);
	
	$corb="INSERT INTO `corbeille_modified_intervention` (id_inc, id_int, gab , original_user,user_modified, action_modified, type_modified, motif_int_a, motif_int_n) 
	VALUES (  '".mysqli_real_escape_string($connexion,$idIncid)."',  '".mysqli_real_escape_string($connexion,$id_action)."',
	  '".mysqli_real_escape_string($connexion,$gab)."',
	'".mysqli_real_escape_string($connexion,get_user_by_id_interve($id_action))."',
	'".$_SESSION['id_utilisateur']."',
	NOW(),'4',
	'".mysqli_real_escape_string($connexion,get_motif_by_id_interve($id_action))."',  
	'".mysqli_real_escape_string($connexion,$id_motif)."' ) ";
    $resultcorb=mysqli_query($connexion,$corb);
    if (!$resultcorb)
    {
        error_log("Erreur SQL 906: ".$corb."  ".mysqli_error($connexion));
        die('ERREUR QUERY 906 !');
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    $sql = "UPDATE  `new_intevention_incident` 
	SET  `id_action_intervention` =    '".mysqli_real_escape_string($connexion,$id_motif)."',
    `id_niveau_intervention` =  '".mysqli_real_escape_string($connexion,get_id_niveau_intervention_incident($id_motif))."',	
    `id_categories` =  '".mysqli_real_escape_string($connexion,get_id_categorie_intervention($id_motif))."'	
    WHERE  `new_intevention_incident`.`id_action_interv` = '".mysqli_real_escape_string($connexion,$id_action)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 907: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 907 !');
    }



    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    $idUser=$_SESSION['id_utilisateur'];
		 
    $sqltemp = "UPDATE  `new_intevention_incident_tmp` 
	SET  `id_action_intervention` =    '".mysqli_real_escape_string($connexion,$id_motif)."',
    `id_niveau_intervention` =  '".mysqli_real_escape_string($connexion,get_id_niveau_intervention_incident($id_motif))."',	
    `id_categories` =  '".mysqli_real_escape_string($connexion,get_id_categorie_intervention($id_motif))."'	
    WHERE  `new_intevention_incident_tmp`.`id_action_interv` = '".mysqli_real_escape_string($connexion,$id_action)."'";
    $resulttemp=mysqli_query($connexion,$sqltemp);
    if (!$resulttemp)
    {
        error_log("Erreur SQL 908: ".$sqltemp."  ".mysqli_error($connexion));
        die('ERREUR QUERY 908 !');
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    $sqlSelectMaxIntervention= "SELECT max(id_action_interv) as maxInterv FROM new_intevention_incident 
	WHERE id_incident = '".mysqli_real_escape_string($connexion,$idIncid)."'";
    $selectMaxIntervention=mysqli_query($connexion,$sqlSelectMaxIntervention);
    if (!$selectMaxIntervention)
    {
        error_log("Erreur SQL 909: ".$sqlSelectMaxIntervention."  ".mysqli_error($connexion));
        die('ERREUR QUERY 909 !');
    }
    if ($selectMaxIntervention)
    {
        if(mysqli_num_rows($selectMaxIntervention)>0)
        {
            while ($row = mysqli_fetch_assoc($selectMaxIntervention))
            {
                $maxIdIn =  $row["maxInterv"];
            }
        }
        mysqli_free_result($selectMaxIntervention);
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    if($id_action==$maxIdIn)
    {
        /***Corbeille Modif Motif Incident***/
        $corb="INSERT INTO `corbeille_modified_intervention` 
		(id_inc, id_int, gab , original_user,user_modified, action_modified, type_modified, motif_int_a, 
		motif_int_n, prise_en_charge_a) 
		VALUES ('".mysqli_real_escape_string($connexion,$idIncid)."','".mysqli_real_escape_string($connexion,$id_action)."',  '".mysqli_real_escape_string($connexion,$gab)."',
		'".mysqli_real_escape_string($connexion,get_user_by_id_interve($id_action))."',
		'".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',
		NOW(),'1','".mysqli_real_escape_string($connexion,get_motif_by_id_interve($id_action))."',
		
		  '".mysqli_real_escape_string($connexion,$id_motif)."',  '".mysqli_real_escape_string($connexion,$dateArret)."' ) ";
        $resultCorb=mysqli_query($connexion,$corb);
        if (!$resultCorb)
        {
            error_log("Erreur SQL 910: ".$corb."  ".mysqli_error($connexion));
            die('ERREUR QUERY 910 !');
        }


        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $sql2 = "UPDATE  `new_incident_gab` SET  `id_action_fonctionelle` =  '".mysqli_real_escape_string($connexion,$id_motif)."',
        `id_niveau_fonctionelle` =  '".mysqli_real_escape_string($connexion,get_id_niveau_intervention_incident($id_motif))."',
        `id_categories_fonctionnelle` =  '".mysqli_real_escape_string($connexion,get_id_categorie_intervention($id_motif))."'
        WHERE    `new_incident_gab`.`id_incident`=  '".mysqli_real_escape_string($connexion,$idIncid)."'";
        $result2=mysqli_query($connexion,$sql2);
        if (!$result2)
        {
            error_log("Erreur SQL 911: ".$sql2."  ".mysqli_error($connexion));
            die('ERREUR QUERY 911 !');
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $sql2Ouv = "UPDATE  `new_incident_gab_ouvert` SET  `id_action_fonctionelle` =  '".mysqli_real_escape_string($connexion,$id_motif)."',
        `id_niveau_fonctionelle` =  '".mysqli_real_escape_string($connexion,get_id_niveau_intervention_incident($id_motif))."',
        `id_categories_fonctionnelle` =  '".mysqli_real_escape_string($connexion,get_id_categorie_intervention($id_motif))."'
        WHERE    `new_incident_gab_ouvert`.`id_incident`=  '".mysqli_real_escape_string($connexion,$idIncid)."'";
        $resultOuv=mysqli_query($connexion,$sql2Ouv);
        if (!$resultOuv)
        {
            error_log("Erreur SQL 912: ".$sql2Ouv."  ".mysqli_error($connexion));
            die('ERREUR QUERY 912 !');
        }

	}

    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_update_action_intervention($id,$action_intervention)
{
			echo '<select   class="form-control" id="idaction_intervention'.$id.'"  required name="idaction_intervention'.$id.'" 
			onChange="javascript:update_id_action_intervention(\''.$id.'\')">';				
			get_select_action_intervention($action_intervention);	
			get_all_select_action_intervention($action_intervention);
			echo '</select>';	
	 echo '<a onClick="javascript:get_annuler_update_action_intervention2(\''.$id.'\',\''.$action_intervention.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_count_intervention_technique($id_incident)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  count(`nbr_tentative`) as nbrtentative 
	FROM `new_intevention_incident`, `new_action_intervention` WHERE `id_intevention` = `id_action_intervention`
    AND `id_incident`  =    '".mysqli_real_escape_string($connexion,$id_incident)."' ORDER BY `nbr_tentative` ASC";

	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 913: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 913 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["nbrtentative"];
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
						
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nbr_tentative($id,$nbr_tentative)
{
	if ($nbr_tentative==""){$nbr_tentative="----";}	
	echo '<span  onclick="get_update_nbr_tentative(\''.$id.'\',\''.$nbr_tentative.'\')"><a>'.$nbr_tentative.'</a></span>';
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_action_intervention1($id,$action_intervention)
{
	echo '<span  onclick="get_update_action_intervention(\''.$id.'\',\''.$action_intervention.'\')"><a>'.get_libelle_action_intervention($action_intervention).'</a></span>';
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
function get_information_intevention_technique($id_incident)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  max(`date_cloture`) as dateMancloture, min(`date_action`) as dateaMinction, max(`nbr_tentative`) as Maxnbrtentative, min(`nbr_tentative`) as Minnbrtentative
    FROM `new_intevention_incident`, `new_action_intervention`
    WHERE        `id_intevention` = `id_action_intervention`
    AND `id_incident`  =   '".mysqli_real_escape_string($connexion,$id_incident)."'
    ORDER BY `nbr_tentative` ASC";
	
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 914: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 914 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    $i=0;
			while ($row = mysqli_fetch_assoc($result)) 
            {
                if (($row["dateMancloture"]=="") || ($row["dateMancloture"]=="0000-00-00 00:00:00"))
                {$dateMancloture[$i]=0;}	else{$dateMancloture[$i]=$row["dateMancloture"];}

                if (($row["dateaMinction"]=="") || ($row["dateaMinction"]=="0000-00-00 00:00:00"))
                {$dateaMinction[$i]=0;}	else{$dateaMinction[$i]=$row["dateaMinction"];	}

                if (($row["Maxnbrtentative"]==""))
                {$Maxnbrtentative[$i]=0;}	else{$Maxnbrtentative[$i]=$row["Maxnbrtentative"];}
			
 				if (($row["Maxnbrtentative"]==""))
 				{$Minnbrtentative[$i]=0;}	else{$Minnbrtentative[$i]=$row["Maxnbrtentative"];}
                $i++;
            }

            return  array($dateMancloture,$dateaMinction,$Maxnbrtentative,$Minnbrtentative);

		}
		else
			{
				return array(0,0,0,0);
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_duree_sla($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `duree_sla`  FROM `new_libelle_type_contact` 
	WHERE `id_type` =   '".mysqli_real_escape_string($connexion,$id)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 915: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 915 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["duree_sla"];  	
					}
			}	
		else
			{
				return "";
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_prestataire($id)
{
    $connexion=ma_db_connexion();
    $sql ="SELECT `libelle` FROM `new_libelle_type_contact` WHERE `id_type` =   '".mysqli_real_escape_string($connexion,$id)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 916: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 916 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return  STRTOUPPER($row["libelle"]);
            }
		}
		else
			{
				return "";
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}	
///////////////////////////////////////////////////////////////////////////////////////////////////////
function get_liste_action_nasser($id_incident)
{
    $conn=ma_db_connexion();
    $sql = "SELECT id_categories,date_action,  id_affectation, id_action_intervention
			FROM  `new_intevention_incident` 
			where id_incident =   '".mysqli_real_escape_string($conn,$id_incident)."'
			order by date_action;";

    mysqli_query($conn,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($conn,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 917: ".$sql."  ".mysqli_error($conn));
        die('ERREUR QUERY 917 !');
    }
    if($result)
    {
        if (mysqli_num_rows($result)>0)
        {
            $i =0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $id_categorie[$i]=$row["id_categories"];
				$date_action[$i]=$row["date_action"];
				$id_affectation[$i]=$row["id_affectation"];
				$id_action_intervention[$i]=$row["id_action_intervention"];
				$i++;
			}
			return  array($id_categorie,$date_action,$id_affectation,$id_action_intervention); 
		  }
		  mysqli_free_result($result);

    }
    else
    {
      return array("", "", "", "", "");

    }
    mysqli_close($conn);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
function get_liste_affectation_nasser()
{
    $conn=ma_db_connexion();
    $sql = "SELECT id_type, libelle FROM  `new_libelle_type_contact`;";
    mysqli_query($conn,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($conn,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 918: ".$sql."  ".mysqli_error($conn));
        die('ERREUR QUERY 918 !');
    }
    if ($result)
	{
	    if (mysqli_num_rows($result)>0)
	    {
	        while ($row = mysqli_fetch_assoc($result))
            {
                $libelle[$row["id_type"]]=$row["libelle"];
			}
			return  $libelle;
	    }
	    mysqli_free_result($result);
	}

    else
    {
      return "";
    }
    mysqli_close($conn);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function suppimer_gab_suivi($id_incident)
{
    $connexion=ma_db_connexion();
	/**CORBEILLE Supression Incident**/
		// $InsIncid= mysqli_query("INSERT INTO corbeille_deleted_incident (SELECT * FROM new_incident_gab WHERE `id_incident`=  '".$id_incident."') ") or die(mysqli_error());
	/***********************/
	/**CORBEILLE Supression Intervention**/
		// $InsInterv= mysqli_query("INSERT INTO corbeille_deleted_intervention (SELECT * FROM new_intevention_incident WHERE `id_incident`=  '".$id_incident."') ")or die(mysqli_error());
	/***********************/
	/**CORBEILLE Supression Incident**/
	$sqlSelectIncident="SELECT id_gab,date_arrete, date_prise_en_charge,num_tiket,num_affectation,date_remise,date_derniere_interv,date_derniere_rappel,
	etat_incident,remarque_press,remarque_frss,rapport_technique_excel,cd_prestataire,cd_fournisseur,cd_arret_fonctionnelle,
	id_categories_fonctionnelle,cd_arret_technique,id_categories_technique,id_action_fonctionelle,id_niveau_fonctionelle,id_action_technique,
	id_niveau_technique,id_facturable
	FROM new_incident_gab WHERE `id_incident`=    '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $selectIncident=mysqli_query($connexion,$sqlSelectIncident);
    if (!$selectIncident)
    {
        error_log("Erreur SQL 919: ".$sqlSelectIncident."  ".mysqli_error($connexion));
        die('ERREUR QUERY 919 !');
    }
	if($selectIncident)
	{
	    if(mysqli_num_rows($selectIncident)>0)
	    {
			while ($list= mysqli_fetch_assoc($selectIncident))
            {
				$id_gab= $list["id_gab"];
				$date_arrete= $list["date_arrete"];
				$date_prise_en_charge= $list["date_prise_en_charge"];
				$num_tiket= $list["num_tiket"];
				$num_affectation= $list["num_affectation"];
				$date_remise= $list["date_remise"];
				$date_derniere_interv= $list["date_derniere_interv"];
				$date_derniere_rappel= $list["date_derniere_rappel"];
				$etat_incident= $list["etat_incident"];
				$remarque_press= $list["remarque_press"];
				$remarque_frss= $list["remarque_frss"];
				$rapport_technique_excel= $list["rapport_technique_excel"];
				$cd_prestataire= $list["cd_prestataire"];
				$cd_fournisseur= $list["cd_fournisseur"];
				$cd_arret_fonctionnelle= $list["cd_arret_fonctionnelle"];
				$id_categories_fonctionnelle= $list["id_categories_fonctionnelle"];
				$cd_arret_technique= $list["cd_arret_technique"];
				$id_categories_technique= $list["id_categories_technique"];
				$id_action_fonctionelle= $list["id_action_fonctionelle"];
				$id_niveau_fonctionelle= $list["id_niveau_fonctionelle"];
				$id_action_technique= $list["id_action_technique"];
				$id_niveau_technique= $list["id_niveau_technique"];
				$id_facturable= $list["id_facturable"];	
			}
	    }
	    mysqli_free_result($selectIncident);
	}	
	/*********************************/
	/**CORBEILLE Supression Intervention**/
	$sqlSelectIntervention="SELECT id_action_interv,id_gab,date_action,date_prise_en_charge,date_prise_en_charge2,date_prise_charge_gestionnaire,
	num_affectation,id_affectation,degre_appel,type_contact,etat_contact,personne_avisee,id_action_intervention,id_niveau_intervention,last_Trans,
	etat_cloture,date_cloture,date_rappel,nbr_tentative,nbr_escalade,id_utilisateur,degre_intervention,motif_cloture,auto_cloture
	FROM new_intevention_incident WHERE `id_incident`=    '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $selectIntervention=mysqli_query($connexion,$sqlSelectIntervention);
    if (!$selectIntervention)
    {
        error_log("Erreur SQL 920: ".$sqlSelectIntervention."  ".mysqli_error($connexion));
        die('ERREUR QUERY 920 !');
    }
	if($selectIntervention)
	{
		if(mysqli_num_rows($selectIntervention)>0)
		{
			while ($list= mysqli_fetch_assoc($selectIntervention))
            {
				$id_action_interv= $list["id_action_interv"];
				$id_gab= $list["id_gab"];
				$date_action= $list["date_action"];
				$date_prise_en_charge= $list["date_prise_en_charge"];
				$date_prise_en_charge2= $list["date_prise_en_charge2"];
				$date_prise_charge_gestionnaire= $list["date_prise_charge_gestionnaire"];
				$num_affectation= $list["num_affectation"];
				$id_affectation= $list["id_affectation"];
				$degre_appel= $list["degre_appel"];
				$type_contact= $list["type_contact"];
				$etat_contact= $list["etat_contact"];
				$personne_avisee= $list["personne_avisee"];
				$id_action_intervention= $list["id_action_intervention"];
				$id_niveau_intervention= $list["id_niveau_intervention"];
				$last_Trans= $list["last_Trans"];
				$etat_cloture= $list["etat_cloture"];
				$date_cloture= $list["date_cloture"];
				$date_rappel= $list["date_rappel"];
				$nbr_tentative= $list["nbr_tentative"];
				$nbr_escalade= $list["nbr_escalade"];
				$id_utilisateur= $list["id_utilisateur"];
				$degre_intervention= $list["degre_intervention"];
				$motif_cloture= $list["motif_cloture"];
				$auto_cloture= $list["auto_cloture"];
		
			}
		}
		mysqli_free_result($selectIntervention);
	}	
	/************************************/
	
	
    $sql_2temp = "DELETE FROM `new_intevention_incident_tmp` WHERE  `id_incident`=   '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $rs4=mysqli_query($connexion,$sql_2temp);
    if (!$rs4)
    {
        error_log("Erreur SQL 921: ".$sql_2temp."  ".mysqli_error($connexion));
        die('ERREUR QUERY 921 !');
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    $sql_2O = "DELETE FROM `new_incident_gab_ouvert` WHERE  `id_incident`=   '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $rs5=mysqli_query($connexion,$sql_2O);
    if (!$rs5)
    {
        error_log("Erreur SQL 922: ".$sql_2O."  ".mysqli_error($connexion));
        die('ERREUR QUERY 922 !');
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    $sql_2 = "DELETE FROM `new_intevention_incident` WHERE  `id_incident`=    '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $rs6=mysqli_query($connexion,$sql_2);
    if (!$rs6)
    {
        error_log("Erreur SQL 923: ".$sql_2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 923 !');
    }


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    $sql = "DELETE FROM `new_incident_gab` WHERE  `id_incident`=   '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $rs7=mysqli_query($connexion,$sql);
    if (!$rs7)
    {
        error_log("Erreur SQL 924: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 924 !');
    }
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
function liste_gab_admin_suivi($terminal="")
{
    include "languages/" . $_SESSION['lang'] . ".php";

    $connexion=ma_db_connexion();
    $liste_affect=get_liste_affectation_nasser();
    $liste_action_na=get_action_nasser();
 
    if($terminal=="")
    {
        $terminal="%";
        $SQL1 = "SELECT `id_incident`, `id_gab`, `date_arrete`, `date_remise`, `remarque_frss`, `remarque_press`
        FROM `new_incident_gab`,`new_list_gab`
        WHERE  `new_list_gab`.`terminal`=`new_incident_gab`.`id_gab`
        AND (trim(`new_incident_gab`.`id_gab`) like trim('$terminal') 
		OR  trim(`new_incident_gab`.`id_incident`) = trim('$terminal')  
		OR UPPER(`nom_gab`) like '%".strtoupper($terminal)."%')        
        ORDER BY `date_arrete` DESC";
        $page = new Pagination($SQL1, 12);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL = $page->req();
    }
    else
    {
        $SQL = "SELECT `id_incident`, `id_gab`, `date_arrete`, `date_remise`, `remarque_frss`, `remarque_press`
        FROM `new_incident_gab`,`new_list_gab`
        WHERE  `new_list_gab`.`terminal`=`new_incident_gab`.`id_gab`
		AND ( trim(`new_incident_gab`.`id_gab`) like   '%".mysqli_real_escape_string($connexion,trim($terminal))."%'
		OR  trim(`new_incident_gab`.`id_incident`) =   '".mysqli_real_escape_string($connexion,trim($terminal))."'
		OR UPPER(`nom_gab`) like '%".mysqli_real_escape_string($connexion,strtoupper($terminal))."%' )
        ORDER BY `date_arrete` DESC";
    }
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 925: ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 925 !');
    }
    echo '<table class="table table-responsive-sm table-hover table-outline mb-0"> ';
    if(mysqli_num_rows($result)>0)
    {
        $i=0;
        echo ' <thead class="thead-light">
            <tr >
            <th class="text-center"></th>
            <th class="text-center">'.$lang['atm_id'].'</th>
            <th class="text-center">'.$lang['atm_name'].'</th> 
            <th class="text-center">'.$lang['stop_date'].'</th>
            <th class="text-center">'.$lang['cause_default'].'</th>
            <th class="text-center">'.$lang['date_inter'].'</th>
            <th class="text-center">'.$lang['date_remi'].'</th>
            <th class="text-center">'.$lang['dure'].'</th>
            <th class="text-center">'.$lang['supprimer'].'</th>
            </tr>
        </thead>';
         while ($row = mysqli_fetch_assoc($result)) 
         {
             if ($row["date_remise"]=="0000-00-00 00:00:00")
             {
                 $date_remise=date('Y-m-d  H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y')));
             }
             else
			 {
			     $date_remise=$row["date_remise"];
			 }

             $gab=get_array_information_gab($row["id_gab"]);
             $duree_retard  = date_different($date_remise,$row["date_arrete"]);

             echo ' <tr>';
		 
             if ($duree_retard['minutes_total']>=240)
             {
                 echo '<td class="text-center"><span class="badge badge-pill badge-danger">+ 4H</span></td>';
             }
             else if (($duree_retard['minutes_total']<240) && ($duree_retard['minutes_total']>=120))
             {
                 echo '<td class="text-center"> <span class="badge badge-pill badge-warning">+ 2H</span> </td>';
             }
             else if (($duree_retard['minutes_total']<120) && ($duree_retard['minutes_total']>=0))
             {
                 echo '<td class="text-center"><span class="badge badge-pill badge-success">- 2H</span></td>';
             }
             echo '<td class="text-center">'.$row["id_gab"].'</td>
             <td class="text-center"><a target="_blank" title="N°  Dossier : '.$row["id_incident"].'" href="detail_gab.php?ternimal='.$row["id_gab"].'&id='.$row["id_incident"].'" >'.$gab["0"].'</a></td>
             <td class="text-center">'.$row["date_arrete"].'</td>
             <td class="text-center">';
             /******************************************************/
             $inter=get_liste_action_nasser($row["id_incident"]);
             $nb_inter=get_count_nbr_intervention($row["id_incident"]);
			 //echo "nb_inter: ".$nb_inter;
             for($j=0;$j<$nb_inter;$j++) // tant que $i est inferieur au nombre d'éléments du tableau...
             {
                 if((!empty($inter[2][$j])))
                 {
                     if((!empty($inter[3][$j])))
                     {
                         echo ($j+1)." - ".$liste_action_na[$inter[3][$j]]."<br>";
                     }
                     else
                     {
                         echo ($j+1)." - <br>";
                     }
                 }
                 else if((empty($inter[2][$j])))
                 {
                     if ($j=="0")
                     {
                         echo '<p style="text-align: center;"><a><span class="fa fa-minus"></span></a></p>';
                     }
                 }
             }
             /******************************************************/
			 echo'</td><td class="text-center">';
			 for($j=0;$j<$nb_inter;$j++) // tant que $i est inferieur au nombre d'éléments du tableau...
			 {
			     if((!empty($inter[2][$j])))
			     {
			         echo $inter[1][$j]." - ". $liste_affect[$inter[2][$j]]."<br>";
			     }
			     else if((empty($inter[2][$j])))
			     {
			         if ($j=="0")
			         {
			             echo '<p style="text-align: center;"><a><span class="fa fa-minus"></span></a></p>';
			         }
			     }
			 }
			/******************************************************/
			 echo'</td><td class="text-center">';
			 $date_cloture_fonctionnelle=get_date_cloture_gab($row["id_incident"]);
			 if ($date_cloture_fonctionnelle=="0000-00-00 00:00:00")
			 {
			     echo '<input name="cloture_fonction"   onChange="javascript:cloturer_incident_fonctionnelle1(\''.$row["id_incident"].'\','.$i.',\'0\')" id="cloture_fonction'.$i.'"   type="text"  
				 style="font-size:8px;font-weight:bold;color:#000;" size="20" value=""  placeholder="YYYY-MM-DD HH:MN:SS" class="form-control input-sm">';
			 }
			 else
			 {
			     //echo $date_cloture_fonctionnelle;
                 echo $date_remise;
			 }
			 echo '</td><td class="text-center">';
			 if ($date_cloture_fonctionnelle=="0000-00-00 00:00:00")
			 {
			     echo '<p style="text-align: center;"><a><span class="fa fa-minus"></span></a></p>';
			 }
			 else
			 {
			     if ($duree_retard['months']>=1)
			     {
			         echo $duree_retard['months']." M<br> ";
			     }
			     if ($duree_retard['days']>=1)
			     {
			         if ($_SESSION['lang']=='fr')
			         {
                         echo $duree_retard['days']." J<br> ";
                     }
			         else
			         {
                         echo $duree_retard['days']." Day<br> ";
                     }
			     }
			     if ($duree_retard['hours']>=1)
			     {
			         echo $duree_retard['hours']." H<br> ";
			     }
			     if ($duree_retard['minutes']>=1)
			     {
			         echo $duree_retard['minutes']." MN ";
			     }
			 }
			 echo'</td>';
			 echo '<td class="text-center"><span  onclick="suppimer_gab_suivi(\''.$row["id_incident"].'\')" class="c-icon cil-triangle"></span></td></tr>';


			 $i++;
         }
         if(($terminal=="") || ($terminal=="%"))
         {
             echo '<tr><td colspan="9" class="text-center">';
             echo   '<ul class="pagination justify-content-center">'.$lien.'</ul>';
             echo   '<div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>';
             echo'</td></tr>';
         }
    }
    else
    {
        echo ' <tr>';
        echo '<th colspan =9><div class="alert alert-danger text-center" role="alert">'.$lang['gab_non_trou'].'</div></th>';
        echo '</tr>';
    }
    echo '</table>';
    mysqli_free_result($result);
    mysqli_close($connexion);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
function liste_gab_admin_suivi_par_region($terminal="")
{
    include "languages/" . $_SESSION['lang'] . ".php";

    $connexion=ma_db_connexion();
    $liste_affect=get_liste_affectation_nasser();
    $liste_action_na=get_action_nasser();
 
    if($terminal=="")
    {
        $terminal="%";
        $SQL1 = "SELECT `id_incident`, `id_gab`, `date_arrete`, `date_remise`, `remarque_frss`, `remarque_press`
        FROM `new_incident_gab`,`new_list_gab`
        WHERE  `new_list_gab`.`terminal`=`new_incident_gab`.`id_gab`
        AND (trim(`new_incident_gab`.`id_gab`) like trim('$terminal') 
		OR  trim(`new_incident_gab`.`id_incident`) = trim('$terminal')  
		OR UPPER(`nom_gab`) like '%".strtoupper($terminal)."%')        
        ORDER BY `date_arrete` DESC";
        $page = new Pagination($SQL1, 12);
        $total = $page->getCount($lang['aff_lign'].'  %d - %d  ( total  : %d )');
        $lien = $page->liens(5);
        $SQL = $page->req();
    }
    else
    {
        $SQL = "SELECT `id_incident`, `id_gab`, `date_arrete`, `date_remise`, `remarque_frss`, `remarque_press`
        FROM `new_incident_gab`,`new_list_gab`
        WHERE  `new_list_gab`.`terminal`=`new_incident_gab`.`id_gab`
		AND ( trim(`new_incident_gab`.`id_gab`) like   '%".mysqli_real_escape_string($connexion,trim($terminal))."%'
		OR  trim(`new_incident_gab`.`id_incident`) =   '".mysqli_real_escape_string($connexion,trim($terminal))."'
		OR UPPER(`nom_gab`) like '%".mysqli_real_escape_string($connexion,strtoupper($terminal))."%' )
        ORDER BY `date_arrete` DESC";
    }
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 925: ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 925 !');
    }
    echo '<table class="table table-responsive-sm table-hover table-outline mb-0"> ';
    if(mysqli_num_rows($result)>0)
    {
        $i=0;
        echo ' <thead class="thead-light">
            <tr >
            <th class="text-center"></th>
            <th class="text-center">'.$lang['atm_id'].'</th>
            <th class="text-center">'.$lang['atm_name'].'</th> 
            <th class="text-center">'.$lang['stop_date'].'</th>
            <th class="text-center">'.$lang['cause_default'].'</th>
            <th class="text-center">'.$lang['date_inter'].'</th>
            <th class="text-center">'.$lang['date_remi'].'</th>
            <th class="text-center">'.$lang['dure'].'</th>
            <th class="text-center">'.$lang['supprimer'].'</th>
            </tr>
        </thead>';
         while ($row = mysqli_fetch_assoc($result)) 
         {
             if ($row["date_remise"]=="0000-00-00 00:00:00")
             {
                 $date_remise=date('Y-m-d  H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y')));
             }
             else
			 {
			     $date_remise=$row["date_remise"];
			 }

             $gab=get_array_information_gab($row["id_gab"]);
             $duree_retard  = date_different($date_remise,$row["date_arrete"]);

             echo ' <tr>';
		 
             if ($duree_retard['minutes_total']>=240)
             {
                 echo '<td class="text-center"><span class="badge badge-pill badge-danger">+ 4H</span></td>';
             }
             else if (($duree_retard['minutes_total']<240) && ($duree_retard['minutes_total']>=120))
             {
                 echo '<td class="text-center"> <span class="badge badge-pill badge-warning">+ 2H</span> </td>';
             }
             else if (($duree_retard['minutes_total']<120) && ($duree_retard['minutes_total']>=0))
             {
                 echo '<td class="text-center"><span class="badge badge-pill badge-success">- 2H</span></td>';
             }
             echo '<td class="text-center">'.$row["id_gab"].'</td>
             <td class="text-center"><a target="_blank" title="N°  Dossier : '.$row["id_incident"].'" href="detail_gab.php?ternimal='.$row["id_gab"].'&id='.$row["id_incident"].'" >'.$gab["0"].'</a></td>
             <td class="text-center">'.$row["date_arrete"].'</td>
             <td class="text-center">';
             /******************************************************/
             $inter=get_liste_action_nasser($row["id_incident"]);
             $nb_inter=get_count_nbr_intervention($row["id_incident"]);
			 //echo "nb_inter: ".$nb_inter;
             for($j=0;$j<$nb_inter;$j++) // tant que $i est inferieur au nombre d'éléments du tableau...
             {
                 if((!empty($inter[2][$j])))
                 {
                     if((!empty($inter[3][$j])))
                     {
                         echo ($j+1)." - ".$liste_action_na[$inter[3][$j]]."<br>";
                     }
                     else
                     {
                         echo ($j+1)." - <br>";
                     }
                 }
                 else if((empty($inter[2][$j])))
                 {
                     if ($j=="0")
                     {
                         echo '<p style="text-align: center;"><a><span class="fa fa-minus"></span></a></p>';
                     }
                 }
             }
             /******************************************************/
			 echo'</td><td class="text-center">';
			 for($j=0;$j<$nb_inter;$j++) // tant que $i est inferieur au nombre d'éléments du tableau...
			 {
			     if((!empty($inter[2][$j])))
			     {
			         echo $inter[1][$j]." - ". $liste_affect[$inter[2][$j]]."<br>";
			     }
			     else if((empty($inter[2][$j])))
			     {
			         if ($j=="0")
			         {
			             echo '<p style="text-align: center;"><a><span class="fa fa-minus"></span></a></p>';
			         }
			     }
			 }
			/******************************************************/
			 echo'</td><td class="text-center">';
			 $date_cloture_fonctionnelle=get_date_cloture_gab($row["id_incident"]);
			 if ($date_cloture_fonctionnelle=="0000-00-00 00:00:00")
			 {
			     echo '<input name="cloture_fonction"   onChange="javascript:cloturer_incident_fonctionnelle1(\''.$row["id_incident"].'\','.$i.',\'0\')" id="cloture_fonction'.$i.'"   type="text"  
				 style="font-size:8px;font-weight:bold;color:#000;" size="20" value=""  placeholder="YYYY-MM-DD HH:MN:SS" class="form-control input-sm">';
			 }
			 else
			 {
			     //echo $date_cloture_fonctionnelle;
                 echo $date_remise;
			 }
			 echo '</td><td class="text-center">';
			 if ($date_cloture_fonctionnelle=="0000-00-00 00:00:00")
			 {
			     echo '<p style="text-align: center;"><a><span class="fa fa-minus"></span></a></p>';
			 }
			 else
			 {
			     if ($duree_retard['months']>=1)
			     {
			         echo $duree_retard['months']." M<br> ";
			     }
			     if ($duree_retard['days']>=1)
			     {
			         if ($_SESSION['lang']=='fr')
			         {
                         echo $duree_retard['days']." J<br> ";
                     }
			         else
			         {
                         echo $duree_retard['days']." Day<br> ";
                     }
			     }
			     if ($duree_retard['hours']>=1)
			     {
			         echo $duree_retard['hours']." H<br> ";
			     }
			     if ($duree_retard['minutes']>=1)
			     {
			         echo $duree_retard['minutes']." MN ";
			     }
			 }
			 echo'</td>';
			 echo '<td class="text-center"><span  onclick="suppimer_gab_suivi(\''.$row["id_incident"].'\')" class="c-icon cil-triangle"></span></td></tr>';


			 $i++;
         }
         if(($terminal=="") || ($terminal=="%"))
         {
             echo '<tr><td colspan="9" class="text-center">';
             echo   '<ul class="pagination justify-content-center">'.$lien.'</ul>';
             echo   '<div class="alert alert-dark" role="alert"><h6>'.$total.'</h6></div>';
             echo'</td></tr>';
         }
    }
    else
    {
        echo ' <tr>';
        echo '<th colspan =9><div class="alert alert-danger text-center" role="alert">'.$lang['gab_non_trou'].'</div></th>';
        echo '</tr>';
    }
    echo '</table>';
    mysqli_free_result($result);
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_remarque_incident_terminal_fournisseur($idincident)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `remarque_frss` FROM `new_incident_gab` 
	WHERE TRIM(`id_incident`) = '".mysqli_real_escape_string($connexion,TRIM($idincident))."' AND  `remarque_frss`<>''";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 926: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 926 !');
    }
    if ($result)
	{	
	    if(mysqli_num_rows($result)>0)
	    {
	        echo '<table style="font-size:9pt;font-weight:bold;"  class="table table-striped" style="font-size:12px;font-weight:bold;" >
		   <tr  style="border-left: 2px solid #F96464;;border-right: 2px solid #F96464;;border-top: 2px solid #F96464;"> 
		   <td colspan=7 style="font-size:11pt;font-weight:bold;color:#FE2E2E;"><strong>Remarque Fournisseur :</strong>';
	        echo '<td></tr>';
	        echo '<tr style="border-left: 2px solid #F96464;;border-right: 2px solid #F96464;;border-bottom: 2px solid #F96464;"> 
            <td colspan=7 style="font-size:11pt;font-weight:bold;color:#FA5858;">';
	        echo "<strong >";
	        while ($row = mysqli_fetch_assoc($result))
            {
                return $row["remarque_frss"];
            }
            echo"</strong>";
	        echo '<td></tr></table>';
	    }
	    mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_remarque_incident_terminal_prestataire($idincident)
{
   
    include "languages/" . $_SESSION['lang'] . ".php";


    $connexion=ma_db_connexion();
    $sql_note = "SELECT  `remarque_press` FROM `new_incident_gab`
	WHERE TRIM(`id_incident`) = '".mysqli_real_escape_string($connexion,TRIM($idincident))."' AND  `remarque_press`<>''";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql_note);
    if (!$result)
    {
        error_log("Erreur SQL 927: ".$sql_note."  ".mysqli_error($connexion));
        die('ERREUR QUERY 927 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                echo '<table style="font-size:9pt;font-weight:bold;"  class="table table-striped" style="font-size:12px;font-weight:bold;" >
                <tr style="border-left: 2px solid #F96464;;border-right: 2px solid #F96464;;border-top: 2px solid #F96464;"> 
                <td colspan=7 style="font-size:11pt;font-weight:bold;color:#FE2E2E;"><strong>'.$lang["remarq"].' :</strong>';
                echo '<td></tr>';
                echo '<tr style="border-left: 2px solid #F96464;;border-right: 2px solid #F96464;;border-bottom: 2px solid #F96464;"> 
                <td colspan=7 style="font-size:11pt;font-weight:bold;color:#FA5858;">';
                echo "<strong >";
                while ($row = mysqli_fetch_assoc($result))
                {
                    echo $row["remarque_press"];
                }
                echo"</strong>";
                echo '<td></tr></table>';
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function gest_taux_disponibilite_detail_gab($date,$id_gab,$type)
{
    $connexion=ma_db_connexion();
    $sql="SELECT round(`taux_dispo_reel`,2) as taux_dispo_reel FROM `dispo_final`
	WHERE `id_gab` like '".mysqli_real_escape_string($connexion,$id_gab)."' AND `date_courant` like DATE_FORMAT(now() ,  '%Y-%m-%d' ) 
	and `type_dispo` = '".mysqli_real_escape_string($connexion,$type)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 928: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 928 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			    while ($row = mysqli_fetch_assoc($result))
                {
                    if ((substr($row["taux_dispo_reel"],0,1)==0) || (substr($row["taux_dispo_reel"],0,2)==0))
                    {
                        return "0%";
                    }
                    else
                    {
                        if (substr($row["taux_dispo_reel"],0,3)==100)
                        {
                            return substr($row["taux_dispo_reel"],0,3)."%";
                        }
                        else
					    {
					        return  substr($row["taux_dispo_reel"],0,5)."%";
					    }
                    }
                }
			}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_facturation($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`libelle` FROM  `new_libelle_facturation`
	WHERE `id_facturation` = '".mysqli_real_escape_string($connexion,$id)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 929: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 929 !');
    }
	if ($result)
	{
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["libelle"];
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_date_remise($id,$id_etat)
{
    $connexion=ma_db_connexion();
    if ($id_etat=="1")
    {
        $sql = "SELECT max(`date_rappel`) max_date_rappel FROM  `new_intevention_incident`	
		WHERE  `id_incident`= '".mysqli_real_escape_string($connexion,$id)."'";
        mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
        $result=mysqli_query($connexion,$sql);
        if (!$result)
        {
            error_log("Erreur SQL 930: ".$sql."  ".mysqli_error($connexion));
            die('ERREUR QUERY 930 !');
        }
        if ($result)
        {
            if(mysqli_num_rows($result)>0)
            {
                while ($row = mysqli_fetch_assoc($result))
                {
                    return $row["max_date_rappel"];
                }
			}	
            else
			{
				return '<span class="fa fa-minus" aria-hidden="true"></span>';
			}
            mysqli_free_result($result);
        }
    }
	else
	{
	    return '<span class="fa fa-minus" aria-hidden="true"></span>';
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_num_affectation($id,$num_affectation)
{
	if ($num_affectation==""){$num_affectation="----";}	
	echo '<span  onclick="get_update_num_affectation(\''.$id.'\',\''.$num_affectation.'\')"><a>'.$num_affectation.'</a></span>';
}
/*******************************************************/
function getDetailIncident_declarer($idInc)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT * FROM new_incident_gab WHERE id_incident=  '".mysqli_real_escape_string($connexion,$idInc)."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 931: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 931 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    $row = mysqli_fetch_assoc($result);
		    return($row);
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/*******************************************************************************************************************************************/
function get_information_duree_sla()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_type`, `libelle`, `duree_sla`  FROM  `new_libelle_type_contact` ORDER BY `libelle` ASC";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 932: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 932 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            echo '<table style="font-size:9pt;font-weight:bold;"  class="table table-striped" style="font-size:11px;font-weight:bold;" >
		            <tr>
				        <th >SLA</th><th>Durée</th>			
			        </tr>';
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '	<tr><th>'.$row["libelle"].'</th>';
	            echo '<th>'.$row["duree_sla"].'</th></tr>';
            }
            echo '</table>';
        }
        else
		{
		    return "";
		}
        mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_duree__prendre_en_charge_iprc($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT  `id_incident`,  ";
    $sql=$sql ."TIMESTAMPDIFF(MINUTE ,  `date_prise_en_charge_contractuelle` , 
	`new_incident_gab`.`date_prise_en_charge` ) AS moyen,
    TIMESTAMPDIFF(DAY , DATE_FORMAT(`date_prise_en_charge_contractuelle`, '%Y-%m-%d') , DATE_FORMAT(`new_incident_gab`.`date_prise_en_charge`, '%Y-%m-%d') ) AS day
    FROM    `new_incident_gab` 
    WHERE   `id_incident` = '".mysqli_real_escape_string($connexion,$id)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 933: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 933 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			    while ($row = mysqli_fetch_assoc($result))
                {
                    return	($row["moyen"])-480*$row["day"]." mn";
                }
			}	
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function personne_a_contacter($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_appel`,`id_contact`, `date_appel`, `etat_appel` FROM   `new_appel_agence`  
	WHERE  `id_incident`= '".mysqli_real_escape_string($connexion,$id)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 934: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 934 !');
    }
	if ($result)
	{	
	    if(mysqli_num_rows($result)>0)
	    {
			echo '<tr><th colspan=4 style="font-size:18px;font-weight:bold;text-align: center;color: #fff;background-color:#e98731;">Personne à contacté</th></tr>';	
			echo '<tr><th>Nom / Prénom</th><th>Date appel</th><th>Etat </th></tr>';	
			while ($row = mysqli_fetch_assoc($result)) 
            {
                echo '<tr>
				    <th>'.get_nom_contact2($row["id_contact"]).'</th>
					<th><div id="div_date_charge_appel_contact'.$row["id_appel"].'">';
					echo get_date_prise_charge_appel_contact($row["id_appel"],$row["date_appel"]);echo' </div></th>
					<th><div id="id_etat_appel'.$row["id_appel"].'">';
					echo get_libelle_etat_appel1($row["id_appel"],$row["etat_appel"]);
					echo '</div></th>
				</tr>';
            }
	    }
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_return_type_gab2($id_gab)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `libelle`, `id_strategiques` FROM  `new_libelle_strategiques`,  `new_list_gab`
    WHERE  	`new_list_gab`.`id_strategiques`=`new_libelle_strategiques`.`id_strategique` AND	
	`new_list_gab`.`terminal` like '".mysqli_real_escape_string($connexion,$id_gab)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 935: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 935 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return '<span  onclick="get_update_type_gab2(\''.$id_gab.'\',\''.$row["id_strategiques"].'\')"><a>'.$row["libelle"].'</a></span>';
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
	mysqli_close($connexion);
}		
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_reverifier_contact($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `appelagence` FROM  `new_incident_gab`   
	WHERE  `new_incident_gab`.`id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 936: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 936 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
                while ($row = mysqli_fetch_assoc($result))
                {
                    if ($row["appelagence"]==1)
                    {
                        return '<span class="glyphicon glyphicon-eye-open" aria-hidden="true" onclick="get_update_reverifier_contact(\''.$id.'\',\''.$row["appelagence"].'\')"></span>';
                    }
                    else
                    {
                        return '<span class="glyphicon glyphicon-eye-close" aria-hidden="true" onclick="get_update_reverifier_contact(\''.$id.'\',\''.$row["appelagence"].'\')"></span>';
                    }
                }
			}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_return_fornisseur_terminal($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`new_list_fournisseur`.`id_fournisseur` as id_frss,	`nom_fournisseur`,	`gsm_fournisseur` 
	FROM  `new_list_fournisseur`, `new_list_gab`
	WHERE `new_list_gab`.`id_fournisseur`=`new_list_fournisseur`.`id_fournisseur`
	AND	`new_list_gab`.`terminal` like  '".mysqli_real_escape_string($connexion,$id)."'";

	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 937: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 937 !');
    }
	if ($result)
	{	
	    if(mysqli_num_rows($result)>0)
	    {
	        while ($row = mysqli_fetch_assoc($result))
            {
                if ($row["gsm_fournisseur"]=="")
                {
                    return $row["nom_fournisseur"];
                }
                else
                {
                    return $row["nom_fournisseur"].' / '.$row["gsm_fournisseur"];
                }
            }
	    }
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_information_nom_banque_agence_gab($id_gab)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT   `nom_filiale`     FROM `new_list_gab`, `new_filiale` 
    WHERE 	`new_list_gab`.`code_bank`=`new_filiale`.`id_filiale`	AND	`new_list_gab`.`terminal`  like   '".mysqli_real_escape_string($connexion,$id_gab)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 938: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 938 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                $direction =  $row["nom_filiale"];
            }
            return  (strtoupper($direction));
		}
		else
			{
				return "";
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_gab_type_terminal_abi($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `nom_fournisseur` FROM  `new_list_fournisseur`,  `new_list_gab`  
    WHERE  	`new_list_gab`.`id_fournisseur`=`new_list_fournisseur`.`id_fournisseur` AND	`new_list_gab`.`terminal` 
	like  '".mysqli_real_escape_string($connexion,$id)."' ";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 939: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 939 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["nom_fournisseur"];
            }
		}
		else
		    {
				return "";
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_return_nom_agence_gab($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`new_list_agence`.`code_agence` AS cd_ag, `new_list_agence`.`nom_agence` `nom_agence` FROM  `new_list_gab`, `new_list_agence`
	WHERE  `new_list_gab`.`code_agence`=`new_list_agence`.`code_agence`		AND	`new_list_gab`.`terminal`
	like  '".mysqli_real_escape_string($connexion,$id)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 940: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 940 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["nom_agence"];  	
					}
			}	
		else
			{
				return "";
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_return_id_agence_gab($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`new_list_agence`.`code_agence` AS cd_ag  FROM  `new_list_gab`,  `new_list_agence`
		WHERE 	`new_list_gab`.`code_agence`=`new_list_agence`.`code_agence` AND `new_list_gab`.`terminal` 
		like  '".mysqli_real_escape_string($connexion,$id)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 941: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 941 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["cd_ag"];  	
					}
			}	
		else
			{
				return "";
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getNumSerie($id,$serie)
{
	if ($serie==""){$serie="----";}	
	echo '<span  onclick="getupdateNumSerie(\''.$id.'\',\''.$serie.'\')"><a>'.$serie.'</a></span>';
}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_adresse_ip2($id,$adresse_ip)
{
	if ($adresse_ip==""){$adresse_ip="----";}	
	echo '<span  onclick="get_update_adresse_ip(\''.$id.'\',\''.$adresse_ip.'\')"><a>'.$adresse_ip.'</a></span>';
}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_nom_gab($id,$nom_gab)
{
	if ($nom_gab==""){$nom_gab="----";}	
	echo '<span  onclick="get_update_nom_gab(\''.$id.'\',\''.$nom_gab.'\')"><a>'.$nom_gab.'</a></span>';
}
/////////////////////////////////////////////////////////////
function get_update_nom_gab($id,$nom_gab)
{
	
echo '<input size="10"  align="center" 	onChange="javascript:modifier_nom_gab2(\''.$id.'\')" id="nom_gab'.$id.'"  name="nom_gab'.$id.'" type="text"   
	value="'.$nom_gab.'"  class="form-control input-sm">';
	 echo '<a onClick="javascript:get_annuler_update_nom_gab2(\''.$id.'\',\''.$nom_gab.'\')" > <span class="fa fa-times" aria-hidden="true"></span>Annuler </a>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_array_information_agence_gab($id_gab)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT   `libelle_agence`, `ville` , `code_agence`     FROM `new_list_gab`  
	WHERE trim(`new_list_gab`.`terminal`)  like  '".mysqli_real_escape_string($connexion,$id_gab)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 942: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 942 !');
    }
    if ($result)
	{
	    $i=0;
		if(mysqli_num_rows($result)>0)
		{
			 while ($row = mysqli_fetch_assoc($result)) 
             {
                 $cd_agc[$i] = $row["code_agence"];
                 $nom_agence[$i] = $row["libelle_agence"];
                 $ville[$i] = $row["ville"];
                 $i++;
             }
             return  array($cd_agc[0], $nom_agence[0], $ville[0]);
		}
		else
		{
		    return  array("", "", "");
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_categories_arret($id_action)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_categories`  FROM `new_action_intervention`	
	WHERE 	`new_action_intervention`.`id_intevention`  =   '".mysqli_real_escape_string($connexion,$id_action)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 943: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 943 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                return $row["id_categories"];
            }
		}
		else
		{
		    return 7;
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getEtatFacturation($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_facturations` FROM `new_action_intervention`
	WHERE `id_intevention`  =   '".mysqli_real_escape_string($connexion,$id)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 944: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 944 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                return $row["id_facturations"];
            }

		}
		else
			{
				return  0;
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_etat_strategique($terminal)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_strategiques` FROM `new_list_gab` 	WHERE 	`terminal`   LIKE '".mysqli_real_escape_string($connexion,$terminal)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 945: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 945 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["id_strategiques"];
            }
		}
		else
			{
				return 0;
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_etat_activation($terminal)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_activation` FROM `new_list_gab` 		WHERE 	`terminal`   LIKE '".mysqli_real_escape_string($connexion,$terminal)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 946: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 946 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["id_activation"];
            }
		}
		else
			{
				return 0;
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_code_fournisseur($terminal)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_fournisseur` FROM `new_list_gab` WHERE 	`terminal`   = '".mysqli_real_escape_string($connexion,$terminal)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 947: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 947 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["id_fournisseur"];  	
					}
			}	
		else
			{
				return 0;
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
function get_code_prestataire($terminal)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_prestataire` FROM `new_list_gab` WHERE 	`terminal`   = '".mysqli_real_escape_string($connexion,$terminal)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 948: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 948 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["id_prestataire"];
            }
		}
		else
		{
		    return 0;
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_region($terminal)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_direction` FROM `new_list_gab`, `new_list_agence`
    WHERE   `new_list_agence`.`code_agence` =  `new_list_gab`.`code_agence`
    AND     `new_list_gab`.`terminal` = '".mysqli_real_escape_string($connexion,$terminal)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 949: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 949 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["id_direction"];
            }
		}
		else
			{
				return 0;
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
	//////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_agence($terminal)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `code_agence` FROM `new_list_gab` WHERE  `new_list_gab`.`terminal` = '".mysqli_real_escape_string($connexion,$terminal)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 950: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 950 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["code_agence"];  	
					}
			}	
		else
			{
					return 0;
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
	//////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_banque($terminal)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `code_bank` FROM `new_list_gab` 
	WHERE  `new_list_gab`.`terminal` = '".mysqli_real_escape_string($connexion,$terminal)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 951: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 951 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["code_bank"];
            }
		}
		else
			{
				return "";
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////
function get_date_prise_charge_contractuel($date_arret)
{
	 list($d, $h) = explode(' ', $date_arret);
	 
	 list($hh, $mm, $ss) = explode(':', $h);
	 list($yy, $mn, $dy) = explode('-', $d);
	 
	 $date2=date("Y-m-d  23:00:00", mktime(23, 00, 00,$mn,$dy-1,$yy));	 
	 $date3=date("Y-m-d  23:59:59", mktime(23, 59, 59,$mn,$dy-1,$yy));
	 
	 $date4=date("Y-m-d  00:00:00", mktime(00, 00, 00,$mn,$dy,$yy));
	 $date5=date("Y-m-d  07:00:00", mktime(7, 00, 00,$mn,$dy,$yy));
	 
	 $date6=date("Y-m-d  07:00:00", mktime(7, 00, 00,$mn,$dy+1,$yy));	

	 $date7=date("Y-m-d  23:00:00", mktime(23, 00, 00,$mn,$dy,$yy));	
	 $date8=date("Y-m-d  23:59:59", mktime(23, 59, 59,$mn,$dy,$yy));
	 
	if((strtotime($date2) < strtotime($date_arret)) && (strtotime($date_arret) < strtotime($date3))) 
	  {
		  return $date6;
	  }	 
    else if((strtotime($date4) < strtotime($date_arret)) && (strtotime($date_arret) < strtotime($date5))) 
	  {
		  return $date5;
	  }	 
    else if ((strtotime($date7) < strtotime($date_arret))  && (strtotime($date_arret) < strtotime($date8)))  
	  {
		  return $date6;
	  }		  
    else if ((strtotime($date5) <= strtotime($date_arret))  && (strtotime($date_arret) <= strtotime($date7)))  
	  {
		  return $date_arret;
	  }			
}
/*******************************************************************************************************************************************/

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_affiche_dans_rapport_technique($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `affiche_rapport_technique` FROM `new_action_intervention` 
	WHERE `id_intevention`	 = '".mysqli_real_escape_string($connexion,$id)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 952: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 952 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["affiche_rapport_technique"];
            }
		}
		else
			{
				return 0;
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_niveau_intervention_fonctionnelle($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `degre`  FROM  `new_action_intervention` WHERE `degre`=1 
	and	`new_action_intervention`.`id_intevention`  =  '".mysqli_real_escape_string($connexion,$id)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 953: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 953 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["degre"];  	
					}
			}	
		else
			{
				return 0;
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}	
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_array_idcategorie($id_action)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_categories`,`degre`  FROM `new_action_intervention`
	WHERE 	`new_action_intervention`.`id_intevention`  =  '".mysqli_real_escape_string($connexion,$id_action)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 954: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 954 !');
    }
    if ($result)
    {
        if (mysqli_num_rows($result)>0)
        {
            $i=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                if ($row["degre"]==1)
                {
                    $categorie_fonctionnelle[$i] =$row["id_categories"];
                    $categorie_technique[$i] = 0;
                }
                else
                {
                    $categorie_fonctionnelle[$i] = 0;
                    $categorie_technique[$i] = $row["id_categories"];
                }
                $i++;
            }

            return  array($categorie_fonctionnelle[0], $categorie_technique[0]);
        }
        else
        {
            return  array(0, 0);
        }
        mysqli_free_result($result);
    }

    mysqli_close($connexion);
}
	 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_array_type_arret($id_action)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT  `type_arret`,`degre`  FROM `new_action_intervention` 
	WHERE 	`new_action_intervention`.`id_intevention`  ='".mysqli_real_escape_string($connexion,$id_action)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 955: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 955 !');
    }
    if ($result)
    {
        if (mysqli_num_rows($result)>0)
        {
            $i=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                if ($row["degre"]==1)
                {
                    $type_arret_fonctionnelle[$i] = $row["type_arret"];
                    $type_arret_technique[$i] = 0;
                }
                else
                {
                    $type_arret_fonctionnelle[$i] = 0;
                    $type_arret_technique[$i] = $row["type_arret"];
                }
                $i++;
            }
            mysqli_free_result($result);
            return  array($type_arret_fonctionnelle[0], $type_arret_technique[0]);
        }
        else
        {
            mysqli_free_result($result);
            return  array(0, 0);
        }
    }
    mysqli_close($connexion);
}
	/*******************************************************************************************************************************************/
function controlIncidentsImbriques($idGab,$dateArret)
{
    $connexion=ma_db_connexion();
	list($annee,$mois,$rest)=explode('-',$dateArret);
	$dateNew=$annee."-".$mois;
    $result="";
    $sql="SELECT * FROM new_incident_gab WHERE id_gab like '".mysqli_real_escape_string($connexion,$idGab)."' 
	
	AND (DATE_FORMAT( `date_arrete` , '%Y-%m' )='".mysqli_real_escape_string($connexion,$dateNew)."' OR DATE_FORMAT( `date_remise` , '%Y-%m' )='".mysqli_real_escape_string($connexion,$dateNew)."')";
 
    $selectIncident=mysqli_query($connexion,$sql);
    if (!$selectIncident)
    {
        error_log("Erreur SQL 956: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 956 !');
    }
    if ($selectIncident)
    {
        if( mysqli_num_rows($selectIncident) > 0)
        {
            while ($donnLastInc= mysqli_fetch_assoc($selectIncident))
            {
                $incident = $donnLastInc["id_incident"];
                $dateARRETInci = $donnLastInc["date_arrete"];
                $dateREMISEInci = $donnLastInc["date_remise"];
                // echo "incident: ".$incident."  dateARRETInci:".$dateARRETInci."   dateREMISEInci:".$dateREMISEInci."<br>";
                if (strtotime($dateArret)<=strtotime($dateARRETInci) OR (strtotime($dateArret)>strtotime($dateARRETInci) AND strtotime($dateArret)<strtotime($dateREMISEInci)))
                {
                    $result="OUI";
                    break;
                }
                else
                {
                    $result="";
                }
            }
            // echo "result:".$result;
        }
        else
        {

            $result="";
        }
        mysqli_free_result($selectIncident);
    }
    mysqli_close($connexion);
	return $result;
}
/*******************************************************************************************************************************************/
function control_date_arret_same_values_last_Inci($terminal,$dateArret)
{
    $connexion=ma_db_connexion();
    $result="";
    $dateARRETLast="";
    $sql="SELECT date_arrete FROM new_incident_gab 
	WHERE id_gab like '".mysqli_real_escape_string($connexion,$terminal)."'
	ORDER BY  `new_incident_gab`.`id_incident` DESC LIMIT 1  ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $selectIncident=mysqli_query($connexion,$sql);
    if (!$selectIncident)
    {
        error_log("Erreur SQL 957: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 957 !');
    }
    if($selectIncident)
    {
        if( mysqli_num_rows($selectIncident) > 0)
        {
            while ($donnLastInc= mysqli_fetch_assoc($selectIncident))
            {
                $dateARRETLast = $donnLastInc["date_arrete"];
            }
            mysqli_free_result($selectIncident);
            if ($dateArret == $dateARRETLast)
            {
                $result= "OUI";
            }
            else
            {
                $result="";
            }
        }
        else
        {
            mysqli_free_result($selectIncident);
            $result="";
        }
    }
    mysqli_close($connexion);
    return $result;
}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_niveau_intervention($lebelle)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`id_niveau` FROM  `new_degre_intervention`
	WHERE 	`new_degre_intervention`.`Libelle` like '".mysqli_real_escape_string($connexion,$lebelle)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 958: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 958 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["id_niveau"];
            }
		}
		else
			{
				return "";
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}		
	
function get_date_indident_declaration($date_rappel,$dateactuel,$niveau_intervention)
{
/*
	if(((($date_rappel)=="JO7") && (($niveau_intervention=="2") )) || ((($date_rappel)=="JO7") && (($niveau_intervention=="3") )))
		{
			return date('Y-m-d 09:00:00',getNextJOAGENCE($dateactuel) );
		}

	else if(((($date_rappel)=="JO12") && (($niveau_intervention=="2") )) || ((($date_rappel)=="JO12") && (($niveau_intervention=="3") )))
		{
			return date('Y-m-d 12:00:00',getNextJOAGENCE( $dateactuel) );
		} 
	else if((($date_rappel)=="JO7") &&  (($niveau_intervention=="1") ))
		{
			return date('Y-m-d 09:00:00',getNextJO( $dateactuel) );
		} 
	else if((($date_rappel)=="JO12") && (($niveau_intervention=="1")))
		{
			return date('Y-m-d 12:00:00',getNextJO( $dateactuel) );
		} 
		else
		{
			return $dateactuel;
		}
		
		*/
					return $dateactuel;
}
	//////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_tp_intervention_fornisseur($intervention)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `type_arret` FROM `new_action_intervention` WHERE `degre`<>1 
	AND `id_intevention` = '".mysqli_real_escape_string($connexion,$intervention)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 959: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 959 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["type_arret"];
            }
		}
		else
		{
		    return 0;
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_categorie_intervention_fornisseur($intervention)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_categories` FROM `new_action_intervention` WHERE `degre`<>1 
	AND `id_intevention` = '".mysqli_real_escape_string($connexion,$intervention)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 960: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 960 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["id_categories"];
            }
		}
		else
		{
		    return 0;
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_tp_intervention_prestataire($intervention)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `type_arret` FROM `new_action_intervention` 
    WHERE `degre`=1 AND `id_intevention` = '".mysqli_real_escape_string($connexion,$intervention)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 961: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 961 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["type_arret"];
            }
		}
		else
			{
				return 0;
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_derniere_date_rappel_intervention_incident($id_incident,$date_rappel,$remarque_pres,$remarque_frss,$date_declaration,$id_action_interv)
{
    $connexion=ma_db_connexion();
    if (get_niveau_intervention_fonctionnelle($id_action_interv)==0){$inter=0;}else{$inter=$id_action_interv;}
    if (get_niveau_intervention_technique($id_action_interv)==0){$inter_t=0;}else{$inter_t=$id_action_interv;}
    $SQL1="UPDATE `new_incident_gab` SET 
    `date_derniere_interv`='".$date_declaration."',
    `date_derniere_rappel`='".($date_rappel)."' ,
    `id_indisponibilite` =  '".get_etat_disponibilite_intervention($id_action_interv)."', 					   
    `date_remise`='0000-00-00 00:00:00' ,
    `cd_arret_technique` =  '".get_id_tp_intervention_fornisseur($id_action_interv)."',
    `id_categories_technique` =  '".get_id_categorie_intervention_fornisseur($id_action_interv)."',
    `id_action_technique` =  '".$inter_t."',
    `id_niveau_technique` =  '".get_niveau_intervention_technique($id_action_interv)."',
    `cd_arret_fonctionnelle` =  '".get_id_tp_intervention_prestataire($id_action_interv)."',
    `id_categories_fonctionnelle` =  '".get_id_categorie_intervention_prestataire($id_action_interv)."',
    `id_action_fonctionelle` =  '".$inter."',
    `id_niveau_fonctionelle` =  '".get_niveau_intervention_fonctionnelle($id_action_interv)."',	 
    `etat_incident`='0' WHERE  `id_incident`=  '$id_incident'";

    $result1=mysqli_query($connexion,$SQL1);
    if (!$result1)
    {
        error_log("Erreur SQL 962: ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 962 !');
    }

    $SQL2="UPDATE `new_incident_gab_ouvert` SET 
    `date_derniere_interv`='".$date_declaration."',
    `date_derniere_rappel`='".($date_rappel)."' ,
    `id_indisponibilite` =  '".get_etat_disponibilite_intervention($id_action_interv)."', 					   
    `date_remise`='0000-00-00 00:00:00' ,
    `cd_arret_technique` =  '".get_id_tp_intervention_fornisseur($id_action_interv)."',
    `id_categories_technique` =  '".get_id_categorie_intervention_fornisseur($id_action_interv)."',
    `id_action_technique` =  '".$inter_t."',
    `id_niveau_technique` =  '".get_niveau_intervention_technique($id_action_interv)."',
    `cd_arret_fonctionnelle` =  '".get_id_tp_intervention_prestataire($id_action_interv)."',
    `id_categories_fonctionnelle` =  '".get_id_categorie_intervention_prestataire($id_action_interv)."',
    `id_action_fonctionelle` =  '".$inter."',
    `id_niveau_fonctionelle` =  '".get_niveau_intervention_fonctionnelle($id_action_interv)."',	 
    `etat_incident`='0' WHERE  `id_incident`=  '$id_incident'";

    $result2=mysqli_query($connexion,$SQL2);
    if (!$result2)
    {
        error_log("Erreur SQL 963: ".$SQL2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 963 !');
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_type_arret_fournisseur($id_incident,$intervention)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_incident` FROM `new_incident_gab`
    WHERE  `id_incident` ='".mysqli_real_escape_string($connexion,$id_incident)."' AND id_action_technique=0";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 964: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 964 !');
    }
    if ($result)
	{	
	    if(mysqli_num_rows($result)>0)
	    {
	        if (get_niveau_intervention_technique($intervention)==0){$inter=0;}else{$inter=$intervention;}
	        $sql2 = "UPDATE  `new_incident_gab` 
			SET  `cd_arret_technique` =  '".mysqli_real_escape_string($connexion,get_id_tp_intervention_fornisseur($intervention))."',
			`id_action_technique` =  '".mysqli_real_escape_string($connexion,$inter)."',
			`id_indisponibilite` =  '".mysqli_real_escape_string($connexion,get_etat_disponibilite_intervention($intervention))."', 
			`id_niveau_technique` =  '".mysqli_real_escape_string($connexion,get_niveau_intervention_technique($intervention))."'
			WHERE  `id_incident` ='".mysqli_real_escape_string($connexion,$id_incident)."' ";
            $result2=mysqli_query($connexion,$sql2);
            if (!$result2)
            {
                error_log("Erreur SQL 965: ".$sql2."  ".mysqli_error($connexion));
                die('ERREUR QUERY 965 !');
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            if (get_niveau_intervention_technique($intervention)==0){$inter=0;}else{$inter=$intervention;}
            $sql2O = "UPDATE  `new_incident_gab_ouvert` 
            SET  `cd_arret_technique` =  '".mysqli_real_escape_string($connexion,get_id_tp_intervention_fornisseur($intervention))."',
            `id_action_technique` =  '".mysqli_real_escape_string($connexion,$inter)."',
            `id_indisponibilite` =  '".mysqli_real_escape_string($connexion,get_etat_disponibilite_intervention($intervention))."', 
            `id_niveau_technique` =  '".mysqli_real_escape_string($connexion,get_niveau_intervention_technique($intervention))."'
            WHERE  `id_incident` ='".mysqli_real_escape_string($connexion,$id_incident)."' ";
            $result20=mysqli_query($connexion,$sql2O);
            if (!$result20)
            {
                error_log("Erreur SQL 966: ".$sql2O."  ".mysqli_error($connexion));
                die('ERREUR QUERY 966 !');
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            $sql2Douteux = "UPDATE  `new_incident_gab_douteux` 
            SET  `cd_arret_technique` =  '".mysqli_real_escape_string($connexion,get_id_tp_intervention_fornisseur($intervention))."',
            `id_action_technique` =  '".mysqli_real_escape_string($connexion,$inter)."',
            `id_indisponibilite` =  '".mysqli_real_escape_string($connexion,get_etat_disponibilite_intervention($intervention))."', 
            `id_niveau_technique` =  '".mysqli_real_escape_string($connexion,get_niveau_intervention_technique($intervention))."'
            WHERE  `id_incident` ='".mysqli_real_escape_string($connexion,$id_incident)."' ";
            $result2Douteux=mysqli_query($connexion,$sql2Douteux);
            if (!$result2Douteux)
            {
                error_log("Erreur SQL 967: ".$sql2Douteux."  ".mysqli_error($connexion));
                die('ERREUR QUERY 967 !');
            }
	    }
	    mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_type_arret_prestataire($id_incident,$intervention)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_incident` FROM `new_incident_gab`
	WHERE  `id_incident` ='".mysqli_real_escape_string($connexion,$id_incident)."' 
	AND id_action_fonctionelle=0";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 968: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 968 !');
    }
    if ($result)
	{	
	    if(mysqli_num_rows($result)>0)
	    {
            if (get_niveau_intervention_fonctionnelle($intervention)==0){$inter=0;}else{$inter=$intervention;}
            $sql2 = "UPDATE  `new_incident_gab` 
            SET  `cd_arret_fonctionnelle` =  '".get_id_tp_intervention_prestataire($intervention)."',
            `id_categories_fonctionnelle` =  '".get_id_categorie_intervention_prestataire($intervention)."',
            `id_action_fonctionelle` =  '".$inter."',
            `id_indisponibilite` =  '".get_etat_disponibilite_intervention($intervention)."', 
            `id_niveau_fonctionelle` =  '".get_niveau_intervention_fonctionnelle($intervention)."'
            WHERE  `id_incident` ='".$id_incident."' ";
            $result2=mysqli_query($connexion,$sql2);
            if (!$result2)
            {
                error_log("Erreur SQL 969: ".$sql2."  ".mysqli_error($connexion));
                die('ERREUR QUERY 969 !');
            }


            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            $sql2Ouv = "UPDATE  `new_incident_gab_ouvert` 
            SET  `cd_arret_fonctionnelle` =  '".mysqli_real_escape_string($connexion,get_id_tp_intervention_prestataire($intervention))."',
            `id_categories_fonctionnelle` =  '".mysqli_real_escape_string($connexion,get_id_categorie_intervention_prestataire($intervention))."',
            `id_action_fonctionelle` =  '".mysqli_real_escape_string($connexion,$inter)."',
            `id_indisponibilite` =  '".mysqli_real_escape_string($connexion,get_etat_disponibilite_intervention($intervention))."', 
            `id_niveau_fonctionelle` =  '".mysqli_real_escape_string($connexion,get_niveau_intervention_fonctionnelle($intervention))."'
            WHERE  `id_incident` ='".mysqli_real_escape_string($connexion,$id_incident)."' ";
            $result2Ouv=mysqli_query($connexion,$sql2Ouv);
            if (!$result2Ouv)
            {
                error_log("Erreur SQL 970: ".$sql2Ouv."  ".mysqli_error($connexion));
                die('ERREUR QUERY 970 !');
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            $sql2ODouteux = "UPDATE  `new_incident_gab_douteux` 
            SET  `cd_arret_fonctionnelle` =  '".mysqli_real_escape_string($connexion,get_id_tp_intervention_prestataire($intervention))."',
            `id_categories_fonctionnelle` =  '".mysqli_real_escape_string($connexion,get_id_categorie_intervention_prestataire($intervention))."',
            `id_action_fonctionelle` =  '".mysqli_real_escape_string($connexion,$inter)."',
            `id_indisponibilite` =  '".mysqli_real_escape_string($connexion,get_etat_disponibilite_intervention($intervention))."', 
            `id_niveau_fonctionelle` =  '".mysqli_real_escape_string($connexion,get_niveau_intervention_fonctionnelle($intervention))."'
            WHERE  `id_incident` ='".mysqli_real_escape_string($connexion,$id_incident)."' ";
            $result2Douteux=mysqli_query($connexion,$sql2ODouteux);
            if (!$result2Douteux)
            {
                error_log("Erreur SQL 971: ".$sql2ODouteux."  ".mysqli_error($connexion));
                die('ERREUR QUERY 971 !');
            }
	    }
	    mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function return_degre_intervention($degre_intervention,$niveau_intervention)
{
    if (($degre_intervention=="1") && ($niveau_intervention=="1")){ return "2";}
    if (($degre_intervention=="2") && ($niveau_intervention=="1")){ return "2";}
    if (($degre_intervention=="3") && ($niveau_intervention=="1")){ return "2";}
    if (($degre_intervention=="4") && ($niveau_intervention=="1")){ return "2";}
    if (($degre_intervention=="2") && ($niveau_intervention=="2")){ return "3";}
    if (($degre_intervention=="3") && ($niveau_intervention=="2")){ return "4";}
    if (($degre_intervention=="4") && ($niveau_intervention=="2")){ return "4";}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/***********************************************************************************/
function get_heure_jour_ouvrable($id)
{
    $connexion=ma_db_connexion();
    $terminal=7;
    $sql = "SELECT `heure_rappel`  FROM  `new_libelle_type_contact`	WHERE `id_type` =  '".mysqli_real_escape_string($connexion,$id)."'";
    $res=mysqli_query($connexion,$sql);
    if (!$res)
    {
        error_log("Erreur SQL 972: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 972 !');
    }
    if ($res)
	{	
		if(mysqli_num_rows($res)>0)
		{
			while ($row = mysqli_fetch_assoc($res)) 
            {
                $terminal=$row["heure_rappel"];
            }
		}
		else
		{
		    $terminal= 7;
		}
		mysqli_free_result($res);
	}
    mysqli_close($connexion);
    return $terminal;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function ajouter_rappel_gab($type_contact,$id_incident,$date_rappel,$id_action_interv,$remarque,$note,$niveau_inter,$date_declaration,$persone_avise,$id_affectation,$id_degre,$id_etat)
{
    $connexion=ma_db_connexion();
    /****Recuperer id gab***/
    $recup = "SELECT id_gab FROM new_incident_gab 
	WHERE id_incident= '".mysqli_real_escape_string($connexion,$id_incident)."'";
    // $res=mysql_fetch_assoc($recup);
    // $terminal=$res["id_gab"];

    $res=mysqli_query($connexion,$recup);
    if (!$res)
    {
        error_log("Erreur SQL 973: ".$recup."  ".mysqli_error($connexion));
        die('ERREUR QUERY 973 !');
    }
    if ($res)
	{	
		if(mysqli_num_rows($res)>0)
		{
			while ($row = mysqli_fetch_assoc($res)) 
            {
                $terminal=$row["id_gab"];
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($res);
	}

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    session_start();
    if(get_return_array_degre_inertvention($id_action_interv)<>"1")
    {
        $remarque_frss=$remarque;
    }
    else
	{
	    $remarque_pres=$remarque;
	}

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    $sql="SELECT max(nbr_tentative) as nbr_tentative,max(degre_intervention) as degre_intervention, max(nbr_escalade) as nbr_escalade
    FROM new_intevention_incident
    where `id_incident` = '".mysqli_real_escape_string($connexion,$id_incident)."' AND `degre_appel` = '".mysqli_real_escape_string($connexion,$id_degre)."' ";

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 974: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 974 !');
    }
    if($result)
    {
        if (mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                $degre_action_intervention=return_degre_intervention($row["degre_intervention"],get_return_array_degre_inertvention($id_action_interv));
                $cmd2="INSERT INTO  `new_intevention_incident` 
                (`id_action_interv`, `id_incident`,`id_gab`, `date_action`, `date_prise_en_charge`, `type_contact`, `personne_avisee`, `id_action_intervention`, `id_categories`, `id_niveau_intervention`,
				`date_rappel`, `nbr_tentative`, `nbr_escalade`, `id_utilisateur`, `etat_cloture`, `remarque`, `note`, `degre_intervention`, `id_affectation`, `degre_appel`, `etat_contact`)
                VALUES  ( NULL, '".mysqli_real_escape_string($connexion,$id_incident)."','".mysqli_real_escape_string($connexion,$terminal)."', 
				'".mysqli_real_escape_string($connexion,$date_declaration)."',  '".mysqli_real_escape_string($connexion,$date_declaration)."','".mysqli_real_escape_string($connexion,$type_contact)."',
				'".mysqli_real_escape_string($connexion,addslashes($persone_avise))."', '".mysqli_real_escape_string($connexion,$id_action_interv)."',
				'".mysqli_real_escape_string($connexion,get_categories_arret($id_action_interv))."', 
				'".mysqli_real_escape_string($connexion,get_return_array_degre_inertvention($id_action_interv))."',
				'".mysqli_real_escape_string($connexion,$date_rappel)."','".($row["nbr_tentative"]+1)."',
				'".($row["nbr_escalade"]+1)."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."','0','',
				'".mysqli_real_escape_string($connexion,$note)."', '".mysqli_real_escape_string($connexion,$degre_action_intervention)."',  '".mysqli_real_escape_string($connexion,$id_affectation)."', 
				'".mysqli_real_escape_string($connexion,$id_degre)."', '".mysqli_real_escape_string($connexion,$id_etat)."')";

                $result2=mysqli_query($connexion,$cmd2);
                if (!$result2)
                {
                    error_log("Erreur SQL 975: ".$cmd2."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 975 !');
                }

                ////////////////////////////////////

				$last_id_interv = MaxIdIncident('id_action_interv','new_intevention_incident');
				
				$cmd2temp="INSERT INTO  `new_intevention_incident_tmp` 
                (`id_action_interv`, `id_incident`,`id_gab`, `date_action`, `date_prise_en_charge`, `type_contact`, `personne_avisee`, `id_action_intervention`, `id_categories`, `id_niveau_intervention`, 
				`date_rappel`, `nbr_tentative`, `nbr_escalade`, `id_utilisateur`, `etat_cloture`, `remarque`, `note`, `degre_intervention`, `id_affectation`, `degre_appel`, `etat_contact`)
                VALUES  ('".mysqli_real_escape_string($connexion,$last_id_interv)."', '".mysqli_real_escape_string($connexion,$id_incident)."','".mysqli_real_escape_string($connexion,$terminal)."',
				'".mysqli_real_escape_string($connexion,$date_declaration)."',  '".mysqli_real_escape_string($connexion,$date_declaration)."','".mysqli_real_escape_string($connexion,$type_contact)."',
				'".mysqli_real_escape_string($connexion,addslashes($persone_avise))."', '".mysqli_real_escape_string($connexion,$id_action_interv)."',
				'".mysqli_real_escape_string($connexion,get_categories_arret($id_action_interv))."', 
				'".mysqli_real_escape_string($connexion,get_return_array_degre_inertvention($id_action_interv))."',  
				'".mysqli_real_escape_string($connexion,$date_rappel)."','".($row["nbr_tentative"]+1)."',
				'".($row["nbr_escalade"]+1)."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."','0', '',
				'".mysqli_real_escape_string($connexion,$note)."', '".mysqli_real_escape_string($connexion,$degre_action_intervention)."',  '".mysqli_real_escape_string($connexion,$id_affectation)."',
				'".mysqli_real_escape_string($connexion,$id_degre)."', '".mysqli_real_escape_string($connexion,$id_etat)."')";
                $result2tmp=mysqli_query($connexion,$cmd2temp);
                if (!$result2tmp)
                {
                    error_log("Erreur SQL 976: ".$cmd2temp."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 976 !');
                }

                ////////////////////////////////////

				$sql2 = "UPDATE  `new_intevention_incident`  SET   `date_rappel` =  '".mysqli_real_escape_string($connexion,$date_declaration)."'
				WHERE  `id_incident` ='".mysqli_real_escape_string($connexion,$id_incident)."' AND `nbr_tentative` = '".mysqli_real_escape_string($connexion,$row["nbr_tentative"])."'";
                $result2=mysqli_query($connexion,$sql2);
                if (!$result2)
                {
                    error_log("Erreur SQL 977: ".$sql2."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 977 !');
                }

                ////////////////////////////////////

                $sql2temp = "UPDATE  `new_intevention_incident_tmp`  SET   `date_rappel` =  '".mysqli_real_escape_string($connexion,$date_declaration)."'
				WHERE  `id_incident` ='".mysqli_real_escape_string($connexion,$id_incident)."' AND `nbr_tentative` = '".mysqli_real_escape_string($connexion,$row["nbr_tentative"])."'";
                $resulttemp=mysqli_query($connexion,$sql2temp);
                if (!$resulttemp)
                {
                    error_log("Erreur SQL 978: ".$sql2temp."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 978 !');
                }


                ////////////////////////////////////

                update_type_arret_prestataire($id_incident,$id_action_interv);
				update_type_arret_fournisseur($id_incident,$id_action_interv);				
				update_derniere_date_rappel_intervention_incident($id_incident,$date_rappel,$remarque_pres,$remarque_frss,$date_declaration,$id_action_interv);
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
function get_date_rappel2_declaration($date_rappel,$dateactuel,$niveau_intervention,$id_affecter)
{
// echo $date_rappel."=======================".$dateactuel."===========================".date_transaction($dateactuel)."<br>";
	if(((($date_rappel)=="JO7") && (($niveau_intervention=="2") )) || ((($date_rappel)=="JO7") && (($niveau_intervention=="3") )))
		{
			return date('Y-m-d 10:00:00',getNextJOAGENCE($dateactuel) );
		}

	else if(((($date_rappel)=="JO12") && (($niveau_intervention=="2") )) || ((($date_rappel)=="JO12") && (($niveau_intervention=="3") )))
		{
			return date('Y-m-d 12:00:00',getNextJOAGENCE( $dateactuel) );
		} 
	else if((($date_rappel)=="JO7") &&  (($niveau_intervention=="1") ))
		{
			return date('Y-m-d '.get_heure_jour_ouvrable($id_affecter).':00:00',getNextJO( $dateactuel) );
		} 
	else if((($date_rappel)=="JO12") && (($niveau_intervention=="1")))
		{
			return date('Y-m-d 12:00:00',getNextJO( $dateactuel) );
		} 
   else if((($date_rappel)=="86400") ||  (($date_rappel)=="172800") || (($date_rappel)=="259200") || (($date_rappel)=="345600"))
		{
			list($p1, $p2) = explode('  ',  date_transaction($dateactuel));
			list($yr, $mn, $dy) = explode('-', $p1);
			list($hh, $mm, $ss) = explode(':', $p2);		
			return date('Y-m-d  09:00:00',mktime($hh, $mm,$ss+$date_rappel, $mn,$dy,$yr));
			//return calcule_date_rappel(time('Y-m-d  H:i:s'),$date_rappel);
		}
		else
		{
			list($p1, $p2) = explode('  ',  date_transaction($dateactuel));
			list($yr, $mn, $dy) = explode('-', $p1);
			list($hh, $mm, $ss) = explode(':', $p2);		
			return date('Y-m-d  H:i:s',mktime($hh, $mm,$ss+$date_rappel, $mn,$dy,$yr));			
		}
}	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_niveau_intervention_incident($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `degre` FROM `new_action_intervention` WHERE `id_intevention` = '".mysqli_real_escape_string($connexion,$id)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 979: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 979 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["degre"];
            }
		}
		else
		{
		    return 1;
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/***************************************************************************/	
function get_verif_mail_gab_abi2($id_intevention,$terminal)
{
   // var_dump("id_intevention : ".$id_intevention);
    $connexion=ma_db_connexion();
    $sql = "SELECT `adresse_mail_aa`, `adresse_mail_cc`, `corps_messagerie` 
	FROM   `new_mail_action_intevention` ,`new_mail_messagerie` 
    WHERE   `new_mail_messagerie`.`id_mail`= `new_mail_action_intevention`.`id_mail`
    AND `new_mail_action_intevention`.`id_intevention`='".mysqli_real_escape_string($connexion,$id_intevention)."' 
    AND `niveau_messagenie`='APPEL'";

    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 980: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 980 !');
    }
    if ($result)
	{

		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                return  1;
            }
		}
		else
		{
		    return 0;
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/***************************************************************************/	
function get_etat_status_device($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `status`, `libelle` FROM  `list_status`  WHERE `status`= '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 981: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 981 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["libelle"];
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/***************************************************************************/	
function get_check_filiale($id)
{
    $connexion=ma_db_connexion();
	$sql = "SELECT `id_filiale` FROM `filiale_bcp` WHERE `id_filiale`= '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 982: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 982 !');
    }
    if ($result)
	{	
	    if(mysqli_num_rows($result)>0)
	    {
	        while ($row = mysqli_fetch_assoc($result))
            {
                return $row["id_filiale"];
            }
	    }
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/*******************************************************************************************************************************************/
function check_filiale($id_filiales,$id_filiale)
{
	// print_r($id_filiales);
    foreach($id_filiales as $filiale)
    {
        echo $filiale."<br>";
		if ($filiale==get_check_filiale($id_filiale)){ return 'checked="checked"';}else{return "";}
	}	
}
/*******************************************************************************************************************************************/
function getFilialesChehckBox3($array_filiale)
{
    $connexion=ma_db_connexion();
    $sql="SELECT id_filiale, nom_filiale FROM filiale_bcp";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 983: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 983 !');
    }
    if ($result)
	{
	    echo"<div class='checkbox'>
			  <label><input type='checkbox' name='id_filiale[]' value='tf'>Toutes les filiales</label>
	    </div>";
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                echo"<div class='checkbox'>
			        <label><input type='checkbox' name='id_filiale[]' value='".$row["id_filiale"]."'".check_filiale($array_filiale,$row["id_filiale"]).">".$row["nom_filiale"]."</label>
		        </div>";
            }
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/*******************************************************************************************************************************************/
function liste_gabs_hors_service2()
{

	$gabArret=list_arret_selon_BPR($_POST['id_filiale']);
	
	echo '
	    <div>
            <div class="jumbotron">
                <div class="container">
                  <h3><strong> Liste des GABs hors services :'; date_raff_arret($gabArret);  echo'</strong></h3>
                </div>
          </div>
      </div>
	  
	  
	  

       <div id="liste_intevention" class="row" style=" margin:0 8px 0 8px;" class="table-responsive">	   
			<div class="col-sm-12">
					<form class="form-inline" method="post" action="" role="form">
					
						<div class="form-group">
							<label>Selectionner filiale:</label>';
							 getFilialesChehckBox3($_POST['id_filiale']);
							echo'
							<button type="submit" style="vertical-align:middle" name="bbb">
								<span class="glyphicon glyphicon-refresh"></span>
							</button>
						</div>
					</form>	
						<div id="div_declarer1" class="table-responsive">';
						
							if (mysqli_num_rows($gabArret) > 0) {
							   
								  echo '<table class="table table-striped" style="font-size:11px;font-weight:bold;">';
								   echo ' <tr>'; 
										  echo ' <th style="font-size:10pt;color: #43231e;background-color: #e98731;">Déclarer</th>';
										  echo ' <th style="font-size:10pt;color: #43231e;background-color: #e98731;">Détail Arrêt</th>';   	
										  echo ' <th style="font-size:10pt;color: #43231e;background-color: #e98731;">Terminal</th>'; 
										  echo ' <th style="font-size:10pt;color: #43231e;background-color: #e98731;">Code Agence</th>';
										  echo ' <th style="font-size:10pt;color: #43231e;background-color: #e98731;">Code Banque</th>';  			  	  	  	
										  echo ' <th style="font-size:10pt;color: #43231e;background-color: #e98731;">Dernière Transaction</th>';	
										  echo ' <th style="font-size:10pt;color: #43231e;background-color: #e98731;">Dernier événement</th>';
										  echo ' <th style="font-size:10pt;color: #43231e;background-color: #e98731;">Date d\'arrêt</th>';    	
										  echo ' <th style="font-size:10pt;color: #43231e;background-color: #e98731;">Dernière mise en service</th>'; 
										   
									echo '</tr>';  	
									
								while($row = mysqli_fetch_assoc($gabArret)) {
								 $donn=getDescriptionIdByEvent2($row["last_event"]);
								 $motif=mysqli_fetch_assoc($donn);
								 echo "<tr>
								 <td>
								 <a name='declarer' href='declarer.php?terminal=".$row["terminal_atm_number"]."&dateArret=". $row["last_event_date"]."&id_motif=". $motif["id_intevention"]."' target='_blank'>Declarer</a>
								 - <a name='declarer' href='https://local.iprc.ma/backoffice/cfg/ivision/declarer.php?terminal=".$row["terminal_atm_number"]."&dateArret=". $row["last_event_date"]."&id_motif=". $motif["id_intevention"]."' target='_blank'>Declarer</a>
								 
								 </td>";
								 
								 /*echo '<tr>
								 <td><a href="javascript:declarer_alerte(\''.$row["terminal_atm_number"].'\',\''.$row["last_transaction_date"].'\',\''.$motif["libelle_intevention"].'\',\''.$motif["id_intevention"].'\')">Declarer </a></td>';*/
								
								getDetailArret(0,$row["terminal_atm_number"],$motif["libelle_intevention"],$motif["id_intevention"]);
								echo " 
								 <td>" . $row["terminal_atm_number"];displayNewGab($row["terminal_atm_number"],$row["isNew"]);
								 
								 echo"
								 </td>
								 <td>" . $row["outlet_number"]. "</td>
								 <td>" . $row["atm_acronym"]. "</td>
								 <td>" . $row["last_transaction_date"]. "</td>
								 <td>" . $motif["libelle_intevention"]. " </td>
								 <td name='dateArret'>" . $row["last_event_date"]. "</td>
								 <td>" . $row["last_in_service"]. "</td>
								 ";
								 
								 echo "
								 </tr>";
								 
							 }					
							echo '</table>';				
							} else {
							 echo "Aucun Gab en arrêt";
						}												
	echo'							
						</div> 
					
			</div>    
	  </div>  
	
	
	
	
	';
	
	
	
	
	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_motif_peripherique_incident22($libelle)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_motif` FROM  `list_champ_motif`  WHERE `libelle`= '".mysqli_real_escape_string($connexion,$libelle)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 984: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 984 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["id_motif"];
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_status_peripherique($cassette_reject,$safe_box,$pinpad,$card_reade,$encryption,$ticket,$log_printe,$dispenser,$terminal_atm_number,$date_arret,$terminal)
{
	//Statut Hors service		
	if (($cassette_reject)=="O"){echo '<span  class="glyphicon glyphicon-plus" style="color:#088A29"   onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('cassette_reject_status').'\',\''.$terminal.'\');">
	  </span> <strong style="font-size:12px;font-weight:bold;color:#b9121b">  Cassette Rejet : '.get_etat_status_device($cassette_reject)."</strong><br>";}
	if (($safe_box)=="O"){echo '<span   class="glyphicon glyphicon-plus" style="color:#088A29"  onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('safe_box_status').'\',\''.$terminal.'\');">
	  </span> <strong style="font-size:12px;font-weight:bold;color:#b9121b">  Porte coffre : '.get_etat_status_device($safe_box)."</strong><br>";}
	if (($pinpad)=="O"){echo '<span   class="glyphicon glyphicon-plus" style="color:#088A29"  onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('pinpad_status').'\',\''.$terminal.'\');"> 
	  </span> <strong style="font-size:12px;font-weight:bold;color:#b9121b">  Clavier EPP (Pinpad) : '.get_etat_status_device($pinpad)."</strong><br>";}
	if (($card_reade)=="O"){echo '<span   class="glyphicon glyphicon-plus" style="color:#088A29"  onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('card_reader_status').'\',\''.$terminal.'\');"> 
	  </span> <strong style="font-size:12px;font-weight:bold;color:#b9121b">  Lecteur : '.get_etat_status_device($card_reade)."</strong><br>";}
	if (($encryption)=="O"){echo '<span   class="glyphicon glyphicon-plus" style="color:#088A29"  onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('encryption_device_status').'\',\''.$terminal.'\');">
	  </span> <strong style="font-size:12px;font-weight:bold;color:#b9121b">  Clavier EPP : '.get_etat_status_device($encryption)."</strong><br>";}
	if (($ticket)=="O"){echo '<span   class="glyphicon glyphicon-plus" style="color:#088A29"  onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('ticket_printer_status').'\',\''.$terminal.'\');"> 
	  </span> <strong style="font-size:12px;font-weight:bold;color:#b9121b">  Ticket : '.get_etat_status_device($ticket)."</strong><br>";}
	if (($log_printe)=="O"){echo '<span  class="glyphicon glyphicon-plus" style="color:#088A29"   onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('log_printer_status').'\',\''.$terminal.'\');"> 
	 </span> <strong style="font-size:12px;font-weight:bold;color:#b9121b">  Journal : '.get_etat_status_device($log_printe)."</strong><br>";}
	if (($dispenser)=="O"){echo '<span  class="glyphicon glyphicon-plus" style="color:#088A29"   onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('dispenser').'\',\''.$terminal.'\');"> 
	 </span> <strong style="font-size:12px;font-weight:bold;color:#b9121b">  Distributeur : '.get_etat_status_device($dispenser)."</strong><br>";}
	//Statut Critique	
	if (($cassette_reject)=="C"){echo '<span  class="glyphicon glyphicon-plus" style="color:#088A29"  onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('cassette_reject_status').'\',\''.$terminal.'\')"> 
	 </span><label style="font-size:12px;font-weight:bold;color:#DF7401"> Cassette Rejet : </label><label>'.get_etat_status_device($cassette_reject)."</label><br>";}
	if (($safe_box)=="C"){echo '<span  class="glyphicon glyphicon-plus" style="color:#088A29"  onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('safe_box_status').'\',\''.$terminal.'\')"> 
	 </span> <label style="font-size:12px;font-weight:bold;color:#DF7401"> Porte coffre : </label><label>'.get_etat_status_device($safe_box)."</label><br>";}
	if (($pinpad)=="C"){echo '<span  class="glyphicon glyphicon-plus" style="color:#088A29"  onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('pinpad_status').'\',\''.$terminal.'\')"> 
	  </span> <strong style="font-size:12px;font-weight:bold;color:#DF7401"> Clavier EPP (Pinpad) : '.get_etat_status_device($pinpad)."</strong><br>";}
	if (($card_reade)=="C"){echo '<span class="glyphicon glyphicon-plus" style="color:#088A29"   onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('card_reader_status').'\',\''.$terminal.'\')"> 
	  </span> <strong style="font-size:12px;font-weight:bold;color:#DF7401"> Lecteur : '.get_etat_status_device($card_reade)."</strong><br>";}
	if (($encryption)=="C"){echo '<span class="glyphicon glyphicon-plus" style="color:#088A29"   onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('encryption_device_status').'\',\''.$terminal.'\')"> 
	 </span> <strong style="font-size:12px;font-weight:bold;color:#DF7401"> Clavier EPP : '.get_etat_status_device($encryption)."</strong><br>";}
	if (($ticket)=="C"){echo '<span  class="glyphicon glyphicon-plus" style="color:#088A29"  onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('ticket_printer_status').'\',\''.$terminal.'\')"> 
	 </span> <strong style="font-size:12px;font-weight:bold;color:#DF7401"> Ticket : '.get_etat_status_device($ticket)."</strong><br>";}
	if (($log_printe)=="C"){echo '<span class="glyphicon glyphicon-plus" style="color:#088A29"   onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('log_printer_status').'\',\''.$terminal.'\')"> 
	 </span> <strong style="font-size:12px;font-weight:bold;color:#DF7401"> Journal : '.get_etat_status_device($log_printe)."</strong><br>";}
	if (($dispenser)=="C"){echo '<span class="glyphicon glyphicon-plus" style="color:#088A29"   onClick="javascript:get_motif_incident2(\''.get_motif_peripherique_incident22('dispenser').'\',\''.$terminal.'\')"> 
	  </span> <strong style="font-size:12px;font-weight:bold;color:#DF7401"> Distributeurt : '.get_etat_status_device($dispenser)."</strong><br>";}
	//Statut En service
	if (($cassette_reject)=="I"){echo '<span class="fa fa-minus" style="color:#088A29">  </span> <strong style="font-size:12px;font-weight:bold;">  Cassette Rejet : '.get_etat_status_device($cassette_reject)."</strong><br>";}
	if (($safe_box)=="I"){echo '<span class="fa fa-minus" style="color:#088A29"> </span><strong style="font-size:12px;font-weight:bold;">  Porte coffre : '.get_etat_status_device($safe_box)."</strong><br>";}
	if (($pinpad)=="I"){echo '<span class="fa fa-minus" style="color:#088A29"> </span><strong style="font-size:12px;font-weight:bold;">  Clavier EPP (Pinpad) : '.get_etat_status_device($pinpad)."</strong><br>";}
	if (($card_reade)=="I"){echo '<span class="fa fa-minus" style="color:#088A29"> </span><strong style="font-size:12px;font-weight:bold;">  Lecteur : '.get_etat_status_device($card_reade)."</strong><br>";}
	if (($encryption)=="I"){echo '<span class="fa fa-minus" style="color:#088A29"> </span><strong style="font-size:12px;font-weight:bold;">  Clavier EPP : '.get_etat_status_device($encryption)."</strong><br>";}
	if (($ticket)=="I"){echo '<span class="fa fa-minus" style="color:#088A29"> </span><strong style="font-size:12px;font-weight:bold;">  Ticket : '.get_etat_status_device($ticket)."</strong><br>";}
	if (($log_printe)=="I"){echo '<span class="fa fa-minus" style="color:#088A29"> </span><strong style="font-size:12px;font-weight:bold;">  Journal : '.get_etat_status_device($log_printe)."</strong><br>";}
	if (($dispenser)=="I"){echo '<span class="fa fa-minus" style="color:#088A29">  </span><strong style="font-size:12px;font-weight:bold;">  Distributeur : '.get_etat_status_device($dispenser)."</strong><br>";}

}
/***************************************************************************/	
function get_motif_incident22($status,$idcassette)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_motif` FROM  `list_status_cassette`  
	WHERE `status`= '".mysqli_real_escape_string($connexion,$status)."' 
	AND `num_cassette`= '".mysqli_real_escape_string($connexion,$idcassette)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 985: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 985 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
						return $row["id_motif"];  	
            }
		}
		else
		{
		    return "";
		}
    mysqli_free_result($result);
	}
    mysqli_close($connexion);
}	
function get_etat_status_casssttes2($status,$montant,$idcassette)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_status`,`status`, `libelle` FROM  `list_status_cassette`  
	WHERE `status`= '".mysqli_real_escape_string($connexion,$status)."'  AND `num_cassette`= '".mysqli_real_escape_string($connexion,$idcassette)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 986: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 986 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
			{
			    return $row["libelle"].' - Montant : '.$montant;
			}
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
 /***************************************************************************/
function get_return_stat_cassette2($st_cst1,$mnt_cst1,$st_cst2,$mnt_cst2,$st_cst3,$mnt_cst3,$st_cst4,$mnt_cst4,$terminal_atm_number,$date_arret,$terminal)
{
echo"
<div class='row' style='background-color:#f9f9f9'>";
		if ($st_cst1=='N'){echo '<span class="glyphicon glyphicon-plus" onClick="javascript:get_motif_incident2(\''.get_motif_incident22($st_cst1,1).'\',\''.$terminal.'\')"  style="color:#088A29"> </span> <strong style="font-size:12px;font-weight:bold;color:#b9121b">  '.get_etat_status_casssttes2($st_cst1,$mnt_cst1,1)."</strong><br>";}
		if ($st_cst1=='E'){echo '<span class="glyphicon glyphicon-plus" onClick="javascript:get_motif_incident2(\''.get_motif_incident22($st_cst1,1).'\',\''.$terminal.'\')"  style="color:#088A29"> </span> <strong style="font-size:12px;font-weight:bold;color:#fc8a79">  '.get_etat_status_casssttes2($st_cst1,$mnt_cst1,1)."</strong><br>";}
		if ($st_cst1=='C'){echo '<span class="glyphicon glyphicon-plus" onClick="javascript:get_motif_incident2(\''.get_motif_incident22($st_cst1,1).'\',\''.$terminal.'\')"  style="color:#088A29"> </span> <strong style="font-size:12px;font-weight:bold;color:#DF7401">  '.get_etat_status_casssttes2($st_cst1,$mnt_cst1,1)."</strong><br>";}
		if ($st_cst1=='A'){echo '<span class="fa fa-minus" style="color:#088A29"> </span><strong style="font-size:12px;font-weight:bold;">  '.get_etat_status_casssttes2($st_cst1,$mnt_cst1,1)."</strong><br>";}
echo"</div>
<div class='row'>";

		if ($st_cst2=='N'){echo '<span class="glyphicon glyphicon-plus"  onClick="javascript:get_motif_incident2(\''.get_motif_incident22($st_cst2,2).'\',\''.$terminal.'\')" style="color:#088A29"> </span> <strong style="font-size:12px;font-weight:bold;color:#b9121b">  '.get_etat_status_casssttes2($st_cst2,$mnt_cst2,2)."</strong><br>";}
		if ($st_cst2=='E'){echo '<span class="glyphicon glyphicon-plus"  onClick="javascript:get_motif_incident2(\''.get_motif_incident22($st_cst2,2).'\',\''.$terminal.'\')" style="color:#088A29"> </span> <strong style="font-size:12px;font-weight:bold;color:#fc8a79">  '.get_etat_status_casssttes2($st_cst2,$mnt_cst2,2)."</strong><br>";}
		if ($st_cst2=='C'){echo '<span class="glyphicon glyphicon-plus"  onClick="javascript:get_motif_incident2(\''.get_motif_incident22($st_cst2,2).'\',\''.$terminal.'\')" style="color:#088A29"> </span> <strong style="font-size:12px;font-weight:bold;color:#DF7401">  '.get_etat_status_casssttes2($st_cst2,$mnt_cst2,2)."</strong><br>";}
		if ($st_cst2=='A'){echo '<span class="fa fa-minus" style="color:#088A29"></span><strong style="font-size:12px;font-weight:bold;">  '.get_etat_status_casssttes2($st_cst2,$mnt_cst2,2)."</strong><br>";}
echo"</div>
<div class='row' style='background-color:#f9f9f9'>";
		
		if ($st_cst3=='N'){echo '<span class="glyphicon glyphicon-plus"  onClick="javascript:get_motif_incident2(\''.get_motif_incident22($st_cst3,3).'\',\''.$terminal.'\')" style="color:#088A29"> </span> <strong style="font-size:12px;font-weight:bold;color:#b9121b">  '.get_etat_status_casssttes2($st_cst3,$mnt_cst3,3)."</strong><br>";}
		if ($st_cst3=='E'){echo '<span class="glyphicon glyphicon-plus"  onClick="javascript:get_motif_incident2(\''.get_motif_incident22($st_cst3,3).'\',\''.$terminal.'\')" style="color:#088A29"> </span> <strong style="font-size:12px;font-weight:bold;color:#fc8a79">  '.get_etat_status_casssttes2($st_cst3,$mnt_cst3,3)."</strong><br>";}
		if ($st_cst3=='C'){echo '<span class="glyphicon glyphicon-plus"  onClick="javascript:get_motif_incident2(\''.get_motif_incident22($st_cst3,3).'\',\''.$terminal.'\')" style="color:#088A29"> </span> <strong style="font-size:12px;font-weight:bold;color:#DF7401">  '.get_etat_status_casssttes2($st_cst3,$mnt_cst3,3)."</strong><br>";}
		if ($st_cst3=='A'){echo '<span class="fa fa-minus" style="color:#088A29"></span><strong style="font-size:12px;font-weight:bold;">  '.get_etat_status_casssttes2($st_cst3,$mnt_cst3,3)."</strong><br>";}
echo"</div>
<div class='row'>";
		if ($st_cst4=='N'){echo '<span class="glyphicon glyphicon-plus"  onClick="javascript:get_motif_incident2(\''.get_motif_incident22($st_cst4,4).'\',\''.$terminal.'\');" style="color:#088A29">  </span> <strong style="font-size:12px;font-weight:bold;color:#b9121b">  '.get_etat_status_casssttes2($st_cst4,$mnt_cst4,4)."</strong>";}
		if ($st_cst4=='E'){echo '<span class="glyphicon glyphicon-plus"  onClick="javascript:get_motif_incident2(\''.get_motif_incident22($st_cst4,4).'\',\''.$terminal.'\');" style="color:#088A29"> </span> <strong style="font-size:12px;font-weight:bold;color:#f0ad4e">  '.get_etat_status_casssttes2($st_cst4,$mnt_cst4,4)."</strong>";}
		if ($st_cst4=='C'){echo '<span class="glyphicon glyphicon-plus"  onClick="javascript:get_motif_incident2(\''.get_motif_incident22($st_cst4,4).'\',\''.$terminal.'\');" style="color:#088A29">  </span> <strong style="font-size:12px;font-weight:bold;color:#DF7401">  '.get_etat_status_casssttes2($st_cst4,$mnt_cst4,4)."</strong>";}
		if ($st_cst4=='A'){echo '<span class="fa fa-minus" style="color:#088A29"></span><strong style="font-size:12px;font-weight:bold;">  '.get_etat_status_casssttes2($st_cst4,$mnt_cst4,4)."</strong>";}
echo"</div> ";
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function alerte_gab_deja_declarer($gab)
{
echo '<div class="alert alert-danger" align="center" style="font-size:15px;font-weight:bold;"> Attention le Gab  : '.$gab.' est déjà declarer </strong></div>'; 
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function actueliser_commentaire()
{
echo '	<label <for="id_remarque_3" class="col-sm-2 control-label">Remarque</label>
				<div class="col-sm-10">
				 <textarea class="form-control" id="remarque_incident" name="remarque_incident" rows="3"></textarea>						
         	</div>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function actueliser_date_arrete()
{
echo '	<label for="inputarret" class="col-sm-3 control-label">Date d\'arrêt</label>
				<div class="col-sm-9">
					<input placeholder="Date d\'arrêt" id="inputarret" name="inputarret" type="text" required  value="" class="form-control input-sm">
				</div>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function vider_date_rappel()
{
echo '		<label for="id_rappel_alert" class="col-sm-3 control-label">Durée rappel</label>
			   <div class="col-sm-9">
    			<select class="form-control" id="id_rappel" required name="rappel" > </select>      
			
				</div>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function afficher_affectation_gab($id_gab)
{
    $affectation='Assignment';
    if ($_SESSION['lang']=='fr')
    {
        $affectation='Affectation';
    }
    echo '<label class="col-sm-3 col-form-label" for="id_affecter">'.$affectation.'</label>
        <div class="col-md-9">
    	    <select class="form-control" id="id_affecter_sel" required name="id_affecter"> ';
    get_select_affectation($id_gab);
    echo '  </select>   
	</div>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function actueliser_date_rappel()
{
    if ($_SESSION['lang']=='fr')
    {
        echo '<label class="col-sm-3 col-form-label" for="id_rappel_alert">Durée rappel</label>
    <div class="col-md-9">
        <select class="form-control" id="id_rappel"  name="rappel" required>
            <option value="3600">1h</option>
            <option value="5400">1h30</option>
            <option value="7200">2h</option>
            <option value="14400">4h</option>
            <option value="JO7">Jour Ouvrable</option>
            <option value="86400">24h (1 Jour)</option>
            <option value="172800">48h (2 Jours)</option>
            <option value="259200">72h (3 Jours)</option>					
            <option value="345600">96h (4 Jours)</option>
        </select>
    </div>';
    }
    else
    {
        echo '<label class="col-sm-3 col-form-label" for="id_rappel_alert">Reminder duration</label>
    <div class="col-md-9">
        <select class="form-control" id="id_rappel"  name="rappel" required>
            <option value="3600">1h</option>
            <option value="5400">1h30</option>
            <option value="7200">2h</option>
            <option value="14400">4h</option>
            <option value="JO7">Business day</option>
            <option value="86400">24h (1 Day)</option>
            <option value="172800">48h (2 Day)</option>
            <option value="259200">72h (3 Day)</option>					
            <option value="345600">96h (4 Day)</option>
        </select>
    </div>';
    }


}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDescriptionIdByEvent2($event)
{
    $connexion=ma_db_connexion();
    $sql="SELECT libelle_intevention, id_intevention FROM new_action_intervention
	WHERE event='".mysqli_real_escape_string($connexion,$event)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 987: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 987 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    return($result);
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDetailGabByTerminal($term)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT isNew, terminal_atm_grouping, outlet_number, atm_acronym, 
	link_com_addr, terminal_profile, cassette1_notes_type, cassette1_status, cassette1_available_amount,
	cassette2_notes_type, cassette2_status, cassette2_available_amount, cassette3_notes_type, cassette3_status, cassette3_available_amount, cassette4_notes_type, cassette4_status, cassette4_available_amount, cassette_reject_status, safe_box_status, pinpad_status, card_reader_status, encryption_device_status, ticket_printer_status, log_printer_status, dispenser, last_transaction_date, last_event, last_event_date, last_in_service 
    FROM Etat_Parc_Gab WHERE terminal_atm_number='".mysqli_real_escape_string($connexion,$term)."' ";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 988: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 988 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
            $res=mysqli_fetch_assoc($result);
            return($res);
		}
		else
			{
				return "";
			}
    mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/*******************************************************************************************************************************************/
function getDateLastRaffra($bpr)
{
    $connexion=ma_db_connexion();
    $sql= "SELECT MAX(date_extraction) AS Max_Date_BPR
	FROM  new_verif_extration_xml
	WHERE  id_bpr ='".$bpr."' ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 989: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 989 !');
    }
    if ($result)
	{
	    if( mysqli_num_rows($result) > 0)
	    {
	        while ($myDate= mysqli_fetch_assoc($result))
            {
                $date = date_create($myDate["Max_Date_BPR"]);
                return date_format($date, date('d-m-Y à H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y'))));
            }
	    }
	    else
	    {
	        echo"NON DISPONIBLE ";
	    }

	    mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
/*******************************************************************************************************************************************/
function warning_date_raf_for_detail($bpr)  
{
    $connexion=ma_db_connexion();
    $sql="SELECT MAX(date_extraction) AS Max_Date_BPR FROM  new_verif_extration_xml	WHERE  id_bpr ='".$bpr."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 990: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 990 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($myDate = mysqli_fetch_assoc($result))
            {
                $dateRf = $myDate["Max_Date_BPR"];
            }
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);

    /*kamar
    $date = date("d-m-Y");
    $hr= date("H")+regle_heure_backoffice();
    $heure = gmdate("$hr:i:s");//date('Y-m', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),$mn-1,date('d'),$yr));
    $totalDate=$date." ".$heure;
    */
    $totalDate = date('d-m-Y  H:i:s', mktime(date("H")+ regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y')));

    $datetime1 = new DateTime($dateRf);
    $datetime2 = new DateTime($totalDate);

    $difference = $datetime2->diff($datetime1);

    $years = $difference->y;
    $months = $difference->m;
    $days = $difference->d;
    $hours = $difference->h;
    $min = $difference->i;
    $sec = $difference->s;

    $minutes = $days * 24 * 60;
    $minutes +=$hours * 60;
    $minutes +=$min;
    if ($minutes >= 40){return " <span class='glyphicon glyphicon-warning-sign' style='color:red'>".$totalDate."  ".$minutes. " ".$dateRf."  </span>";}//else return"<label>".$totalDate."</label>";
}
/*******************************************************/
function getCouleurCassette($etat)
{
	if ($etat=='A'){
		return("#000000");
	} else if ($etat=='C'){;
		return("#DB882A");
	} else if ($etat=='E'){
		return("#B9121B");
	} else if ($etat=='N'){
		return("#B9121B");
	} 	
}
/*******************************************************/	
function getDescriptionCassete($etat){
	if ($etat=='A'){
		return("Op");
	} else if ($etat=='C'){
		return("Critique");
	} else if ($etat=='E'){
		return("Vide");
	} else if ($etat=='N'){
		return("N.Conf/N.Op");
	} else {
		return("Inconnu");
	}	
}
/*******************************************************/
function getCouleurPeripherique($per){
	if ($per=='I'){
			return("#000000");
		} else if ($per=='O'){
			return("#B9121B");
		} else if ($per=='C'){
			return("#DB882A");
		} else {
			return("#000000");
		}
}
/*******************************************************************************************************************************************/
function getDescriptionPeripherique($etat){
	if ($etat=='I'){
		return("En service");
	} else if ($etat=='O'){
		return("Hors service");
	} else if ($etat=='C'){
		return("Critique");
	} else {
		return("Inconnu");
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getDetailGabDetailIncident($terminal){
	$detail=getDetailGabByTerminal($terminal);
	
	$donn=getDescriptionIdByEvent2($detail["last_event"]);
	$lastEvent=mysqli_fetch_assoc($donn);
		
	
echo"
<a data-toggle='modal' href='#myModal".$terminal."'><span class='glyphicon glyphicon-search'></span></a>"; 
		 echo"
		 <div class='modal fade' id='myModal".$terminal."' role='dialog'>
			<div id='modal_d' class='modal-dialog'>
				<div class='modal-content'>
					<div class='modal-header'>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
						<div style='font-size:13pt;color: #3a1d19;' class='modal-title' ><strong>Etat GAB: ".$detail["atm_acronym"]."<br>";
						// echo getDateLastRaffra($detail["terminal_atm_grouping"]);
						echo "</strong></div>";//warning_date_raf_for_detailmorsli($detail["terminal_atm_grouping"]);
						echo"
					</div>
					<div class='modal-body' style='padding:40px 50px;'>
					<div class='row'>
								
									<div class='panel-heading' style='background-color:#e7722c;font-size:13pt;color:#fff;'>Statuts Cassettes</div>
										<div style='margin-left:2px;font-size:9pt;color:#00060b;' class='panel-body'>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurCassette($detail["cassette1_status"])."'>
															<div class='col-sm-4'>
																<label>Cassette 1</label>
															</div>
															<div class='col-sm-4'>
																<label>Montant:". $detail["cassette1_available_amount"]."</label>
															</div>
															<div class='col-sm-4'>
																<label>Etat: ".getDescriptionCassete($detail["cassette1_status"]);	
										echo"				</label>
															</div>
											</div>
											<div class='row' style='color:".getCouleurCassette($detail["cassette2_status"])."'>
															<div class='col-sm-4'>
																<label>Cassette 2</label>
															</div>
															<div class='col-sm-4'>
																<label>Montant:". $detail["cassette2_available_amount"]."</label>
															</div>
															<div class='col-sm-4'>
																<label>Etat: ".getDescriptionCassete($detail["cassette2_status"]);	
										echo"  					</label>
															</div>
											</div>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurCassette($detail["cassette3_status"])."'>
															<div class='col-sm-4'>
																<label>Cassette 3</label>
															</div>
															<div class='col-sm-4'>
																<label>Montant:". $detail["cassette3_available_amount"]."</label>
															</div>
															<div class='col-sm-4'>
																<label>Etat: ".getDescriptionCassete($detail["cassette3_status"]);		
										echo"					</label>
															</div>
											</div>
											<div class='row'  style='color:".getCouleurCassette($detail["cassette4_status"])."'>
															<div class='col-sm-4'>
																<label>Cassette 4</label>
															</div>
															<div class='col-sm-4'>
																<label>Montant:". $detail["cassette4_available_amount"]."</label>
															</div>
															<div class='col-sm-4'>
																<label>Etat: ".getDescriptionCassete($detail["cassette4_status"]);	
										echo"					</label>
															</div>
											</div>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detail["cassette_reject_status"])."'>
															<div class='col-sm-4'>
																<label>Cassette rejet:</label>
															</div>
															<div class='col-sm-8'>
																<label>". getDescriptionPeripherique($detail["cassette_reject_status"]);	
										echo"					</label>
															</div>
											</div>
										</div>
									<div class='panel-heading' style='background-color:#e7722c;font-size:13pt;color:#fff;'>Statuts Périphériques</div>
										<div style='margin-left:2px;font-size:9pt;color:#00060b;' class='panel-body'>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detail["dispenser"])."'>
														<div class='col-sm-4'>
															<label>Separateur</label>
														</div>
														<div class='col-sm-8'>
															<label>".getDescriptionPeripherique($detail["dispenser"]);		
										echo"				</label>
														</div>
											</div>
											<div class='row' style='color:".getCouleurPeripherique($detail["card_reader_status"])."'>
														<div class='col-sm-4'>
															<label>Lecteur de carte</label>
														</div>
														<div class='col-sm-8'>
															<label>".getDescriptionPeripherique($detail["card_reader_status"]);	
												
										echo"				</label>
														</div>
											</div>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detail["log_printer_status"])."'>
														<div class='col-sm-4'>
															<label>Journal</label>
														</div>
														<div class='col-sm-8'>
															<label>".getDescriptionPeripherique($detail["log_printer_status"]);			
										echo"				</label>
														</div>
											</div>
											<div class='row' style='color:".getCouleurPeripherique($detail["pinpad_status"])."'>
														<div class='col-sm-4'>
															<label>Pinpad</label>
														</div>
														<div class='col-sm-8'>
															<label>".getDescriptionPeripherique($detail["pinpad_status"]);	
										echo"				</label>
														</div>
											</div>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detail["encryption_device_status"])."'>
														<div class='col-sm-4'>
															<label>Clavier EPP</label>
														</div>
														<div class='col-sm-8'>
															<label>".getDescriptionPeripherique($detail["encryption_device_status"]);	
										echo"				</label>
														</div>
											</div>
											<div class='row' style='color:".getCouleurPeripherique($detail["ticket_printer_status"])."'>
														<div class='col-sm-4'>
															<label>Ticket</label>
														</div>
														<div class='col-sm-8'>
															<label>".getDescriptionPeripherique($detail["ticket_printer_status"]);	
										echo"				</label>
														</div>
											</div>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detail["safe_box_status"])."'>
														<div class='col-sm-4'>
															<label>Porte coffre</label>
														</div>
														<div class='col-sm-8'>
															<label>".getDescriptionPeripherique($detail["safe_box_status"]);	
										echo"				</label>
														</div>
											</div>
										</div>
										<div class='panel-heading' style='background-color:#e7722c;font-size:13pt;color:#fff;'>Autre</div>
										<div style='margin-left:2px;font-size:9pt;color:#00060b;' class='panel-body'>
											<div style='background-color:#f9f9f9' class='row'>
														<div class='col-sm-4'>
															<label>Dernière Transaction</label>
														</div>
														<div class='col-sm-8'>
															<label>" .$detail["last_transaction_date"]."</label>
														</div>
											</div>
											<div class='row'>
														<div class='col-sm-4'>
															<label>Dernier événement</label>
														</div>
														<div class='col-sm-8'>
															<label>" .$lastEvent["libelle_intevention"]."</label>
														</div>
											</div>"
											; 
											echo "<div style='background-color:#f9f9f9' class='row'>
														<div class='col-sm-4'>
															<label>Date événement</label>
														</div>
														<div class='col-sm-8'>
															<label>" .$detail["last_event_date"]."</label>
														</div>
												  </div> ";
											
											echo"
											
											<div class='row'>
														<div class='col-sm-4'>
															<label>Dernière mise en service</label>
														</div>
														<div class='col-sm-8'>
															<label>" .$detail["last_in_service"]."</label>
														</div>
											</div>
											
								</div>
					</div>
					</div>
					<div class='modal-footer'>
						<button type='button' class='btn btn-default' data-dismiss='modal'>Fermer</button>
						
					</div>
			</div>
		</div>
		</div>
		 
		
";	
}
/*******************************************************************************************************************************************/
function actueliser_date_arret()
{
    echo '<label class="col-sm-3 col-form-label" for="inputarret">Date d\'arrêt</label>';
    echo '<div class="col-md-9">';
    echo '<input placeholder="Date d\'arrêt" id="inputarret" name="inputarret" type="text" required  value="'.date('Y-m-d  H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y'))).'" class="form-control">';
    echo '</div>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_array_action_intevention_incident_mail($id_incident)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_incident`, `date_action`, `id_action_intervention`, `id_niveau_intervention`, `date_rappel`,	`etat_cloture`,`id_intevention`, `libelle_intevention`,`nbr_tentative` 
    FROM `new_intevention_incident`, `new_action_intervention`
    WHERE `id_intevention` = `id_action_intervention` 
	AND `id_incident`  =  '".mysqli_real_escape_string($connexion,$id_incident)."' AND `new_intevention_incident`.`nbr_tentative`  = '1' 
    ORDER BY `date_action` ASC";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 991: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 991 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
            $i=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $nbr_inter[$i] = $row["nbr_tentative"];
                $date_action[$i] = $row["date_action"];
                $libelle[$i] = $row["libelle_intevention"];
                $date_rappel[$i] = $row["date_rappel"];
                $motif_cloture[$i] = $row["etat_cloture"];
                $i++;
            }
            return  array($nbr_inter,$date_action,$libelle,$date_rappel,$motif_cloture);
		}
		else
		{
		    return array("", "", "", "", "");
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_affectation($id_gab)
{
    $connexion=ma_db_connexion();
    $sql1 = "SELECT `id_type`, `libelle` FROM `new_libelle_type_contact` ";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result1=mysqli_query($connexion,$sql1);
    if (!$result1)
    {
        error_log("Erreur SQL 992: ".$sql1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 992 !');
    }
    if ($result1)
	{	
		if(mysqli_num_rows($result1)>0)
		{
		    while ($row = mysqli_fetch_assoc($result1))
            {
                echo '<option value="'.$row["id_type"].'">'.strtoupper($row["libelle"]).'</option>';
            }
		}
		mysqli_free_result($result1);
	}

	/*if(get_gestionnaire_gab22($id_gab)==9)//GAB AGENCE/GF BCC
	{
	    $sql1 = "SELECT `id_type`, `libelle` FROM `new_libelle_type_contact` WHERE `id_type` = 1 OR `id_type` = 2";
	    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
        $result1=mysqli_query($connexion,$sql1);
        if (!$result1)
        {
            error_log("Erreur SQL 993: ".$sql1."  ".mysqli_error($connexion));
            die('ERREUR QUERY 993 !');
        }
				
		if ($result1)
		{
		    if(mysqli_num_rows($result1)>0)
		    {
		        while ($row = mysqli_fetch_assoc($result1))
                {
                    echo '<option value="'.$row["id_type"].'">'.strtoupper($row["libelle"]).' (AGENCE BCC)</option>';
                }
		    }
		    mysqli_free_result($result1);
		}
	}
	else //GAB AGENCE/GF BCC
	{
        $sql1 = "SELECT `gestionnaire`,	`libelle`, 	`id_type` FROM  `new_list_gab`, `new_libelle_type_contact` 	
        WHERE `gestionnaire`=`id_type` AND `terminal` LIKE '".mysqli_real_escape_string($connexion,trim($id_gab))."'";
        mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
        $result1=mysqli_query($connexion,$sql1);
        if (!$result1)
        {
            error_log("Erreur SQL 994: ".$sql1."  ".mysqli_error($connexion));
            die('ERREUR QUERY 994 !');
        }
        if ($result1)
        {
            if(mysqli_num_rows($result1)>0)
            {
                while ($row = mysqli_fetch_assoc($result1))
                {
                    echo '<option value="'.$row["id_type"].'">'.strtoupper($row["libelle"]).'</option>';
                }
            }
            mysqli_free_result($result1);
        }
	}
		
	if (get__info__type_gab($id_gab)=='DIEBOLD')
	{
	    $type_affectation=get_gestionnaire_gab2(4);//DIEBOLD===>MUNISYS
	}
	else
	{
	    $type_affectation=get__info__type_gab($id_gab);
	}
		
    $sql = "SELECT 	`id_type`,	`libelle` FROM  `new_libelle_type_contact` WHERE UPPER(`libelle`) 
	LIKE '".mysqli_real_escape_string($connexion,strtoupper($type_affectation))."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 995: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 995 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["id_type"].'">'.strtoupper($row["libelle"]).'</option>';
            }
        }
        mysqli_free_result($result);
    }
	
    $sql2 = "SELECT `id_type`,	`libelle` FROM  `new_libelle_type_contact` WHERE `id_type` =7 OR `id_type` =8";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result2=mysqli_query($connexion,$sql2);
    if (!$result2)
    {
        error_log("Erreur SQL 996: ".$sql2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 996 !');
    }
    if ($result2)
    {
        if(mysqli_num_rows($result2)>0)
        {
            while ($row = mysqli_fetch_assoc($result2))
            {
                echo '<option value="'.$row["id_type"].'">'.strtoupper($row["libelle"]).'</option>';
            }
        }
        mysqli_free_result($result2);
    }*/
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_all_affectation()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_type`, `libelle` FROM `new_libelle_type_contact` ";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 997: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 997 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                echo '<option value="'.$row["id_type"].'">'.$row["libelle"].'</option>';
            }
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getGabStrategique($id_gab)
{
    $connexion=ma_db_connexion();
    $sql="SELECT `terminal` FROM `new_list_gab` WHERE `terminal` LIKE '".mysqli_real_escape_string($connexion,$id_gab)."' AND  `id_strategiques` =1";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 998: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 998 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                return " - GAB stratégique";
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);

	}
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getTelAgences2($code_agence,$id_gab)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`nom_contact`,`escalade`,`tel1`, `affectation_contact` 	FROM  `new_contact_agence` 
    WHERE `new_contact_agence`.`code_agence` like '".mysqli_real_escape_string($connexion,$code_agence)."' AND `nom_contact` <> '' ";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 999: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 999 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                echo  $row["escalade"].' ) '.$row["nom_contact"].' --> '.getAffectationContactGABAstreinte($row["affectation_contact"]).' -- '.trim($row["tel1"]).' '.trim($row["tel1"]).'<br>';
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_agence($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`nom_agence` 	FROM  `new_list_agence` WHERE `new_list_agence`.`code_agence` like '".mysqli_real_escape_string($connexion,$id)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1000: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1000 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                return $row["nom_agence"];
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);	
	}
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_horaires_cibles($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`horaires_cibles` 	FROM  `new_list_agence` 
	WHERE `new_list_agence`.`code_agence` like '".mysqli_real_escape_string($connexion,$id)."'";
        $result=mysqli_query($connexion,$sql);
        if (!$result)
        {
            error_log("Erreur SQL 1001: ".$sql."  ".mysqli_error($connexion));
            die('ERREUR QUERY 1001 !');
        }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return str_replace("?", "à", $row["horaires_cibles"]);
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_horaires_cibles_ramadan($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`horaires_cibles_ramadan` 	FROM  `new_list_agence` WHERE `new_list_agence`.`code_agence` 
	like '".mysqli_real_escape_string($connexion,$id)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1003: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1003 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return  str_replace("?", "à", $row["horaires_cibles_ramadan"]);
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
			
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_filiale2($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`nom_filiale` 	FROM  `new_filiale` WHERE `id_filiale`
	like '".mysqli_real_escape_string($connexion,$id)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1004: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1004 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["nom_filiale"];
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_prestataire_gab($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`nom_prestataire` 	FROM  `new_list_prestataire` 
	WHERE `id_prestataire` = '".mysqli_real_escape_string($connexion,$id)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1005: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1005 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["nom_prestataire"];  	
					}
			}	
		else
			{
				return "";
			}
		mysqli_free_result($result);
	}

    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_gestionnaire_gab($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`nom_fournisseur` 	FROM  `new_list_fournisseur` 
	WHERE `id_fournisseur` = '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1006: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1006 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["nom_fournisseur"];  	
					}
			}	
		else
			{
				return "";
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_prestataire_gab2($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`nom_prestataire` 	FROM  `new_list_prestataire` 
	WHERE `id_prestataire` = '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1007: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1007 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["nom_prestataire"];
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_gestionnaire_gab2($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`libelle` 	
	FROM  `new_libelle_type_contact` WHERE `id_type` =  '".mysqli_real_escape_string($connexion,$id)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1008: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1008 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["libelle"];
            }
		}
		else
			{
				return "";
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_gestionnaire_gab22($id_gab)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`gestionnaire` 	FROM  `new_list_gab` WHERE `terminal` 
	LIKE '".mysqli_real_escape_string($connexion,$id_gab)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1009: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1009 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                return $row["gestionnaire"];
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function afficher_nom_gab($id_gab)
{
    $connexion=ma_db_connexion();
    $sql="SELECT  `nom_gab`, `id_strategiques` FROM `new_list_gab` WHERE `terminal` 
	LIKE '".mysqli_real_escape_string($connexion,$id_gab)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1010: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1010 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
            {
                echo  '<div class="alert alert-info" align="center">
                                <strong>'.$row["nom_gab"].''.getGabStrategique($id_gab).'</strong>
                            </div>';
            }
		}
		else
		{
		    echo  "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}			
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function setEtatGestion($etat)
{
    if ($etat == 1)
    {
        return 'Interne';
    }
    else if($etat == 10)
    {
        return 'Externe';
    }
	else
    {
        return'Erreur';
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_array_action_intevention_incident($id_incident)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `id_incident`, `date_action`, `id_action_intervention`, `id_niveau_intervention`, `date_rappel`,	`etat_cloture`,`id_intevention`, `libelle_intevention`,`nbr_tentative` 
    FROM `new_intevention_incident`, `new_action_intervention`
    WHERE 
    `id_intevention` = `id_action_intervention`
    AND `id_incident`  =  '".mysqli_real_escape_string($connexion,$id_incident)."' 
    ORDER BY `date_action` ASC";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1011: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1011 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    $i=0;
		    while ($row = mysqli_fetch_assoc($result))
            {
                $k=$i+1;
                $nbr_inter[$i] = $row["nbr_tentative"];
				$date_action[$i] = $row["date_action"];
                $libelle[$i] = $row["libelle_intevention"];  
                $date_rappel[$i] = $row["date_rappel"];
                $motif_cloture[$i] = $row["etat_cloture"];
				$i++;
            }
            return  array($nbr_inter,$date_action,$libelle,$date_rappel,$motif_cloture);
		}
		else
		{
		    return array("", "", "", "", "");
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_motif_arret($motif,$id_motif,$terminal)
{
    $cause_default="Cause d'arrêt";
    if ($_SESSION['lang']=='en')
    {
        $cause_default="Cause default";
    }

    echo '<label class="col-sm-3 col-form-label" for="inputcauseaction">'.$cause_default.'</label>
             <div class="col-md-9 search-box">
             	<input type="text" name="inputcauseaction"  id="inputcauseaction" class="form-control" value="'.$motif.'-'.$id_motif.'"    onkeyup="autocomplet()" onFocus="javascript:get_generer_mail(this.value)" placeholder="Motif" data-type="search" autocomplete="off">
                 <ul class="dropdown-menu" id="terminal_list_id"></ul>
             </div>';
}


 /***************************************************************************/
function get_detail_incident2($terminal)
{
    $connexion=ma_db_connexion();
    $SQL1 = "SELECT * FROM `Etat_Parc_Gab`    WHERE  `terminal_atm_number` like '".mysqli_real_escape_string($connexion,$terminal)."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
          error_log("Erreur SQL 1012: ".$SQL1."  ".mysqli_error($connexion));
          die('ERREUR QUERY 1012 !');
    }
    if ($result)
	{	
	    if(mysqli_num_rows($result)>0)
        {
			while ($row = mysqli_fetch_assoc($result)) 
            {
                echo '<div class="panel-heading" style="background-color:#e7722c;font-size:11pt;color:#fff;"><strong>Statuts Cassettes</strong></div>
                <div style="margin-left: 2px" class="panel-body">';
                echo get_return_stat_cassette2($row["cassette1_status"],
                $row["cassette1_available_amount"],
                $row["cassette2_status"],
                $row["cassette2_available_amount"],
                $row["cassette3_status"],
                $row["cassette3_available_amount"],
                $row["cassette4_status"],
                $row["cassette4_available_amount"],
                $row["terminal_atm_number"],
                $row["last_transaction_date"],$terminal);
                echo'</div>
                <div class="panel-heading" style=";background-color:#e7722c">
                    <h3 class="panel-title" style="font-size:11pt;color: #fff;"><strong> Statuts Périphériques </strong></h3>
                </div>		
                <table class="table" style="font-size:12px;font-weight:bold;" >';
                echo ' <tr>	';
                echo '<td>';
                echo get_return_status_peripherique($row["cassette_reject_status"],
                $row["safe_box_status"],
                $row["pinpad_status"],
                $row["card_reader_status"],
                $row["encryption_device_status"],
                $row["ticket_printer_status"],
                $row["log_printer_status"],
                $row["dispenser"],
                $row["terminal_atm_number"],
                $row["last_transaction_date"],$terminal);
                echo '</td>';
                echo '</tr>';
                echo '</table>';
            }
        }
	    mysqli_free_result($result);
	}
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_information_contact_gab3_ancienne($id_intervention,$id_gab)///Modifier kamar
{
    $connexion=ma_db_connexion();
    if (!empty($id_intervention))
    {

        $sql="SELECT `nom_contact`, `niveau_escalade`, `fonction_contact`, `nom_contact`, `fixe_contact1`, `fixe_contact2`, `adresse_mail`, `niveau_escalade`, `type_contact` FROM `new_list_contact_agence`   
         WHERE `code_filiale` like '".get_code_agence_agence($id_gab)."'
         GROUP BY `nom_contact`
         ORDER BY `niveau_escalade`,`id_contact` ASC";

        $result=mysqli_query($connexion,$sql);
        if (!$result)
        {
            error_log("Erreur SQL 1013: ".$sql."  ".mysqli_error($connexion));
            die('ERREUR QUERY 1013 !');
        }
        if ($result)
        {
            echo '<table class="table"  style="font-size:12px;font-weight:bold;" class="table-responsive">';
            echo ' <tr style="color: #000;font-size:12px;background-color:#e98731;color:#ffffff;"> <th>Niveau Escaladé</th><th>Nom contact </th><th>Fonction </th><th>E-mail</th><th>Gsm</th><th>Tel</th></tr>';

            if(mysqli_num_rows($result)>0)
            {
                $i=0;
                while ($row = mysqli_fetch_assoc($result))
                {
                     echo ' <tr>
                     <th><strong style="color: #000;font-size:11px;">'.$row["niveau_escalade"].'</strong></th>
                     <th><strong style="color: #000;font-size:11px;">'.$row["nom_contact"].'</strong></th>
                     <th><strong style="color: #000;font-size:11px;">'.$row["fonction_contact"].'</strong></th>			 
                     <th><strong style="color: #000;font-size:11px;">'.$row["adresse_mail"].'</strong></th>			 
                     <th><strong><input  style="font-size:10pt;font-weight:bold;color:#000;"  align="center" onChange="javascript:modifier_gsm_contact(\''.$row["fixe_contact1"].'\',\''.$i.'\',\''.$id_intervention.'\',\''.$id_gab.'\',\''.$row["niveau_escalade"].'\',\''.$row["type_contact"].'\')" id="gsm_contact'.$i.'" name="gsm_contact'.$i.'" type="text"   value="'.$row["fixe_contact1"].'"     class="form-control input-sm"></strong>
                     <a  onclick="javascript:appel_contact_detail(\''.$i.'\')" class="btn btn-info btn-xs btn-block">Call  </a>			 
                     </th>
                     <th><strong><input  style="font-size:10pt;font-weight:bold;color:#000;"  align="center" onChange="javascript:modifier_gsm_contact2(\''.$row["fixe_contact2"].'\',\''.$i.'\',\''.$id_intervention.'\',\''.$id_gab.'\',\''.$row["niveau_escalade"].'\',\''.$row["type_contact"].'\')" id="gsm_contact2'.$i.'" name="gsm_contact2'.$i.'" type="text"   value="'.$row["fixe_contact2"].'"    class="form-control input-sm"></strong>
                     <a  onclick="javascript:appel_contact_detail2(\''.$i.'\')" class="btn btn-info btn-xs btn-block">Call 2  </a>			 
                     </th></tr>';
                    $i++;
                }
            }
            echo '	</table>';

            mysqli_free_result($result);
        }
    }
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getCodeAgence($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `code_agence`  FROM `new_list_gab`      WHERE `terminal` LIKE '".mysqli_real_escape_string($connexion,$id)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1014: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1014 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                return $row["code_agence"];
            }
		}
		else
		{

		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getCodeBPRbpr($id_gab)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `code_bank` FROM  `new_list_gab`		WHERE `terminal` like '".mysqli_real_escape_string($connexion,trim($id_gab))."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1016: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1016 !');
    }
	if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                return $row["code_bank"];
            }
		}
		else
		{
		    return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getCodeSuccursale($id)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT `code_succursale`  FROM `new_list_gab`    WHERE `terminal` LIKE '".mysqli_real_escape_string($connexion,$id)."'";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1015: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1015 !');
    }
    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
			while ($row = mysqli_fetch_assoc($result)) 
			{
			    return trim($row["code_succursale"]);
			}
		}
		else
		{
			return "";
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
  //////////////////////////////////////////////////////////////////////////////////////////////
function view_add_contact($id_intervention,$id_gab,$type_agence)
{
     $connexion=ma_db_connexion();
	 if ($type_agence==1){ echo '<tr><td colspan=6 style="background-color: #cecece;text-align: center">Niveau I : contact agence</td></tr>';}
	 if ($type_agence==2){ echo '<tr><td colspan=6 style="background-color: #cecece;text-align: center">Niveau II : contact sucursale</td></tr>';}
	 if ($type_agence==3){ echo '<tr><td colspan=6 style="background-color: #cecece;text-align: center">Niveau III : Siège régional</td></tr>';}
	
	if ($id_gab<>"")
	{	  
        $SQL="SELECT `nom_contact`, `niveau_escalade`, `fonction_contact`, `nom_contact`, `fixe_contact1`, `fixe_contact2`, `adresse_mail`, `niveau_escalade`, `type_contact`, `date_insertion`  FROM `new_list_contact_agence`   
        WHERE ";
        if ($type_agence==1){ $SQL=$SQL." `code_filiale` LIKE  '".getCodeAgence($id_gab)."' AND ";}
        if ($type_agence==2){$SQL=$SQL." `code_succursale` LIKE  '".getCodeSuccursale($id_gab)."' AND ";}
        $SQL=$SQL."  `affectation` =  '".$type_agence."'
        AND `etat_contact` =  '0' ";
        // $SQL=$SQL." AND `code_bpr` IN(".getCodeBPRbpr($id_gab).")";
        $SQL=$SQL." GROUP BY `nom_contact`
        ORDER BY `niveau_escalade`,`id_contact` ASC";
		 // echo $SQL;
        $result=mysqli_query($connexion,$SQL);
        if (!$result)
        {
            error_log("Erreur SQL 1017: ".$SQL."  ".mysqli_error($connexion));
            die('ERREUR QUERY 1017 !');
        }
	    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
	    if ($result)
	    {
	        if(mysqli_num_rows($result)>0)
			{
			    $i=0;
			    while ($row = mysqli_fetch_assoc($result))
                {
                    if ($row["date_insertion"]<>'0000-00-00 00:00:00'){$date_insertion='/Date Insert. '.$row["date_insertion"];}else{$date_insertion="";}
                    echo ' <tr>
                    <th><strong style="color: #000;font-size:11px;">'.$row["niveau_escalade"].'</strong></th>
                    <th><strong style="color: #000;font-size:11px;">'.$row["nom_contact"].'</strong></th>
                    <th><strong style="color: #000;font-size:11px;">'.$row["fonction_contact"].'</strong></th>			 
                    <th><strong style="color: #000;font-size:11px;">'.$row["adresse_mail"].''.$date_insertion.'</strong></th>			 
                    <th><strong><input  style="font-size:10pt;font-weight:bold;color:#000;"  align="center" onChange="javascript:modifier_gsm_contact(\''.$row["fixe_contact1"].'\',\''.$i.'\',\''.$id_intervention.'\',\''.$id_gab.'\',\''.$row["niveau_escalade"].'\',\''.$row["type_contact"].'\')" id="gsm_contact'.$i.'" name="gsm_contact'.$i.'" type="text"   value="'.$row["fixe_contact1"].'"     class="form-control input-sm"></strong>
                    <a  onclick="javascript:appel_contact_detail(\''.$i.'\')" class="btn btn-info btn-xs btn-block">Call  </a>			 
                    </th>
                    <th><strong><input  style="font-size:10pt;font-weight:bold;color:#000;"  align="center" onChange="javascript:modifier_gsm_contact2(\''.$row["fixe_contact2"].'\',\''.$i.'\',\''.$id_intervention.'\',\''.$id_gab.'\',\''.$row["niveau_escalade"].'\',\''.$row["type_contact"].'\')" id="gsm_contact2'.$i.'" name="gsm_contact2'.$i.'" type="text"   value="'.$row["fixe_contact2"].'"    class="form-control input-sm"></strong>
                    <a  onclick="javascript:appel_contact_detail2(\''.$i.'\')" class="btn btn-info btn-xs btn-block">Call 2  </a>			 
                    </th></tr>';
                    $i++;
                }
			}	
		else
			{
				return "";
			}
		mysqli_free_result($result);
	    }
	}
     mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_information_contact_gab3($id_intervention,$id_gab)
{
    // $SQL="SELECT `nom_contact`, `niveau_escalade`, `fonction_contact`, `nom_contact`, `fixe_contact1`, `fixe_contact2`, `adresse_mail`, `niveau_escalade`, `type_contact` FROM `new_list_contact_agence`
    // WHERE `terminal_id`='$id_gab'
    // GROUP BY `nom_contact`
    // ORDER BY `niveau_escalade`,`id_contact` ASC";
    echo '<table class="table"  style="font-size:12px;font-weight:bold;" class="table-responsive">';
    echo ' <tr style="color: #000;font-size:12px;background-color:#e98731;color:#ffffff;"> <th>Niveau Escaladé</th><th>Nom contact </th><th>Fonction </th><th>E-mail</th><th>Gsm</th><th>Tel</th></tr>';
    // view_add_contact($id_intervention,$id_gab,1);
    // view_add_contact($id_intervention,$id_gab,2);
    // view_add_contact($id_intervention,$id_gab,3);
    echo '	</table>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function vider_verif_declaration_gab()
{
    echo'<div class="col-sm-12" ></div>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_verif_declaration_incident_gab($id_gab)
{
    $att_des='Attention !!!  GAB désactivé';
    $att_dec='Attention !!!  Le gab est déja déclaré ';

    if ($_SESSION['lang']=='en')
    {
        $att_des='Warning !!! Cashpoint deactivated';
        $att_dec='Warning !!! Cashpoint is already declared';
    }
    $connexion=ma_db_connexion();
    $sql1 = "SELECT `terminal` FROM `new_list_gab` WHERE `id_activation`= 0 AND `terminal`  
	LIKE '".mysqli_real_escape_string($connexion,$id_gab)."'";
    $result1=mysqli_query($connexion,$sql1);
    if (!$result1)
    {
        error_log("Erreur SQL 1018: ".$sql1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1018 !');
    }
    if ($result1)
	{	
	    if(mysqli_num_rows($result1)>0)
	    {
	        while ($row = mysqli_fetch_assoc($result1))
            {
                echo'<div class="alert alert-danger" align="center"> <strong>'.$att_des.' </strong></div>';
            }
	    }
	    mysqli_free_result($result1);
	}

    $sql2 = "SELECT `id_gab` FROM `new_incident_gab` WHERE `etat_incident`= 0 AND `id_gab`  like '".$id_gab."'";
    $res2=mysqli_query($connexion,$sql2);
    if (!$res2)
    {
        error_log("Erreur SQL 1019: ".$sql2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1019 !');
    }
    if ($res2)
	{	
		if(mysqli_num_rows($res2)>0)
		{
			//while ($row = mysqli_fetch_assoc($res2)) 
            
                echo'<div class="alert alert-danger" align="center"> <strong>'.$att_dec.'</strong></div>';
            
		}
		mysqli_free_result($res2);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_verif_gab($id_gab)
{
    $connexion=ma_db_connexion();
    $sql1 = "SELECT `terminal` FROM `new_list_gab` WHERE `terminal` like '".mysqli_real_escape_string($connexion,$id_gab)."'";
    $req=mysqli_query($connexion,$sql1);
    if (!$req)
    {
        error_log("Erreur SQL 1020: ".$sql1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1020 !');
    }
    if ($req)
    {
        $data = mysqli_fetch_array($req);
        mysqli_free_result($req);
        return $data[0];
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_Ip_atm($id_gab)
{
	$connexion=ma_db_connexion();
    $sql1 = "SELECT `ip_adresse_gab` FROM `new_list_gab` WHERE `terminal` like '".mysqli_real_escape_string($connexion,$id_gab)."'";
   
    $req=mysqli_query($connexion,$sql1);
    if (!$req)
    {
        error_log("Erreur SQL 1021: ".$sql1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1021 !');
    }


   if ($req)
    {
        $data = mysqli_fetch_array($req);
        mysqli_free_result($req);
        return $data[0];
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get__info__type_gab($id)
{
$connexion=ma_db_connexion();

            $sql = "SELECT  `nom_fournisseur`
			FROM  `new_list_fournisseur`,  `new_list_gab` 
            WHERE `new_list_fournisseur`.`id_fournisseur`= `new_list_gab`.`id_fournisseur`	
			AND  `new_list_gab`.`terminal` like '".mysqli_real_escape_string($connexion,trim($id))."'";  

  $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1021: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1021 !');
    }				

if ($result) 
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["nom_fournisseur"];  	
					}
			}	
		else
			{
				return "";
			}
mysqli_free_result($result);	
			}				
				
				
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_gab_introuvable()
{
    $gab_inco='Attention GAB inconnue   !!!';
    $dec_gab=' Voulez-vous déclarer nouveau GAB';
    if ($_SESSION['lang']=='en')
    {
        $gab_inco='Attention ATM unknown !!!';
        $dec_gab=' Do you want to declare a new ATM';
    }
    echo'<br>
	<div class="alert alert-danger" align="center"> <strong>'.$gab_inco.'</strong><br>
	<br><a target="_blank" style="background-color:#DFC6C4;color:#3a1d19" href="detail_gab.php" class="btn-xs btn-block">  '.$dec_gab.'</a>

  </div>';
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_tel_agence($code_agence,$id_gab)
{
	
$tel1="";
$tel="";
$tel2="";
$connexion=ma_db_connexion();
$sql = "SELECT 	`tel` 	FROM  `new_list_agence` WHERE `new_list_agence`.`code_agence` 
like '".mysqli_real_escape_string($connexion,$code_agence)."'";

 $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1022: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1022 !');
    }

if ($result) 
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						$tel1 =trim($row["tel"]);
					}
			}	

		mysqli_free_result($result);	
	}


	
$sql2 = "SELECT 	`id_contact`,`tel1`,`tel2` 	FROM  `new_contact_agence` 
WHERE `new_contact_agence`.`code_agence` like '".mysqli_real_escape_string($connexion,$code_agence)."' 
AND `nom_contact` = '' ";
 $result=mysqli_query($connexion,$sql2);
    if (!$result)
    {
        error_log("Erreur SQL 1023: ".$sql2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1023 !');
    }

if ($result2=mysqli_query($connexion,$sql2) or die('Erreur   get_tel_agence 222 !<br>'.$sql2.'<br>'.mysqli_error())) 
	{	
		if(mysqli_num_rows($result2)>0)
			{
			while ($row2 = mysqli_fetch_assoc($result2)) 
					{
					
					$tel = trim($row["tel1"]).' '.trim($row["tel1"]).' '.trim($row["tel2"]).' '.trim($row["tel2"]);  
					$tel2=$tel."".$tel2;
						
					}
			}

		mysqli_free_result($result2);	
	}


				
	return 	$tel1."".$tel;	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_information_gab2($id_gab)
{
    $libel_gab='Libellé GAB	';
    $ip='Adresse IP';
    $type_gab='Type GAB';
    $n_ser='N° Série';
    $gest='Gestion';
    $gestion='Gestionnaire';
    $cd_agc='Code Agence';
    $agen='Agence';
    $tel_agen='Tel Agence';
    $region='Région';
    $ville='Ville';

    if ($_SESSION['lang']=='en')
    {
        $libel_gab='Cashpoint Name	';
        $ip='IP adress';
        $type_gab='Cashpoint type';
        $n_ser='Serial number';
        $gest='Management type';
        $gestion='Manager';
        $cd_agc='Branch code';
        $agen='Branch';
        $tel_agen='Phone Num';
        $region='Area';
        $ville='City';
    }
	$connexion=ma_db_connexion();
	$sql="SELECT `terminal`, `numero_serie`, `cdf`, `date_installation`, `emplacement`, 
    `type_emplacement`, `gestion`, `gestionnaire`, `nom_gab`, `ip_adresse_gab`, `type_gab`, 
    `code_bank`, `code_group`, `code_agence`, `libelle_agence`, `Importance`, `id_fournisseur`, `id_prestataire`, `ville` 
    FROM `new_list_gab` WHERE `terminal` LIKE '".mysqli_real_escape_string($connexion,trim($id_gab))."'";

	$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1024: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1024 !');
    }

    if ($result)
	{	
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {

                echo '	<table class="table table-responsive-sm table-hover table-outline mb-0">
		        <thead class="bg-light"><tr ><th></th><th></th><th></th></tr></thead>
		   
			    <tr><th class="text-center">'.$libel_gab.'</th><th class="text-center">:</th><th class="text-center">';echo 	$row["nom_gab"];echo '</th></tr>
			
			    <tr><th class="text-center">'.$ip.'</th><th class="text-center">:</th><th class="text-center">';	echo 	$row["ip_adresse_gab"];echo '</th></tr>
			
			    <tr><th class="text-center">'.$type_gab.' </th><th class="text-center">:</th><th class="text-center">';echo  get__info__type_gab($id_gab); echo '</th></tr>
			
			    <tr><th class="text-center">'.$n_ser.'</th><th class="text-center">:</th><th class="text-center">';echo 	$row["numero_serie"];	echo '</th></tr>';
			    echo '<tr><th class="text-center">'.$gest.'</th><th class="text-center">:</th><th class="text-center">';echo 	setEtatGestion($row["gestion"]);echo '</th></tr>
		
		        <tr><th class="text-center">'.$gestion.'</th><th class="text-center">:</th><th class="text-center">';echo 	get_gestionnaire_gab2($row["gestionnaire"]);echo '</th></tr>';
			
		        echo '<tr><th class="text-center">'.$cd_agc.'</th><th class="text-center">:</th><th class="text-center">'; echo $row["code_agence"];echo '</th></tr>
			
			    <tr><th class="text-center">'.$agen.'</th><th class="text-center">:</th><th class="text-center">';echo 	get_libelle_agence($row["code_agence"]);echo '</th></tr>
			
			    <tr><th class="text-center">'.$tel_agen.'</th><th class="text-center">:</th><th class="text-center"><div id="div_tel_gab'.$id_gab.'">';echo 	get_tel_agence($row["code_agence"],$id_gab);echo '</div></th></tr>';
			    echo 	get_horaires_cibles_ramadan($row["code_agence"]);echo '</th></tr>';
			    echo ' <tr><th class="text-center">'.$region.'</th><th class="text-center">:</th><th class="text-center">';
			    echo 	get_libelle_filiale2($row["code_bank"]);
			    echo '</th></tr> ';
			    echo ' <tr><th class="text-center">'.$ville.'</th><th class="text-center">:</th><th class="text-center">';echo $row["ville"];echo '</th></tr>';
			    echo'</table>';
            }
		}
		mysqli_free_result($result);
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_motif_incident2($id_motif,$terminal)
{
?>

				<label for="inputcauseaction" class="col-sm-3 control-label"><strong>Cause d'arrêt </strong></label>
					<div class="col-sm-9">
						 <input type="text" required name="inputcauseaction" id="inputcauseaction" class="form-control" value="<?php echo get_libelle_motifs($id_motif);?>"  onkeyup="autocomplet()"  
						 onFocus="javascript:get_generer_mail(this.value)" placeholder="Motif" data-type="search">
						 <ul class="dropdown-menu" id="terminal_list_id"></ul>										 
					</div>  
				

<?php
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_etat_contact2()
{
	echo '<option value=""></option>';
$sql = "SELECT 	`id_type`,	`libelle` FROM  `new_type_contact`";
	
	mysqli_query(ma_db_connexion(),"SET CHARACTER SET 'utf8'");
if ($result=mysqli_query(ma_db_connexion(),$sql) or die('Erreur   get_libelle_etat_contact2 !<br>'.$sql.'<br>'.mysqli_error())) 
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						echo '<option value="'.$row["id_type"].'">'.$row["libelle"].'</option>';
	
					}
			}	
		else
			{
				echo '<option value="0"></option>';
			}
mysqli_free_result($result);	
			}	
	
	
	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_motifs($id)
{
	  $connexion=ma_db_connexion();
$sql = "SELECT  `libelle_intevention` FROM  `new_action_intervention`	
WHERE  `new_action_intervention`.`id_intevention`  LIKE '".mysqli_real_escape_string($connexion,$id)."'";	

	 $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1025: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1025 !');
    }	
	
if ($result) 
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return trim($row["libelle_intevention"])."-".$id;	
					}
			}	
		else
			{
				return "";
			}
mysqli_free_result($result);	
			}		
		
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function afficher_ping($ipAtm)
{
    //echo "ipAtm : ".$ipAtm;
// echo '	<button  type="button" onclick= "javascript:pingGab( \''.$ipAtm.'\')" class="btn btn-default" data-dismiss="modal">Ping</button>   ';	
echo '	<button  type="button" class="btn btn-primary" onclick= "javascript:pingGab( \''.get_Ip_atm($ipAtm).'\',\'' . $ipAtm . '\')"  >Ping</button>   ';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_intervention_1_f($id)
{
	 $connexion=ma_db_connexion();
$sql = "SELECT 	`libelle_intevention` FROM  `new_action_intervention`	
WHERE 	`new_action_intervention`.`id_intevention`  =  '".mysqli_real_escape_string($connexion,$id)."'";

 $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1026: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1026 !');
    }
if ($result) 
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["libelle_intevention"];  	
					}
			}	
		else
			{
				return "";
			}
mysqli_free_result($result);	
	}	
	
	
	
	
}
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_action_intervention_incident($id)
{
	$connexion=ma_db_connexion();
$sql = "SELECT `id_action_intervention` FROM `new_intevention_incident`
 WHERE  `id_action_interv`  = '".mysqli_real_escape_string($connexion,$id)."'";


				
	 $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1022: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1022 !');
    }
if ($result) 
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["id_action_intervention"];  	
					}
			}	
		else
			{
				return 0;
			}
mysqli_free_result($result);	
	}		
		
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_max_id_action_fontionnelle($id_incident)
{
		$connexion=ma_db_connexion();
        $sql = "SELECT max(`id_action_interv`) as id_action        FROM `new_intevention_incident`       
		WHERE  `id_incident`  =  '".mysqli_real_escape_string($connexion,$id_incident)."'";
	
			
	 $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1027: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1027 !');
    }
if ($result) 
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["id_action"];  	
					}
			}	
		else
			{
				return 0;
			}
mysqli_free_result($result);	
	}			
			
			
    }	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_information_historique_gab($id_gab)
{
    $n_doss='N° Dossier';
    $date_arr='Date d\'arrêt';
    $date_rem='Date de remise';
    $caus_arr='Cause Arrêt';
    $non_hist='Pas d\'historique';

    if ($_SESSION['lang']=='en')
    {
        $n_doss='File number';
        $date_arr='Stop date';
        $date_rem='Uptime date';
        $caus_arr='Cause Stop';
        $non_hist='No history';

    }
    $connexion=ma_db_connexion();
    $sql = "SELECT 	`new_incident_gab`.`id_incident` as idincident,
    `new_incident_gab`.`id_gab`  as id_gab,  `date_arrete`, `date_remise`
    FROM `new_incident_gab`
    WHERE `new_incident_gab`.`id_gab` like '".mysqli_real_escape_string($connexion,$id_gab)."'
    GROUP BY `new_incident_gab`.`id_incident`
    ORDER BY `date_arrete` DESC
    LIMIT 20";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1028: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1028 !');
    }
    if($result)
    {
        $i=0;
        if(mysqli_num_rows($result)>0)
        {
            echo '<table  class="table table-responsive-sm table-hover table-outline mb-0">
                <thead class="bg-light text-dark">
                    <tr>
                        <th class="text-center">'.$n_doss.'</th>
                        
                        <th class="text-center">'.$date_arr.'</th>
                        
                        <th class="text-center">'.$date_rem.'</th>
                        
                        <th class="text-center">'.$caus_arr.'</th>
                    </tr>	
                </thead>
					';	
	
			while ($row = mysqli_fetch_assoc($result)) 
			{
			                if ($i % 2) {
                echo '<tr >';
                            }
                else
                            {
                echo '<tr >';
                            }
			
			echo'
									    <td class="text-center"><strong><a target="_blank" title="'.$n_doss.' : '.$row["idincident"].'" href="detail_gab.php?ternimal='.$row["id_gab"].'&id='.$row["idincident"].'" >'.$row["idincident"].'</a></strong></td>
										<td><strong>'.$row["date_arrete"].'</strong></td>

										<td class="text-center"><strong>';
				if ($row["date_remise"]=="0000-00-00 00:00:00")
				{
				echo "Hors service"; 
				}
				else
				{
				echo $row["date_remise"];
				}
				echo '</strong></td>

				<td class="text-center"><strong>';

				echo get_intervention_1_f(get_id_action_intervention_incident(get_max_id_action_fontionnelle($row["idincident"])));

				echo '</strong>
				</td>
									</tr>	
			';
			$i++;
			}
			echo '</table>'	;
			
	}
	else
	{
	    echo '<table class="table table-responsive-sm table-hover table-outline mb-0">
                    <thead class="thead-light">
                        <tr>
                            <th class="text-center">'.$non_hist.'</th>
                        </tr>
                    </thead>
								</table>
					';	
	}
mysqli_free_result($result);		
}	
}
/*******************************************************************************************************************************************/
function getDetailIncident_actuel($terminal,$Inc){

	/*Détail   Actuel*/
	$detail=getDetailGabByTerminal($terminal);
	$donnDActuel=getDescriptionIdByEvent2($detail["last_event"]);
	$motifActuel=mysqli_fetch_assoc($donnDActuel);
	
	/*Détail   Incident*/
	$detailIncident=getDetailIncident_declarer($Inc);
	$donnInc=getDescriptionIdByEvent2($detailIncident["last_event"]);
	$motifInc=mysqli_fetch_assoc($donnInc);
	
	echo"
<td><a style='vertical-align:middle' data-toggle='modal' href='#myModal".$terminal."'><span class='glyphicon glyphicon-search'></span></a>"; 
		 echo"
		 <div class='modal fade' id='myModal".$terminal."' role='dialog'>
			<div id='modal_d' class='modal-dialog '>
				<div class='modal-content'>
					<div class='modal-header'>
						<button type='button' class='close' data-dismiss='modal'>&times;</button>
						<div style='font-size:13pt;color: #3a1d19 !important;' class='modal-title' >Détail Incident N°".$Inc."<br>";
						
						// echo getDateLastRaffra($detail["terminal_atm_grouping"]);
						echo "</div>";
						//warning_date_raf_for_detail($detail["terminal_atm_grouping"])."
					echo "</div>
					<div class='modal-body' style='padding:35px 35px;'>
		
								<div class='row'>
								<div class='col-sm-6'>
									<div class='panel-heading' style='background-color:#e7722c;font-size:11pt;color:#fff;line-height: 80%;'>Statuts Cassettes (Actuel)</div>
										<div style='margin-left: 2px;font-size:9pt;line-height: 120%;' class='panel-body'>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurCassette($detail["cassette1_status"])."'>
															<div class='col-sm-4'>
																<label>C1</label>
															</div>
															<div class='col-sm-3'>
																<label style='font-weight: normal;'>".$detail["cassette1_available_amount"]."</label>
															</div>
															<div class='col-sm-5'>
																<label style='font-weight: normal;'>".getDescriptionCassete($detail["cassette1_status"]);	
										echo"				</label>
															</div>
											</div>
											<div class='row' style='color:".getCouleurCassette($detail["cassette2_status"])."'>
															<div class='col-sm-4'>
																<label>C2</label>
															</div>
															<div class='col-sm-3'>
																<label style='font-weight: normal;'>".$detail["cassette2_available_amount"]."</label>
															</div>
															<div class='col-sm-5'>
																<label>".getDescriptionCassete($detail["cassette2_status"]);	
										echo"  					</label style='font-weight: normal;'>
															</div>
											</div>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurCassette($detail["cassette3_status"])."'>
															<div class='col-sm-4'>
																<label>C3</label>
															</div>
															<div class='col-sm-3'>
																<label style='font-weight: normal;'>".$detail["cassette3_available_amount"]."</label>
															</div>
															<div class='col-sm-5'>
																<label style='font-weight: normal;'>".getDescriptionCassete($detail["cassette3_status"]);	   	
										echo"					</label>
															</div>
											</div>
											<div class='row'  style='color:".getCouleurCassette($detail["cassette4_status"])."'>
															<div class='col-sm-4'>
																<label>C4</label>
															</div>
															<div class='col-sm-3'>
																<label style='font-weight: normal;'>".$detail["cassette4_available_amount"]."</label>
															</div>
															<div class='col-sm-5'>
																<label style='font-weight: normal;'>".getDescriptionCassete($detail["cassette4_status"]);	
										echo"					</label>
															</div>
											</div>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detail["cassette_reject_status"])."'>
															<div class='col-sm-4'>
																<label>CR:</label>
															</div>
															<div class='col-sm-8'>
																<label style='font-weight: normal;'>". getDescriptionPeripherique($detail["cassette_reject_status"]);	
										echo"					</label>
															</div>
											</div>
										</div>
									<div class='panel-heading' style='background-color:#e7722c;font-size:11pt;color:#fff;line-height: 80%;'>Statuts Périphériques (Actuel)</div>
										<div style='margin-left: 2px;font-size:9pt;line-height: 120%;' class='panel-body'>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detail["dispenser"])."'>
														<div class='col-sm-4'>
															<label>Separateur</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".getDescriptionPeripherique($detail["dispenser"]);		
										echo"				</label>
														</div>
											</div>
											<div class='row' style='color:".getCouleurPeripherique($detail["card_reader_status"])."'>
														<div class='col-sm-4'>
															<label>Lecteur de carte</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".getDescriptionPeripherique($detail["card_reader_status"]);	
												
										echo"				</label>
														</div>
											</div>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detail["log_printer_status"])."'>
														<div class='col-sm-4'>
															<label>Journal</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".getDescriptionPeripherique($detail["log_printer_status"]);			
										echo"				</label>
														</div>
											</div>
											<div class='row' style='color:".getCouleurPeripherique($detail["pinpad_status"])."'>
														<div class='col-sm-4'>
															<label>Pinpad</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".getDescriptionPeripherique($detail["pinpad_status"]);	
										echo"				</label>
														</div>
											</div>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detail["encryption_device_status"])."'>
														<div class='col-sm-4'>
															<label>Clavier EPP</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".getDescriptionPeripherique($detail["encryption_device_status"]);	
										echo"				</label>
														</div>
											</div>
											
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detail["safe_box_status"])."'>
														<div class='col-sm-4'>
															<label>Porte coffre</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".getDescriptionPeripherique($detail["safe_box_status"]);	
										echo"				</label>
														</div>
											</div>
										</div>
										<div class='panel-heading' style='background-color:#e7722c;font-size:11pt;color:#fff;line-height: 80%;'>Evénements (Actuel)</div>
										<div style='margin-left: 2px;font-size:9pt;line-height: 120%;' class='panel-body'>
											<div style='background-color:#f9f9f9' class='row'>
														<div class='col-sm-4'>
															<label>Dernière Transaction</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>" .$detail["last_transaction_date"]."</label>
														</div>
											</div>
											<div class='row'>
														<div class='col-sm-4'>
															<label>Dernier événement</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>" .$motifActuel["libelle_intevention"]."</label>
														</div>
											</div>"
											;
											echo "<div style='background-color:#f9f9f9' class='row'>
														<div class='col-sm-4'>
															<label>Date dernier événement</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>" .$detail["last_event_date"]."</label>
														</div>
												  </div> ";
											
											echo"
											
											<div class='row'>
														<div class='col-sm-4'>
															<label>Dernière mise en service</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>" .$detail["last_in_service"]."</label>
														</div>
											</div>
											
								</div>
							</div>
							<div class='col-sm-6'>
										<div class='panel-heading' style='background-color:#e7722c;font-size:11pt;color:#fff;line-height: 80%;'>Statuts Cassettes (Incident)</div>
										<div style='margin-left: 2px;font-size:9pt;line-height: 120%;' class='panel-body'>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurCassette($detailIncident["etat_c1"])."'>
															<div class='col-sm-4'>
																<label>C1</label>
															</div>
															<div class='col-sm-3'>
																<label style='font-weight: normal;'>".$detailIncident["montant_c1"]."</label>
															</div>
															<div class='col-sm-5'>
																<label style='font-weight: normal;'>".getDescriptionCassete($detailIncident["etat_c1"]);	
										echo"				</label>
															</div>
											</div>
											<div class='row' style='color:".getCouleurCassette($detailIncident["etat_c2"])."'>
															<div class='col-sm-4'>
																<label>C2</label>
															</div>
															<div class='col-sm-3'>
																<label style='font-weight: normal;'>".$detailIncident["montant_c2"]."</label>
															</div>
															<div class='col-sm-5'>
																<label style='font-weight: normal;'>".getDescriptionCassete($detailIncident["etat_c2"]);	
										echo"  					</label>
															</div>
											</div>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurCassette($detailIncident["etat_c3"])."'>
															<div class='col-sm-4'>
																<label>C3</label>
															</div>
															<div class='col-sm-3'>
																<label style='font-weight: normal;'>".$detailIncident["montant_c3"]."</label>
															</div>
															<div class='col-sm-5'>
																<label style='font-weight: normal;'>".getDescriptionCassete($detailIncident["etat_c3"]);		
										echo"					</label>
															</div>
											</div>
											<div class='row'  style='color:".getCouleurCassette($detailIncident["etat_c4"])."'>
															<div class='col-sm-4'>
																<label>C4</label>
															</div>
															<div class='col-sm-3'>
																<label style='font-weight: normal;'>". $detailIncident["montant_c4"]."</label>
															</div>
															<div class='col-sm-5'>
																<label style='font-weight: normal;'>".getDescriptionCassete($detailIncident["etat_c4"]);	
										echo"					</label>
															</div>
											</div>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detailIncident["etat_cas_rejet"])."'>
															<div class='col-sm-4'>
																<label>CR:</label>
															</div>
															<div class='col-sm-8'>
																<label style='font-weight: normal;'>".getDescriptionPeripherique($detailIncident["etat_cas_rejet"]);	
										echo"					</label>
															</div>
											</div>
										</div>
									<div class='panel-heading' style='background-color:#e7722c;font-size:11pt;color:#fff;line-height: 80%;'>Statuts Périphériques (Incident)</div>
										<div style='margin-left: 2px;font-size:9pt;line-height: 120%;' class='panel-body'>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detailIncident["etat_sep"])."'>
														<div class='col-sm-4'>
															<label>Separateur</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".getDescriptionPeripherique($detailIncident["etat_sep"]);		
										echo"				</label>
														</div>
											</div>
											<div class='row' style='color:".getCouleurPeripherique($detailIncident["etat_lecteur"])."'>
														<div class='col-sm-4'>
															<label '>Lecteur de carte</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".getDescriptionPeripherique($detailIncident["etat_lecteur"]);	
												
										echo"				</label>
														</div>
											</div>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detailIncident["etat_journal"])."'>
														<div class='col-sm-4'>
															<label>Journal</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".getDescriptionPeripherique($detailIncident["etat_journal"]);			
										echo"				</label>
														</div>
											</div>
											<div class='row' style='color:".getCouleurPeripherique($detailIncident["etat_pinpad"])."'>
														<div class='col-sm-4'>
															<label>Pinpad</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".getDescriptionPeripherique($detailIncident["etat_pinpad"]);	
										echo"				</label>
														</div>
											</div>
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detailIncident["etat_epp"])."'>
														<div class='col-sm-4'>
															<label>Clavier EPP</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".getDescriptionPeripherique($detailIncident["etat_epp"]);	
										echo"				</label>
														</div>
											</div>
											
											<div class='row' style='background-color:#f9f9f9;color:".getCouleurPeripherique($detailIncident["etat_pc"])."'>
														<div class='col-sm-4'>
															<label>Porte coffre</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".getDescriptionPeripherique($detailIncident["etat_pc"]);	
										echo"				</label>
														</div>
											</div>
										</div>
										<div class='panel-heading' style='background-color:#e7722c;font-size:11pt;color:#fff;line-height: 80%;'>Evénements (Incident)</div>
										<div style='margin-left: 2px;font-size:9pt;line-height: 120%;' class='panel-body'>
											<div style='background-color:#f9f9f9' class='row'>
														<div class='col-sm-4'>
															<label>Dernière Transaction</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>" .$detailIncident["last_Trans"]."</label>
														</div>
											</div>
											<div class='row'>
														<div class='col-sm-4'>
															<label>Dernier événement</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".$motifInc["libelle_intevention"]."</label>
														</div>
											</div>"
											; 
											echo "<div style='background-color:#f9f9f9' class='row'>
														<div class='col-sm-4'>
															<label>Date dernier événement</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".$detailIncident["last_event_date"]."</label>
														</div>
												  </div> ";
											
											echo"
											
											<div class='row'>
														<div class='col-sm-4'>
															<label>Dernière mise en service</label>
														</div>
														<div class='col-sm-8'>
															<label style='font-weight: normal;'>".$detailIncident["last_inserv"]."</label>
														</div>
											</div>
											
								</div>
					</div>
					</div>
					</div>
					<div class='modal-footer'>
						
						<button type='button' class='btn btn-default' data-dismiss='modal'>Fermer</button>
						
					</div>
			</div>
		</div>
		 
		
";
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getMailFournisseur($id_incident)
{
	 $connexion=ma_db_connexion();
$sql = "SELECT `message`	FROM  `retourMailFournisseur` 	WHERE  `Dossier`  = '".mysqli_real_escape_string($connexion,$id_incident)."'";
$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1029: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1029 !');
    }	
if ($result) 
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
								echo '<div class="table-responsive">
								<table  class="table table-striped " >
									<tr>
										<th>'.nl2br($row["message"]).'</th>
									</tr>
								</table>
								</div>';
					}
			}	
		else
			{
				echo "Mail fournisseur non trouvé";
			}
mysqli_free_result($result);	
	}

	
	
}
 
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function get_array_information_action_intervention($id_intervention)
    {
		 $connexion=ma_db_connexion();
        $sql = "SELECT    `id_action_intervention`, `degre_intervention`,`id_incident`,`id_affectation`,`degre_appel`,`etat_contact` 
			    FROM `new_intevention_incident`
				WHERE `new_intevention_incident`.`id_action_interv`  =  '".mysqli_real_escape_string($connexion,$id_intervention)."'";

				  $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1030: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1030 !');
    }
				if ($result) 
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
				return  array($row["degre_intervention"], 
							 $row["id_incident"], 
							 $row["id_action_intervention"], 
							 $row["id_affectation"], 
							 $row["degre_appel"], 
							 $row["etat_contact"]); 
					}
          }  
			else
			{
				return  array("","","","","",""); 
			}	
mysqli_free_result($result);	
	}


			
    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_return_information_terminal($id)
{
	 $connexion=ma_db_connexion();
$sql = "SELECT 	`terminal`, `nom_gab`  FROM  `new_incident_gab`, `new_list_gab` 
		WHERE `new_incident_gab`.`id_gab`=`new_list_gab`.`terminal` 
		AND   `new_incident_gab`.`id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
	  $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1031: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1031 !');
    }	
if ($result) 
	{
	if(mysqli_num_rows($result)>0)
	{
			while ($row = mysqli_fetch_assoc($result)) 
			{
				return	array($row["terminal"],$row["nom_gab"]);
			}
	}
	else
	{	
			return array('','');
	}
	mysqli_free_result($result);
	}	
}
 
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_array_degre_inertvention($id)
{
	  $connexion=ma_db_connexion();
$sql = "SELECT 	 `degre` FROM  `new_action_intervention`
WHERE 	`new_action_intervention`.`id_intevention`  =  '".mysqli_real_escape_string($connexion,$id)."'";

	 $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1034: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1034 !');
    }
if ($result) 
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["degre"];  	
					}
			}	
		else
			{
				return "";
			}
mysqli_free_result($result);	
	}	
	
	
}
	//////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_categorie_intervention_prestataire($intervention)
{
	$connexion=ma_db_connexion();
$sql = "SELECT `id_categories` FROM `new_action_intervention` WHERE  `id_intevention` = '".mysqli_real_escape_string($connexion,$intervention)."'";
 $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1032: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1032 !');
    }		
if ($result) 
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["id_categories"];  	
					}
			}	
		else
			{
					return 0;
			}
mysqli_free_result($result);	
	}	
	
	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_date_rappel_max($id_incident)
{
	$connexion=ma_db_connexion();
 $sql = "SELECT max(`date_rappel`) AS daterappel FROM `new_intevention_incident` 
 WHERE `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
	 
  $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1033: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1033 !');
    }
if ($result) 
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["daterappel"];  	
					}
			}	
		else
			{
					return "";
			}
mysqli_free_result($result);	
	}				
				
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_id_intervention_max($id_incident)
{
	 $connexion=ma_db_connexion();
            $sql = "SELECT max(`id_action_interv`) AS id_action_interv FROM `new_intevention_incident` 
			WHERE `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
		 
  $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1035: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1035 !');
    }		
				
if ($result) 
	{	
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result)) 
					{
						return $row["id_action_interv"];  	
					}
			}	
		else
			{
					return "";
			}
mysqli_free_result($result);	
	}					
				
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  function update_modifier_date_rappel_incident($id_incident,$date_rappel)
  {
	  $connexion=ma_db_connexion();
	  
                       $sql="UPDATE `new_incident_gab` SET 
					   `date_derniere_interv`='".mysqli_real_escape_string($connexion,$date_rappel)."',
					   `date_derniere_rappel`='".mysqli_real_escape_string($connexion,$date_rappel)."'
                      WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
					
	$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1036: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1036 !');
    }
	mysqli_free_result($result);
	
					  $SQL11="UPDATE `new_incident_gab_ouvert` SET 
					   `date_derniere_interv`='".mysqli_real_escape_string($connexion,$date_rappel)."',
					   `date_derniere_rappel`='".mysqli_real_escape_string($connexion,$date_rappel)."'
                      WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
		$result2=mysqli_query($connexion,$SQL11);
    if (!$result2)
    {
        error_log("Erreur SQL 1037: ".$SQL11."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1037 !');
    }
					mysqli_free_result($result2);	
					  
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  function update_modifier_date_rappel_intervention_incident($id_intervention,$date_rappel)
  {
      $connexion = ma_db_connexion();
      $sql = "UPDATE `new_intevention_incident` SET 
					   `date_rappel`='" . mysqli_real_escape_string($connexion, $date_rappel) . "'
                      WHERE  `id_action_interv` = '" . mysqli_real_escape_string($connexion, $id_intervention) . "'";
      $result = mysqli_query($connexion, $sql);
      if (!$result) {
          error_log("Erreur SQL 1038: " . $sql . "  " . mysqli_error($connexion));
          die('ERREUR QUERY 1038 !');
          mysqli_free_result($result);

          $SQL11 = "UPDATE `new_intevention_incident_tmp` SET 
					   `date_rappel`='" . mysqli_real_escape_string($connexion, $date_rappel) . "'
                      WHERE  `id_action_interv` = '" . mysqli_real_escape_string($connexion, $id_intervention) . "'";

          $result2 = mysqli_query($connexion, $SQL11);
          if (!$result2) {
              error_log("Erreur SQL 1039: " . $SQL11 . "  " . mysqli_error($connexion));
              die('ERREUR QUERY 1039 !');
          }
          mysqli_free_result($result2);

      }
  }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function supprimer_action_intervention_gab($id_incident,$id_intervention)
{
	/**CORBEILLE Supression Intervention**/

	$connexion=ma_db_connexion();

	$sqlSelectIntervention="SELECT id_action_interv,id_gab,date_action,date_prise_en_charge,date_prise_en_charge2,date_prise_charge_gestionnaire,
	num_affectation,id_affectation,degre_appel,type_contact,etat_contact,personne_avisee,id_action_intervention,id_niveau_intervention,last_Trans,
	etat_cloture,date_cloture,date_rappel,nbr_tentative,nbr_escalade,id_utilisateur,degre_intervention,motif_cloture,auto_cloture
	FROM new_intevention_incident WHERE `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";

	 $selectIntervention=mysqli_query($connexion,$sqlSelectIntervention);
    if (!$selectIntervention)
    {
        error_log("Erreur SQL 1040: ".$sqlSelectIntervention."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1040 !');
    }
		if(mysqli_num_rows($selectIntervention)>0){
			while ($list= mysqli_fetch_assoc($selectIntervention)){
				$id_action_interv= $list["id_action_interv"];
				$id_gab= $list["id_gab"];
				$date_action= $list["date_action"];
				$date_prise_en_charge= $list["date_prise_en_charge"];
				$date_prise_en_charge2= $list["date_prise_en_charge2"];
				$date_prise_charge_gestionnaire= $list["date_prise_charge_gestionnaire"];
				$num_affectation= $list["num_affectation"];
				$id_affectation= $list["id_affectation"];
				$degre_appel= $list["degre_appel"];
				$type_contact= $list["type_contact"];
				$etat_contact= $list["etat_contact"];
				$personne_avisee= $list["personne_avisee"];
				$id_action_intervention= $list["id_action_intervention"];
				$id_niveau_intervention= $list["id_niveau_intervention"];
				$last_Trans= $list["last_Trans"];
				$etat_cloture= $list["etat_cloture"];
				$date_cloture= $list["date_cloture"];
				$date_rappel= $list["date_rappel"];
				$nbr_tentative= $list["nbr_tentative"];
				$nbr_escalade= $list["nbr_escalade"];
				$id_utilisateur= $list["id_utilisateur"];
				$degre_intervention= $list["degre_intervention"];
				$motif_cloture= $list["motif_cloture"];
				$auto_cloture= $list["auto_cloture"];

			}

	}
	/************************************/

$sqltemp = "DELETE FROM `new_intevention_incident_tmp` WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id_intervention)."'";

  $rs1=mysqli_query($connexion,$sqltemp);
    if (!$rs1)
    {
        error_log("Erreur SQL 1041: ".$sqltemp."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1041 !');
    }



mysqli_free_result($rs1);

$sql = "DELETE FROM `new_intevention_incident` WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id_intervention)."'";

  $rs=mysqli_query($connexion,$sql);
    if (!$rs)
    {
        error_log("Erreur SQL 1042: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1042 !');
    }
mysqli_free_result($rs);



update_modifier_date_rappel_incident($id_incident,get_return_date_rappel_max($id_incident));
update_modifier_date_rappel_intervention_incident(get_return_id_intervention_max($id_incident),get_return_date_rappel_max($id_incident));
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_select_return_libelle3($id="")
{
	$connexion=ma_db_connexion();
      if($id==""){$id="%";}

      $SQL="SELECT   `id_intevention`, `libelle_intevention` FROM `new_action_intervention` 
      WHERE  `id_intevention`  =  '".mysqli_real_escape_string($connexion,$id)."'";

	 $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 1043: ".$SQL."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1043 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["libelle_intevention"];
					}
			}
		else
			{
				return "";
			}
mysqli_free_result($result);
	}


}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_change_dateprisebcprappel($dateprisebcp,$id_incident,$idaction)
{


	  if (($dateprisebcp)=="0000-00-00 00:00:00")
		{
			echo '<a> Cliquez ici </a>';
		}
	 else
	    {
			echo '<a>'.$dateprisebcp.'</a>';

		}

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_change_affectation_appel($nmaffectation,$id_incident,$idaction)
{


	  if (($nmaffectation)=="")
		{
			echo '<a onClick="javascript:get_nmaffectationappel(\''.$nmaffectation.'\',\''.$id_incident.'\',\''.$idaction.'\')" > Cliquez ici </a>';
		}
	 else
	    {
			echo '<a onClick="javascript:get_nmaffectationappel(\''.$nmaffectation.'\',\''.$id_incident.'\',\''.$idaction.'\')" >'.$nmaffectation.'</a>';

		}

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_detail_nouveau_appel_gab($incident)
{

echo '
<form class="form-horizontal" role="form">
<div  class="form-group">
<label <for="input_terminal" class="col-sm-2 control-label"></label>
				<div class="col-sm-10">
				</div>
				</div>';

            $SQL = "SELECT `date_action`,`id_incident`, `date_rappel`, `nbr_tentative`, `id_action_interv`, `id_action_intervention`, `degre_appel`, `date_prise_en_charge`,  `date_rappel`, 
			`id_niveau_intervention`,  `num_affectation`,  `nbr_escalade`, `id_utilisateur`
             FROM   `new_intevention_incident`
			 WHERE id_incident =  '".$incident."' 
			 GROUP BY `degre_appel`
			 ";

if ($result=mysqli_query(ma_db_connexion(),$SQL) or die('Erreur   get_detail_nouveau_appel_gab !<br>'.$SQL.'<br>'.mysqli_error()))
	{

        if(mysqli_num_rows($result)>0)
        {$i=0;
		echo '<small>';
           echo '<table style="font-size:11px;font-weight:bold;" class="table table-striped"> ';
          while ($row = mysqli_fetch_assoc($result))
              {$k=$i+1;

		  echo ' <tr><th colspan=10 style="font-size:12px;color:#000;text-align:center">N° Appel : '.$row["degre_appel"].'</th></tr>';
          echo ' <tr>';
          echo ' <th>#</th>
		  <th ><strong>Cause d\'arrêt</strong></th>
		 <!--<th ><strong>Nun Affectation </strong></th>-->
		  <th ><strong>Date prise en charge </strong></th>
		  <th ><strong>Date Rappel/clôture </strong></th>
		  <th ><strong>Utilisateur</strong></th>
			</tr>';
			echo '<tr>';
			echo '<th><strong>'.$row["nbr_tentative"].'</strong></th>';
			echo '<th><strong>'.get_select_return_libelle3($row["id_action_intervention"]).'</strong></th>';
		//	echo '<th><div id="getaffectationappel'.$row["id_action_interv"].'">';
					//get_change_affectation_appel($row["num_affectation"],$row["id_incident"],$row["id_action_interv"]);
					//echo '</div></th>';
			echo '<th><div id="getdateddrappel'.$row["id_action_interv"].'">';
					get_change_dateprisebcprappel(min_date_declaration($row["id_action_interv"],$row["degre_appel"]),$row["id_incident"],$row["id_action_interv"]);
					echo'</div></th>';
			echo '<th><div id="getdateddfrappel'.$row["id_action_interv"].'">';
					get_change_ddf_rappel(max_date_rappel($row["id_action_interv"],$row["degre_appel"]),$row["id_incident"],$row["id_action_interv"],$row["degre_appel"]);
					echo '</div></th>';
			echo '<th><strong>'.get_utilisateur($row["id_utilisateur"]).'</strong></th>';
			echo '</tr>';
			$i++;
			   }
        echo '</table>';
        echo '</small>';
        }

mysqli_free_result($result);
	}


echo '</form>				
';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
function get_fournisseur($code_frss)
{
	$connexion=ma_db_connexion();
$sql = "SELECT `id_fournisseur`, `nom_fournisseur` FROM `new_list_fournisseur` 
WHERE `id_fournisseur` = '".mysqli_real_escape_string($connexion,$code_frss)."'";
	$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1044: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1044 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["nom_fournisseur"];
					}
			}
		else
			{
				return "";
			}
mysqli_free_result($result);
	}


}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_max_id_degre_appel($id_incident)
{
	$connexion=ma_db_connexion();
            $sql = "SELECT max(`degre_appel`) AS degre_appel FROM `new_intevention_incident`
			WHERE `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";

  $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1045: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1045 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["degre_appel"]+1;
					}
			}
		else
			{
				return 1;
			}
mysqli_free_result($result);
	}



}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_type_gab_incident($id)
{
	$connexion=ma_db_connexion();
$sql = "SELECT 	`id_fournisseur` FROM  `new_list_gab`	WHERE 	`new_list_gab`.`terminal` like '".mysqli_real_escape_string($connexion,$id)."'";
 $result=mysqli_query($connexion,$sql);

    if (!$result)
    {
        error_log("Erreur SQL 1046: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1046 !');
    }

if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["id_fournisseur"];
					}
			}
		else
			{
				return "";
			}
mysqli_free_result($result);
	}

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_motif_incident($id)
{

	 $connexion=ma_db_connexion();
$sql = "SELECT 	`id_action_intervention` FROM  `new_intevention_incident`	
WHERE 	`new_intevention_incident`.`id_action_interv` = '".mysqli_real_escape_string($connexion,$id)."'";
  $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1047: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1047 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["id_action_intervention"];
					}
			}
		else
			{
				return "";
			}
mysqli_free_result($result);
	}

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_gestionnaire_incident($id)
{
	$connexion=ma_db_connexion();
$sql = "SELECT 	`gestionnaire` FROM  `new_list_gab`	WHERE 	`new_list_gab`.`terminal` 
like '".mysqli_real_escape_string($connexion,$id)."'";

  $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1048: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1048 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["gestionnaire"];
					}
			}
		else
			{
				return "";
			}
mysqli_free_result($result);
	}


}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_max_id_action_intervention($id)
 {
	   $connexion=ma_db_connexion();
      $sql="SELECT    MAX(`id_action_interv`) as idaction  FROM `new_intevention_incident`  
	  WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
	   $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1049: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1049 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["idaction"];
					}
			}
		else
			{
				return 0;
			}
mysqli_free_result($result);
	}

 }
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_gab_incident($id)
{
	 $connexion=ma_db_connexion();
$sql = "SELECT 	`id_gab` FROM  `new_incident_gab`	
WHERE 	`new_incident_gab`.`id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
		  $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1050: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1050 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["id_gab"];
					}
			}
		else
			{
				return "";
			}
mysqli_free_result($result);
	}



}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function max_date_rappel($id,$degree_appel)
{
	  $connexion=ma_db_connexion();
            $sql = "SELECT max(`date_rappel`) AS date_rappel 
			FROM `new_intevention_incident` 
			WHERE `id_action_interv` = '".mysqli_real_escape_string($connexion,$id)."' AND  `degre_appel` = '".mysqli_real_escape_string($connexion,$degree_appel)."'";

	$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1051: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1051 !');
    }

if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["date_rappel"];
					}
			}
		else
			{
				return "0000-00-00 00:00:00";
			}
mysqli_free_result($result);
	}


}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_change_ddf_rappel($dateddfbcp,$id_incident,$idaction)
{


	  if (($dateddfbcp)=="0000-00-00 00:00:00")
		{
			echo '<a > Cliquez ici </a>';
		}
	 else
	    {
			echo '<a >'.$dateddfbcp.'</a>';

		}

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function min_date_declaration($id,$degree_appel)
{
	$connexion=ma_db_connexion();
            $sql = "SELECT min(`date_prise_en_charge`) AS date_prise_en_charge 
			FROM `new_intevention_incident` 
			WHERE `id_action_interv` = '".mysqli_real_escape_string($connexion,$id)."' AND  `degre_appel` = '".mysqli_real_escape_string($connexion,$degree_appel)."'";
$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1052: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1052 !');
    }

if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["date_prise_en_charge"];
					}
			}
		else
			{
				return "0000-00-00 00:00:00";
			}
mysqli_free_result($result);
	}


}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function get_numero_affectation($id)
    {
		$connexion=ma_db_connexion();
        $sql = "SELECT  `num_affectation`   
		FROM `new_incident_gab`   WHERE `id_incident`  =  '".mysqli_real_escape_string($connexion,$id)."'";
$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1053: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1053 !');
    }

if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["num_affectation"];
					}
			}
		else
			{
				return "";
			}
mysqli_free_result($result);
	}


   }
///////////////////////////////////////////////////////////////////////////////////////
function get_mail_nouveau_appel1($id_gab,$motif,$date_intervention,$id_intervention,$gestionnaire)
{
$codeAgence=get_cd_agence($id_gab);
$astreinteGAB=getContactGABAstreinte($codeAgence,$gestionnaire);
$astreinteGAB2=getContactGABAstreinte2($codeAgence,$gestionnaire);
$mail=get_verif_mail_incident_gab($motif,$id_gab,$gestionnaire);
echo '

<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingThree1" style="font-size:13px;font-weight:bold;color: #fff;background-color:#e98731">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree1" aria-expanded="false" aria-controls="collapseThree1">
         <strong> Afficher E-mail2 ====> ('.$gestionnaire.') </strong>
        </a>
      </h4>
    </div>
    <div id="collapseThree1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree1">
      <div class="panel-body">
        <table class="table table-bordered table-hover " style="border-left: 2px solid #F96464;;border-right: 2px solid #F96464;;border-top: 2px solid #F96464;border-bottom: 2px solid #F96464;">
            <tr>
                <th colspan="2">
                    <strong>
                        <p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> AA :  '; if($gestionnaire<>"AGENCE"){echo $mail[0];}else{echo $mail[0];}echo '</p>
                        <p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> CC :  '; if($gestionnaire<>"AGENCE"){echo $mail[1];}else{echo $mail[1];}echo '</p>
                        <p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> GAB : '. get_return_nom_gab_declarer($id_gab).'</p>
                    </strong>
                    <strong>
                        <p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> OBJET : '.$mail[3].'</p>
                    </strong>
                    <div id="code01">
                        <strong>';
                            $message=str_replace("num_terminal",$id_gab,$mail[2]);
                            $message=str_replace("nom_terminal",get_return_nom_gab_declarer($id_gab),$message);
                            $message=str_replace("num_banque",get_return_nom_banque_abi2($id_gab),$message);
                            $message=str_replace("tel_agence",getTelAgence($id_gab),$message);
                            $message=str_replace("nom_filiale",get_nom_filiale(get_id_code_filiale($id_gab)),$message);
                            $message=str_replace("date_iertvention",$date_intervention,$message);
                            $message=str_replace("num_serie",get_return_num_serie($id_gab),$message);
                            $message=str_replace("responsableGAB",$astreinteGAB2,$message);
                            $message=str_replace("remarque","",$message);
                            // $message=str_replace("date_iertvention",date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))),$message);
                            $message=str_replace("motif","motif : «".get_lebelle_declaration($motif)."»",$message);
                            echo '<p style="margin-left: 14px;font-family: Calibri;font-size: small;font-weight:normal;">'.nl2br($message).'</p>';
                            echo '</strong>
                        </div>
                </th>
            </tr>
            <tr>
           
                <th><a onClick="javascript:Select_code(\'code01\');"class="btn btn-info btn-xs btn-block"> Sélectionné</a></th>
                <th>';
                    $message=html_entity_decode_outlouk($message);
                    if($gestionnaire<>"AGENCE")// verifer AGENCE/GF BCC
                        {
                            $a_mail= $mail[0];
                            $cc_mail= $mail[1];
                        }
                    else
                    {
                        $a_mail= $mail[0];
                        $cc_mail= $mail[1];
                    }
                    $de_mail="supervision_GAB@cfgbank.com";
                    $bcc="";
					$bcc="";

					$obj=str_replace("num_terminal",$id_gab,$mail[3]);
					$obj=str_replace("nom_filiale",get_nom_filiale(get_id_code_filiale($id_gab)),$obj);
					$obj=str_replace("nom_terminal",get_return_nom_gab_declarer($id_gab),$obj);
					$obj=str_replace("responsable_gab",$astreinteGAB,$obj);

							  ?>
									 <a  class="btn btn-success btn-xs btn-block" href="mailto:<?php echo $a_mail;?>
									 ?From=<?php echo $de_mail;?>
									 &cc=<?php echo $cc_mail;?><?php echo $bcc;?>
									 &subject=<?php echo $obj?>
									 &body=<?php echo  ($message);?>">
									 <?php echo "Générer mail";?></a>
                     <?php
                echo '</th>
            </tr>
        </table>
	  </div>
    </div>
  </div>
</div>

';
}
///////////////////////////////////////////////////////////////////////////////////////
function getCodeAgenceBCP($id_gab)
{
    $connexion=ma_db_connexion();
$sql = "SELECT `code_agence` FROM   `new_list_gab` WHERE `terminal`='".mysqli_real_escape_string($connexion,$id_gab)."'";
$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1053: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1053 !');
    }

if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["code_agence"];
					}
			}
		else
			{
				return 0;
			}
mysqli_free_result($result);
	}
}
///////////////////////////////////////////////////////////////////////////////////////
function get_cc_email_gestionaire_gab($id_gab,$gestionnaire)
{
	   $contact="";
    $connexion=ma_db_connexion();
   $SQL1="SELECT `aa_mail`, `cc_mail`  FROM `new_libelle_type_contact` WHERE `libelle` lIKE '".mysqli_real_escape_string($connexion,$gestionnaire)."'";
$result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 1054: ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1054 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						$contact=$row["cc_mail"].';'.$contact;
					}
			}
			return $contact;
mysqli_free_result($result);
	}




  }
 ///////////////////////////////////////////////////////////////////////////////////////
function get_mail_nouveau_appel8($id_gab,$motif,$date_intervention,$id_intervention,$gestionnaire)
{
$codeAgence=get_cd_agence($id_gab);

$astreinteGAB=getContactGABAstreinte($codeAgence,$gestionnaire);
$astreinteGAB2=getContactGABAstreinte2($codeAgence,$gestionnaire);
$mail=get_verif_mail_incident_gab($motif,$id_gab,$gestionnaire);
echo '

<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingThree18" style="font-size:13px;font-weight:bold;color: #fff;background-color:#e98731">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree18" aria-expanded="false" aria-controls="collapseThree18">
         <strong>Afficher E-mail4 ====> ('.$gestionnaire.') </strong>
        </a>
      </h4>
    </div>
    <div id="collapseThree18" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree18">
      <div class="panel-body">
<table class="table" style="border-left: 2px solid #F96464;;border-right: 2px solid #F96464;;border-top: 2px solid #F96464;border-bottom: 2px solid #F96464;">
<tr><th colspan="2">
<strong>
<p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> AA :  '; if($gestionnaire<>"AGENCE"){echo get_aa_email_gestionaire_gab($id_gab,$gestionnaire);}else{echo get_aa_email_gab1($id_gab);}echo '</p>
<p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> CC :  '; if($gestionnaire<>"AGENCE"){echo get_cc_email_gestionaire_gab($id_gab,$gestionnaire);}else{echo get_cc_email_gab1($id_gab);}echo '</p>
<p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> GAB : '. get_return_nom_gab_declarer($id_gab).'</p>
</strong>
<strong>
    <p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> OBJET : '.$mail[3].'</p>
</strong>
<div id="code04">
<strong>';
$message=str_replace("num_terminal",$id_gab,$mail[2]);
$message=str_replace("nom_terminal",get_return_nom_gab_declarer($id_gab),$message);
$message=str_replace("num_banque",get_return_nom_banque_abi2($id_gab),$message);
$message=str_replace("nom_filiale",get_nom_filiale(get_id_code_filiale($id_gab)),$message);
$message=str_replace("date_iertvention",$date_intervention,$message);
$message=str_replace("num_serie",get_return_num_serie($id_gab),$message);
$message=str_replace("ip_adress",getIPATMConfirmed($id_gab),$message);
$message=str_replace("responsableGAB",$astreinteGAB2,$message);
$message=str_replace("remarque","",$message);
// $message=str_replace("date_iertvention",date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))),$message);
$message=str_replace("motif_iertvention",get_lebelle_declaration($motif),$message);
echo '
<p style="margin-left: 14px;font-family: Calibri;font-size: small;font-weight:normal;">'.nl2br($message).'</p>';
echo '
</div> 
</strong>
</th>
</tr><tr>
<th><a onClick="javascript:Select_code(\'code04\');"class="btn btn-info btn-xs btn-block"> Sélectionné</a></th>
<th>';
//get_return_id_prestataire($id_incident)
$message=html_entity_decode_outlouk($message);

   if($gestionnaire<>"AGENCE")// verifer AGENCE/GF BCC
		{
			$a_mail=get_aa_email_gestionaire_gab($id_gab,$gestionnaire);
			$cc_mail=get_cc_email_gestionaire_gab($id_gab,$gestionnaire);
		}
	else
		{
			$a_mail=get_aa_email_gab1($id_gab);
			$cc_mail=get_cc_email_gab1($id_gab);
		}
// $a_mail=$mail[0];
// $cc_mail=$mail[1];
$de_mail="supervision_GAB@cfgbank.com";

$bcc="";

$obj=str_replace("num_terminal",$id_gab,$mail[3]);
$obj=str_replace("nom_filiale",get_nom_filiale(get_id_code_filiale($id_gab)),$obj);
$obj=str_replace("nom_terminal",get_return_nom_gab_declarer($id_gab),$obj);
$obj=str_replace("responsable_gab",$astreinteGAB,$obj);

          ?>
                 <a  class="btn btn-success btn-xs btn-block" href="mailto:<?php echo $a_mail;?>
				 ?From=<?php echo $de_mail;?>
				 &cc=<?php echo $cc_mail;?><?php echo $bcc;?>
				 &subject=<?php echo $obj?>
				 &body=<?php echo  ($message);?>">
				 <?php echo "Générer mail";?></a>
          <?php
echo '</th>
</tr>
</table>
	</div>
    </div>
  </div>

</div>

';
}
///////////////////////////////////////////////////////////////////////////////////////
function get_mail_nouveau_appel7($id_gab,$motif,$date_intervention,$id_intervention,$gestionnaire)
{
$codeAgence=get_cd_agence($id_gab);
$astreinteGAB=getContactGABAstreinte($codeAgence,$gestionnaire);
$astreinteGAB2=getContactGABAstreinte2($codeAgence,$gestionnaire);

$mail=get_verif_mail_incident_gab($motif,$id_gab,$gestionnaire);
echo '

<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingThree17" style="font-size:13px;font-weight:bold;color: #fff;background-color:#e98731">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree17" aria-expanded="false" aria-controls="collapseThree17">
         <strong>Afficher E-mail3 ====> ('.$gestionnaire.') </strong>
        </a>
      </h4>
    </div>
    <div id="collapseThree17" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree17">
      <div class="panel-body">
<table class="table" style="border-left: 2px solid #F96464;;border-right: 2px solid #F96464;;border-top: 2px solid #F96464;border-bottom: 2px solid #F96464;">
<tr><th colspan="2">
<strong>
<p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> AA :  '; if($gestionnaire<>"AGENCE"){echo get_aa_email_gestionaire_gab($id_gab,$gestionnaire);}else{echo get_aa_email_gab1($id_gab);}echo '</p>
<p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> CC :  '; if($gestionnaire<>"AGENCE"){echo get_cc_email_gestionaire_gab($id_gab,$gestionnaire);}else{echo get_cc_email_gab1($id_gab);}echo '</p>
<p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> GAB : '. get_return_nom_gab_declarer($id_gab).'</p>
</strong>
<strong>
    <p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> OBJET : '.$mail[3].'</p>
</strong>
<div id="code03">
<strong>';
$message=str_replace("num_terminal",$id_gab,$mail[2]);
$message=str_replace("nom_terminal",get_return_nom_gab_declarer($id_gab),$message);
$message=str_replace("num_banque",get_return_nom_banque_abi2($id_gab),$message);
$message=str_replace("nom_filiale",get_nom_filiale(get_id_code_filiale($id_gab)),$message);
$message=str_replace("date_iertvention",$date_intervention,$message);
$message=str_replace("num_serie",get_return_num_serie($id_gab),$message);
$message=str_replace("responsableGAB",$astreinteGAB2,$message);
$message=str_replace("remarque","",$message);
// $message=str_replace("date_iertvention",date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))),$message);
$message=str_replace("motif_iertvention",get_lebelle_declaration($motif),$message);
echo '
<p style="margin-left: 14px;font-family: Calibri;font-size: small;font-weight:normal;">'.nl2br($message).'</p>';
echo '
</div>
</strong>
</th>
</tr><tr>
<th><a onClick="javascript:Select_code(\'code03\');"class="btn btn-info btn-xs btn-block"> Sélectionné</a></th>
<th>';
//get_return_id_prestataire($id_incident)
$message=html_entity_decode_outlouk($message);

   if($gestionnaire<>"AGENCE")// verifer AGENCE/GF BCC
		{
			$a_mail=get_aa_email_gestionaire_gab($id_gab,$gestionnaire);
			$cc_mail=get_cc_email_gestionaire_gab($id_gab,$gestionnaire);
		}
	else
		{
			$a_mail=get_aa_email_gab1($id_gab);
			$cc_mail=get_cc_email_gab1($id_gab);
		}
// $a_mail=$mail[0];
// $cc_mail=$mail[1];
$de_mail="supervision_GAB@cfgbank.com";

$bcc="";

$obj=str_replace("num_terminal",$id_gab,$mail[3]);
$obj=str_replace("nom_filiale",get_nom_filiale(get_id_code_filiale($id_gab)),$obj);
$obj=str_replace("nom_terminal",get_return_nom_gab_declarer($id_gab),$obj);
$obj=str_replace("responsable_gab",$astreinteGAB,$obj);

          ?>
                 <a  class="btn btn-success btn-xs btn-block" href="mailto:<?php echo $a_mail;?>
				 ?From=<?php echo $de_mail;?>
				 &cc=<?php echo $cc_mail;?><?php echo $bcc;?>
				 &subject=<?php echo $obj?>
				 &body=<?php echo  ($message);?>">
				 <?php echo "Générer mail";?></a>
          <?php
echo '</th>
</tr>
</table>
	</div>
    </div>
  </div>

</div>

';
}
///////////////////////////////////////////////////////////////////////////////////////
function getTelAgence($id_gab)
{
	  $connexion=ma_db_connexion();
	  $sql = "SELECT `tel` FROM   `new_list_agence` WHERE `code_agence`='".mysqli_real_escape_string($connexion,getCodeAgenceBCP($id_gab))."'";
	  $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1055: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1055 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return trim("Tel Agence : ".$row["tel"]);
					}
			}
		else
			{
				return "Tel Agence : -----";
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
///////////////////////////////////////////////////////////////////////////////////////
function get_cc_email_gestionaire_gab_n2($id_gab,$gestionnaire)
{

    $contact="";
    $connexion=ma_db_connexion();
    $SQL1="SELECT `aa_mail`, `cc_mail`  FROM `new_libelle_type_contact` 
    WHERE `libelle` lIKE '".mysqli_real_escape_string($connexion,$gestionnaire)."'";
    $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 1056: ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1056 !');
    }

    if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						$contact=$row["cc_mail"].';'.$contact;
					}
			}
			return $contact;
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
///////////////////////////////////////////////////////////////////////////////////////
function get_aa_email_gestionaire_gab($id_gab,$gestionnaire)
{
   $contact="";
     $connexion=ma_db_connexion();

   $SQL1="SELECT `aa_mail`, `cc_mail`  FROM `new_libelle_type_contact` 
   WHERE `libelle` lIKE '".mysqli_real_escape_string($connexion,$gestionnaire)."'";
  $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 1057: ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1057 !');
    }


if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						$contact=$row["aa_mail"].';'.$contact;
					}
			}
			return $contact;
mysqli_free_result($result);
	}
    mysqli_close($connexion);
  }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_num_serie($id)
{
    $connexion=ma_db_connexion();
    $numero_serie="";
    $sql = "SELECT `numero_serie` FROM `new_list_gab` WHERE `new_list_gab`.`terminal` 
    like '".mysqli_real_escape_string($connexion,$id)."'";
	//var_dump($sql);echo "<br>";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1058: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1058 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                $numero_serie = $row["numero_serie"];
            }
		}

		mysqli_free_result($result);
	}
    mysqli_close($connexion);
    return $numero_serie;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_lebelle_declaration($id_motif)
{
	  $connexion=ma_db_connexion();
	$sql = "SELECT `libelle_intevention` FROM   `new_action_intervention`
	WHERE `id_intevention`='".mysqli_real_escape_string($connexion,$id_motif)."'";
	$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1059: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1059 !');
    }

if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["libelle_intevention"];
					}
			}
		else
			{
				return "";
			}
mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_return_nom_banque_abi2($id)
{
$connexion=ma_db_connexion();
$sql = "SELECT  `nom_filiale` FROM  `new_list_gab` ,`new_filiale`
WHERE    `new_filiale`.`id_filiale` =    `new_list_gab`.`code_bank` 
AND `new_list_gab`.`terminal`  like '".mysqli_real_escape_string($connexion,$id)."'";

$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1060: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1060 !');
    }

if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["nom_filiale"];
					}
			}
		else
			{
				return "";
			}
mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
 ///////////////////////////////////////////////////////////////////////////////////////
function get_cc_email_gab($id_gab)
{
   $contact="";
   $connexion=ma_db_connexion();
   $SQL1="SELECT `aa_mail`, `cc_mail`  FROM `new_libelle_type_contact` 
   WHERE `id_type` =  '".mysqli_real_escape_string($connexion,get_id_gestionnaire($id_gab))."'";
   $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 1061: ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1061 !');
    }

    if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						$contact=$row["cc_mail"].';'.$contact;
					}
			}
			return $contact;
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
 ///////////////////////////////////////////////////////////////////////////////////////
function get_mail_nouveau_appel($id_gab,$motif,$date_intervention,$id_intervention,$gestionnaire)
{
    $codeAgence=get_cd_agence($id_gab);
    $astreinteGAB=getContactGABAstreinte($codeAgence,$gestionnaire);
    $astreinteGAB2=getContactGABAstreinte2($codeAgence,$gestionnaire);
    $mail=get_verif_mail_incident_gab($motif,$id_gab,$gestionnaire);
    echo '
    
    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
      <div class="panel panel-default">
        <div class="panel-heading" role="tab" id="headingThree" style="font-size:13px;font-weight:bold;color: #fff;background-color:#e98731">
          <h4 class="panel-title">
            <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
             <strong> Afficher E-mail1 ====> ('.$gestionnaire.') </strong>
            </a>
          </h4>
        </div>
        <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
          <div class="panel-body">
    <table class="table" style="border-left: 2px solid #F96464;;border-right: 2px solid #F96464;;border-top: 2px solid #F96464;border-bottom: 2px solid #F96464;">
    <tr><th colspan="2">
    <strong>
    <p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> AA :  '; if($gestionnaire<>"AGENCE"){echo get_aa_email_gab($id_gab);}else{echo get_aa_email_gab1($id_gab);}echo '</p>
    <p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> CC :  '; if($gestionnaire<>"AGENCE"){echo get_cc_email_gab($id_gab);}else{echo get_cc_email_gab1($id_gab);}echo '</p>
    <p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> GAB : '. get_return_nom_gab_declarer($id_gab).'</p>
    </strong>
    <strong>
		<p style="margin-left: 31px;margin-left: 14px;font-family: Calibri;font-size: small;font-weight:bold;"> OBJET : '.$mail[3].'</p>
	</strong>
    <div id="code11">
    <strong>';
    $message=str_replace("num_terminal",$id_gab,$mail[2]);
    $message=str_replace("nom_terminal",get_return_nom_gab_declarer($id_gab),$message);
    $message=str_replace("num_banque",get_return_nom_banque_abi2($id_gab),$message);
    $message=str_replace("nom_filiale",get_nom_filiale(get_id_code_filiale($id_gab)),$message);
    $message=str_replace("date_iertvention",$date_intervention,$message);
    $message=str_replace("num_serie",get_return_num_serie($id_gab),$message);
    $message=str_replace("responsableGAB",$astreinteGAB2,$message);
    $message=str_replace("remarque","",$message);
    // $message=str_replace("date_iertvention",date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))),$message);
    $message=str_replace("motif_iertvention",get_lebelle_declaration($motif),$message);
    echo '
    <p style="margin-left: 14px;font-family: Calibri;font-size: small;font-weight:normal;">'.nl2br($message).'</p>';
    echo '
    </div>
    </strong>
    </th>
    </tr><tr>
    <th><a onClick="javascript:Select_code(\'code11\');"class="btn btn-info btn-xs btn-block"> Sélectionné</a></th>
    <th>';
    //get_return_id_prestataire($id_incident)
    $message=html_entity_decode_outlouk($message);
       if($gestionnaire<>"AGENCE")// verifer AGENCE/GF BCC
            {
                $a_mail=get_aa_email_gab($id_gab);
                $cc_mail=get_cc_email_gab($id_gab);
            }
        else
            {
                $a_mail=get_aa_email_gab1($id_gab);
                $cc_mail=get_cc_email_gab1($id_gab);
            }
    $de_mail="supervision_GAB@cfgbank.com";

    $bcc="";


$obj=str_replace("num_terminal",$id_gab,$mail[3]);
$obj=str_replace("nom_filiale",get_nom_filiale(get_id_code_filiale($id_gab)),$obj);
$obj=str_replace("nom_terminal",get_return_nom_gab_declarer($id_gab),$obj);
$obj=str_replace("responsable_gab",$astreinteGAB,$obj);

          ?>
                 <a  class="btn btn-success btn-xs btn-block" href="mailto:<?php echo $a_mail;?>
				 ?From=<?php echo $de_mail;?>
				 &cc=<?php echo $cc_mail;?><?php echo $bcc;?>
				 &subject=<?php echo $obj?>
				 &body=<?php echo  ($message);?>">
				 <?php echo "Générer mail";?></a>
              <?php
    echo '</th>
    </tr>
    </table>
        </div>
        </div>
      </div>
    
    </div>
    
    ';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_verif_mail_incident_gab($id_intevention,$terminal,$gestionnaire)
{

    $connexion=ma_db_connexion();
	
    if ($gestionnaire=='AGENCE')
    {
        $sql = "SELECT `objet`, `adresse_mail_aa`, `adresse_mail_cc`, `corps_messagerie` FROM   `new_mail_action_intevention` ,`new_mail_messagerie` 
		WHERE   `new_mail_messagerie`.`id_mail`= `new_mail_action_intevention`.`id_mail`
		AND `new_mail_action_intevention`.`id_intevention`='".mysqli_real_escape_string($connexion,$id_intevention)."' 
		AND `niveau_messagenie`='APPEL'";

    }
    elseif ($gestionnaire=="BRINK'S")
    {
        $sql = "SELECT `objet`, `adresse_mail_aa`, `adresse_mail_cc`, `corps_messagerie` FROM  `new_mail_messagerie` 
		WHERE   `new_mail_messagerie`.`mail`= 'PRESTATAIRE'
		AND `niveau_messagenie`='APPEL'";
    }
    elseif ($gestionnaire=="Logistique")
    {
        $sql = "SELECT `objet`, `adresse_mail_aa`, `adresse_mail_cc`, `corps_messagerie` FROM  `new_mail_messagerie` 
		WHERE   `new_mail_messagerie`.`mail`= 'Logistique'
		AND `niveau_messagenie`='APPEL'";
    }
    elseif ($gestionnaire=="TELECOM")
    {
        $sql = "SELECT `objet`, `adresse_mail_aa`, `adresse_mail_cc`, `corps_messagerie` FROM  `new_mail_messagerie` 
		WHERE   `new_mail_messagerie`.`mail`= 'TELECOM'
		AND `niveau_messagenie`='APPEL'";
    }
    elseif ($gestionnaire=="NCR")
    {
        $sql = "SELECT `objet`, `adresse_mail_aa`, `adresse_mail_cc`, `corps_messagerie` FROM  `new_mail_messagerie` 
		WHERE   `new_mail_messagerie`.`mail`= 'NCR'
		AND `niveau_messagenie`='APPEL'";


    }
    else
	{
	    $sql = "SELECT `objet`, `adresse_mail_aa`, `adresse_mail_cc`, `corps_messagerie` FROM  `new_mail_messagerie` 
		WHERE   `new_mail_messagerie`.`mail`= 'PRESTATAIRE2'
		AND `niveau_messagenie`='APPEL'";
	}
    

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1063: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1063 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $i=0;
            while ($row = mysqli_fetch_assoc($result))
            {
                $adresse_mail_aa[$i] = $row["adresse_mail_aa"];
                $adresse_mail_cc[$i] = $row["adresse_mail_cc"];
                $corps_messagerie[$i] = $row["corps_messagerie"];
                $objet[$i] = $row["objet"];
                $i++;
            }
            mysqli_free_result($result);
            return  array($adresse_mail_aa[0], $adresse_mail_cc[0], $corps_messagerie[0], $objet[0]);

        }
        else
        {
            mysqli_free_result($result);
            return  array(" ", " ", " ");
        }
    }
    mysqli_close($connexion);
}
///////////////////////////////////////////////////////////////////////////////////////
function get_aa_email_gab($id_gab)
{

   $contact="";
   $connexion=ma_db_connexion();
   $SQL1="SELECT `aa_mail` FROM `new_libelle_type_contact` 
   WHERE `id_type` = '".mysqli_real_escape_string($connexion,$id_gab)."'";

  
   $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 1064: ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1064 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                $contact=$row["aa_mail"];
            }
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
    return $contact;
}
///////////////////////////////////////////////////////////////////////////////////////
function get_cc_email_gab2($id_gab)
{

   $contact="";
   $connexion=ma_db_connexion();
   $SQL1="SELECT `cc_mail` FROM `new_libelle_type_contact` 
   WHERE `id_type` = '".mysqli_real_escape_string($connexion,$id_gab)."'";

   //var_dump($SQL1);
   $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 1064: ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1064 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
		{
		    while ($row = mysqli_fetch_assoc($result))
            {
                $contact=$row["cc_mail"];
            }
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
    return $contact;
}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_all_select_return_motif_arret2()
{

	  $connexion=ma_db_connexion();

		$sql = "SELECT  `id_intevention`,`libelle_intevention` 
		FROM `new_action_intervention` ORDER BY  `new_action_intervention`.`libelle_intevention` ASC ";

		$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1065: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1065 !');
    }
	   if ($result)
        {
            if(mysqli_num_rows($result)>0)
                {
                while ($row = mysqli_fetch_assoc($result))
                        {
                            echo '<option value="'.$row["id_intevention"].'">'.$row["libelle_intevention"].'</option>';
                        }
                }
            else
                {
                    echo '<option value=""></option>';
                }
            mysqli_free_result($result);
	    }

    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_id_gestionnaire($id)
{
	 $connexion=ma_db_connexion();
$sql = "SELECT 	 `gestionnaire`  FROM  `new_list_gab`	
WHERE `terminal` like '".mysqli_real_escape_string($connexion,$id)."'";

$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1066: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1066 !');
    }

if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["gestionnaire"];
					}


			}
			else
					{
						return "";
					}
mysqli_free_result($result);
	}


}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function verifMailgetLibelleGestionnaireGab($dossier,$motif,$distinataire)
{
	$connexion=ma_db_connexion();
	$sql = "SELECT 	`idMail` 	FROM  `historiqueMailPCA` 
	WHERE `numDossier` = '".mysqli_real_escape_string($connexion,$dossier)."' 
	AND `motif` = '".mysqli_real_escape_string($connexion,$motif)."' 
	AND `distinataire` like '".mysqli_real_escape_string($connexion,$distinataire)."'";

	$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1067: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1067 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return 1;
					}


			}
			else
					{
						return 0;
					}
mysqli_free_result($result);
	}



}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_durue_rappel_sla($id)
{
	$connexion=ma_db_connexion();

$sql = "SELECT 	`duree_rappel_sla`, `duree_sla` FROM  `new_libelle_type_contact`	
WHERE 	`new_libelle_type_contact`.`id_type` =  '".mysqli_real_escape_string($connexion,$id)."'";

$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1068: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1068 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["duree_rappel_sla"];
					}
			}

mysqli_free_result($result);
	}


}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_libelle_durue_rappel_sla($id)
{
	$connexion=ma_db_connexion();
$sql = "SELECT 	`duree_rappel_sla`, `duree_sla` FROM  `new_libelle_type_contact`	
WHERE 	`new_libelle_type_contact`.`id_type` =  '".mysqli_real_escape_string($connexion,$id)."'";

$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1069: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1069 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["duree_sla"];
					}
			}

mysqli_free_result($result);
	}

}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function ajouter_nouveau_appel($id_incident,$id_motif,$txtnumaffectation,$id_affectation,$date_prise_bcp,$duree_rappel,$degre_appel,$id_etat)
{
 $connexion=ma_db_connexion();

            $date_actuel=date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y")));
			$date_rappel=get_date_rappel2_declaration($duree_rappel,date_transaction($date_actuel),get_id_niveau_intervention_incident($id_motif),$id_affectation);


            $duree = date_different(date_transaction($date_prise_bcp), $date_actuel);
			if (($duree['minutes_total']>=0) &&($duree['minutes_total']<=144500) && ($id_affectation <> "")  && ($id_etat <> "")   && ($id_motif <> ""))
					{
 $sql = "SELECT   `id_incident`, `id_gab`, `id_gab_powerdcard`, `nomgab`, `cd_agence`, `nom_agence`, `id_affectation`, `cd_region_iprc`,  `id_fournisseur`, `num_affectation`,   `responsable`, `details`,  `date_prise_charge_gestionnaire`, `type_contact`, `personne_avisee`, `gsm_personne_avise`, `id_action_intervention`, `id_niveau_intervention`, `etat_cloture`, `date_cloture`, `date_rappel`, max(`nbr_tentative`)  as max_tentatif, max(`nbr_escalade`) as max_escalade,`remarque`, `note`, `degre_intervention`, `motif_cloture`,  `Commentaire` 
         FROM `new_intevention_incident` 
		 WHERE `id_incident` = '".mysqli_real_escape_string($connexion,$id_incident)."'";

		 $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1070: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1070 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
 /******************Table new_intevention_incident*********/
 $sql2="INSERT INTO `new_intevention_incident`(
 `id_action_interv`, 
 `id_incident`,
 `date_action`,
 `date_prise_en_charge`,
 `num_affectation`,
 `date_prise_charge_gestionnaire`,
 `etat_contact`,
 `type_contact`,
 `personne_avisee`, 
 `id_action_intervention`,
 `id_categories`,
 `id_niveau_intervention`,
 `etat_cloture`,
 `date_rappel`, 
 `nbr_tentative`,
 `nbr_escalade`,
 `id_utilisateur`,
 `remarque`,
 `note`, 
 `degre_intervention`,
 `id_gab`,
 `id_gab_powerdcard`,
 `nomgab`,
 `cd_agence`,
 `cd_region_iprc`,
 `nom_agence`,
 `details`,
 `responsable`,
 `id_affectation`,
 `id_fournisseur`,
 `degre_appel`
    ) 
 VALUES (
 NULL,
 '".mysqli_real_escape_string($connexion,$id_incident)."',
 '".mysqli_real_escape_string($connexion,$date_actuel)."',
 '".mysqli_real_escape_string($connexion,$date_actuel)."',
 '".mysqli_real_escape_string($connexion,$txtnumaffectation)."',
 '".mysqli_real_escape_string($connexion,date_transaction($date_prise_affectation))."',
 '".mysqli_real_escape_string($connexion,$id_etat)."',
 'Declaration',
 '".mysqli_real_escape_string($connexion,addslashes($row["personne_avisee"]))."',
 '".mysqli_real_escape_string($connexion,$id_motif)."',
 '".mysqli_real_escape_string($connexion,get_categories_arret($id_motif))."',
 '".mysqli_real_escape_string($connexion,get_id_niveau_intervention_incident($id_motif))."',
 '".mysqli_real_escape_string($connexion,$row["etat_cloture"])."',
 '".mysqli_real_escape_string($connexion,$date_rappel)."',
 '".mysqli_real_escape_string($connexion,$row["max_tentatif"]+1)."',
 1,
 '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',
 '".mysqli_real_escape_string($connexion,addslashes($row["remarque"]))."',
 '".mysqli_real_escape_string($connexion,addslashes($row["note"]))."',
 '".mysqli_real_escape_string($connexion,$row["degre_intervention"])."',
 '".mysqli_real_escape_string($connexion,$row["id_gab"])."',
 '".mysqli_real_escape_string($connexion,$row["id_gab_powerdcard"])."',
 '".mysqli_real_escape_string($connexion,addslashes($row["nomgab"]))."',
 '".mysqli_real_escape_string($connexion,$row["cd_agence"])."',
 '".mysqli_real_escape_string($connexion,addslashes($row["cd_region_iprc"]))."',
 '".mysqli_real_escape_string($connexion,addslashes($row["nom_agence"]))."',
 '".mysqli_real_escape_string($connexion,addslashes($row["details"]))."',
 '".mysqli_real_escape_string($connexion,addslashes($row["responsable"]))."', 
 '".mysqli_real_escape_string($connexion,$id_affectation)."', 
 '".mysqli_real_escape_string($connexion,$row["id_fournisseur"])."', 
 '".mysqli_real_escape_string($connexion,$degre_appel)."'
 )";
  $result2=mysqli_query($connexion,$sql2);
    if (!$result2)
    {
        error_log("Erreur SQL 1071: ".$sql2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1071 !');
    }

 mysqli_free_result($result2);


 $last_id_int = MaxIdIncident("id_action_interv","new_intevention_incident");
 /******************Table tempo new_intevention_incident_tmp*********/
 $sql2temp="INSERT INTO `new_intevention_incident_tmp`(
 
 `id_action_interv`, 
 `id_incident`,
 `date_action`,
 `date_prise_en_charge`,
 `num_affectation`,
 `date_prise_charge_gestionnaire`,
 `etat_contact`,
 `type_contact`,
 `personne_avisee`, 
 `id_action_intervention`,
 `id_categories`,
 `id_niveau_intervention`,
 `etat_cloture`,
 `date_rappel`, 
 `nbr_tentative`,
 `nbr_escalade`,
 `id_utilisateur`,
 `remarque`,
 `note`, 
 `degre_intervention`,
 `id_gab`,
 `id_gab_powerdcard`,
 `nomgab`,
 `cd_agence`,
 `cd_region_iprc`,
 `nom_agence`,
 `details`,
 `responsable`,
 `id_affectation`,
 `id_fournisseur`,
 `degre_appel`
    ) 
 VALUES (
 
 '".mysqli_real_escape_string($connexion,$last_id_int)."',
 '".mysqli_real_escape_string($connexion,$id_incident)."',
 '".mysqli_real_escape_string($connexion,$date_actuel)."',
 '".mysqli_real_escape_string($connexion,$date_actuel)."',
 '".mysqli_real_escape_string($connexion,$txtnumaffectation)."',
 '".mysqli_real_escape_string($connexion,date_transaction($date_prise_affectation))."',
 '".mysqli_real_escape_string($connexion,$id_etat)."',
 'Declaration',
 '".mysqli_real_escape_string($connexion,addslashes($row["personne_avisee"]))."',
 '".mysqli_real_escape_string($connexion,$id_motif)."',
 '".mysqli_real_escape_string($connexion,get_categories_arret($id_motif))."',
 '".mysqli_real_escape_string($connexion,get_id_niveau_intervention_incident($id_motif))."',
 '".mysqli_real_escape_string($connexion,$row["etat_cloture"])."',
 '".mysqli_real_escape_string($connexion,$date_rappel)."',
 '".mysqli_real_escape_string($connexion,$row["max_tentatif"]+1)."',
 1,
 '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',

 '".mysqli_real_escape_string($connexion,addslashes($row["remarque"]))."',
 '".mysqli_real_escape_string($connexion,addslashes($row["note"]))."',
 '".mysqli_real_escape_string($connexion,$row["degre_intervention"])."',
 '".mysqli_real_escape_string($connexion,$row["id_gab"])."',
 '".mysqli_real_escape_string($connexion,$row["id_gab_powerdcard"])."',
 '".mysqli_real_escape_string($connexion,addslashes($row["nomgab"]))."',
 '".mysqli_real_escape_string($connexion,$row["cd_agence"])."',
 '".mysqli_real_escape_string($connexion,addslashes($row["cd_region_iprc"]))."',
 '".mysqli_real_escape_string($connexion,addslashes($row["nom_agence"]))."',
 '".mysqli_real_escape_string($connexion,addslashes($row["details"]))."',
 '".mysqli_real_escape_string($connexion,addslashes($row["responsable"]))."', 
 '".mysqli_real_escape_string($connexion,$id_affectation)."', 
 '".mysqli_real_escape_string($connexion,$row["id_fournisseur"])."', 
 '".mysqli_real_escape_string($connexion,$degre_appel)."'
 )";

 $result2temp=mysqli_query($connexion,$sql2temp);
    if (!$result2temp)
    {
        error_log("Erreur SQL 1072: ".$sql2temp."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1072 !');
    }
 mysqli_free_result($result2temp);




 if (($id_affectation==1) || ($id_affectation==4)){$appelagence=1;}else{$appelagence=0;}

	                       $cmd="UPDATE `new_incident_gab` SET 
					    `date_derniere_interv`='".mysqli_real_escape_string($connexion,$date_actuel)."',
						`appelagence` =   '".mysqli_real_escape_string($connexion,$appelagence)."',
					    `date_derniere_rappel`='".mysqli_real_escape_string($connexion,$date_rappel)."' ,
					    `id_indisponibilite` =  '".mysqli_real_escape_string($connexion,get_etat_disponibilite_intervention($id_motif))."', 					   
					    `date_remise`='0000-00-00 00:00:00' ,
					    `cd_arret_technique` =  '".mysqli_real_escape_string($connexion,get_id_tp_intervention_fornisseur($id_motif))."',
					    `id_categories_technique` =  '".mysqli_real_escape_string($connexion,get_id_categorie_intervention_fornisseur($id_motif))."',
						`id_action_technique` =  '".mysqli_real_escape_string($connexion,$id_motif)."',
						`id_niveau_technique` =  '".mysqli_real_escape_string($connexion,get_niveau_intervention_technique($id_motif))."',
						`cd_arret_fonctionnelle` =  '".mysqli_real_escape_string($connexion,get_id_tp_intervention_prestataire($id_motif))."',
						`id_categories_fonctionnelle` =  '".mysqli_real_escape_string($connexion,get_id_categorie_intervention_prestataire($id_motif))."',
						`id_action_fonctionelle` =  '".mysqli_real_escape_string($connexion,$id_motif)."',
						`id_niveau_fonctionelle` =  '".mysqli_real_escape_string($connexion,get_niveau_intervention_fonctionnelle($id_motif))."'
                      WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
	$resultcmd=mysqli_query($connexion,$cmd);
    if (!$resultcmd)
    {
        error_log("Erreur SQL 1073: ".$cmd."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1073 !');
    }
			 mysqli_free_result($resultcmd);

					  $cmd2="UPDATE `new_incident_gab_ouvert` SET 
					    `date_derniere_interv`='".mysqli_real_escape_string($connexion,$date_actuel)."',
						`appelagence` =   '".mysqli_real_escape_string($connexion,$appelagence)."',
					    `date_derniere_rappel`='".mysqli_real_escape_string($connexion,$date_rappel)."' ,
					    `id_indisponibilite` =  '".mysqli_real_escape_string($connexion,get_etat_disponibilite_intervention($id_motif))."', 					   
					    `date_remise`='0000-00-00 00:00:00' ,
					    `cd_arret_technique` =  '".mysqli_real_escape_string($connexion,get_id_tp_intervention_fornisseur($id_motif))."',
					    `id_categories_technique` =  '".mysqli_real_escape_string($connexion,get_id_categorie_intervention_fornisseur($id_motif))."',
						`id_action_technique` =  '".mysqli_real_escape_string($connexion,$id_motif)."',
						`id_niveau_technique` =  '".mysqli_real_escape_string($connexion,get_niveau_intervention_technique($id_motif))."',
						`cd_arret_fonctionnelle` =  '".mysqli_real_escape_string($connexion,get_id_tp_intervention_prestataire($id_motif))."',
						`id_categories_fonctionnelle` =  '".mysqli_real_escape_string($connexion,get_id_categorie_intervention_prestataire($id_motif))."',
						`id_action_fonctionelle` =  '".mysqli_real_escape_string($connexion,$id_motif)."',
						`id_niveau_fonctionelle` =  '".mysqli_real_escape_string($connexion,get_niveau_intervention_fonctionnelle($id_motif))."'
                      WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";



		  $resultcmd2=mysqli_query($connexion,$cmd2);
    if (!$resultcmd2)
    {
        error_log("Erreur SQL 1074: ".$cmd2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1074 !');
    }

			 mysqli_free_result($resultcmd2);



				$sql2 = "UPDATE  `new_intevention_incident`  SET   `date_rappel` =  '".mysqli_real_escape_string($connexion,$date_actuel)."'
				WHERE  `id_incident` ='".mysqli_real_escape_string($connexion,$id_incident)."'
				AND `nbr_tentative` = '".mysqli_real_escape_string($connexion,$row["max_tentatif"])."'";
			 $resultsql2=mysqli_query($connexion,$sql2);
    if (!$resultsql2)
    {
        error_log("Erreur SQL 1075: ".$sql2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1075 !');
    }
			    mysqli_free_result($resultsql2);



				$sql2temp = "UPDATE  `new_intevention_incident_tmp`  SET   `date_rappel` =  '".mysqli_real_escape_string($connexion,$date_actuel)."'
				WHERE  `id_incident` ='".mysqli_real_escape_string($connexion,$id_incident)."'
				AND `nbr_tentative` = '".mysqli_real_escape_string($connexion,$row["max_tentatif"])."'";

					 $resulttemp2=mysqli_query($connexion,$sql2temp);
				if (!$resulttemp2)
				{
					error_log("Erreur SQL 1076: ".$sql2temp."  ".mysqli_error($connexion));
					die('ERREUR QUERY 1076 !');
				}


			    mysqli_free_result($resulttemp2);



	        	}

		}
	}
mysqli_free_result($result);
	}

}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 function get_nouveau_appel_gab($incident)
{
    $connexion=ma_db_connexion();
		get_detail_nouveau_appel_gab($incident);
		$id_intervention=get_max_id_action_intervention($incident);
		$id_gab=get_id_gab_incident($incident);
		$motif=get_id_motif_incident($id_intervention);
		$act=get_array_information_action_intervention(($id_intervention));
		$gestionnaire=get_gestionnaire_gab2(get_id_gestionnaire_incident($id_gab));
		$type_gab=get_fournisseur(get_id_type_gab_incident($id_gab));
		$date_prise=gmdate("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y")));
echo '
<form class="form-horizontal" role="form">
					<input  id="degre_declaration"  name="degre_declaration" type="hidden"   value="'.get_return_max_id_degre_appel($incident).'" class="form-control input-sm">

<div  class="form-group">
<label <for="input_terminal" style="text-align:left" class="col-sm-3 control-label">Motif</label>
				<div class="col-sm-9">';
	echo '<select style="font-size:10pt;font-weight:bold;color:#000;" '.enabling_button($incident,0).' 	class="form-control" id="id_motif_arret" required name="id_motif_arret" >';
			//get_select_return_motif_arret2($idcausearret);
			get_select_intervention_id($motif);
			get_all_select_return_motif_arret2();
			echo '</select>';

	      echo '</div>
				</div>					
					
';
	echo '<input  align="center"  id="txtnumaffectation" name="txtnumaffectation" type="hidden"   value="'.get_numero_affectation($incident).'"    class="form-control input-sm">';
				echo '

				
<div  class="form-group">
<label <for="input_terminal" style="text-align:left" class="col-sm-3 control-label">Affectation</label>
				<div class="col-sm-9">';
	echo '<select  '.enabling_button($incident,0).' class="form-control" id="id_affectation"  name="id_affectation">';
				get_libelle_type_contact($act[3]);
				// get_select_affectation($id_gab);
				get_select_all_affectation();
			// get_libelle_type_contact2();
				echo ' </select>		';
				echo '</div>
				</div>

<div  class="form-group">
<label <for="input_id_etat" style="text-align:left" class="col-sm-3 control-label">Etat contact</label>
				<div class="col-sm-9">';
	echo '<select '.enabling_button($incident,0).' class="form-control" id="id_etat"  name="id_etat">';
				get_libelle_etat_contact($act[4]);
				get_libelle_etat_contact2();
				echo ' </select>';
				echo '</div>
				</div>
				
<div  class="form-group">
<label <for="input_terminal" style="text-align:left" class="col-sm-3 control-label">Date Prise en charge</label>
				<div class="col-sm-9">';
	echo '<input  '.enabling_button($incident,0).' align="center"  id="date_prise" name="date_prise" type="text"   value="'.$date_prise.'"    class="form-control input-sm">';
				echo '</div>
				</div>


<div  class="form-group">
<label <for="input_terminal" style="text-align:left" class="col-sm-3 control-label">Durée Rappel : </label>
				<div class="col-sm-9">';
	echo '    			<select '.enabling_button($incident,0).' class="form-control" id="id_rappel" required name="rappel" >';
								  echo '    <option value='.get_return_durue_rappel_sla($act[3]).'>'.get_return_libelle_durue_rappel_sla($act[3]).'</option>';
								  echo '  
											<option value="3600">1h</option>
										    <option value="5400">1h30</option>
											<option value="7200">2h</option>
											<option value="14400">4h</option>
											<option value="JO7">Jour ouvrable</option>
											<option value="86400">24h (1Jour)</option>
											<option value="172800">48h (2Jours)</option>
											<option value="259200">72h (3Jours)</option>					
											<option value="345600">96h (4Jours)</option>	
			    </select> ';


				// if (enabling_button($incident,0)=='disabled'){$etatActivation='disabled';}else $etatActivation='';


				echo '</div>
				</div>

				
<div  class="form-group">				
<label <for="name_agence" class="col-sm-3 control-label"></label>
				<div class="col-sm-9">
				<button type="button" '.enabling_button($incident,0).' class="btn btn-info btn-xs btn-block" id="btn_nouv_appel" style="background-color:#3276b1" onClick="javascript:ajouter_nouvelle_appel2(\''.$incident.'\')"   >Nouveau Appel</button>
		  </div>
		</div>
		
<div  class="form-group">				
<div class="col-sm-9"> ';

	$sqle = "SELECT `id_incident` 	FROM  `new_incident_gab_ouvert` 	
	WHERE `id_incident`=  '".mysqli_real_escape_string($connexion,$incident)."' ";
	$resulte=mysqli_query($connexion,$sqle);
	if (!$resulte)
	{
	    error_log("Erreur SQL 1077: ".$sqle."  ".mysqli_error($connexion));
	    die('ERREUR QUERY 1077 !');
	}

	if ($resulte)
	{
	    if(mysqli_num_rows($resulte)>0)
	    {
	        if (($motif <>281) && ($motif <>6))
	        {
						// if (verifMailgetLibelleGestionnaireGab($incident,$motif,$gestionnaire)==0)	{	//echo $incident."---".$motif."---".$gestionnaire;
								// echo '<a href="/mailing/gbp/gab/bcpxml/gestionMail/autoEnvoiMailAgence.php?terminal='.$id_gab.'&dossier='.$incident.'&motif='.$motif.'&use='.$_SESSION['id_utilisateur'].'"   target="_blank" >Mail Agence</a><br>';
							// }	else	{		echo 'Mail déja envoi à la agence';		}
                echo '<br>';
                if (verifMailgetLibelleGestionnaireGab($incident,$motif,$type_gab)==0)
                {
                    // echo $incident.'---'.$motif.'---'.$type_gab;
                    // echo '<a href="/mailing/gbp/gab/bcpxml/gestionMail/autoEnvoiMailFournisseur.php?terminal='.$id_gab.'&dossier='.$incident.'&motif='.$motif.'&use='.$_SESSION['id_utilisateur'].'"   target="_blank" >Mail Fournisseur</a><br>';
                }
                else
                {
                    echo 'Mail déja envoi au '.$type_gab;
                    echo "<br>";
                    // echo '<a href="/mailing/gbp/gab/bcpxml/gestionMail/autoEnvoiRelanceMail.php?terminal='.$id_gab.'&dossier='.$incident.'&motif='.$motif.'&use='.$_SESSION['id_utilisateur'].'"   target="_blank" >Voulez vous relancer l\'e-mail</a><br>';
                }
                // echo '<br>';
                // if (verifMailgetLibelleGestionnaireGab($incident,$motif,get_gestionnaire_gab2(7))==0)	{ //echo $incident.'---'.$motif.'---'.get_gestionnaire_gab2(7);
                // echo '<a href="/mailing/gbp/gab/bcpxml/gestionMail/autoEnvoiMailPCA.php?terminal='.$id_gab.'&dossier='.$incident.'&motif='.$motif.'&use='.$_SESSION['id_utilisateur'].'"   target="_blank" >Mail PCA</a><br>';
                // }	else	{		echo 'Mail déja envoi au '.get_gestionnaire_gab2(7);		}
                // echo '<br>';
                // if (verifMailgetLibelleGestionnaireGab($incident,$motif,get_gestionnaire_gab2(7))==0)	{// echo $incident.'---'.$motif.'---'.get_gestionnaire_gab2(8);
                // echo '<a href="/mailing/gbp/gab/bcpxml/gestionMail/autoEnvoiMailTelecom.php?terminal='.$id_gab.'&dossier='.$incident.'&motif='.$motif.'&use='.$_SESSION['id_utilisateur'].'"   target="_blank" >Mail Telecom</a><br>';
                // }	else	{		echo 'Mail déja envoi au '.get_gestionnaire_gab2(8);		}

	        }
	    }
	    else
	    {
	        echo "Incident Clôturé";
	    }
	    mysqli_free_result($resulte);
	}

echo '</div>
		</div>
		
		
		';

    if(get_id_gestionnaire($id_gab)==9)// verifer AGENCE/GF BCC
		{

			// get_mail_nouveau_appel1($id_gab,$motif,$date_prise,$id_intervention,get_libelle_prestataire_gab(1));

			// get_mail_nouveau_appel($id_gab,$motif,$date_prise,$id_intervention,get_libelle_prestataire_gab(2));

		//	get_mail_nouveau_appel2($id_gab,$motif,$date_prise,$id_intervention,$type_gab);

		}
	else
		{
		//	 get_mail_nouveau_appel($id_gab,$motif,$date_prise,$id_intervention,$gestionnaire);
		}
	//NCR
    get_mail_nouveau_appel1($id_gab,$motif,$date_prise,$id_intervention,$type_gab);
    //électricité
    get_mail_nouveau_appel7($id_gab,$motif,$date_prise,$id_intervention,get_gestionnaire_gab2(3));
    // Télécom
    get_mail_nouveau_appel8($id_gab,$motif,$date_prise,$id_intervention,get_gestionnaire_gab2(8));
    echo "<br>";



echo '</form>				
';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_array_modifier_incident_gab($id_incident)
 {
	   $connexion=ma_db_connexion();
        $sql = "SELECT  `id_incident`,  `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`
							FROM `new_incident_gab`
							WHERE 	`new_incident_gab`.`id_incident`  =  '".mysqli_real_escape_string($connexion,$id_incident)."'";

							$result=mysqli_query($connexion,$sql);
				if (!$result)
				{
					error_log("Erreur SQL 1078: ".$sql."  ".mysqli_error($connexion));
					die('ERREUR QUERY 1078 !');
				}

if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{ $i=0;
			while ($row = mysqli_fetch_assoc($result))
					{

                $date_arrete[$i] = $row["date_arrete"];
                $date_remise[$i] = $row["date_remise"];
                $date_rappel[$i] = $row["date_derniere_rappel"];
                $etat_incident[$i] = $row["etat_incident"];
					$i++;
					}

			return  array($date_arrete[0], $date_remise[0], $date_rappel[0], $etat_incident[0]);

			}
		else
			{
				return  array("", "", "", "");
			}
mysqli_free_result($result);
	}



}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_information_gab($id_intervention)
    {
		$connexion=ma_db_connexion();
        $sql = "SELECT     `new_incident_gab`.`id_gab` id_gab
							FROM `new_intevention_incident`,  `new_incident_gab` 
							WHERE 							 
							`new_incident_gab`.`id_incident` =`new_intevention_incident`.`id_incident` 
							AND 
							`new_intevention_incident`.`id_action_interv`  =  '".mysqli_real_escape_string($connexion,$id_intervention) ."'";

$result=mysqli_query($connexion,$sql);
				if (!$result)
				{
					error_log("Erreur SQL 1080: ".$sql."  ".mysqli_error($connexion));
					die('ERREUR QUERY 1080 !');
				}

if ($result=mysqli_query(ma_db_connexion(),$sql) or die('Erreur   get_return_information_gab !<br>'.$sql.'<br>'.mysqli_error()))
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						  $id_gab= $row["id_gab"];
					}
					return  $id_gab;
			}
		else
			{
				return "";
			}
mysqli_free_result($result);
	}



    }

/*******************************************************************************************************************************************/
function dureeDifferenceDates($supDate,$infDate)
{

list($extrDateSupReel, $extrHeureSupReel) = explode(' ', $supDate);
$totalDate = date('d-m-Y  H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y')));

list($dateSupDate,$heureSupDate)= explode(' ',$supDate);
list($dateInfDate,$heureInfDate)= explode(' ',$infDate);

$datetime1 = new DateTime($supDate);

$datetime2 = new DateTime($infDate);

$difference = $datetime1->diff($datetime2);

$years = $difference->y;
$months = $difference->m;
$days = $difference->d;
$hours = $difference->h;
$min = $difference->i;
$sec = $difference->s;
$formatDurree="";
$durreeTotalMinutes=0;
if($extrHeureSupReel=='23:59:59'){
	$min=$min+1;
}

$durreeTotalMinutes= $min+($hours*60)+($days*24*60)+($months*30*24*60)+($years*12*30*24*60);
// $durreeTotalSecondes=($durreeTotalMinutes*60)+$sec;
// $durreeTotalMinutes= round($durreeTotalSecondes/60);
if ($heureSupDate=='23:59:59' AND $heureInfDate=='00:00:00' AND $dateSupDate==$dateInfDate )	{
	$durreeTotalMinutes=1440;
}


	// if($months >= 1){$formatDurree= $months." M<br>";}
			// if($days >= 1){$formatDurree= $formatDurree."".$days." J<br>";}
			// if($hours >= 1){$formatDurree= $formatDurree."".$hours." h<br>";}
			return $durreeTotalMinutes;
}
/*******************************************************************************************************************************************/

function controlReouvertureDossierIncident($idGab,$idIncident)
{
	 $connexion=ma_db_connexion();
$contr="SELECT * FROM new_incident_gab WHERE id_gab = '".mysqli_real_escape_string($connexion,$idGab)."' ORDER BY id_incident DESC LIMIT 1 ";

$control=mysqli_query($connexion,$contr);
				if (!$control)
				{
					error_log("Erreur SQL 1081: ".$contr."  ".mysqli_error($connexion));
					die('ERREUR QUERY 1081 !');
				}

if ($control)
		{
		if( mysqli_num_rows($control) > 0) {
			while ($donnLastInc= mysqli_fetch_assoc($control)){
						$incident = $donnLastInc["id_incident"];
						if($incident==$idIncident){ $result=1;} else {$result=0; }
				}
		} else { $result=1;}
return $result;
		mysqli_free_result($control);
		}
}
/*******************************************************************************************************************************************/
function control_duree_reouverture_dossier($idIncident)
{
	 $connexion=ma_db_connexion();
	$contr="SELECT * FROM new_incident_gab WHERE id_incident =   '".mysqli_real_escape_string($connexion,$idIncident)."' ";

	$control=mysqli_query($connexion,$contr);
				if (!$control)
				{
					error_log("Erreur SQL 1082: ".$contr."  ".mysqli_error($connexion));
					die('ERREUR QUERY 1082 !');
				}
	if ($control)
		{
		if( mysqli_num_rows($control) > 0) {
			while ($donnLastInc= mysqli_fetch_assoc($control)){$dateRemise = $donnLastInc["date_remise"];}
		}

	 $dateActuel = date('Y-m-d  H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y')));
	 if ($dateRemise=='0000-00-00 00:00:00'){ $durree=0;}
	 else{$durree=dureeDifferenceDates($dateActuel,$dateRemise);}


	 	 // echo $dateActuel." ======================================== ".$dateRemise." ======================================== ".$durree;
	 if ($durree>=720){
		 $etat=1;
	 } else { $etat=0;}
	 return $etat;
		mysqli_free_result($control);
		}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function update_duree_disponibilité($id_incident)
    {
		$connexion=ma_db_connexion();
        $sql = "SELECT   `date_debut_dispo`, `date_fin_dispo`, `date_debut_arret`, `date_remise` 
		        FROM `new_disponibilite`
				WHERE `new_disponibilite`.`id_incident`  =    '".mysqli_real_escape_string($connexion,$id_incident)."'";

 $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1083: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1083 !');
    }

if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
			  $duree=1440;
              return  $duree;
					}
			}
		else
			{
				return 0;
			}
mysqli_free_result($result);
	}

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  function update_disponibilite_intervention_gab2($id_incident)
  {
  $connexion=ma_db_connexion();
                       $SQL1="UPDATE `new_disponibilite` SET 
					   `duree_arret`='".update_duree_disponibilité($id_incident)."'
                       WHERE  `id_incident`=  '$id_incident'";
 $result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 1085: ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1085 !');
    }					mysqli_free_result($result);
  }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  function update_disponibilite_intervention_gab($id_incident,$date_cloture)
  {
  $connexion=ma_db_connexion();
                       $SQL1="UPDATE `new_disponibilite` SET 
					   `date_remise`='".mysqli_real_escape_string($connexion,$date_cloture)."'
                       WHERE  `id_incident`=   '".mysqli_real_escape_string($connexion,$id_incident)."'";
$result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 1086: ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1086 !');
    }
	mysqli_free_result($result);
  }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function get_nbr_verif_exist_alerte_technique($id_incident)
    {
		$connexion=ma_db_connexion();
        $sql = "SELECT  count(`id_action_interv`) as id_action     FROM `new_intevention_incident`, `new_action_intervention`
        WHERE `id_intevention` = `id_action_intervention`
		AND (`new_action_intervention`.`degre`=2 OR `new_action_intervention`.`degre`=3)
        AND `id_incident`  =    '".mysqli_real_escape_string($connexion,$id_incident)."' ";
			 $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1087: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1087 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
				if (($row["id_action"]==""))
					{
						return 0;
					}
				else
					{
						return $row["id_action"];
					}
					}
			}
		else
			{
				return 0;
			}
mysqli_free_result($result);
	}

    }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function get_verif_date_cloture_intevention_fontionnelle($id_incident)
    {
		 $connexion=ma_db_connexion();
        $sql = "SELECT  count(`id_action_interv`) as id_action  FROM `new_intevention_incident`, `new_action_intervention`
        WHERE   `id_intevention` = `id_action_intervention`
		AND `new_action_intervention`.`degre`=1
		AND `date_cloture`<>'0000-00-00 00:00:00'
        AND `id_incident`  =    '".mysqli_real_escape_string($connexion,$id_incident)."' ";

			$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1088: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1088 !');
    }
	if ($result=mysqli_query(ma_db_connexion(),$sql) or die('Erreur   get_date_remise_by_id_incid !<br>'.$sql.'<br>'.mysqli_error()))
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
				if (($row["id_action"]==""))
					{
						return 0;
					}
				else
					{
						return $row["id_action"];
					}
					}
			}
		else
			{
				return 0;
			}
mysqli_free_result($result);
	}

    }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_nbr_verif_exist_alerte_fontionnelle($id_incident)
{
		$connexion=ma_db_connexion();
        $sql = "SELECT  count(`id_action_interv`) as id_action     FROM `new_intevention_incident`, `new_action_intervention`
        WHERE `id_intevention` = `id_action_intervention`
		AND `new_action_intervention`.`degre`=1
        AND `id_incident`  =   '".mysqli_real_escape_string($connexion,$id_incident)."' ";
		$result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1089: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1089 !');
    }
if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
				if (($row["id_action"]==""))
					{
						return 0;
					}
				else
					{
						return $row["id_action"];
					}
					}
			}
		else
			{
				return 0;
			}
		mysqli_free_result($result);
	}
mysqli_close($connexion);
    }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function get_verif_etat_incident($id_incident)
    {
				if (((get_nbr_verif_exist_alerte_fontionnelle($id_incident)>0) && (get_verif_date_cloture_intevention_fontionnelle($id_incident)==0)) || ((get_nbr_verif_exist_alerte_technique($id_incident)>0) && (get_verif_date_cloture_intevention_technique($id_incident)==0)))
					{
						return 0;
					}
				else
					{
						return 1;
					}
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  function update_cloturer_incident($id_incident,$date_cloture)
  {
  $connexion=ma_db_connexion();
                       $SQL1="UPDATE `new_incident_gab` SET 
					   `date_derniere_interv`='".mysqli_real_escape_string($connexion,$date_cloture)."',
					   `date_remise`='".mysqli_real_escape_string($connexion,$date_cloture)."',
					   `date_derniere_rappel`='".(mysqli_real_escape_string($connexion,$date_cloture))."', 
					   `etat_incident`='".get_verif_etat_incident($id_incident)."' 
                      WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
$result=mysqli_query($connexion,$SQL1);
    if (!$result)
    {
        error_log("Erreur SQL 1090: ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1090 !');
    }					mysqli_free_result($result);

/**Supression des incidents ouverts de la table intermediaire  en cas de  cloture**/
         if(get_verif_etat_incident($id_incident)==1)
         {
             $SQL2="DELETE FROM `new_incident_gab_ouvert` WHERE `id_incident`= '$id_incident'";
             $result2=mysqli_query($connexion,$SQL2);
             if (!$result2)
             {
                 error_log("Erreur SQL 1091: ".$SQL2."  ".mysqli_error($connexion));
                 die('ERREUR QUERY 1091 !');
             }
        }
  }
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_cloturer_intervention_incident($id_action,$motif_cloture,$date_cloture)
{
    $connexion=ma_db_connexion();
    $SQL1="UPDATE `new_intevention_incident` SET 
    `date_cloture`='".mysqli_real_escape_string($connexion,$date_cloture)."',
       `date_rappel`='".(mysqli_real_escape_string($connexion,$date_cloture))."', 
       `motif_cloture`='".(mysqli_real_escape_string($connexion,$motif_cloture))."', 
       `etat_cloture`='1'  
        WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id_action)."'";
    $result2=mysqli_query($connexion,$SQL1);
    if (!$result2)
    {
        error_log("Erreur SQL 1093: ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1093 !');
    }

    $Suppression="DELETE FROM  new_intevention_incident_tmp WHERE `id_incident`=  (SELECT id_incident FROM new_intevention_incident WHERE id_action_interv = '".mysqli_real_escape_string($connexion,$id_action)."')";
    $resultSuppression=mysqli_query($connexion,$Suppression);
    if (!$resultSuppression)
    {
        error_log("Erreur SQL 1094: ".$Suppression."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1093 !');
    }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function cloturer_rappel_gab($id_incident,$motif_cloture,$id_action_interv,$date_cloture)
{
    session_start();
    $connexion=ma_db_connexion();

    /*$date_actuel=date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y")));
    $duree = date_different(date_transaction($date_cloture), $date_actuel);
    //if (($duree['minutes_total']>=0) &&($duree['minutes_total']<=4500))
	$gab = get_gab_by_id_incid($id_incident);*/
	$delete_first_show_old_ca = "DELETE FROM atm_list_stopped_test WHERE id_incident = '".mysqli_real_escape_string($connexion,$id_incident)."'";
    $resultdelete=mysqli_query($connexion,$delete_first_show_old_ca);
    if (!$resultdelete)
    {
        error_log("Erreur SQL 1095: ".$delete_first_show_old_ca."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1095 !');
    }
    update_type_arret_prestataire($id_incident,$id_action_interv);
    update_type_arret_fournisseur($id_incident,$id_action_interv);
    update_cloturer_intervention_incident($id_action_interv,$motif_cloture,date_transaction($date_cloture));
    update_cloturer_incident($id_incident,date_transaction($date_cloture));
    update_disponibilite_intervention_gab($id_incident,date_transaction($date_cloture));

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_cloturer_incident_detail($terminal,$id_incident,$id_intervention,$id_degre)
{

    include "../languages/" . $_SESSION['lang'] . ".php";
    //array($nom_gab[0], $ip_adresse_gab[0], $id_prestataire[0], $id_fournisseur[0]);
    $gab=get_array_information_gab(get_return_information_gab($id_intervention));
    //return    array($id_action_intervention[0], $degre_intervention[0], $id_action[0]);
    $act=get_array_information_action_intervention(($id_intervention));

echo '
<form class="form-horizontal" role="form">
<div  class="form-group row">
<label for="input_terminal" class="col-sm-3 control-label">'.$lang['atm'].'</label>
				<div class="col-sm-9">
					<input placeholder="terminal" id="terminal" disabled name="terminal" type="text"   value="'.get_return_information_gab($id_intervention).'  -  '.$gab[0].'" class="form-control input-sm">
					<input  id="id_terminal_6"  name="id_terminal_6" type="hidden"   value="'.$terminal.'" class="form-control input-sm">
					<input  id="id_incident_6"  name="id_incident_6" type="hidden"   value="'.$id_incident.'"class="form-control input-sm">
					<input  id="id_degre_6"  name="id_degre_6" type="hidden"   value="'.$act[1].'" class="form-control input-sm">		
					<input  id="date_rappel_6"  name="date_rappel_6" type="hidden"   value="" class="form-control input-sm">				
					<input  id="id_action_interv_6"  name="id_action_interv_6" type="hidden"    value="'.$id_intervention.'"class="form-control input-sm">				
					<input  id="id_remarque_6"  name="id_remarque_6" type="hidden"   value="" class="form-control input-sm">				
					<input  id="id_note_6"  name="id_note_6" type="hidden"   value="'.$act[1].'" class="form-control input-sm">				
				</div>
				</div>
<div  class="form-group row">		
		<label for="input_terminal" class="col-sm-3 control-label">'.$lang['date_clo'].'</label>
		<div class="col-sm-9">
		<input  id="id_cloturer_6"  name="id_cloturer_6" type="text"   value="'.date('Y-m-d  H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y'))).'" class="form-control input-sm">
		</div>
	</div>			
<div  class="form-group row">				
<label for="inputrappel" class="col-sm-3 control-label">'.$lang['mot_clot'].'</label>
				<div class="col-sm-9">
				    			<select class="form-control" id="motif_cloturer_6" required name="motif_cloturer_6" >
											<option value="I">Intervention</option>
											<option value="R">'.$lang['rappo'].'</option>
			    </select>     
				</div>
				</div>	';


echo '</form> ';
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_information_contact_gab($id_gab)
{
    $connexion=ma_db_connexion();
    $sql="SELECT `id_contact`,`nom_contact`, `niveau_escalade`, `fonction_contact`, `nom_contact`, `fixe_contact1`, `fixe_contact2`, `adresse_mail`, `niveau_escalade`, `type_contact` FROM `new_list_contact_agence`   
         WHERE `code_filiale` like '".get_code_agence_agence(mysqli_real_escape_string($connexion,$id_gab))."'
		 GROUP BY `nom_contact`		 
         ORDER BY `niveau_escalade`,`id_contact` ASC";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1096: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1096 !');
    }
    if ($result)
	{
	    echo '<table class="table  table-striped"  style="font-size:11px;font-weight:bold;" class="table-responsive">';
		if(mysqli_num_rows($result)>0)
			{$i=0;
			while ($row = mysqli_fetch_assoc($result))
            {
                if ($i==0){echo ' <tr style="font-size:14px;font-weight:bold;text-align: center;"> <th>Niveau Escalade</th><th>Resposable Escaladé</th><th>Fonction </th><th>E-mail</th><th>GSM</th><th>Tel</th></tr>';}

                echo ' <tr>
					 <th><div id="div_niveau_escalade'.$row["id_contact"].'">';
					  echo get_niveau_escalade($row["id_contact"],trim($row["niveau_escalade"]));
					  echo '</div></th>
					 <th><div id="div_nom_contact'.$row["id_contact"].'">';
					  echo get_nom_contact($row["id_contact"],trim($row["nom_contact"]));
					  echo '</div></th>
					 <th><div id="div_fonction_contact'.$row["id_contact"].'">';
					  echo get_fonction_contact($row["id_contact"],trim($row["fonction_contact"]));
					  echo '</div></th>
					 <th><div id="div_mail_contact'.$row["id_contact"].'">';
					  echo get_mail_contact($row["id_contact"],trim($row["adresse_mail"]));
					  echo '</div></th>					 
					 <th><div id="div_gsm_contact'.$row["id_contact"].'">';
					  echo get_gsm_contact($row["id_contact"],trim($row["fixe_contact1"]));
					  echo '</div></th>
					 <th><div id="div_tel_contact'.$row["id_contact"].'">';
					  echo get_tel_contact($row["id_contact"],trim($row["fixe_contact2"]));
					  echo '</div></th></tr>';
					  $i++;
            }
			}
	 echo '	</table>';

		mysqli_free_result($result);
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_list_intervention_gab($id_terminal,$id_incident)
{
    include "languages/" . $_SESSION['lang'] . ".php";

    $connexion=ma_db_connexion();

    $sql = "SELECT 	`id_action_interv`, `id_incident`, `date_action`, `personne_avisee`,`date_prise_en_charge`,`etat_contact`, `id_action_intervention`, `id_affectation`, `nbr_escalade`,  `date_rappel`, `nbr_tentative`, `id_utilisateur`, `etat_cloture`, `remarque`, `note`, `degre_intervention`, `date_cloture`, `degre_appel`, `auto_cloture`
		FROM  `new_intevention_incident` 
		WHERE id_incident = '".mysqli_real_escape_string($connexion,$id_incident)."'
		ORDER BY `degre_appel`,nbr_escalade ASC ";
	mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1097: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1097 !');
    }

    if ($result)
    {
        echo '<div class="table-responsive">';
        if(mysqli_num_rows($result)>0)
        {
            echo '<table class="table table-responsive-sm table-hover table-outline mb-0"  >';

            echo '<tr>
				<th>NB Action</th>
				<th>'.$lang["probl"].'</th>
				<th>'.$lang["date_pri_ch"].'</th>
				<th>'.$lang["date_rap"].'</th>
				<th>'.$lang["date_clo"].'</th>
				<th>'.$lang["cont"].'</th>
				<th>'.$lang["pers_avi"].'</th>
				<th>'.$lang["eta_cont"].'</th>
				<th>'.$lang["nb_esc"].'</th>
				<th>'.$lang["n_app"].'</th>
				<th>'.$lang["Login_inp"].'</th>
				<th></th>
			</tr>';
			while ($row = mysqli_fetch_assoc($result))
			{

				//array($dateMancloture,$dateaMinction,$Maxnbrtentative,$Minnbrtentative)
				$info_technique=get_information_intevention_technique($row["id_incident"]);
				$date_cloture_intevention_technique=$info_technique[0][0];
				$min_date_intevention_technique=$info_technique[1][0];
				$min_nbr_tentative_technique =$info_technique[3][0];
			    $id_action_interv=$row["id_action_interv"];
			    $degre=$row["degre_intervention"];
				$count_nbr_tentative_technique=get_count_intervention_technique($row["id_incident"]);
		  			// if ($i % 2)
					{
                echo '<tr>';
                            }
                // else
                            {
                // echo '<tr>';
                            }
				echo '
				<th><div id="div_nbr_tentative'.$row["id_action_interv"].'">';
					echo get_nbr_tentative($row["id_action_interv"],$row["nbr_tentative"]);

				echo '</div></th>
				
					<th><div id="div_id_action_intervention'.$row["id_action_interv"].'">';
					echo get_libelle_action_intervention1($row["id_action_interv"],$row["id_action_intervention"]);
				echo '</div></th>			
                     
					 <th><div id="div_date_charge2'.$row["id_action_interv"].'">';
					  echo get_date_prise_charge2($row["id_action_interv"],$row["date_prise_en_charge"]);


					  echo' </div></th>	

					 <th><div id="div_date_rappel2'.$row["id_action_interv"].'">';
					 if (enabling_button($id_incident,0)=='disabled'){
						 echo get_date_rappel_sans_modif($row["id_action_interv"],$row["date_rappel"]);
					 } else {
					  echo get_date_rappel2($row["id_action_interv"],$row["date_rappel"]);
					 }
					  echo' </div></th>	
					 
					  
					  
				<th>';//get_date_rappel_sans_modif $row["nbr_tentative"]

			echo get_date_cloture_intervention($row["id_incident"],$row["id_action_interv"],$row["id_affectation"],$row["degre_appel"],$row["nbr_tentative"]);

				echo '</th>
				
				<th><div id="id_affectation'.$row["id_action_interv"].'">';
					echo get_libelle_id_affectation($row["id_action_interv"],$row["id_affectation"]);
				echo '</div></th>
				
				<th><div id="personne_avisee'.$row["id_action_interv"].'">';
					echo get_libelle_personne_avisee($row["id_action_interv"],$row["personne_avisee"]);
				echo '</div></th>	
				
				<th><div id="id_etat_contact'.$row["id_action_interv"].'">';
					echo get_libelle_etat_contact1($row["id_action_interv"],$row["etat_contact"]);
				echo '</div></th>
				';

				echo '<th><div id="div_nbr_escalade'.$row["id_action_interv"].'">';
					echo get_nbr_escalade($row["id_action_interv"],$row["nbr_escalade"]);
				echo '</div></th>
				<th><div id="div_nbr_appel'.$row["id_action_interv"].'">';
					echo get_nbr_degre_appel($row["id_action_interv"],$row["degre_appel"]);
				echo '</div></th>
				<th>'.get_utilisateur($row["id_utilisateur"]).'  '.get_auto_cloture($row["auto_cloture"]).'</th>
				<th>';



                if (verif_habilitation($_SESSION['habilitation_action'],9)==true)
                {
                    if (verif_habilitation($_SESSION['habilitation_action'],2)==true )
                    {
                        echo '<a title="Supprimer"><span class="c-icon cil-triangle" 
						 aria-hidden="true"
						 onclick="supprimer_intervention_incident_6(\''.$id_terminal.'\',\''.$id_incident.'\',\''.$row["id_action_interv"].'\',\''.$degre.'\',5)"></span></a>';
                    }
                }


				echo'</th>
			</tr>';

			}

			echo '<tr>
			
            <th colspan=3>';
			if (enabling_button($id_incident,0)=='disabled'){$typeModal='ajouter_rappel_detail_3_cloturer';}else $typeModal='ajouter_rappel_detail_3';
			if (verif_habilitation($_SESSION['habilitation_action'],2)==true)
			{
                echo' <button tabindex="-1" class="btn btn-primary btn-xs btn-block"  data-toggle="modal" onClick="javascript:get_ajouter_rappel_detail_3(\''.$id_terminal.'\',\''.$id_incident.'\',\''.$id_action_interv.'\',\''.$degre.'\',0)"   data-target="#'.$typeModal.'"><i class="fa fa-repeat"></i>&nbsp;'.$lang['relancer'].'</button>';
			}
			echo '</th>';
            /*echo '<th colspan=2>';
			if (verif_habilitation($_SESSION['habilitation_action'],2)==true)
			{
                echo' <button tabindex="-1" class="btn btn-primary btn-xs btn-block"  data-toggle="modal" onClick="javascript:get_nouveau_appel_gab(\''.$id_incident.'\')"   data-target="#'.$typeModal.'"><i class="fa fa-plus"></i>&nbsp;'.$lang['nv_ap'].'  </button>';
			}
			echo '</th>';*/
            echo'<th colspan=4>';
			if (verif_habilitation($_SESSION['habilitation_action'],2)==true)
			{
                echo' <button tabindex="-1" class="btn btn-primary btn-xs btn-block"  data-toggle="modal"  onClick="javascript:get_modifier_detail_5(\''.$id_terminal.'\',\''.$id_incident.'\',\''.$id_action_interv.'\',\''.$degre.'\',2)"   data-target="#modifier_detail_5"><i class="fa fa-pencil"></i>&nbsp;'.$lang['modifier'].' </button>';
			}
			echo '</th> <th colspan=4>';
			if (verif_habilitation($_SESSION['habilitation_action'],2)==true)
			{
                echo' <button '.enabling_button($id_incident,0).' tabindex="-1" class="btn  btn-danger  btn-xs btn-block"  data-toggle="modal"  onClick="javascript:get_cloturer_detail_6(\''.$id_terminal.'\',\''.$id_incident.'\',\''.$id_action_interv.'\',\''.$degre.'\',3)"   data-target="#cloturer_detail_6"><i class="fa fa-lock"></i>&nbsp;'.$lang['clot'].'</button>';
			}
			echo '</th>
			</tr>
			<tr>	
			<th colspan=12></th>
			</tr>	';


			mysqli_free_result($result);
        }
    }
get_remarque_incident_terminal_prestataire($id_incident);
//echo "<br>";
//get_remarque_incident_terminal_fournisseur($id_incident);
//get_note_incident($id_incident);
 echo '			
		</div>';
 echo '			
		</table>';
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_gab_by_id_incid($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT id_gab FROM `new_incident_gab` WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1098: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1098 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			    while ($row = mysqli_fetch_assoc($result))
                {
                    return $row["id_gab"];
                }
			}
		else
			{
				return "";
			}
		mysqli_free_result($result);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_rappel_by_id_incid($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT date_derniere_rappel FROM `new_incident_gab` WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1099: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1099 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["date_derniere_rappel"];
					}
			}

		mysqli_free_result($result);
	}

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_remise_by_id_incid($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT date_remise FROM `new_incident_gab` WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1100: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1100 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["date_remise"];
					}
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_arret_by_id_incid($id)
{
    $connexion=ma_db_connexion();
    $sql="SELECT date_arrete FROM `new_incident_gab` WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id)."'";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1101: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1101 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["date_arrete"];
					}
			}

		mysqli_free_result($result);
	}
    mysqli_close($connexion);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_modifier_incident($id_incident,$date_arret,$date_remise,$date_rappel,$etat)
{
    var_dump($etat);
    $connexion=ma_db_connexion();
    $date_arret_anc=get_date_arret_by_id_incid($id_incident);
    $date_remise_anc=get_date_remise_by_id_incid($id_incident);
    $date_last_rappel_anc=get_date_rappel_by_id_incid($id_incident);



    if ($etat==0){$date_remise='0000-00-00 00:00:00';}else{$date_remise=$date_remise;}

    $SQL11="UPDATE `new_incident_gab` SET 
	`date_arrete`='".mysqli_real_escape_string($connexion,$date_arret)."',
	`date_derniere_interv`='".mysqli_real_escape_string($connexion,$date_rappel)."',
	`date_remise`='".mysqli_real_escape_string($connexion,$date_remise)."',
	`date_derniere_rappel`='".(mysqli_real_escape_string($connexion,$date_rappel))."', 
	`etat_incident`='".(mysqli_real_escape_string($connexion,$etat))."'
     WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";

    $result11=mysqli_query($connexion,$SQL11);
    if (!$result11)
    {
        error_log("Erreur SQL 1102: ".$SQL11."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1102 !');
    }


    $SQL1="UPDATE `new_incident_gab_douteux` SET 
	`date_arrete`='".mysqli_real_escape_string($connexion,$date_arret)."',
	`date_derniere_interv`='".mysqli_real_escape_string($connexion,$date_rappel)."',
	`date_remise`='".mysqli_real_escape_string($connexion,$date_remise)."',
	`date_derniere_rappel`='".(mysqli_real_escape_string($connexion,$date_rappel))."', 
	`etat_incident`='".(mysqli_real_escape_string($connexion,$etat))."'
     WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."' ";

    $result1=mysqli_query($connexion,$SQL1);
    if (!$result1)
    {
        error_log("Erreur SQL 1103: ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1103 !');
    }

    /**Si Incident douteux***/
    $ifDouteux="SELECT * FROM new_incident_gab_douteux WHERE `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."' ";
    $result2=mysqli_query($connexion,$ifDouteux);
    if (!$result2)
    {
        error_log("Erreur SQL 1104: ".$ifDouteux."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1104 !');
    }

    /***Traitement sur la table tempo des incidents ouverts**/
    $tableT = "SELECT id_incident FROM new_incident_gab_ouvert WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."' ";
    $tableTemp=mysqli_query($connexion,$tableT);
    if (!$tableTemp)
    {
        error_log("Erreur SQL 1105: ".$tableT."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1105 !');
    }
    if ($tableTemp)
    {
        if(mysqli_num_rows($tableTemp) > 0)
        {
            if ($etat==0)
            {
                /***Corbeille Modif****/
                $gab = get_gab_by_id_incid($id_incident);
                $corb="INSERT INTO `corbeille_modified_incident` (id_inc, id_gab ,user_modified, action_modified, type_modified, date_arret_a, date_arret_n, date_last_rappel_a, date_last_rappel_n) 
			    VALUES ('".mysqli_real_escape_string($connexion,$id_incident)."','".mysqli_real_escape_string($connexion,$gab)."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',NOW(),'13','".mysqli_real_escape_string($connexion,$date_arret_anc)."','".mysqli_real_escape_string($connexion,$date_arret)."', '".mysqli_real_escape_string($connexion,$date_last_rappel_anc)."','".mysqli_real_escape_string($connexion,$date_rappel)."') ";
                $resultcorb=mysqli_query($connexion,$corb);
                if (!$resultcorb)
                {
                    error_log("Erreur SQL 1106: ".$corb."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 1106 !');
                }


                /********************/

                $date_remise='0000-00-00 00:00:00';
                $SQL2="UPDATE `new_incident_gab_ouvert` SET 
				`date_arrete`='".mysqli_real_escape_string($connexion,$date_arret)."',
                `date_derniere_interv`='".mysqli_real_escape_string($connexion,$date_rappel)."',
                `date_remise`='".mysqli_real_escape_string($connexion,$date_remise)."',
                `date_derniere_rappel`='".(mysqli_real_escape_string($connexion,$date_rappel))."', 
                `etat_incident`='".(mysqli_real_escape_string($connexion,$etat))."'
                WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
                $result22=mysqli_query($connexion,$SQL2);
                if (!$result22)
                {
                    error_log("Erreur SQL 1107: ".$SQL2."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 1107 !');
                }


            }
            else if($etat==1)
            {
                $Suppression="DELETE FROM  new_incident_gab_ouvert WHERE `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
                $resultSupp=mysqli_query($connexion,$Suppression);
                if (!$resultSupp)
                {
                    error_log("Erreur SQL 1108: ".$Suppression."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 1108 !');
                }
            }

        }
        else if ($etat==0)
        {

            /***Corbeille Modif****/
            $gab = get_gab_by_id_incid($id_incident);
            $corb="INSERT INTO `corbeille_modified_incident` (id_inc, id_gab ,user_modified, action_modified, type_modified, date_arret_a, date_arret_n, date_cloture_a, date_cloture_n) 
			VALUES ('".mysqli_real_escape_string($connexion,$id_incident)."','".mysqli_real_escape_string($connexion,$gab)."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',NOW(),'12','".mysqli_real_escape_string($connexion,$date_arret_anc)."','".mysqli_real_escape_string($connexion,$date_arret)."', '".$date_remise_anc."','".mysqli_real_escape_string($connexion,$date_remise)."') ";
            $resultcorb=mysqli_query($connexion,$corb);
            if (!$resultcorb)
            {
                error_log("Erreur SQL 1109: ".$corb."  ".mysqli_error($connexion));
                die('ERREUR QUERY 1109 !');
            }

            /********************/
            /***Traitement des incidents douteux****/
            ///if (mysqli_num_rows($ifDouteux)>0) (Appliquée pour tt types de modif incident)
            $up_cass= "SELECT * FROM Etat_Parc_Gab WHERE terminal_atm_number = '".mysqli_real_escape_string($connexion,$gab)."'";

            $resultup_cass=mysqli_query($connexion,$up_cass);
            if (!$resultup_cass)
            {
                error_log("Erreur SQL 1110: ".$up_cass."  ".mysqli_error($connexion));
                die('ERREUR QUERY 1110 !');
            }
            if ($resultup_cass)
            {
                if(mysqli_num_rows($resultup_cass)>0)
                {
                    while ($up_cass_donn= mysqli_fetch_assoc($resultup_cass))
                    {
                        $m1 = $up_cass_donn["cassette1_available_amount"];
                        $m2 = $up_cass_donn["cassette2_available_amount"];
                        $m3 = $up_cass_donn["cassette3_available_amount"];
                        $m4 = $up_cass_donn["cassette4_available_amount"];
                        $s1 = $up_cass_donn["cassette1_status"];
                        $s2 = $up_cass_donn["cassette2_status"];
                        $s3 = $up_cass_donn["cassette3_status"];
                        $s4 = $up_cass_donn["cassette4_status"];
                        $LastTrans=$up_cass_donn["last_transaction_date"];

                    }
                }
                mysqli_free_result($resultup_cass);
            }
           /* $up_cass_douteux= "UPDATE new_incident_gab SET if_chgmt_montant=1, m_c1_chgmt='".mysqli_real_escape_string($connexion,$m1)."', s_c1_chgmt='$s1',m_c2_chgmt='$m2', s_c2_chgmt='$s2',m_c3_chgmt='$m3', s_c3_chgmt='$s3',m_c4_chgmt='$m4', s_c4_chgmt='$s4' WHERE `id_incident`=  '$id_incident' ";
            $resultcass_douteux=mysqli_query(ma_db_connexion(),$up_cass_douteux) or die('Erreur up_cass_douteux  update_modifier_incident !<br>'.$up_cass_douteux.'<br>'.mysqli_error());
            mysqli_free_result($resultcass_douteux);
            $up_etat_Incident= "UPDATE new_incident_gab SET  up_last_Trans='$LastTrans' ,if_chgmt_montant= 1, m_c1_chgmt='$m1', s_c1_chgmt='$s1', m_c2_chgmt='$m2', s_c2_chgmt='$s2', m_c3_chgmt='$m3', s_c3_chgmt='$s3',m_c4_chgmt='$m4', s_c4_chgmt='$s4' WHERE `id_incident`=  '$id_incident' ";
            $resultetat_Incident=mysqli_query(ma_db_connexion(),$up_etat_Incident) or die('Erreur up_etat_Incident  update_modifier_incident !<br>'.$up_etat_Incident.'<br>'.mysqli_error());
            mysqli_free_result($resultetat_Incident);
            /********************/
            $insertionOuvert = "INSERT INTO  new_incident_gab_ouvert SELECT * FROM  new_incident_gab WHERE `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";

            var_dump("insertionOuvert : ".$insertionOuvert);
            $resultOuvert=mysqli_query($connexion,$insertionOuvert);
            if (!$resultOuvert)
            {
                error_log("Erreur SQL 01109: ".$insertionOuvert."  ".mysqli_error($connexion));
                die('ERREUR QUERY 01109 !');
            }
            /*$SuppressionDouteux = "DELETE FROM  new_incident_gab_douteux WHERE `id_incident`=  '$id_incident'";
            $resultDouteux=mysqli_query(ma_db_connexion(),$SuppressionDouteux) or die('Erreur SuppressionDouteux  update_modifier_incident !<br>'.$SuppressionDouteux.'<br>'.mysqli_error());
            mysqli_free_result($resultDouteux);*/


        }
        else if ($etat==1)
        {
            /***Corbeille Modif****/
            $gab = get_gab_by_id_incid($id_incident);
            $corb="INSERT INTO `corbeille_modified_incident` (id_inc, id_gab ,user_modified, action_modified, type_modified, date_arret_a, date_arret_n, date_cloture_a, date_cloture_n) 
			VALUES ('".mysqli_real_escape_string($connexion,$id_incident)."','".mysqli_real_escape_string($connexion,$gab)."','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',NOW(),'14','".mysqli_real_escape_string($connexion,$date_arret_anc)."','".mysqli_real_escape_string($connexion,$date_arret)."', '".mysqli_real_escape_string($connexion,$date_remise_anc)."','".mysqli_real_escape_string($connexion,$date_remise)."') ";
            $resultcorb=mysqli_query($connexion,$corb);
            if (!$resultcorb)
            {
                error_log("Erreur SQL 1111: ".$corb."  ".mysqli_error($connexion));
                die('ERREUR QUERY 1111 !');
            }
            /********************/
        }
        mysqli_free_result($tableTemp);
    }
    mysqli_close($connexion);
  }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function update_modifier_intervention_incident2($id_incident,$id_interv,$date_rappel,$etat,$date_remise)
{
    $connexion=ma_db_connexion();

 	$SQL1="UPDATE `new_intevention_incident` SET `date_rappel`='".(mysqli_real_escape_string($connexion,$date_rappel))."'    WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id_interv)."'";
    $resultSQL1=mysqli_query($connexion,$SQL1);
    if (!$resultSQL1)
    {
        error_log("Erreur SQL 1112: ".$SQL1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1112 !');
    }
;
    if ($etat==0)
    {$date_remise='0000-00-00 00:00:00';}
    $SQL2="UPDATE `new_intevention_incident` SET 
	`date_cloture`='".(mysqli_real_escape_string($connexion,$date_remise))."', 
	`etat_cloture`='".(mysqli_real_escape_string($connexion,$etat))."'
     WHERE  `id_incident`= '".mysqli_real_escape_string($connexion,$id_incident)."'";

    $resultSQL2=mysqli_query($connexion,$SQL2);
    if (!$resultSQL2)
    {
        error_log("Erreur SQL 1113: ".$SQL2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1113 !');
    }

    /****Incident douteux**/
    $SQLDouteux1="UPDATE `new_intevention_incident_douteux` SET 
	`date_rappel`='".(mysqli_real_escape_string($connexion,$date_rappel))."'
    WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id_interv)."' ";

    $resultDouteux1=mysqli_query($connexion,$SQLDouteux1);
    if (!$resultDouteux1)
    {
        error_log("Erreur SQL 1114: ".$SQLDouteux1."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1114 !');
    }

    if ($etat==0){$date_remise='0000-00-00 00:00:00';}
    $SQLDouteux2="UPDATE `new_intevention_incident_douteux` SET 
	`date_cloture`='".(mysqli_real_escape_string($connexion,$date_remise))."', 
	`etat_cloture`='".(mysqli_real_escape_string($connexion,$etat))."'
    WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."' ";

    $resultDouteux2=mysqli_query($connexion,$SQLDouteux2);
    if (!$resultDouteux2)
    {
        error_log("Erreur SQL 1115: ".$SQLDouteux2."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1115 !');
    }

    $tableTemp = "SELECT id_incident FROM new_intevention_incident_tmp WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
    // echo $tableTemp;
    $resultTemp=mysqli_query($connexion,$tableTemp);
    if (!$resultTemp)
    {
        error_log("Erreur SQL 1116: ".$tableTemp."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1116 !');
    }
    if($resultTemp)
    {
        if(mysqli_num_rows($resultTemp) > 0)
        {
            if ($etat==0)
            {
                $SQL1tp="UPDATE `new_intevention_incident_tmp` SET 
                `date_rappel`='".(mysqli_real_escape_string($connexion,$date_rappel))."'
                WHERE  `id_action_interv` = '".mysqli_real_escape_string($connexion,$id_interv)."'";
                $result1tp=mysqli_query($connexion,$SQL1tp);
                if (!$result1tp)
                {
                    error_log("Erreur SQL 1117: ".$SQL1tp."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 1117 !');
                }

                if ($etat==0){$date_remise='0000-00-00 00:00:00';}
                $SQL2tp="UPDATE `new_intevention_incident_tmp` SET `date_cloture`= '".mysqli_real_escape_string($connexion,$date_remise)."', `etat_cloture`='".mysqli_real_escape_string($connexion,$etat)."' WHERE  `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";

                $result2tp=mysqli_query($connexion,$SQL2tp);
                if (!$result2tp)
                {
                    error_log("Erreur SQL 1118: ".$SQL2tp."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 1118 !');
                }
            }
            else if($etat==1)
            {
                $Suppression="DELETE FROM  new_intevention_incident_tmp WHERE `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."' ";
                $resultsup=mysqli_query($connexion,$Suppression);
                if (!$resultsup)
                {
                    error_log("Erreur SQL 1119: ".$Suppression."  ".mysqli_error($connexion));
                    die('ERREUR QUERY 1119 !');
                }
            }

        }
    }

    else if ($etat==0)
    {
        $insertion = "INSERT INTO new_intevention_incident_tmp SELECT * FROM new_intevention_incident WHERE  `id_incident` =  '".mysqli_real_escape_string($connexion,$id_incident)."'";
        $resultins=mysqli_query($connexion,$insertion);
        if (!$resultins)
        {
            error_log("Erreur SQL 1120: ".$insertion."  ".mysqli_error($connexion));
            die('ERREUR QUERY 1120 !');
        }


        $SuppressionDouteux="DELETE FROM  new_intevention_incident_douteux WHERE `id_incident`=  '".mysqli_real_escape_string($connexion,$id_incident)."'";
        $resultDouteux=mysqli_query($connexion,$SuppressionDouteux);
        if (!$resultDouteux)
        {
            error_log("Erreur SQL 1121: ".$SuppressionDouteux."  ".mysqli_error($connexion));
            die('ERREUR QUERY 1121 !');
        }
    }
    mysqli_free_result($resultTemp);
    mysqli_close($connexion);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function modifier_incident_gab($id_incident,$id_interv,$date_arret,$date_remis,$date_rappel,$etat)
{
 session_start();
 ///////////////////////////////////////////////
 update_type_arret_prestataire($id_incident,$id_interv);
 update_type_arret_fournisseur($id_incident,$id_interv);
 update_modifier_intervention_incident2($id_incident,$id_interv,$date_rappel,$etat,$date_rappel);
 update_modifier_incident($id_incident,$date_arret,$date_rappel,$date_rappel,$etat);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_modifier_incident_detail($terminal,$id_incident,$id_intervention,$id_degre)
{
    include "../languages/" . $_SESSION['lang'] . ".php";
    $gab=get_array_information_gab(get_return_information_gab($id_intervention));
    //return  array($date_arrete[0], $date_remise[0], $date_rappel[0], $etat_incident[0]);
    $inc=get_array_modifier_incident_gab(($id_incident));

    echo '<form class="form-horizontal" role="form">
    <div  class="form-group row">
    <label for="input_terminal" class="col-sm-3 control-label">'.$lang['atm'].'</label>
				<div class="col-sm-9">
				    <input  id="date_remis_5"  name="date_remis_5" type="hidden"   value="'.$inc[1].'" class="form-control input-sm">
					<input placeholder="terminal" id="terminal" disabled name="terminal" type="text"   value="'.get_return_information_gab($id_intervention).'  -  '.$gab[0].'" class="form-control input-sm">
					<input  id="id_terminal_5"  name="id_terminal_5" type="hidden"   value="'.$terminal.'" class="form-control input-sm">
					<input  id="id_incident_5"  name="id_incident_5" type="hidden"   value="'.$id_incident.'"class="form-control input-sm">
    				<input  id="id_intervention_5"  name="id_intervention_5" type="hidden"    value="'.$id_intervention.'"class="form-control input-sm">				
    			</div>
				</div>
	<div  class="form-group row">		
		<label for="input_terminal" class="col-sm-3 control-label">'.$lang['stop_date'].'</label>
		<div class="col-sm-9">
		<input  id="date_arret_5"  name="date_arret_5" type="text"   value="'.$inc[0].'" class="form-control input-sm">
		</div>
	</div>	

    <div  class="form-group row">		
		<label for="input_terminal" class="col-sm-3 control-label">';if ($inc[3]=="0"){echo $lang['date_rap'];}else{echo$lang['date_clo'];} echo '</label>
		<div class="col-sm-9">
		<input  id="date_rappel_5"  name="date_rappel_5" type="text"   value="'.$inc[2].'" class="form-control input-sm">
		</div>
	</div>	
	
	<div  class="form-group row">		
		<label for="input_terminal" class="col-sm-3 control-label">'.$lang['etat_inci'].'</label>
		<div class="col-sm-9">
				<select class="form-control" id="etat_incident_5" required name="etat_incident_5" >';

				echo '	<option value="'.$inc[3].'">';if ($inc[3]=="0"){echo $lang["ouver"];}else{echo$lang["clot"];} echo '</option>';
				echo '	<option value="0">'.$lang['ouver'].'</option>
						<option value="1">'.$lang['clot'].'</option>

			    </select>   
		</div>
	</div>';


echo '</form> ';
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function enabling_button($idInc,$forcage)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT etat_incident
		FROM  `new_incident_gab` 
		WHERE id_incident = '".mysqli_real_escape_string($connexion,$idInc)."' ";

    mysqli_query(ma_db_connexion(),"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1122: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1122 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
		{
            while ($row = mysqli_fetch_assoc($result))
            {
                //$etat_incident = $row["etat_incident"];
                if($row["etat_incident"]==1)
                {
                    return ("disabled");
                }
                else
                    {
                        return ("");
                    }
            }

		}
		else
		{
            return ("");
		}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function control_last_refresh_data_gab($bpr)
{
    $connexion=ma_db_connexion();
    $sql= "SELECT MAX(date_extraction) AS Max_Date_BPR	FROM  new_verif_extration_xml 	WHERE  id_bpr ='".mysqli_real_escape_string($connexion,$bpr)."' ";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1123: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1123 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($myDate = mysqli_fetch_assoc($result))
					{
						$dateRf = $myDate["Max_Date_BPR"];
					}
			}

        mysqli_free_result($result);
        $totalDate = date('d-m-Y  H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y')));
        // echo $totalDate."  hhhhh<br>";
        $datetime1 = new DateTime($dateRf);
        $datetime2 = new DateTime($totalDate);

        $difference = $datetime2->diff($datetime1);

        $years = $difference->y;
        $months = $difference->m;
        $days = $difference->d;
        $hours = $difference->h;
        $min = $difference->i;
        $sec = $difference->s;

        $minutes = $days * 24 * 60;
        $minutes +=$hours * 60;
        $minutes +=$min;
        if ($minutes <= 5){return 1;}else {return 0;}
	}
    mysqli_close($connexion);
}
/*******************************************************************************************************************************************/
function getFilialesChehckBox2_partition_bpr($BPRs)
{
    $connexion=ma_db_connexion();
    $sql="SELECT 	id_user_bpr, type_user_bpr, user_br_list FROM user_bpr";

    $result=mysqli_query($connexion,$sql);
    if (!$result)
    {
        error_log("Erreur SQL 1124: ".$sql."  ".mysqli_error($connexion));
        die('ERREUR QUERY 1124 !');
    }
    if ($result)
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						if($row["id_user_bpr"]==$BPRs){$etat2="checked='checked'";}else {$etat2="";}
						echo"<div class='checkbox'>
						<label><input type='checkbox' name='id_user_bpr' value='".$row["id_user_bpr"]."' ".$etat2.">".$row["type_user_bpr"]."</label>
						</div>";
					}
			}
		mysqli_free_result($result);
	}
    mysqli_close($connexion);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_libelle_traiter_incident2($id)
{
// if ($id==0){  return ' <span class="label label-info" style="font-size:14px;font-weight:bold;text-align: center;">'.get_libelle_traiter_incident($id).'</span>';}
if ($id==1){  return ' <span class="label label-danger" style="font-size:14px;font-weight:bold;text-align: center;">'.get_libelle_traiter_incident($id).'</span> -';}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_return_libelle_groupe($id)
{
$sql = "SELECT  `nom_filiale` FROM  `new_list_gab`,`new_filiale` 	WHERE   `new_filiale`.`id_filiale`= `new_list_gab`.`code_bank` AND `new_list_gab`.`terminal`  LIKE '".$id."'";

if ($result=mysqli_query(ma_db_connexion(),$sql) or die('Erreur   get_return_libelle_groupe !<br>'.$sql.'<br>'.mysqli_error()))
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return " - ".$row["nom_filiale"];
					}
			}
		else
			{
				return "";
			}
				mysqli_free_result($result);
	}
}
/*******************************************************************************************************************************************/
function dureeInactivite($lastTrs)
{

    $totalDate = date('d-m-Y  H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y')));
    $datetime1 = new DateTime($totalDate);
    $datetime2 = new DateTime($lastTrs);
    $difference = $datetime1->diff($datetime2);
    $years = $difference->y;
    $months = $difference->m;
    $days = $difference->d;
    $hours = $difference->h;
    $min = $difference->i;
    $sec = $difference->s;

    if($months >= 1){echo $months." M<br>";}
    if($days >= 1)
    {
        if ($_SESSION['lang']=='fr')
        {
            echo $days." J<br>";
        }
        else
        {
            echo $days." Day<br>";
        }
    }
    if($hours >= 1){echo $hours." h<br>";}
    echo $min." min";
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getpull_ej($terminal,$date,$lang)
{
    $connexion=ma_db_connexion();
    $annee = substr($date,0,-6);
    $mois = substr($date,5,-3);
    $jours = substr($date,-2);
    $filename = 'EJ_'.$annee.'_'.$mois.'_'.$jours.'.txt';
    $SQL="SELECT `terminal`,`nom_gab`,`id_atm`,`id_content`,`data`,`hash_code`, `name_file`, `date_upload`,`state_approbation`, `size_file` 
    FROM `upload_contents`, `new_list_gab`
    WHERE `new_list_gab`.`id_terminal_xfs` = `upload_contents`.`id_atm` AND
    `new_list_gab`.`terminal` = '".mysqli_real_escape_string($connexion,$terminal)."' ";


    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 443:  ".$SQL."  " .mysqli_error($connexion));
        die('ERREUR QUERY 443 !'.$SQL);
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            echo '<table class="table table-responsive-sm table-hover table-outline mb-0">
                    <thead class="thead-light">
                        <tr>
                            <th class="text-center">ID</th>
                            <th class="text-center">'.$lang['atm_id'].'</th>
                            <th class="text-center">'.$lang['atm_name'].'</th>
                            <th class="text-center">File Name</th>
                            <th class="text-center">File Size</th>
                            <th class="text-center">File upload date</th>
                            <th class="text-center">Download File</th>
                            <th class="text-center">View File</th>
                            
                        </tr>
                    </thead>
                    <tbody>';
            while ($row = mysqli_fetch_assoc($result))
            {
                $filedata = $row['data'];
               // $filename = $row['name_file'];
                $id_content = $row['id_content'];

                // header("Content-length: ".strlen($filedata));
                // header("Content-disposition: download; filename=$filename");

                echo '<tr> 
                    <td style="padding: 3px" align="center">' . $row['id_atm'] . '</td>   
                    <td style="padding: 3px" align="center">' . $row['terminal'] . '</td>   
                    <td style="padding: 3px" align="center">' . $row['nom_gab'] . '</td>   
                    <td style="padding: 3px" align="center">' . $filename . '</td>   
                    <td style="padding: 3px" align="center">' . $row['size_file']/1000 . ' KO</td>   
                    <td style="padding: 3px" align="center">' . $row['date_upload'] . '</td>   ';
                if ($row['state_approbation']=="3")
                {
                    echo' <td style="padding: 3px" align="center"><a href="data:file;base64,'.base64_encode( $filedata ).'"  download="' . $filename . '">Download</td>';
                }
                else
                {
                    echo' <td style="padding: 3px" align="center"><a  tabindex="-1"  
                        onClick="javascript:DownloadFileATM(\''.$terminal.'\',\''.$id_content.'\')" data-dismiss="modal"> 
                        <i class="fa fa-cloud-download" title="Télécharger Fichier"></i></a></td>';
                }
                echo '<td style="padding: 3px" align="center">
                    <a class="text-center dropdown-item " tabindex="-1" data-toggle="modal" 
                    onClick="javascript:getjournalATM(\'' . $row["id_atm"] . '\',\'' . $terminal . '\')"    
                    data-target="#detailjournalATM"> <strong style="color:#52c322" ><i class="fa fa-newspaper-o fa-2x" title="E-J"> </i></strong></a>
                </td>';
                echo'  <!--<td style="padding: 3px" align="center"><a target="_blank" href="data:file;base64,/\'//.base64_encode( $filedata )./\'"  >View</a></td>-->
               </tr>';
            }
            echo '</tbody>
            </table>';
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function all_incident_ouvert($terminal="",$lang)
{
    $liste_affect=get_liste_affectation_nasser();
    $liste_action_na=get_action_nasser();
    if($terminal==""){$terminal="%";}


    if( empty($_POST['id_user_bpr']) ){$_POST['id_user_bpr'] ="";}
    if( empty($_POST['if_ext']) ){$_POST['if_ext'] ="";}
    /***************/
    if($_POST['if_ext']==666){$etat1="checked='checked'";}else {$etat1="";}
    if($_POST['if_ext']==333){$etat2="checked='checked'";}else {$etat2="";}


    $list="SELECT 	id_user_bpr, type_user_bpr, user_br_list
	FROM user_bpr WHERE id_user_bpr like '".$_POST['id_user_bpr']."'  ";
    if ($ops=mysqli_query(ma_db_connexion(),$list) or die('Erreur   liste_rappel !!!! !<br>'.$list.'<br>'.mysqli_error()))
    {
        if (mysqli_num_rows($ops)>0)
        {

            while ($usersBPR= mysqli_fetch_assoc($ops)){ $partitionBPR = $usersBPR['user_br_list']; }
        }
        mysqli_free_result($ops);
    }
    /***************/
		if ($listExternalise=mysqli_query(ma_db_connexion(),"SELECT terminal FROM new_list_gab WHERE gestion=10")or die('listExternalise'.mysqli_error()))
		{
		while ($list= mysqli_fetch_assoc($listExternalise)){ $gab= $list["terminal"]; $listGabEXT[]= $gab; }
		if(isset($listGabEXT)){$listGabEXTFinal = implode(',',$listGabEXT);	}
		mysqli_free_result($listExternalise);
		}

        if(isset($partitionBPR))
        {
            if(empty($_POST['if_ext']))
            {
                $SQL = "SELECT `id_incident`,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`,`remarque_frss`, `remarque_press` ,`date_derniere_rappel` ,`etat_stat`,`new_list_gab`.`id_terminal_xfs`
                FROM `new_incident_gab_ouvert`,`new_list_gab`
                WHERE  `new_list_gab`.`terminal`=`new_incident_gab_ouvert`.`id_gab`
                AND ( trim(`id_gab`) like trim('$terminal')  OR UPPER(`nom_gab`) like '%".strtoupper($terminal)."%'  OR trim(`id_incident`) like '%".trim($terminal)."%'  ) 						
                AND (cd_filiale IN ($partitionBPR))
                ORDER BY `id_incident`	ASC";
            }
            else
            {
                if ($_POST['if_ext']==666){$stringRequest="(id_gab IN ($listGabEXTFinal))";} else {$stringRequest="(id_gab NOT IN ($listGabEXTFinal))";}
                $SQL = "SELECT `id_incident`,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`,`remarque_frss`, `remarque_press` ,`date_derniere_rappel` ,`etat_stat` ,`new_list_gab`.`id_terminal_xfs`
                FROM `new_incident_gab_ouvert`,`new_list_gab`
                WHERE  `new_list_gab`.`terminal`=`new_incident_gab_ouvert`.`id_gab`
                AND ( trim(`id_gab`) like trim('$terminal')  OR UPPER(`nom_gab`) like '%".strtoupper($terminal)."%'  OR trim(`id_incident`) like '%".trim($terminal)."%'  ) 						
                AND (cd_filiale IN ($partitionBPR))
                AND ".$stringRequest."
                ORDER BY `id_incident`	ASC";
            }
        }
        else
        {
            if(empty($_POST['if_ext']))
            {
                $SQL = "SELECT `id_incident`,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`,`remarque_frss`, `remarque_press` ,`date_derniere_rappel` ,`etat_stat` ,`new_list_gab`.`id_terminal_xfs`
                FROM `new_incident_gab_ouvert`,`new_list_gab`
                WHERE  `new_list_gab`.`terminal`=`new_incident_gab_ouvert`.`id_gab`
                AND ( trim(`id_gab`) like trim('$terminal')  OR UPPER(`nom_gab`) like '%".strtoupper($terminal)."%'  OR trim(`id_incident`) like '%".trim($terminal)."%'  ) 						
                ORDER BY `id_incident`	ASC";


            }
            else
            {
                if ($_POST['if_ext']==666){$stringRequest="(id_gab IN ($listGabEXTFinal))";} else {$stringRequest="(id_gab NOT IN ($listGabEXTFinal))";}

                $SQL = "SELECT `id_incident`,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`,`remarque_frss`, `remarque_press` ,`date_derniere_rappel` ,`etat_stat` ,`new_list_gab`.`id_terminal_xfs`
                FROM `new_incident_gab_ouvert`,`new_list_gab`
                WHERE  `new_list_gab`.`terminal`=`new_incident_gab_ouvert`.`id_gab`
                AND ( trim(`id_gab`) like trim('$terminal')  OR UPPER(`nom_gab`) like '%".strtoupper($terminal)."%'  OR trim(`id_incident`) like '%".trim($terminal)."%'  ) 						
                AND ".$stringRequest."
                ORDER BY `id_incident`	ASC";
            }
        }



        if ($result=mysqli_query(ma_db_connexion(),$SQL) or die('Erreur   SQL !!!!!!!!!!!!!!!!!!!!!! !<br>'.$SQL.'<br>'.mysqli_error()))
        {
            echo '<table  class="table table-responsive-sm table-hover table-outline mb-0" >   
                <thead class="thead-light">
                    <tr >
                        <th class="text-center"></th>
                        <th class="text-center">'.$lang["atm_id"].'</th>
                        <th class="text-center">'.$lang["atm_name"].'</th>
                        <th class="text-center">'.$lang["cause_default"].'</th>
                        <th class="text-center">'.$lang["date_inter"].'</th>
                        <th class="text-center">'.$lang["date_remi"].'</th>
                        <th class="text-center">'.$lang["dure"].'</th>
                        <th class="text-center"></th>
                        <!--<th class="text-center">#</th>-->
                    </tr>
                </thead>
           <tbody>';
            if(mysqli_num_rows($result)>0)
            {
                $i=0;

                while ($row = mysqli_fetch_assoc($result))
                {
                    $idfilial=getfilialATM($row["id_terminal_xfs"]);
                    list($id_poste_affecter, $name_poste_affecter) = explode('---', get_post_affect_ATM($idfilial));
                    $name_poste_affecter=str_replace(CHR(32),'',$name_poste_affecter);
                    $gab=get_array_information_gab($row["id_gab"]);
                    $duree_rappel  = date_different(date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))), $row["date_derniere_rappel"]);

                    if ($duree_rappel['minutes_total']>=240)
                    {
                        echo '<td class="text-center"><span class="badge badge-pill badge-danger">+ 4H</span></td>';
                    }
                    else if (($duree_rappel['minutes_total']<240) && ($duree_rappel['minutes_total']>=120))
                    {
                        echo '<td class="text-center"><span class="badge badge-pill badge-warning">+ 2H</span></td>';
                    }
                    else if (($duree_rappel['minutes_total']<120) && ($duree_rappel['minutes_total']>=0))
                    {
                        echo '<td class="text-center"><span class="badge badge-pill badge-success">- 2H</span></td>';
                    }
                    echo '<td class="text-center">'.get_libelle_traiter_incident2($row["etat_stat"]).' '.$row["id_gab"].'</td>
                    <td class="text-center"><a target="_blank" title="N°  Dossier : '.$row["id_incident"].'" href="detail_gab.php?ternimal='.$row["id_gab"].'&id='.$row["id_incident"].'" >'.$gab["0"].' '.get_return_libelle_groupe($row["id_gab"]).'</a></td>
                    <td class="text-center">';
                    $inter=get_liste_action_nasser($row["id_incident"]);
                    $nb_inter=get_count_nbr_intervention($row["id_incident"]);

                    /******************************************************/

                    for($j=0;$j<$nb_inter;$j++) // tant que $i est inferieur au nombre d'éléments du tableau...
                    {
                        //	if((!empty($inter[2][$j])))
                        if((!empty($inter[3][$j])))
                        {
                            echo ($j+1)." - ".$liste_action_na[$inter[3][$j]]."<br>";
                        }
                        //else if((empty($inter[2][$j])))
                        else if((empty($inter[3][$j])))
                        {
                            if ($j=="0")
                            {
                                echo '<p style="text-align: center;"><a><span class="fa fa-minus"></span></a></p>';
                            }
                        }
                    }
                    /******************************************************/
                    echo'</td>
                    <td class="text-center">';
                   for($j=0;$j<$nb_inter;$j++) // tant que $i est inferieur au nombre d'éléments du tableau...
                   {
                       if((!empty($inter[2][$j])))
                       {
                           echo $inter[1][$j]." - ". $liste_affect[$inter[2][$j]]."<br>";
                       }
                       else if((empty($inter[2][$j])))
                       {
                           if ($j=="0")
                           {
                               echo '<p style="text-align: center;"><a><span class="fa fa-minus"></span></a></p>';
                           }
                       }
                   }
                   /******************************************************/
                   echo'</td>
                   
                   
                    <td class="text-center">';
                        echo '<input  type="text"   style="font-size:8px;font-weight:bold;color:#000;" size="20" value=""  placeholder="YYYY-MM-DD HH:MN:SS" class="form-control input-sm" onChange="javascript:cloturer_incident_fonctionnelle2(\''.$row["id_incident"].'\','.$i.',\'0\')" id="cloture_fonction'.$i.'" name="cloture_fonction">';

                    echo '</td>
                
                    <td class="text-center">';
                    /***Calcul Durée***/
                    /*kamar
                    $date = date("d-m-Y");
                    $hr=date("H")+regle_heure_backoffice();
                    $heure = gmdate("$hr:i:s");
                    $totalDate=$date." ".$heure;
                    */

                    $totalDate = date('d-m-Y  H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y')));
                    $datetime1 = new DateTime($totalDate);
                    $datetime2 = new DateTime($row["date_derniere_rappel"]);

                    $difference = $datetime1->diff($datetime2);

                    $years = $difference->y;
                    $months = $difference->m;
                    $days = $difference->d;
                    $hours = $difference->h;
                    $min = $difference->i;
                    $sec = $difference->s;
                    if ($_SESSION['lang']=='fr')
                    {
                        if($datetime1<$datetime2)
                        {
                            if($months >= 1){echo "- ".$months." M<br>";}
                            if($days >= 1){echo "- ".$days." J<br>";}
                            if($hours >= 1){echo "- ".$hours." h<br>";}
                            echo "- ".$min." min";
                        }
                        if ($datetime2<$datetime1)
                        {
                            if($months >= 1){echo "+ ".$months." M<br>";}
                            if($days >= 1){echo "+ ".$days." J<br>";}
                            if($hours >= 1){echo "+ ".$hours." h<br>";}
                            echo "+ ".$min." min";
                        }
                    }
                    else
                    {
                        if($datetime1<$datetime2)
                        {
                            if($months >= 1){echo "- ".$months." M<br>";}
                            if($days >= 1){echo "- ".$days." Day<br>";}
                            if($hours >= 1){echo "- ".$hours." h<br>";}
                            echo "- ".$min." min";
                        }
                        if ($datetime2<$datetime1)
                        {
                            if($months >= 1){echo "+ ".$months." M<br>";}
                            if($days >= 1){echo "+ ".$days." Day<br>";}
                            if($hours >= 1){echo "+ ".$hours." h<br>";}
                            echo "+ ".$min." min";
                        }
                    }


                    echo'</td>';
                    echo '<td class="text-center">';
                    if ($row["remarque_press"]<>"")
                    {
                      echo' <a tabindex="-1"  data-toggle="modal"  onClick="javascript:get_remarque_incident_pres(\''.$row["id_incident"].'\')"   data-target="#show_remarque_incident"><span Title="'.$lang['rem_inci'].'"  class="c-icon cil-list-filter"></span> </a>';
                    }
                    echo ' </td>';


                    echo ' </tr>';
                    $i++;
                }
            }
            else
            {
                echo ' <tr>';
                echo '<th colspan =9>
                        <div class="alert alert-danger text-center" role="alert">'.$lang['gab_non_trou'].'</div></th>';
                echo '</tr>';
            }
            echo '</tbody> 
            </table>';
            mysqli_free_result($result);
        }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function liste_rappel($terminal="")//Nouvelle
{
    include "languages/" . $_SESSION['lang'] . ".php";

    $connexion=ma_db_connexion();
    $liste_affect=get_liste_affectation_nasser();
    $liste_action_na=get_action_nasser();
    if($terminal==""){$terminal="%";}
    $avant=date('Y-m-d  H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d')-15,date('Y')));
    $apres=date('Y-m-d  H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y')));

    //echo $sql;
    if( empty($_POST['id_user_bpr']) ){$_POST['id_user_bpr'] ="";}
    if( empty($_POST['if_ext']) ){$_POST['if_ext'] ="";}
    /***************/
    if($_POST['if_ext']==666){$etat1="checked='checked'";}else {$etat1="";}
    if($_POST['if_ext']==333){$etat2="checked='checked'";}else {$etat2="";}


    $list="SELECT 	id_user_bpr, type_user_bpr, user_br_list
	FROM user_bpr WHERE id_user_bpr like '".mysqli_real_escape_string($connexion,$_POST['id_user_bpr'])."'";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $ops=mysqli_query($connexion,$list);

    if (!$ops)
    {
        error_log("Erreur SQL 1125:  ".$list."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 1125 !');
    }
    if ($ops)
    {
        if (mysqli_num_rows($ops)>0)
        {
            while ($usersBPR= mysqli_fetch_assoc($ops))
            {
                $partitionBPR = $usersBPR['user_br_list'];
            }
        }
        mysqli_free_result($ops);
    }
    /***************/
    $SQLExternalise="SELECT terminal FROM new_list_gab WHERE gestion=10";
    $listExternalise=mysqli_query($connexion,$SQLExternalise);
    if (!$ops)
    {
        error_log("Erreur SQL 1126:  ".$SQLExternalise."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 1126 !');
    }
    if ($listExternalise)
    {
        while ($list= mysqli_fetch_assoc($listExternalise))
        {
            $gab= $list["terminal"];
            $listGabEXT[]= $gab;
        }
        if(isset($listGabEXT))
        {
            $listGabEXTFinal = implode(',',$listGabEXT);
        }
        mysqli_free_result($listExternalise);
    }

    if(isset($partitionBPR))
    {
        if(empty($_POST['if_ext']))
        {
            /************************************************************/
            if ((date('D')=="Sat") ||(date('D')=="Sun"))//Rappel du weekend
			{
			/************************************************************/
                $SQL = "SELECT  `new_incident_gab_ouvert`.`id_incident` AS id_incident,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`  , `remarque_frss`, `remarque_press`, `remarque_press` , `date_derniere_rappel`, `etat_stat` 
                FROM `new_incident_gab_ouvert`
                WHERE `date_derniere_rappel` BETWEEN '".mysqli_real_escape_string($connexion,$avant)."' AND '".mysqli_real_escape_string($connexion,$apres)."'
                AND   `id_niveau_fonctionelle` =1 AND `id_niveau_technique`=0
                AND (cd_filiale IN ('".mysqli_real_escape_string($connexion,$partitionBPR)."'))
                ORDER BY `date_derniere_rappel` ASC";
			}
			else
			{
			    // $hour_alerte=date("H:i:s", mktime(date("H")+fusion_horaire(), date("i"), date("s")));
                $hour_alerte=date("H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s")));
                list($h, $m,$s) = explode(':', $hour_alerte);
                $hour=$h.''.$m.''.$s;
                if (($hour>="063000") AND ($hour<="213000"))
                {
                    $SQL = "SELECT  `new_incident_gab_ouvert`.`id_incident` AS id_incident,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`  , `remarque_frss`, `remarque_press`, `remarque_press` , `date_derniere_rappel` , `etat_stat` 
                    FROM `new_incident_gab_ouvert`
                    WHERE `date_derniere_rappel` BETWEEN '".mysqli_real_escape_string($connexion,$avant)."' AND '".mysqli_real_escape_string($connexion,$apres)."'
                    AND (cd_filiale IN ('".mysqli_real_escape_string($connexion,$partitionBPR)."'))
                    ORDER BY `date_derniere_rappel` ASC";
                }
                else
                {
                    $SQL = "SELECT  `new_incident_gab_ouvert`.`id_incident` AS id_incident,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`  , `remarque_frss`, `remarque_press`, `remarque_press` , `date_derniere_rappel` , `etat_stat` 
                    FROM `new_incident_gab_ouvert`
                    WHERE  `date_derniere_rappel`  BETWEEN '".mysqli_real_escape_string($connexion,$avant)."'   AND '".mysqli_real_escape_string($connexion,$apres)."'
                    AND   `id_niveau_fonctionelle` =1 AND `id_niveau_technique`=0
                    AND (cd_filiale IN ('".mysqli_real_escape_string($connexion,$partitionBPR)."'))
                    ORDER BY `date_derniere_rappel` ASC";
                }
			}
			/************************************************************/
        }
        else
        {
            if ($_POST['if_ext']==666)
            {
                $stringRequest="(id_gab IN ($listGabEXTFinal))";
            }
            else
            {
                $stringRequest="(id_gab NOT IN ($listGabEXTFinal))";
            }

            if ((date('D')=="Sat") ||(date('D')=="Sun"))//Rappel du weekend
			{
			    /************************************************************/
                $SQL = "SELECT  `new_incident_gab_ouvert`.`id_incident` AS id_incident,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`  , `remarque_frss`, `remarque_press`, `remarque_press` , `date_derniere_rappel`, `etat_stat` 
                FROM `new_incident_gab_ouvert`
                WHERE `date_derniere_rappel`  BETWEEN '".mysqli_real_escape_string($connexion,$avant)."' AND '".mysqli_real_escape_string($connexion,$apres)."'
                AND   `id_niveau_fonctionelle` =1 AND `id_niveau_technique`=0
                AND (cd_filiale IN ('".mysqli_real_escape_string($connexion,$partitionBPR)."'))
                AND '".mysqli_real_escape_string($connexion,$stringRequest)."'
                ORDER BY    `date_derniere_rappel` ASC ";
			}
			else
			{
			    // $hour_alerte=date("H:i:s", mktime(date("H")+fusion_horaire(), date("i"), date("s")));
                $hour_alerte=date("H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s")));
                list($h, $m,$s) = explode(':', $hour_alerte);
                $hour=$h.''.$m.''.$s;
                if (($hour>="063000") AND ($hour<="213000"))
                {
                    $SQL = "SELECT  `new_incident_gab_ouvert`.`id_incident` AS id_incident,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`  , `remarque_frss`, `remarque_press`, `remarque_press` , `date_derniere_rappel` , `etat_stat` 
					FROM `new_incident_gab_ouvert`
                    WHERE `date_derniere_rappel`  BETWEEN '".mysqli_real_escape_string($connexion,$avant)."' AND '".mysqli_real_escape_string($connexion,$apres)."'
                    AND (cd_filiale IN ('".mysqli_real_escape_string($connexion,$partitionBPR)."'))
                    AND '".mysqli_real_escape_string($connexion,$stringRequest)."'
                    ORDER BY `date_derniere_rappel` ASC";
                }
                else
                {
                    $SQL = "SELECT  `new_incident_gab_ouvert`.`id_incident` AS id_incident,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`  , `remarque_frss`, `remarque_press`, `remarque_press` , `date_derniere_rappel` , `etat_stat` 
                    FROM `new_incident_gab_ouvert`
                    WHERE `date_derniere_rappel`  BETWEEN '".mysqli_real_escape_string($connexion,$avant)."' AND '".mysqli_real_escape_string($connexion,$apres)."'
                    AND   `id_niveau_fonctionelle` =1 AND `id_niveau_technique`=0
                    AND (cd_filiale IN ('".mysqli_real_escape_string($connexion,$partitionBPR)."'))
                    AND '".mysqli_real_escape_string($connexion,$stringRequest)."'
                    ORDER BY `date_derniere_rappel` ASC";
                }
			}
			/************************************************************/
        }
    }
    else
    {
        if(empty($_POST['if_ext']))
        {
            /************************************************************/
            if ((date('D')=="Sat") ||(date('D')=="Sun"))//Rappel du weekend
			{
			/************************************************************/
                $SQL = "SELECT  `new_incident_gab_ouvert`.`id_incident` AS id_incident,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`  , `remarque_frss`, `remarque_press`, `remarque_press` , `date_derniere_rappel`, `etat_stat` 
                FROM `new_incident_gab_ouvert`
                WHERE  `date_derniere_rappel`  BETWEEN '".mysqli_real_escape_string($connexion,$avant)."' AND '".mysqli_real_escape_string($connexion,$apres)."'
                AND   `id_niveau_fonctionelle` =1 AND `id_niveau_technique`=0
                ORDER BY `date_derniere_rappel` ASC";
			}
			else
			{
			    // $hour_alerte=date("H:i:s", mktime(date("H")+fusion_horaire(), date("i"), date("s")));
                $hour_alerte=date("H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s")));
                list($h, $m,$s) = explode(':', $hour_alerte);
                $hour=$h.''.$m.''.$s;
                if (($hour>="063000") AND ($hour<="213000"))
                {

                    $SQL = "SELECT  `new_incident_gab_ouvert`.`id_incident` AS id_incident,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`  , `remarque_frss`, `remarque_press`, `remarque_press` , `date_derniere_rappel` , `etat_stat` 
                    FROM `new_incident_gab_ouvert`
                    WHERE `date_derniere_rappel`  BETWEEN '".mysqli_real_escape_string($connexion,$avant)."' AND '".mysqli_real_escape_string($connexion,$apres)."'
                    ORDER BY `date_derniere_rappel` ASC ";
                }
                else
                {
                    $SQL = "SELECT  `new_incident_gab_ouvert`.`id_incident` AS id_incident,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`  , `remarque_frss`, `remarque_press`, `remarque_press` , `date_derniere_rappel` , `etat_stat` 
                    FROM `new_incident_gab_ouvert`
                    WHERE `date_derniere_rappel`  BETWEEN '".mysqli_real_escape_string($connexion,$avant)."' AND '".mysqli_real_escape_string($connexion,$apres)."'
                    AND   `id_niveau_fonctionelle` = 1 AND `id_niveau_technique` = 0
                    ORDER BY `date_derniere_rappel` ASC ";
                }
			}
			/************************************************************/
        }
        else
        {
            if ($_POST['if_ext']==666)
            {
                $stringRequest="(id_gab IN ($listGabEXTFinal))";
            }
            else
            {
                $stringRequest="(id_gab NOT IN ($listGabEXTFinal))";
            }
			/************************************************************/
            if ((date('D')=="Sat") ||(date('D')=="Sun"))//Rappel du weekend
			{
			    /************************************************************/
                $SQL = "SELECT  `new_incident_gab_ouvert`.`id_incident` AS id_incident,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`  , `remarque_frss`, `remarque_press`, `remarque_press` , `date_derniere_rappel`, `etat_stat` 
                FROM `new_incident_gab_ouvert`
                WHERE  `date_derniere_rappel` BETWEEN '".mysqli_real_escape_string($connexion,$avant)."' AND '".mysqli_real_escape_string($connexion,$apres)."'
                AND   `id_niveau_fonctionelle` =1 AND `id_niveau_technique`=0
                AND '".mysqli_real_escape_string($connexion,$stringRequest)."'
                ORDER BY    `date_derniere_rappel` ASC";
			}
			else
			{
			    // $hour_alerte=date("H:i:s", mktime(date("H")+fusion_horaire(), date("i"), date("s")));
                $hour_alerte=date("H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s")));
                list($h, $m,$s) = explode(':', $hour_alerte);
                $hour=$h.''.$m.''.$s;
                if (($hour>="063000") AND ($hour<="213000"))
                {
                    $SQL = "SELECT  `new_incident_gab_ouvert`.`id_incident` AS id_incident,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`  , `remarque_frss`, `remarque_press`, `remarque_press` , `date_derniere_rappel` , `etat_stat` 
                    FROM `new_incident_gab_ouvert`
                    WHERE  `date_derniere_rappel`  BETWEEN '".mysqli_real_escape_string($connexion,$avant)."' AND '".mysqli_real_escape_string($connexion,$apres)."'
                    AND '".mysqli_real_escape_string($connexion,$stringRequest)."'
                    ORDER BY    `date_derniere_rappel` ASC";
                }
                else
                {
                    $SQL = "SELECT  `new_incident_gab_ouvert`.`id_incident` AS id_incident,  `id_gab`, `date_arrete`, `date_remise`, `date_derniere_rappel`, `etat_incident`  , `remarque_frss`, `remarque_press`, `remarque_press` , `date_derniere_rappel` , `etat_stat` 
                    FROM `new_incident_gab_ouvert`
                    WHERE `date_derniere_rappel`  BETWEEN '".mysqli_real_escape_string($connexion,$avant)."' AND '".mysqli_real_escape_string($connexion,$apres)."'
                    AND   `id_niveau_fonctionelle` =1 AND `id_niveau_technique`=0
                    AND '".mysqli_real_escape_string($connexion,$stringRequest)."'
                    ORDER BY    `date_derniere_rappel` ASC";
                }
			}
			/************************************************************/
        }
    }

    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 1127:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 1127 !');
    }
    if($result)
    {
        echo '<table class="table table-responsive-sm table-hover table-outline mb-0">';
        echo '<tr>
                <th colspan=9 class="text-center text-danger" >'.mysqli_num_rows($result).'  '.$lang['inci_msg'].'</th>
		    </tr>';
        echo '</table>';
        if(mysqli_num_rows($result)>0)
        {
            $i=0;
            echo '<table class="table table-responsive-sm table-hover table-outline mb-0"  >
            <thead class="thead-light">
                <tr>
                    <th class="text-center"></th>
                    <th class="text-center">'.$lang['atm_id'].'</th>
                    <th class="text-center">'.$lang['atm_name'].'</th>
                    <th class="text-center">'.$lang['cause_default'].'</th>
                    <th class="text-center">'.$lang['date_inter'].'</th>
                    <th class="text-center">'.$lang['date_remi'].'</th>
                    <th class="text-center">'.$lang['dure'].'</th>
                    <th class="text-center"></th>
                    
                </tr>
            </thead>
            <tbody>
            ';
                while ($row = mysqli_fetch_assoc($result))
                {
                    echo '<tr class="text-center">';
                    $idfilial=getfilialTerminal($row["id_gab"]);
                    list($id_poste_affecter, $name_poste_affecter) = explode('---', get_post_affect_ATM($idfilial));
                    $name_poste_affecter=str_replace(CHR(32),'',$name_poste_affecter);
                    $gab=get_array_information_gab($row["id_gab"]);
                    $duree_rappel  = date_different(date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))),$row["date_derniere_rappel"]);
                    // $duree = date_different(get_min_date_intevention_technique($row["id_incident"]), get_date_cloture_intevention_technique($row["id_incident"]));

                    if ($duree_rappel['minutes_total']>=240)
                    {
                        echo '<td class="text-center"><span class="badge badge-pill badge-danger">+ 4H</span></td>';
                    }
                    else if (($duree_rappel['minutes_total']<240) && ($duree_rappel['minutes_total']>=120))
                    {
                        echo '<td class="text-center"><span class="badge badge-pill badge-warning">+ 2H</span></td>';
                    }
                    else if (($duree_rappel['minutes_total']<120) && ($duree_rappel['minutes_total']>=0))
                    {
                        echo '<td class="text-center"><span class="badge badge-pill badge-success">- 2H</span></td>';
                    }


                    echo '<td class="text-center">'.get_libelle_traiter_incident2($row["etat_stat"]).'  '.$row["id_gab"].' </td>
                    <td class="text-center"><a target="_blank" title="N°  Dossier : '.$row["id_incident"].'" href="detail_gab.php?ternimal='.$row["id_gab"].'&id='.$row["id_incident"].'" >'.$gab["0"].' '.get_return_libelle_groupe($row["id_gab"]).'</a></td>
                    <td class="text-center">';
                    $inter=get_liste_action_nasser($row["id_incident"]);
                    $nb_inter=get_count_nbr_intervention($row["id_incident"]);

                    for($j=0;$j<$nb_inter;$j++) // tant que $i est inferieur au nombre d'éléments du tableau...
                    {
                        if((!empty($inter[2][$j])))
                        {
                            echo ($j+1)." - ".$liste_action_na[$inter[3][$j]]."<br>";
                        }
                        else if((empty($inter[2][$j])))
                        {
                            if ($j=="0")
                            {
                                echo '<p style="text-align: center;"><a><span class="fa fa-minus"></span></a></p>';
                            }
                        }
                      }

                    echo'</td>
                    <td>';
                    for($j=0;$j<$nb_inter;$j++) // tant que $i est inferieur au nombre d'éléments du tableau...
                    {
                        if((!empty($inter[2][$j])))
                        {
                            echo $inter[1][$j]." - ". $liste_affect[$inter[2][$j]]."<br>";
                        }
                        else if((empty($inter[2][$j])))
                        {
                            if ($j=="0")
                            {
                                echo '<p style="text-align: center;"><a><span class="fa fa-minus"></span></a></p>';
                            }
                        }
                    }
                    echo'</td>
                    <td class="text-center">';
			        echo '<input  type="text"   style="font-size:8px;font-weight:bold;color:#000;" size="20" value=""  placeholder="YYYY-MM-DD HH:MN:SS" class="form-control input-sm" onChange="javascript:cloturer_incident_fonctionnelle2(\''.$row["id_incident"].'\','.$i.',\'0\')" id="cloture_fonction'.$i.'" name="cloture_fonction">';
			        echo '</td>
                    <td class="text-center">';
			            dureeInactivite($row["date_derniere_rappel"]);
		            echo'</td>';
		            echo '<td class="text-center">';
		            if ($row["remarque_press"]<>"")
		            {
                        echo' <a tabindex="-1"  data-toggle="modal"  onClick="javascript:get_remarque_incident_pres(\''.$row["id_incident"].'\')"   data-target="#show_remarque_incident"><span Title="'.$lang['rem_inci'].'"  class="c-icon cil-list-filter"></span> </a>';
		            }
		            echo ' </td>
                 
                  </tr>';

                 $i++;
                }
                echo '
                  </tbody>
                  </table>';
        }


		mysqli_free_result($result);
		}//   if($result)

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_aa_email_gab1($id_gab)
{
    $connexion=ma_db_connexion();
    $contact="";
    $SQL="SELECT  `adresse_mail`,`nom_contact`    FROM `new_list_contact_agence`   
    WHERE `niveau_escalade` = 1 AND `code_filiale` lIKE '".get_code_agence_agence($id_gab)."'  AND `nom_contact` <> ''
    GROUP BY `nom_contact`
    ORDER BY `nbr_contact` ASC";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 1128:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 1128 !');
    }
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                if ($row["adresse_mail"]=="")
                {
                    $adresse_mail=$row["nom_contact"];
                }
                else
                {
                    $adresse_mail=$row["adresse_mail"];
                }
                $contact=$adresse_mail.';'.$contact;
            }

            $date_connect= $row["id_filiale"];
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

    return $contact;

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_cc_email_gab1($id_gab)
{
    $connexion=ma_db_connexion();
    $contact="";
    $SQL="SELECT  `adresse_mail`,`nom_contact`  FROM `new_list_contact_agence`   
    WHERE `niveau_escalade` = 2	 AND `code_filiale` lIKE '".get_code_agence_agence($id_gab)."'    AND `nom_contact` <> ''
	GROUP BY `nom_contact`
    ORDER BY `nbr_contact` ASC";
    mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
    $result=mysqli_query($connexion,$SQL);
    if (!$result)
    {
        error_log("Erreur SQL 1129:  ".$SQL."  " .mysqli_error($connexion));
        die(' ERREUR QUERY 1129 !');
    }


    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                if ($row["adresse_mail"]=="")
                {
                    $adresse_mail=$row["nom_contact"];
                }
                else
                {
                    $adresse_mail=$row["adresse_mail"];
                }
                $contact=$adresse_mail.';'.$contact;
            }

            $date_connect= $row["id_filiale"];
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);

    return $contact;

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_arret_incident($id_incident)
 {

$sql="SELECT  `date_arrete`     FROM `new_incident_gab`      WHERE  `id_incident`=  '".$id_incident."'";

if ($result=mysqli_query(ma_db_connexion(),$sql) or die('Erreur   get_date_arret_incident !<br>'.$sql.'<br>'.mysqli_error()))
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
						return $row["date_arrete"];
					}
			}
		else
			{
				return "";
			}
mysqli_free_result($result);
	}

 }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function get_max_id_intevention_fonctionnelle($id_incident)
    {
        $sql = "SELECT  max(`id_action_interv`) as id_action
        FROM `new_intevention_incident`, `new_action_intervention`
        WHERE 
        `id_intevention` = `id_action_intervention`
		AND (`new_action_intervention`.`degre`=1)
        AND `id_incident`  =  '$id_incident' 
        ORDER BY `nbr_tentative` ASC";

	if ($result=mysqli_query(ma_db_connexion(),$sql) or die('Erreur   get_list_service_atm !<br>'.$sql.'<br>'.mysqli_error()))
	{
		if(mysqli_num_rows($result)>0)
			{
			while ($row = mysqli_fetch_assoc($result))
					{
							if ($row["id_action"]=="")
							{
								return "0";
							}
							else
							{
							  return $row["id_action"];
							}
					}
			}
		else
			{
				return "0";
			}
mysqli_free_result($result);
	}


    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function cloturer_incident_fonctionnelle($id_incident,$date_cloture,$option)
{
    $motif_cloture="I";
    session_start();
    $connexion=ma_db_connexion();
    list($p1, $p2) = explode(' ',  date_transaction($date_cloture));
    list($yr, $mn, $dy) = explode('-', $p1);
    list($hh, $mm, $ss) = explode(':', $p2);

    if(strlen($mn)==1){$mn="0".$mn;}
    if(strlen($dy)==1){$dy="0".$dy;}
    if(strlen($hh)==1){$hh="0".$hh;}
    if(strlen($mm)==1){$mm="0".$mm;}
    if(strlen($ss)==1){$ss="0".$ss;}
    $datecloture=$yr.''.$mn.''.$dy.''.$hh.''.$mm.''.$ss;

    list($p3, $p4) = explode(' ', get_date_arret_incident($id_incident));
    list($y, $m, $d) = explode('-', $p3);
    list($h, $mt, $s) = explode(':', $p4);

    if(strlen($m)==1){$m="0".$m;}
    if(strlen($d)==1){$d="0".$d;}
    if(strlen($h)==1){$h="0".$h;}
    if(strlen($mt)==1){$mt="0".$mt;}
    if(strlen($s)==1){$s="0".$s;}

    $datearret=$y.''.$m.''.$d.''.$h.''.$mt.''.$s;


    $date_actuel=date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y")));
    $duree = date_different(date_transaction($date_cloture), $date_actuel);

    if (($duree['minutes_total']>=0) &&($duree['minutes_total']<=4500))
    {
        ///////////////////////////////////////////////
        if ($option=="0")
        {
            $delete_first_show_old_ca = "DELETE FROM atm_list_stopped_test WHERE id_incident = '".mysqli_real_escape_string($connexion,$id_incident)."'";
            $resultdelete=mysqli_query($connexion,$delete_first_show_old_ca);
            //var_dump($delete_first_show_old_ca);die();
            if (!$resultdelete)
            {
                error_log("Erreur SQL 001095: ".$delete_first_show_old_ca."  ".mysqli_error($connexion));
                die('ERREUR QUERY 001095 !');
            }
            update_cloturer_intervention_incident(get_max_id_intevention_fonctionnelle($id_incident),$motif_cloture,date_transaction($date_cloture));
            update_cloturer_incident($id_incident,date_transaction($date_cloture));
            update_disponibilite_intervention_gab($id_incident,date_transaction($date_cloture));
        }
        else
		{
		    update_cloturer_intervention_incident(get_max_id_intevention_fonctionnelle($id_incident),$motif_cloture,date_transaction($date_cloture));
		}
    }
    else
    {
        echo '<div class="alert alert-danger" align="center" style="font-size:15px;font-weight:bold;"> Incident non enregistrer, Veuillez SVP vérifier la date de  Clôture</strong></div>';
    }
    mysqli_close($connexion);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_rafreshGab($id)
{
            $sql1 = "SELECT  `id_gab` FROM  `new_incident_gab_ouvert`   WHERE  `new_incident_gab_ouvert`.`id_gab`=  '".$id."'";

if ($result1=mysqli_query(ma_db_connexion(),$sql1) or die('Erreur   get_rafreshGab !<br>'.$sql1.'<br>'.mysqli_error()))
	{
		if(mysqli_num_rows($result1)>0)
			{


					$sql = "SELECT  appel_web_service,code_bank FROM  `new_list_gab`   WHERE  terminal= '".$id."'";
					mysqli_query(ma_db_connexion(),"SET CHARACTER SET 'utf8'");
					if ($result=mysqli_query(ma_db_connexion(),$sql) or die('Erreur   get_rafreshGab !<br>'.$sql.'<br>'.mysqli_error()))
					{
						if(mysqli_num_rows($result)>0)
						{
									while ($details= mysqli_fetch_assoc($result)){

										$ifAppelEnCours= $details["appel_web_service"];
										$control_last_refresh= control_last_refresh_data_gab($details["code_bank"]);

											if ($ifAppelEnCours==0){
												if ($control_last_refresh==1){
													return '<h3 style="font-size:9pt;"><strong>Ce gab vient d\'être raffraîchie il y a moins de 5 minutes </strong></h3>  ';
												} else {

													return '<span class="glyphicon glyphicon-refresh" aria-hidden="true" onclick="get_appel_web_service_gab(\''.$id.'\')"></span>';
												}


											} else {

												return '<h3 style="font-size:9pt;"><strong> Appel déjà lancé en cours </strong></h3>  ';
											}
									}
					    }
						mysqli_free_result($result);
					}

						/*******************************************************/


						/*******************************************************/




			}
mysqli_free_result($result1);
	}





}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_detail_gab($id_terminal,$id)
{
    $terminal=$id_terminal;
    include "languages/" . $_SESSION['lang'] . ".php";
    $info=get_array_information_gab($id_terminal);
    ?>
    <div class="col-sm-12 col-lg-12">
        <div class="card shadow-lg p-3 mb-5 bg-white rounded">
            <div class="card text-white bg-facebook mb-3" style="text-align: center;">
                <div class="text-value-xl  c-icon-3xl text-white my-2 text-white"><?php echo $lang['modu_det_gab']?> : <?php echo $terminal." - ".$info["0"]; ?></div>
            </div>
            <div class="card-body row text-left">
                <div class="col">
                    <div class="text-muted small">
                        <div class="panel-body" id="div_declarer">
                            <div class="row">
                                <div class="col-sm-6 col-md-4">
                                    <div class="row">
                                        <div class="col-sm-6 col-md-12">
                                            <div class="card">
                                                <div class="card-header bg-secondary "><h6><?php echo $lang['info_gab']?></h6></div>
                                                <div id="div_incidnet_ouvert"  class="table-responsive">
                                                    <?php
                                                    if (get_verif_gab($id_terminal)>="1")
                                                    {
                                                        get_list_information_detail_terminal($id_terminal,$id);
                                                    }
                                                    else
                                                    {
                                                        get_info_gab_introuvable();
                                                    }
                                                    ?>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6 col-md-12">
                                            <div class="card">
                                                <div class="card-header bg-secondary "><h6><?php echo $lang['dur_inter']?></h6></div>
                                                <div id="div_incidnet_ouvert"  class="table-responsive">
                                                    <?php
                                                    if (get_verif_gab($id_terminal)>="1")
                                                    {
                                                        get_duree_prise_charge($id);
                                                    }
                                                    ?>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6 col-md-12">
                                            <div class="card">
                                                <div class="card-header bg-secondary "><h6><?php echo $lang['inf_sla']?></h6></div>
                                                <div id="div_incidnet_ouvert"  class="table-responsive">
                                                    <?php
                                                    if (get_verif_gab($id_terminal)>="1")
                                                    {
                                                        get_information_duree_sla();
                                                    }
                                                    ?>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-8">
                                    <div class="row">
                                        <div class="col-sm-6 col-md-12">

                                                <div class="card bg-secondary" >
                                                    <div class="card-body pb-0 d-flex justify-content-between align-items-start">
                                                        <div>
                                                            <div class="text-value-lg"><h6><?php echo $lang['dev_stat']?></h6></div>
                                                        </div>
                                                        <div id="testerpériph">
                                                            <?php getdeatil_per($terminal); ?>
                                                        </div>
                                                    </div>
                                                    <br>
                                                </div>



                                                <div class="card">
                                                    <div class="card-header bg-secondary"><h6><?php echo $lang['inf_inc']?></h6></div>
                                                    <div id="div_rappels"  class="table-responsive">
                                                        <?php
                                                        get_return_date_arret_gab($id);
                                                        ?>
                                                    </div>
                                                </div>

                                                <div class="card">
                                                    <div class="card-header bg-secondary"><h6>Actions</h6></div>
                                                    <div id="div_rappels"  class="table-responsive">
                                                        <?php
                                                            get_list_intervention_gab($id_terminal,$id);
                                                        ?>
                                                    </div>
                                                </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function afficher_btn_ajouter()
{
    if ($_SESSION['lang']=='fr')
    {
        echo '<button tabindex="-1" type="submit" class="btn btn-block btn-primary active"> Confirmer</button>';
    }
    else
    {
        echo '<button tabindex="-1" type="submit" class="btn btn-block btn-primary active"> Confirm</button>';
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_declaration($terminal,$id_motif,$date_arret,$id_arret,$lang)
{
    $info=get_array_information_gab($terminal);
?>

 <div id="declar_incident"class="row">

     <div class="col-sm-12 col-lg-12">
         <div class="card shadow-lg p-3 mb-5 bg-white rounded">
             <div class="card text-white bg-facebook mb-3" style="text-align: center;">
                 <div class="text-value-xl  c-icon-3xl text-white my-2 text-white"><?php echo $lang['modul_decl']?><?php echo $terminal." - ".$info["0"]; ?></div>
             </div>
             <div class="card-body row text-left">
                 <div class="col">
                     <div class="text-muted small">
                         <div class="panel-body" id="div_declarer">
                             <div class="row">
                                 <div class="col-sm-6 col-md-4">
                                     <div class="card">
                                         <div class="card-header bg-secondary "><h6><?php echo $lang['decl_gab']?></h6></div>
                                         <form action="detail_declarer.php" method="post" autocomplete="off">
                                             <div class="card-body">
                                                 <div class="form-group row" id="div_input_terminal">
                                                     <label class="col-sm-3 col-form-label" for="input_terminal">N° <?php echo $lang['terminal']?></label>
                                                     <div class="col-md-9">
                                                         <input id="terminal2"  type="hidden"   value="<?php echo $terminal;?>"  class="form-control input-sm">
                                                         <input placeholder="N° Terminal"  type="text" required  class="form-control"required name="num_terminal" id="input_terminal" value="<?php echo $terminal;?>"
                                                         onchange="javascript:verif_declaration_gab(this.value);afficher_information_gab(this.value);afficher_nom_gab(this.value);
                                                         afficher_affectation_gab(this.value);actueliser_date_arret();
                                                         afficher_ping(this.value);getdeatil_per(this.value);afficher_information_historique_gab(this.value);
                                                         afficher_btn_ajouter(this.value);" >
                                                     </div>
                                                 </div>
                                                 <div class="col-sm-12" id="get_nom_gab">
                                                     <?php afficher_nom_gab($terminal); ?>
                                                 </div>
                                                 <div class="col-sm-12" id="div_verif_gab" >
                                                     <?php get_verif_declaration_incident_gab($terminal); ?>
                                                 </div>
                                                 <div id="div_inputarret" class="form-group row">
                                                     <label class="col-sm-3 col-form-label" for="inputarret"><?php echo $lang['stop_date']?></label>
                                                     <div class="col-md-9">
                                                         <?php echo '<input placeholder="yyyy-mm-dd  hh:mm:ss ou dd/mm/yy  hh:mm:ss " id="inputarret" name="inputarret" type="text"
                                                            required  value="'.$date_arret.'" class="form-control">';?>
                                                     </div>
                                                 </div>
                                                 <div id="div_inputrappel" class="form-group row">
                                                     <?php  actueliser_date_rappel(); ?>
                                                 </div>
                                                 <div id="div_affecter" class="form-group row">
                                                     <?php afficher_affectation_gab($terminal);?>
                                                 </div>

                                                 <div id="div_cause_arret" class="form-group row">
                                                     <label class="col-sm-3 col-form-label" for="inputcauseaction"><?php echo $lang['cause_default']?></label>
                                                     <div class="col-md-9 search-box">
                                                         <input type="text" required name="inputcauseaction" id="inputcauseaction" class="form-control" value="<?php echo get_libelle_motifs($id_motif);?>"  onkeyup="autocomplet()"
                                                                onFocus="get_generer_mail(this.value)" placeholder="<?php echo $lang['cause_default']?>" data-type="search" autocomplete="off">

                                                         <ul class="dropdown-menu" id="terminal_list_id"></ul>
                                                     </div>
                                                 </div>

                                                 <div  id="div_capture_ecran"  class="form-group row">
                                                     <?php
                                                     $id_gab=get_IdAtm_Terminal($terminal);
                                                     echo '<strong class="col-sm-12 col-form-label"  data-toggle="modal" onclick="javascript:get_scren_incident(\'' . $id_gab . '\',\'' . $terminal . '\')"
                                                        data-target="#detailscreenincid"> '.$lang['hist_cap'].' <strong style="color:#FF0040"><i class="fa fa-picture-o" title="'.$lang["screenshot"].'"> </i></strong></strong>'
                                                     ?>
                                                     <div class="col-sm-12">
                                                         <p id="p_ret" style="display: inline; color: red"><?php echo $lang['cap_no_selec']?> </p><i id="i_ret" style="color:red;" class="fa fa-times"></i>
                                                     </div>

                                                     <input type="hidden" id="purpose_input" name="purpose_input" value="0">

                                                     <input type="hidden" id="id_arret" name="id_arret" value="<?php echo $id_arret;?>">
                                                 </div>


                                                 <div  id="div_remarque_3"  class="form-group row">
                                                     <label for="id_remarque_3" class="col-sm-3 col-form-label"><?php echo $lang['remarq']?></label>
                                                     <div class="col-md-9">
                                                         <textarea  id="remarque_incident"  name="remarque_incident" rows="3" class="form-control"></textarea>
                                                     </div>
                                                 </div>
                                                 <div  id="div_remarque_3"  class="form-group">
                                                     <label for="id_remarque_3" class="control-label"></label>
                                                     <input  id="persone_avise"  name="persone_avise" type="hidden"    value="" class="form-control input-sm">
                                                 </div>
                                             </div>
                                             <div class="card-footer">
                                                 <div id="div_btn_ajouter" class="form-group row" >
                                                     <?php
                                                     if (($terminal)<>"")
                                                     {
                                                         if (get_verif_gab(trim(trim($terminal)))>="1")
                                                         {
                                                             afficher_btn_ajouter();
                                                         }
                                                     }
                                                     ?>
                                                 </div>
                                                 <div id="div_generer_mail" class="form-group row"></div>
                                             </div>

                                         </form>
                                     </div>
                                 </div>
                                 <div class="col-sm-6 col-md-8">
                                     <div class="row">
                                         <div class="col-sm-6 col-md-12">
                                             <div id="div_information_contact" class="table-responsive"></div>
                                         </div>
                                     </div>

                                     <div class="row">
                                         <div class="col-sm-6 col-md-6">
                                             <div class="card bg-secondary" >
                                                 <div class="card-body pb-0 d-flex justify-content-between align-items-start">
                                                     <div>
                                                         <div class="text-value-lg "><h6>Ping</h6></div>
                                                     </div>
                                                     <div id="testerPing">
                                                         <?php afficher_ping($terminal); ?>
                                                     </div>
                                                 </div>
                                                 <br>
                                             </div>

                                             <div class="card bg-secondary" >
                                                 <div class="card-body pb-0 d-flex justify-content-between align-items-start">
                                                     <div>
                                                         <div class="text-value-lg"><h6><?php echo $lang['dev_stat']?></h6></div>
                                                     </div>
                                                     <div id="testerpériph">
                                                         <?php getdeatil_per($terminal); ?>
                                                     </div>
                                                 </div>
                                                 <br>
                                             </div>
                                             <div class="card">
                                                 <div class="card-header bg-secondary"><h6><?php echo $lang['info_gab']?></h6></div>
                                                 <div class="card-body">
                                                     <div id="div_information_gab" class="table-responsive">
                                                         <?php get_list_information_gab2($terminal); ?>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                         <div class="col-sm-6 col-md-6">
                                             <div class="card">
                                                 <div class="card-header bg-secondary"><h6><?php echo $lang['hist_gab']?></h6></div>
                                                 <div class="card-body">
                                                     <form class="form-horizontal" role="form">
                                                         <div id="div_historique_gab" class="form-group" class="table-responsive">
                                                             <?php get_list_information_historique_gab($terminal); ?>
                                                         </div>
                                                     </form>
                                                 </div>
                                             </div>
                                        </div>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
<?php /************************* Déclaration GAB *****************************/?>

<?php /**********************************************************************/?>

</div>

<?php

}

?>
