<?php  include("init.php");

function ma_db_connexion_user()
{
    $id_connexion =0;
    $id_connexion = mysqli_connect(HOST, USER, PSWD,DATABASE_USER,PORT);

    if(mysqli_connect_errno($id_connexion))
    {

        error_log("Erreur Connect 001: ".mysqli_connect_error()."  ".mysqli_error($id_connexion));
        // echo mysqli_error($id_connexion);
        die(' ERREUR Connect 001 !');

    }
    else
    {
        mysqli_set_charset($id_connexion, "utf8");
        return $id_connexion;

    }

}


function ma_db_connexion()
{
	$id_connexion =0;
	$id_connexion = mysqli_connect(HOST, USER, PSWD,DATABASE,PORT);
	
	if(mysqli_connect_errno($id_connexion))
	{
	    error_log("Erreur Connect 001: ".mysqli_connect_error()."  ".mysqli_error($id_connexion));

        die(' ERREUR Connect 001 !');
	}
	else
	{  
		mysqli_set_charset($id_connexion, "utf8");
		  return $id_connexion;
		
	}

}



//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

?>