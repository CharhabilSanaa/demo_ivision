<?php
header('Content-Type: application/json');

include("../connexion.php");

$conn=ma_db_connexion();
$sum=0;
$total_GAB=0;

$sqlQuery = "SELECT `id_action_fonctionelle` FROM `new_incident_gab_ouvert` ";
$id_action_fonctionelle="";

mysqli_query($conn,"SET CHARACTER SET 'utf8'");
$result=mysqli_query($conn,$sqlQuery);
if (!$result)
{
    error_log("Erreur SQL 0000099:  ".$sqlQuery."  " .mysqli_error($conn));
    die("Erreur SQL 0000099");
}
if ($result)
{

    $data =array();

    if(mysqli_num_rows($result)>0)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
             $data[]=$row["id_action_fonctionelle"];
        }
    }
    mysqli_free_result($result);
}

$sum_retrait_argent=0;
$sum_depot_argent=0;
$sum_depot_cheque=0;
$sum_autre_transactions=0;

foreach ($data as $item)
{
    $sqlQuery2 = "SELECT `retrait_argent`,`depot_argent`,`depot_cheque`,`autre_transactions` FROM `new_action_intervention` WHERE `id_intevention` = '".mysqli_real_escape_string($conn,$item)."';";
    $result2=mysqli_query($conn,$sqlQuery2);
    if (!$result2)
    {
        error_log("Erreur SQL 0000100:  ".$sqlQuery2."  " .mysqli_error($conn));
        die("Erreur SQL 0000100");
    }
    if ($result2)
    {
        if(mysqli_num_rows($result2)>0)
        {
            $row = mysqli_fetch_assoc($result2);
            $sum_retrait_argent=$sum_retrait_argent+$row["retrait_argent"];
            $sum_depot_argent=$sum_depot_argent+$row["depot_argent"];
            $sum_depot_cheque=$sum_depot_cheque+$row["depot_cheque"];
            $sum_autre_transactions=$sum_autre_transactions+$row["autre_transactions"];
        }
    }
}
$data2 =array();
if ($_POST['lang']==="fr")
{
    $data2[]=[libelle =>"Retrait d'argent",nbr_incidents =>$sum_retrait_argent];
    $data2[]=[libelle =>"Depot d'argent",nbr_incidents =>$sum_depot_argent];
    $data2[]=[libelle =>"Depot de cheque",nbr_incidents =>$sum_depot_cheque];
    //$data2[]=[libelle =>"Autre transactions",nbr_incidents =>$sum_autre_transactions];
}
else
{
    $data2[]=[libelle =>"Cash withdrawal",nbr_incidents =>$sum_retrait_argent];
    $data2[]=[libelle =>"Cash deposit",nbr_incidents =>$sum_depot_argent];
    $data2[]=[libelle =>"Check deposit",nbr_incidents =>$sum_depot_cheque];
   // $data2[]=[libelle =>"Other transactions",nbr_incidents =>$sum_autre_transactions];
}

mysqli_close($conn);

echo json_encode($data2);

?>