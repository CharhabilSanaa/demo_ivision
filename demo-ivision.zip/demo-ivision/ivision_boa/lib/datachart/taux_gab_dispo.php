<?php
header('Content-Type: application/json');

include("../connexion.php");

$conn=ma_db_connexion();
$sqlQuery = "SELECT id_indicateur,description as descrip ,taux FROM `indicateurs_taux_dispo` WHERE id_indicateur = 7 ";

$result = mysqli_query($conn,$sqlQuery);

if (!$result)
{
    error_log("Erreur SQL 97:  ".$sqlQuery."  " .mysqli_error($conn));
    die("Erreur SQL 97");
}
if ($result)
{
    $data = array();
    foreach ($result as $row) {
        $data[] = $row;
    }
}


mysqli_close($conn);

echo json_encode($data);

?>