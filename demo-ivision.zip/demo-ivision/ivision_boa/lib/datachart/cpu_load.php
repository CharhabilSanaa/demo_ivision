<?php
header('Content-Type: application/json');

include("../connexion.php");

$id_atm=$_GET["id_atm"];
//echo "id_atm : ".$id_atm;
$conn=ma_db_connexion();
$sqlQuery = "SELECT `cpu_load` as cpu_load FROM `hist_connect` WHERE `id_atm` = $id_atm ORDER BY `id_con` DESC LIMIT 1 ";

//echo $sqlQuery;

$result = mysqli_query($conn,$sqlQuery);

if (!$result)
{
    error_log("Erreur SQL 194:  ".$sqlQuery."  " .mysqli_error($conn));
    die("Erreur SQL 194");
}
if ($result)
{
    $data = array();
    foreach ($result as $row) {
        $data[] = $row;
    }
}


mysqli_close($conn);

echo json_encode($data);

?>