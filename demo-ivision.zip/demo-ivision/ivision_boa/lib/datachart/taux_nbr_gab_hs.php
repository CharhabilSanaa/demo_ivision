<?php
header('Content-Type: application/json');

include("../connexion.php");

$libelle='libelle';
if ($_POST['lang']=='en')
{
    $libelle='libelle_eng';
}

$conn=ma_db_connexion();
$sum=0;
$total_GAB=0;

$sqlQuery = "SELECT `new_categorie_intervention`.".$libelle." as libelle ,`indicateurs_incidents_categorie`.`nbr_incidents` as nbr_incidents 
            FROM `indicateurs_incidents_categorie`,`new_categorie_intervention` 
            WHERE `indicateurs_incidents_categorie`.`id_categorie`=`new_categorie_intervention`.`id_categorie` order by nbr_incidents desc ";

$result = mysqli_query($conn,$sqlQuery);
if (!$result)
{
    error_log("Erreur SQL 97:  ".$sqlQuery."  " .mysqli_error($conn));
    die("Erreur SQL 97");
}
if ($result)
{
    $data = array();
    foreach ($result as $row) {
        $sum= $sum+$row["nbr_incidents"];
        $data[] = $row;
    }
}
mysqli_free_result($result);

$data[]=$sum;

$sqlQuery = " SELECT id_indicateur,description as descrip ,taux FROM `indicateurs_taux_dispo` WHERE id_indicateur = 8 ";

$result = mysqli_query($conn,$sqlQuery);
if (!$result)
{
    error_log("Erreur SQL 96:  ".$sqlQuery."  " .mysqli_error($conn));
    die("Erreur SQL 96");
}
if ($result)
{
    foreach ($result as $row) {

        $total_GAB = $row["taux"];
    }
}

$data[]=$total_GAB;
mysqli_free_result($result);
mysqli_close($conn);
echo json_encode($data);

?>