<?php
header('Content-Type: application/json');

include("../connexion.php");

$id_atm=$_GET["id_atm"];

$conn=ma_db_connexion();
$sqlQuery = "SELECT (`disk_free`/1073741824) as `disk_useds`,(((`disk_available`-`disk_free`)*100)/`disk_available`) as `taux_disk` FROM `hist_connect` WHERE `id_atm` = $id_atm ORDER BY `id_con` DESC LIMIT 1";


$result = mysqli_query($conn,$sqlQuery);

if (!$result)
{
    error_log("Erreur SQL 195:  ".$sqlQuery."  " .mysqli_error($conn));
    die("Erreur SQL 195");
}
if ($result)
{
    $data = array();
    foreach ($result as $row) {
        $data[] = $row;
    }
}




mysqli_close($conn);

echo json_encode($data);

?>