<?php



/****************************************************************************************************************/
function exec_calcul_demo()
{
	
	echo "CALCUL DEMO !!";
	$dateToday='2021-12-26';
	$dateOLD='2021-12-25';
	
	$connexion=ma_db_connexion();
	/********************UPDATE ALL VACATION DATE *****************/	
	$sql = " UPDATE `hist_vacations` SET vacation_date = concat('".$dateToday." ', time(vacation_date))   ";
   
   $result=mysqli_query($connexion,$sql);
   if (!$result)
	{
		error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY Vaca DEMO !');
	}
	/********************UPDATE ALL HIST CONNECT *****************/	
	$sql = " UPDATE `hist_connect` SET date_connect = concat('".$dateToday." ', time(date_connect)) WHERE  date_connect LIKE '%".$dateOLD."%'   ";
   

   $result=mysqli_query($connexion,$sql);
   if (!$result)
	{
		error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY Connect DEMO !');
	}
	/////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////
	/********************UPDATE ATM 4 *****************/	
	/*****Journal***/
	
    $sql = " UPDATE `journal_contents_ncr` SET dateligne = concat('".$dateToday." ', time(dateligne))  
	WHERE dateligne LIKE '%".$dateOLD."%' AND id_atm= 4 ";
   
   $result=mysqli_query($connexion,$sql);
   
   if (!$result)
	{
		error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY 1 DEMO !');
	}
	/*****Stoopped LIST***/
	$sql = " UPDATE `atm_list_stopped_test_test` SET stop_date = concat('".$dateToday." ', time(stop_date)),  
				last_rejected_transaction = concat('".$dateToday." ', time(last_rejected_transaction))
	WHERE  id_atm= 4 ";
   
   $result=mysqli_query($connexion,$sql);
   
   if (!$result)
	{
		error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY 2 DEMO !');
	}
	/****** ScreenSHots**********/
	$sql = " INSERT INTO hist_cmd_execution (id_atm, date_send_cmd, date_exec_cmd,id_cmd, if_executed, if_success,user_exec, 
	date_after_exec_cmd,value_cmd ) 
	VALUES (4,'".$dateToday." 06:30:23','".$dateToday." 06:30:43', 53,1,0,290,now(),'12485,12486')  ";
   $result=mysqli_query($connexion,$sql);
   if (!$result)
	{
		//error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die("Erreur sql 3 DEMO:   ".mysqli_error($connexion));
	}
	/*********/
   
   /****** LogicalName**********/
	$sql = " UPDATE atm_logical_names SET last_withrawel = concat('".$dateToday." ', time(last_withrawel))    
	WHERE   id_atm= 4 ";
   $result=mysqli_query($connexion,$sql);
    
   if (!$result)
	{
		error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY 4 DEMO !');
	}
	/////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////
	/********************UPDATE ATM 12 *****************/	
	/*****Stoopped LIST***/
	$sql = " UPDATE `atm_list_stopped_test_test` SET stop_date = concat('".$dateToday." ', time(stop_date))  
	WHERE  id_atm= 12 ";
   
   $result=mysqli_query($connexion,$sql);
   
   if (!$result)
	{
		error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY 12 2 DEMO !');
	}
	/*****Journal***/
    $sql = " UPDATE `journal_contents_ncr` SET dateligne = concat('".$dateToday." ', time(dateligne))  
	WHERE dateligne LIKE '%".$dateOLD."%' AND id_atm= 12 ";
   $result=mysqli_query($connexion,$sql);
   
   if (!$result)
	{
		error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY 12 1 DEMO !');
	}
	/****** ScreenSHots**********/
	$sql = " INSERT INTO hist_cmd_execution (id_atm, date_send_cmd, date_exec_cmd,id_cmd, if_executed, if_success,user_exec, 
	date_after_exec_cmd,value_cmd ) 
	VALUES (12,'".$dateToday." 06:30:23','".$dateToday." 06:30:43', 53,1,0,290,now(),'12483,12484')  ";
   $result=mysqli_query($connexion,$sql);
   if (!$result)
	{
		//error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die("Erreur sql 12 3 DEMO:   ".mysqli_error($connexion));
	}
	/*********/
	/////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////
	/********************UPDATE ATM 9 *****************/	
	/*****Stoopped LIST***/
	$sql = " UPDATE `atm_list_stopped_test_test` SET stop_date = concat('".$dateToday." ', time(stop_date))  
	WHERE  id_atm= 9 ";
   
   $result=mysqli_query($connexion,$sql);
   
   if (!$result)
	{
		error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY 9 2 DEMO !');
	}
	/*****Journal***/
    $sql = " UPDATE `journal_contents_ncr` SET dateligne = concat('".$dateToday." ', time(dateligne))  
	WHERE dateligne LIKE '%".$dateOLD."%' AND id_atm= 9 ";
   $result=mysqli_query($connexion,$sql);
   
   if (!$result)
	{
		error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY 9 1 DEMO !');
	}
	/****** ScreenSHots**********/
	$sql = " INSERT INTO hist_cmd_execution (id_atm, date_send_cmd, date_exec_cmd,id_cmd, if_executed, if_success,user_exec, 
	date_after_exec_cmd,value_cmd ) 
	VALUES (9,'".$dateToday." 06:30:23','".$dateToday." 06:30:43', 53,1,0,290,now(),'12488,12487')  ";
   $result=mysqli_query($connexion,$sql);
   if (!$result)
	{
		//error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die("Erreur sql 9 3 DEMO:   ".mysqli_error($connexion));
	}
	/*********/
   /////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////
	/********************UPDATE ATM 5 *****************/	
	/*****Stoopped LIST***/
	$sql = " UPDATE `atm_list_stopped_test_test` SET stop_date = concat('".$dateToday." ', time(stop_date))  
	WHERE  id_atm= 5 ";
   
   $result=mysqli_query($connexion,$sql);
   
   if (!$result)
	{
		error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY 5 2 DEMO !');
	}
	/*****Journal***/
    $sql = " UPDATE `journal_contents_ncr` SET dateligne = concat('".$dateToday." ', time(dateligne))  
	WHERE dateligne LIKE '%".$dateOLD."%' AND id_atm= 5 ";
   $result=mysqli_query($connexion,$sql);
   
   if (!$result)
	{
		error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY 5 1 DEMO !');
	}
	/****** ScreenSHots**********/
	$sql = " INSERT INTO hist_cmd_execution (id_atm, date_send_cmd, date_exec_cmd,id_cmd, if_executed, if_success,user_exec, 
	date_after_exec_cmd,value_cmd ) 
	VALUES (5,'".$dateToday." 06:30:23','".$dateToday." 06:30:43', 53,1,0,290,now(),'12490,12491')  ";
   $result=mysqli_query($connexion,$sql);
   if (!$result)
	{
		//error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die("Erreur sql 5 3 DEMO:   ".mysqli_error($connexion));
	}
	/*********/

    mysqli_close($connexion);

	
	
	
	
}
/****************************************************************************************************************/
function get_select_profile()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT   `id_profile` ,`description`  FROM  `atm_profile` ";
   
   $result=mysqli_query($connexion,$sql);
   
   if (!$result)
	{
		error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY 500 !');
	}
   
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["id_profile"].'">'.$row["description"].'</option>';
            }
        }
        else
        {
            return "";
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
/**************************************************************************************************************/
function get_profile_atm($id_atm)
{
    $id_profil=0;
    $connexion=ma_db_connexion();
    $sql = "SELECT  `id_profil`  FROM  `new_list_gab` WHERE `id_terminal_xfs`= '".mysqli_real_escape_string($connexion,$id_atm)."' ";

    $result=mysqli_query($connexion,$sql);

    if (!$result)
    {
        error_log("Erreur sql 5000:  \n".$sql." \n   ".mysqli_error($connexion));
        die('ERREUR QUERY 5000 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            $row = mysqli_fetch_assoc($result);
            $id_profil = $row["id_profil"];

        }

        mysqli_free_result($result);
    }
    mysqli_close($connexion);
    return $id_profil;
}
/**************************************************************************************************************/
function get_select_profile_sel($id_profile)
{
    $connexion=ma_db_connexion();
    $sql = "SELECT   `id_profile` ,`description`  FROM  `atm_profile` ";

    $result=mysqli_query($connexion,$sql);

    if (!$result)
    {
        error_log("Erreur sql 500:  \n".$sql." \n   ".mysqli_error($connexion));
        die('ERREUR QUERY 500 !');
    }

    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                if($id_profile==$row["id_profile"])
                {
                    echo '<option value="'.$row["id_profile"].'" selected >'.$row["description"].'</option>';
                }
                else
                {
                    echo '<option value="'.$row["id_profile"].'" >'.$row["description"].'</option>';
                }

            }
        }
        else
        {
            return "";
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}
/**************************************************************************************************************/
function get_select_command()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT   `id_command` ,`description_cmd`  FROM  `list_cmd_for_atm` ";
	
	$result=mysqli_query($connexion,$sql);
	
     if (!$result)
	{
		error_log("Erreur sql 501:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY 501 !');
	}
	
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'.$row["id_command"].'">'.$row["description_cmd"].'</option>';
            }
        }
        else
        {
            return "";
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}

/**************************************************************************************************************/

function get_select_mode_execution()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT   `id_mode` ,`description_mode`  FROM  `type_execution_mode` ";
	
	$result=mysqli_query($connexion,$sql);
     if (!$result)
	{
		error_log("Erreur sql 502:  \n".$sql." \n   ".mysqli_error($connexion));
		die('ERREUR QUERY 502 !');
	}
	
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'. $row["id_mode"] .'">'. $row["description_mode"] .'</option>';
            }
        }
    }
mysqli_close($connexion);
}

/**************************************************************************************************************/
function get_notes_config_incidents()
{
	echo '<div class="row">
				<br><br><label style="margin-left: 12px">Spécifications: </label><br><br>
				<label style="margin-left: 20px">- Le champ "Id(s) ATM" : </label><br>
					 <p style="margin-left: 40px"><span class="glyphicon glyphicon-edit"></span>  Permet l\'insertion de plusieurs Id atm séparés par des virgules (ex: 25,30,6) </p>
					<p style="margin-left: 40px"><span class="glyphicon glyphicon-edit"></span>  Pour appliquer la config à l\'ensemble du parc tout en gardant les anciens config spécifiques, il suffit d\'inserer le caractère <strong>%</strong></p>
					<p style="margin-left: 40px"><span class="glyphicon glyphicon-edit"></span>  Pour appliquer la config à l\'ensemble du parc sans exception, il suffit d\'inserer le caractère <strong>%%</strong>   </p>
					<p style="margin-left: 40px"><span class="glyphicon glyphicon-edit"></span>  Pour entrer la config par défaut qui sera appliqué automatiquement aux nouveaux GAB, il suffit d\'inserer le caractère <strong>%%%</strong>  </p>
				
				<label style="margin-left: 20px">-Le champ "Logical(s) name" : </label>
					<p style="margin-left: 40px"> <span class="glyphicon glyphicon-edit"></span>  Permet l\'insertion de plusieurs libellés des logical names séparés par des virgules (ex: CDM30,Pinpad1) </p>
					<p style="margin-left: 40px"><span class="glyphicon glyphicon-edit"></span>  Au cas ou le champs est resté vide, la config s\'applique à l\'ensemble des logical names appartenant au service modifié </p>
				
				<label style="margin-left: 20px">- La combinaison des deux champs est prise en considération </label><br>	
				
				<label style="margin-left: 20px">- La selection  "Aucun" en fin de chaque tableau de message permet de suprimer la config existante (en tenant compte des deux champs "Id(s) ATM" et "Logical(s) name:")  </label><br>	
			
			
			</div>';
	
	
}
/**************************************************************************************************************/
function get_notes_config_logical_names()
{
	echo '<div class="row">
	
				<br><br><label style="margin-left: 12px">Spécifications: </label><br><br>
				
				<label style="margin-left: 20px">- La page permet la désactivation des noms logiques pour qu\'ils ne soient pas pris en considération dans la remontée d\'incidents</label><br>	
				<label style="margin-left: 20px">- Le champ "Id(s) ATM" : </label><br>
					 <p style="margin-left: 40px"><span class="glyphicon glyphicon-edit"></span>  Permet l\'insertion de plusieurs Id atm séparés par des virgules (ex: 25,30,6) </p>
					<p style="margin-left: 40px"><span class="glyphicon glyphicon-edit"></span>  Pour appliquer la config à l\'ensemble du parc , il suffit d\'inserer le caractère <strong>%</strong></p>
					<p style="margin-left: 40px"><span class="glyphicon glyphicon-edit"></span>  Au cas ou le champs est resté vide aucune modification n\'aura lieu </p>

				
				<label style="margin-left: 20px">-Le champ "Logical name" : </label>
					<p style="margin-left: 40px"> <span class="glyphicon glyphicon-edit"></span> Permet l\'insertion d\'un seul logical name (ex: CDM30) </p>
					<p style="margin-left: 40px"><span class="glyphicon glyphicon-edit"></span>  Au cas ou le champs est resté vide aucune modification n\'aura lieu </p>
				
				<label style="margin-left: 20px">- La combinaison des deux champs est prise en considération </label><br>	
				
			</div>';
	
	
}
/**************************************************************************************************************/
function updateConfig_fwDevice($idService,$nomService,$valsCheckedStatus,$atm_all,$logicalName)
{
    $connexion=ma_db_connexion();

    $state=false;
	if($atm_all<>"" AND $valsCheckedStatus<>"" AND $valsCheckedStatus<>"init")
	{
		$valeurs=array();
		if($valsCheckedStatus<>"init")
		{
			$valeurs=explode(',',$valsCheckedStatus);	
		}

		if ($logicalName=="")
		{
			$sqlLogicalName="";
		}
		else {
			$LN=array();
			$LN=explode(',',trim ($logicalName));
			$i=0;
			foreach($LN as $valueLn)
				{				
					if($valueLn<>"")
					{
						if($i==0)
						{
							$sqlLogicalName="'".$valueLn."'";
						}
						else{
							
						}
						$sqlLogicalName=$sqlLogicalName .",'".$valueLn."'";
						$i++;
					}
						
				}
				if($logicalName<>"")
				{
					$sqlLogicalName11="AND logical_name IN (".$sqlLogicalName.")";
					//$sqlLogicalName11="AND logical_name IN (".$sqlLogicalName.")";
				}
			
		}

		/******************Garder les config SPECIFIQUES***********************/
		if(trim($atm_all)=='%')
		{
				
				$sql = "SELECT  atm_logical_names.id_logical_name,atm_logical_names.id_atm    
				FROM  `atm_logical_names`
				WHERE  atm_logical_names.id_service=".  mysqli_real_escape_string($connexion,$idService)." AND atm_logical_names.state=1 
				AND atm_logical_names.id_logical_name NOT IN (SELECT id_logical_name FROM config_incident_services WHERE  type_config LIKE 'special' ) ".$sqlLogicalName11."
				
				";
				
				$result=mysqli_query($connexion,$sql);

				if (!$result)
				{
					error_log("Erreur sql 503:  \n".$sql." \n   ".mysqli_error($connexion));
					die('ERREUR QUERY 503 !');
				}
	
            if ($result)
            {
                if(mysqli_num_rows($result)>0)
                {
                    $j=0;
                    while ($row = mysqli_fetch_assoc($result))
                    {
                        /**************************************/
                        $sql2="DELETE FROM config_incident_services WHERE id_service=".$idService." AND id_logical_name= ".  mysqli_real_escape_string($connexion, $row["id_logical_name"]) ."  ";
                     
                        $result2=mysqli_query($connexion,$sql2);
						
						if (!$result2)
							{
								error_log("Erreur sql 504:  \n".$sql2." \n   ".mysqli_error($connexion));
								die('ERREUR QUERY 504 !');
							}
                        /**************************************/
                        foreach($valeurs as $value)
                        {
                            // echo "--> ".$value."<br>";
                            if($value<>"" AND $value<>"init")
                            {
                                $sql3 = "INSERT INTO config_incident_services  
										(id_atm,id_logical_name,id_service,type_status,value_status,date_insert,type_config )
										VALUES (".   mysqli_real_escape_string($connexion,$row["id_atm"]) .",".   mysqli_real_escape_string($connexion,$row["id_logical_name"]) .",
										".  mysqli_real_escape_string($connexion,$idService).",1,".  mysqli_real_escape_string($connexion,$value).",now(),'global' )							
												";
							$result3=mysqli_query($connexion,$sql3);
                                if (!$result3)
									{
										error_log("Erreur sql 505:  ".$sql3."    ".mysqli_error($connexion));
										die('ERREUR QUERY 505 !');
									}
                                
                            }
                        }
                        $state=true;
                    $j++;
                    }
                    mysqli_free_result($result);
                }
			}
		    $sqlUp="UPDATE `atm_logical_names` SET `atm_logical_names`.`up_triggers`=1 ";
            $result4=mysqli_query($connexion,$sqlUp) ;
			if (!$result4)
									{
										error_log("Erreur sql 506:  ".$sqlUp."   ".mysqli_error($connexion));
										die('ERREUR QUERY 506 !');
									}
			
		}
		/******************UPDATE GLOBAL DE TT LES GAB***********************/
		else if($atm_all=='%%')
		{
			$sql = "SELECT  id_logical_name,id_atm    
			FROM  `atm_logical_names` WHERE  id_service=".  mysqli_real_escape_string($connexion,$idService)." AND state=1   ".$sqlLogicalName11." ";
			
			$result=mysqli_query($connexion,$sql) ;
			if (!$result)
									{
										error_log("Erreur sql 507:  ".$sql."   ".mysqli_error($connexion));
										die('ERREUR QUERY 507 !');
									}
            if ($result)
            {
                if(mysqli_num_rows($result)>0)
                {
                    $j=0;
                    while ($row = mysqli_fetch_assoc($result))
                    {
                        /**************************************/
                        $sql2="DELETE FROM config_incident_services WHERE id_service=".  mysqli_real_escape_string($connexion,$idService)." AND id_logical_name= ".  mysqli_real_escape_string($connexion,$row["id_logical_name"])."  ";

                        $result2=mysqli_query($connexion,$sql2);
                        if (!$result2)
									{
										error_log("Erreur sql 508:  ".$sql2."   ".mysqli_error($connexion));
										die('ERREUR QUERY 508 !');
									}
								/**************************************/
								foreach($valeurs as $value)
								{
									//echo "--> ".$value."<br>";
									if($value<>"")
									{
										$sql3 = "INSERT INTO config_incident_services  
													(id_atm,id_logical_name,id_service,type_status,value_status,date_insert,type_config )
													VALUES (".   mysqli_real_escape_string($connexion,$row["id_atm"]) .",".   mysqli_real_escape_string($connexion,$row["id_logical_name"]) .",
													".  mysqli_real_escape_string($connexion,$idService).",1,".  mysqli_real_escape_string($connexion,$value).",now(),'global' )							
															";
									
										$result3=mysqli_query($connexion,$sql3);
										
										if (!$result3)
												{
													error_log("Erreur sql 509:  ".$sql3."   ".mysqli_error($connexion));
													die('ERREUR QUERY 509 !');
												}
										
										mysqli_free_result($result3);
									}
								}
								$state=true;
								$j++;
						mysqli_free_result($result2);
                    }
                }
			mysqli_free_result($result);	
            }
		}
		else if ($atm_all=='%%%')
		{
			/**************************************/
								$sql2="DELETE FROM config_incident_services WHERE id_service=".  mysqli_real_escape_string($connexion,$idService)." AND type_config='default'  ";
                                $result2=mysqli_query($connexion,$sql2);
                               if (!$result2)
												{
													error_log("Erreur sql 510:  ".$sql2."   ".mysqli_error($connexion));
													die('ERREUR QUERY 510 !');
												}


							   if ($result2)
                                {
                                    /**************************************/

                                    foreach($valeurs as $value)
                                    {
                                        //echo "--> ".$value."<br>";
                                        if($value<>"")
                                        {
                                            $sql3 = "INSERT INTO config_incident_services  
										(id_atm,id_logical_name,id_service,type_status,value_status,date_insert,type_config )
										VALUES (NULL,NULL,".  mysqli_real_escape_string($connexion,$idService).",1,".  mysqli_real_escape_string($connexion,$value).",now(),'default' )";
                                           
                                            $result3=mysqli_query($connexion,$sql3);
												if (!$result3)
												{
													error_log("Erreur sql 511:  ".$sql3."   ".mysqli_error($connexion));
													die('ERREUR QUERY 511 !');
												}
                                            $state=true;
                                        }

                                    }
                                }
		}
		/******************UPDATE SPECIFIQUES***********************/
		else
		{
			$sql = "SELECT  id_logical_name,id_atm    
			FROM  `atm_logical_names` WHERE id_atm IN (".trim($atm_all).") AND id_service=".  mysqli_real_escape_string($connexion,$idService)." AND state=1 ".$sqlLogicalName11." ";
            
			$result=mysqli_query($connexion,$sql) ;
			if (!$result)
												{
													error_log("Erreur sql 512:  ".$sql."   ".mysqli_error($connexion));
													die('ERREUR QUERY 512 !');
												}
            
			if ($result)
            {
                if(mysqli_num_rows($result)>0)
                {
                    $j=0;
                    while ($row = mysqli_fetch_assoc($result))
                    {
                        /**************************************/
                        $sql2="DELETE FROM config_incident_services WHERE id_atm  IN (".  mysqli_real_escape_string($connexion,trim($atm_all)).") AND id_service=".  mysqli_real_escape_string($connexion,$idService)." 
									AND id_logical_name= ".  mysqli_real_escape_string($connexion,mysql_result($result,$j,'id_logical_name'))." 	";

                        $result2 = mysqli_query($connexion,$sql2);
                        if (!$result2)
												{
													error_log("Erreur sql 513:  ".$sql2."   ".mysqli_error($connexion));
													die('ERREUR QUERY 513 !');
												}
						
						/**************************************/
                        foreach($valeurs as $value)
                        {
                            //echo "--> ".$value."<br>";
                            if($value<>"")
                            {
                                $sql3 = "INSERT INTO config_incident_services  
										(id_atm,id_logical_name,id_service,type_status,value_status,date_insert,type_config )
										VALUES (".  mysqli_real_escape_string($connexion, $row["id_atm"]) .",".  mysqli_real_escape_string($connexion, $row["id_logical_name"] ).",
										".$idService.",1,".$value.",now(),'special' )							
												";
                                
                                $result3 =  mysqli_query($connexion,$sql3);
                                if (!$result3)
												{
													error_log("Erreur sql 514:  ".$sql3."   ".mysqli_error($connexion));
													die('ERREUR QUERY 514 !');
												}
								$state=true;
                            }
                        }
                     $j++;
                    }
                }
                mysqli_free_result($result);
            }
		}
	}
	mysqli_close($connexion);
	return $state;
}	
/**************************************************************************************************************/
function updateConfig_logical_name($idService,$nomService,$atm_all,$logicalName)
{
	$state= false;
    $connexion=ma_db_connexion();

    if($logicalName<>"" AND $atm_all<>"")
		{
			if(trim($atm_all)=='%')
			{
					
					$sql = "UPDATE  `atm_logical_names` SET atm_logical_names.state=0
					WHERE  atm_logical_names.id_service=".  mysqli_real_escape_string($connexion,$idService)." 
					AND  atm_logical_names.logical_name LIKE '".  mysqli_real_escape_string($connexion,$logicalName)."'
					";
					$result=mysqli_query($connexion,$sql);

					 if (!$result)
												{
													error_log("Erreur sql 515:  ".$sql."   ".mysqli_error($connexion));
													die('ERREUR QUERY 515 !');
												}
				if ($result)
				{
					
					$state=true;
				}
			}
			else{
				$sql = "UPDATE  `atm_logical_names` SET atm_logical_names.state=0
					WHERE  atm_logical_names.id_service=".  mysqli_real_escape_string($connexion,$idService)." 
					AND  atm_logical_names.logical_name LIKE '".  mysqli_real_escape_string($connexion,$logicalName)."' AND atm_logical_names.id_atm IN (".  mysqli_real_escape_string($connexion,$atm_all).")
					";
					$result=mysqli_query($connexion,$sql);
					if (!$result)
												{
													error_log("Erreur sql 516:  ".$sql."   ".mysqli_error($connexion));
													die('ERREUR QUERY 516 !');
												}

					
				if ($result)
				{
					$state=true;
				
				}
				
				
			}
			
			 mysqli_free_result($result);
		}
    mysqli_close($connexion);
	
	return $state;
}
/**************************************************************************************************************/

function get_select_version_client()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT   `id_version` ,`description_version`  FROM  `client_versions` ";
    $result=mysqli_query($connexion,$sql);
					if (!$result)
												{
													error_log("Erreur sql 517:  ".$sql."   ".mysqli_error($connexion));
													die('ERREUR QUERY 517 !');
												}
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'. $row["description_version"] .'">'. $row["description_version"] .'</option>';
            }
        }
        mysqli_free_result($result);
    }
mysqli_close($connexion);
}


/**************************************************************************************************************/

function get_select_service_transaction()
{
    $connexion=ma_db_connexion();
    $sql = "SELECT   `id` ,`libelle_type`  FROM  `type_transaction` WHERE id NOT IN (0,4) ";
    $result=mysqli_query($connexion,$sql);
					if (!$result)
												{
													error_log("Erreur sql 518:  ".$sql."   ".mysqli_error($connexion));
													die('ERREUR QUERY 518 !');
												}
    if ($result)
    {
        if(mysqli_num_rows($result)>0)
        {
            while ($row = mysqli_fetch_assoc($result))
            {
                echo '<option value="'. $row["id"] .'">'.$row["libelle_type"] .'</option>';
            }
        }
        mysqli_free_result($result);
    }
    mysqli_close($connexion);
}


/**************************************************************************************************************/
function validerParamProfile($id_profile,$serviceTransaction,$value,$startDay,$endDay,$valueOut)
{
	$resultBool= false;
	// echo "id_profile  ".$id_profile;
	// echo "serviceTransaction  ".$serviceTransaction;
	// echo "value  ".$value;
    $connexion=ma_db_connexion();
    $sql = "UPDATE  config_passive_values SET  passive_value=".  mysqli_real_escape_string($connexion,$value)." ,
	start_date_day='".  mysqli_real_escape_string($connexion,$startDay).":00:00',end_date_day='".  mysqli_real_escape_string($connexion,$endDay).":00:00', 
	passive_value_night=".  mysqli_real_escape_string($connexion,$valueOut)." 
	WHERE  id_profile =".  mysqli_real_escape_string($connexion,$id_profile)." AND type_transaction=".  mysqli_real_escape_string($connexion,$serviceTransaction)." ";

	
	$result=mysqli_query($connexion,$sql);
					if (!$result)
												{
													error_log("Erreur sql 519:  ".$sql."   ".mysqli_error($connexion));
													die('ERREUR QUERY 519 !');
												}

	/*****************SEVICE RETRAIT CARD************************/
	if($serviceTransaction==1)
	{	
			$sql2 = "UPDATE  atm_logical_names,new_list_gab SET  atm_logical_names.passive_value_withrawel=".$value." ,
			atm_logical_names.start_date_day_passive_value='".  mysqli_real_escape_string($connexion,$startDay).":00:00',
			atm_logical_names.end_date_day_passive_value='".  mysqli_real_escape_string($connexion,$endDay).":00:00', 
			atm_logical_names.passive_value_withrawel_out_schedule=".  mysqli_real_escape_string($connexion,$valueOut)." 
			WHERE  atm_logical_names.id_atm= new_list_gab.id_terminal_xfs
			AND  new_list_gab.id_profil=".  mysqli_real_escape_string($connexion,$id_profile)."    ";
           
			$result2=mysqli_query($connexion,$sql2);
					if (!$result2)
                    {
                        error_log("Erreur sql 520:  ".$sql2."   ".mysqli_error($connexion));
                        die('ERREUR QUERY 520 !');
                    }
			
			
			if($result2 >0)
			{
			   $resultBool= true;	
			}
	}
	/*****************SEVICE DEPOT ARGENT************************/
	else if ($serviceTransaction==2)
	{
			$sql3 = "UPDATE  atm_logical_names,new_list_gab SET  atm_logical_names.passive_value_money_deposit=".  mysqli_real_escape_string($connexion,$value)." ,
			atm_logical_names.start_date_day_passive_value='".  mysqli_real_escape_string($connexion,$startDay).":00:00',
			atm_logical_names.end_date_day_passive_value='".  mysqli_real_escape_string($connexion,$endDay).":00:00', 
			atm_logical_names.passive_value_money_deposit_out_schedule=".  mysqli_real_escape_string($connexion,$valueOut)."
			WHERE  atm_logical_names.id_atm= new_list_gab.id_terminal_xfs
			AND  new_list_gab.id_profil=".  mysqli_real_escape_string($connexion,$id_profile)."    ";
                       
			$result3=mysqli_query($connexion,$sql3);
					if (!$result3)
												{
													error_log("Erreur sql 521:  ".$sql3."   ".mysqli_error($connexion));
													die('ERREUR QUERY 521 !');
												}
			
			if($result3 >0)
                {
                   $resultBool= true;
                }
	}

	/*****************SEVICE DEPOT DE CHEQUE************************/
	else if ($serviceTransaction==3)
	{
		$sql4 = "UPDATE  atm_logical_names,new_list_gab SET  atm_logical_names.passive_value_check_deposit=".  mysqli_real_escape_string($connexion,$value)." ,
			atm_logical_names.start_date_day_passive_value='".  mysqli_real_escape_string($connexion,$startDay).":00:00',
			atm_logical_names.end_date_day_passive_value='".  mysqli_real_escape_string($connexion,$endDay).":00:00', 
			atm_logical_names.passive_value_check_deposit_out_schedule=".  mysqli_real_escape_string($connexion,$valueOut)."
			WHERE  atm_logical_names.id_atm= new_list_gab.id_terminal_xfs
			AND  new_list_gab.id_profil=".  mysqli_real_escape_string($connexion,$id_profile)."    ";
             
			 $result4=mysqli_query($connexion,$sql4);
					if (!$result4)
												{
													error_log("Erreur sql 522:  ".$sql4."   ".mysqli_error($connexion));
													die('ERREUR QUERY 522 !');
												}
			 
			if($result4 >0)
			{
			   $resultBool= true;	
			}
	}
	mysqli_close($connexion);
	return $resultBool;
}

/**************************************************************************************************************/

function validerParamGAB($id_gab,$serviceTransaction,$value,$startDay,$endDay,$valueOut)
{
	$resultBool= false;
    $connexion=ma_db_connexion();

    /*****************SEVICE RETRAIT CARD************************/
	if($serviceTransaction==1)
	{	
			$sql2 = "UPDATE  atm_logical_names,new_list_gab SET  atm_logical_names.passive_value_withrawel=".$value." ,
			atm_logical_names.start_date_day_passive_value='".  mysqli_real_escape_string($connexion,$startDay).":00:00',
			atm_logical_names.end_date_day_passive_value='".  mysqli_real_escape_string($connexion,$endDay).":00:00', 
			atm_logical_names.passive_value_withrawel_out_schedule=".  mysqli_real_escape_string($connexion,$valueOut)." 
			WHERE  atm_logical_names.id_atm= new_list_gab.id_terminal_xfs
			AND  new_list_gab.terminal=".  mysqli_real_escape_string($connexion,$id_gab)."    ";
            $result2=mysqli_query($connexion,$sql2);
					if (!$result2)
												{
													error_log("Erreur sql 523:  ".$sql2."   ".mysqli_error($connexion));
													die('ERREUR QUERY 523 !');
												}

			if($result2 >0)
			{
			   $resultBool= true;	
			}
	}
	/*****************SEVICE DEPOT ARGENT************************/
	else if ($serviceTransaction==2)
	{
			$sql3 = "UPDATE  atm_logical_names,new_list_gab SET  atm_logical_names.passive_value_money_deposit=".  mysqli_real_escape_string($connexion,$value)." ,
			atm_logical_names.start_date_day_passive_value='".  mysqli_real_escape_string($connexion,$startDay).":00:00',
			atm_logical_names.end_date_day_passive_value='".  mysqli_real_escape_string($connexion,$endDay).":00:00', 
			atm_logical_names.passive_value_money_deposit_out_schedule=".  mysqli_real_escape_string($connexion,$valueOut)."
			WHERE  atm_logical_names.id_atm= new_list_gab.id_terminal_xfs AND  new_list_gab.terminal=".  mysqli_real_escape_string($connexion,$id_gab)."     ";
            $result3=mysqli_query($connexion,$sql3);
					if (!$result3)
												{
													error_log("Erreur sql 524:  ".$sql3."   ".mysqli_error($connexion));
													die('ERREUR QUERY 524 !');
												}
            if($result3 >0)
                {
                   $resultBool= true;
                }
	}

	/*****************SEVICE DEPOT DE CHEQUE************************/
	else if ($serviceTransaction==3)
	{
		$sql4 = "UPDATE  atm_logical_names,new_list_gab SET  atm_logical_names.passive_value_check_deposit=".  mysqli_real_escape_string($connexion,$value)." ,
        atm_logical_names.start_date_day_passive_value='".  mysqli_real_escape_string($connexion,$startDay).":00:00',
		atm_logical_names.end_date_day_passive_value='".  mysqli_real_escape_string($connexion,$endDay).":00:00', 
        atm_logical_names.passive_value_check_deposit_out_schedule=".  mysqli_real_escape_string($connexion,$valueOut)."
        WHERE  atm_logical_names.id_atm= new_list_gab.id_terminal_xfs
        AND  new_list_gab.terminal=".  mysqli_real_escape_string($connexion,$id_gab)."    ";
		
        $result4=mysqli_query($connexion,$sql4);
					if (!$result4)
												{
													error_log("Erreur sql 525:  ".$sql4."   ".mysqli_error($connexion));
													die('ERREUR QUERY 525 !');
												}
        if($result4 >0)
        {
           $resultBool= true;
        }
	}
	mysqli_close($connexion);
	return $resultBool;
}


/**************************************************************************************************************/

function validerParamMontantGAB($id_gab,$value)
{
	$resultBool= false;
    $connexion=ma_db_connexion();

	if($value<>"" && $id_gab<>"")
	{	
        $sql2 = "UPDATE  atm_logical_names,new_list_gab SET  atm_logical_names.critical_cash_amount=".  mysqli_real_escape_string($connexion,$value)." 
        WHERE  atm_logical_names.id_atm= new_list_gab.id_terminal_xfs
        AND  new_list_gab.terminal=".  mysqli_real_escape_string($connexion,$id_gab)." AND    atm_logical_names.id_service=4 ";
		
        $result2=mysqli_query($connexion,$sql2);
					if (!$result2)
												{
													error_log("Erreur sql 526:  ".$sql2."   ".mysqli_error($connexion));
													die('ERREUR QUERY 526 !');
												}
												
        if($result2 >0)
        {
           $resultBool= true;
        }
	}
	mysqli_close($connexion);
	return $resultBool;
}
/**************************************************************************************************************/
function validerParamMontantProfile($id_profile,$value)
{
	$resultBool= false;
    $connexion=ma_db_connexion();
    if($value<>"" && $id_profile<>"")
	{	
		$sql = "UPDATE  config_cash_values SET  cash_value=".  mysqli_real_escape_string($connexion,$value)." 
		WHERE  id_profil =".  mysqli_real_escape_string($connexion,$id_profile)."  ";

        $result=mysqli_query($connexion,$sql);
					if (!$result)
												{
													error_log("Erreur sql 526:  ".$sql."   ".mysqli_error($connexion));
													die('ERREUR QUERY 526 !');
												}
												
		if($result>0)
        {
            $resultBool= true;
        }
        $sql2 = "UPDATE  atm_logical_names,new_list_gab SET  atm_logical_names.critical_cash_amount=".  mysqli_real_escape_string($connexion,$value)." 
        WHERE  atm_logical_names.id_atm= new_list_gab.id_terminal_xfs
        AND  new_list_gab.id_profil=".  mysqli_real_escape_string($connexion,$id_profile)."    ";
		
        $result2=mysqli_query($connexion,$sql2);
					if (!$result2)
												{
													error_log("Erreur sql 527:  ".$sql2."   ".mysqli_error($connexion));
													die('ERREUR QUERY 527 !');
												}
												
        if($result2 >0)
        {
           $resultBool= true;
        }
    }
	mysqli_close($connexion);
	return $resultBool;
}


/**************************************************************************************************************/
function validerParamSuperviseurModeProfile($id_profile,$value)
{
	$resultBool= false;
	// echo "id_profile  ".$id_profile;
	// echo "value  ".$value;
    $connexion=ma_db_connexion();

    if($value<>"" && $id_profile<>"")
	{	
		$sql = "UPDATE  config_supervisor_mode_values SET  value=".  mysqli_real_escape_string($connexion,$value)." 
		WHERE  id_profile =".  mysqli_real_escape_string($connexion,$id_profile)."  ";
        
		   $result=mysqli_query($connexion,$sql);
					if (!$result)
												{
													error_log("Erreur sql 528:  ".$sql."   ".mysqli_error($connexion));
													die('ERREUR QUERY 528 !');
												}
												
        if($result>0)
        {
            $resultBool= true;
        }
			
            $sql2 = "UPDATE  atm_logical_names,new_list_gab SET  atm_logical_names.critical_supervisor_mode_value=".  mysqli_real_escape_string($connexion,$value)." 
            WHERE  atm_logical_names.id_atm= new_list_gab.id_terminal_xfs
            AND  new_list_gab.id_profil=".  mysqli_real_escape_string($connexion,$id_profile)."    ";
            
	$result2=mysqli_query($connexion,$sql2);
		if (!$result2)
			{
				error_log("Erreur sql 529:  ".$sql2."   ".mysqli_error($connexion));
				die('ERREUR QUERY 529 !');
			}            if($result2 >0)
            {
               $resultBool= true;
            }
	}
	mysqli_close($connexion);
	return $resultBool;
}
/**************************************************************************************************************/
function validerTimeoutCommand($id_command,$parm_timeout_cmd)
{
	$resultBool= false;
	// echo "id_profile  ".$id_profile;
	// echo "value  ".$value;
    $connexion=ma_db_connexion();

    if($id_command<>"" && $parm_timeout_cmd<>"")
	{
		
		$sql = "DELETE FROM config_timeout_cmd WHERE  id_command =".  mysqli_real_escape_string($connexion,$id_command)."  ";
  
        $result=mysqli_query($connexion,$sql);
	if (!$result)
			{
				error_log("Erreur sql 530:  ".$sql."   ".mysqli_error($connexion));
				die('ERREUR QUERY 530 !');
			}
		
		if($result>0)
        {
           
			$sql2 = "INSERT INTO config_timeout_cmd (id_command,value_config) VALUES (".  mysqli_real_escape_string($connexion,$id_command).",
			".  mysqli_real_escape_string($connexion,$parm_timeout_cmd).") ";
            
            $result2=mysqli_query($connexion,$sql2);
			if (!$result2)
			{
				error_log("Erreur sql 531:  ".$sql2."   ".mysqli_error($connexion));
				die('ERREUR QUERY 531 !');
			}
			
			
			if($result2 >0)
            {
               $resultBool= true;
            }	
        }

	}
	mysqli_close($connexion);
	return $resultBool;
}
/**************************************************************************************************************/
function validerTimeoutCompagn($parm_timeout_compagn)
{
	$resultBool= false;
	// echo "id_profile  ".$id_profile;
	// echo "value  ".$value;
	
	if($parm_timeout_compagn<>"")
	{	
		$conn=ma_db_connexion();
		
		$sql = "DELETE FROM config_timeout_deployment WHERE  type_deployment =1  ";
        
		$result=mysqli_query($connexion,$sql);
		if (!$result)
			{
				error_log("Erreur sql 532:  ".$sql."   ".mysqli_error($connexion));
				die('ERREUR QUERY 532 !');
			}
		if($result>0)
        {
           
			$sql2 = "INSERT INTO config_timeout_deployment (type_deployment,value_config) VALUES (1, ".  mysqli_real_escape_string($connexion,$parm_timeout_compagn).") ";
            
            
			$result2=mysqli_query($connexion,$sql2);
			if (!$result2)
			{
				error_log("Erreur sql 533:  ".$sql2."   ".mysqli_error($connexion));
				die('ERREUR QUERY 533 !');
			}
			
			if($result2 >0)
            {
               $resultBool= true;
            }	
        }
        mysqli_close($conn);
    }
	
	return $resultBool;
}

/**************************************************************************************************************/
function validerParamSuperviseurModeGAB($id_gab,$value)
{
	$resultBool= false;

	if($value<>"" && $id_gab<>"")
	{
        $connexion=ma_db_connexion();
        $sql2 = "UPDATE  atm_logical_names,new_list_gab SET  atm_logical_names.critical_supervisor_mode_value=".  mysqli_real_escape_string($connexion,$value)." 
			WHERE  atm_logical_names.id_atm= new_list_gab.id_terminal_xfs
			AND  new_list_gab.terminal=".  mysqli_real_escape_string($connexion,$id_gab)."  ";
            $result2=mysqli_query($connexion,$sql2);
			if (!$result2)
			{
				error_log("Erreur sql 534:  ".$sql2."   ".mysqli_error($connexion));
				die('ERREUR QUERY 534 !');
			}
			
			if($result2 >0)
			{
			   $resultBool= true;	
			}
			mysqli_close($connexion);
	}
	
	return $resultBool;
}
/**************************************************************************************************************/

function getFormParametragePassive()
{
	?>
	<div id="div_parametrage_passif">
        <div class="row">
	        <div class="col-sm-6" >
			    <div class="card shadow-lg p-3 mb-5 bg-white rounded">
				    <div class="card-header bg-secondary" >Passive ATM settings by Profile</div>
                    <div class="card-body">
                        <div id="div_val_passive_profile">
						    <div class="form-group row">
                                <div class="col-md-6">
                                    <label>Profile:</label>
                                    <select   name="profile"  id="profile" class="form-control">
                                        <?php get_select_profile();?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label>Service:</label>
                                    <select   name="service_profile"  id="service_profile" class="form-control">
                                        <?php	get_select_service_transaction();?>
                                    </select>
                                </div>
																						
							</div>
							<div class="form-group row">
                                <div class="col-md-6">
                                    <label>beginning time:</label>
                                    <input class="form-control" placeholder="00" id="start_passive_profil">
                                </div>
                                <div class="col-md-6">
                                    <label>End time:</label>
                                    <input class="form-control" placeholder="00" id="end_passive_profil">
                                </div>
																						
							</div>
							<div class="form-group row">
							    <div class="col-md-6">
								    <label>Hourly IN value (minutes):</label>
									<input class="form-control" placeholder="00" id="passive_value_profil">
								</div>
                                <div class="col-md-6">
                                    <label>Hourly OUT value (minutes):</label>
                                    <input class="form-control" placeholder="00" id="passive_value_profil_out">
                                </div>
							</div>

                            <div class="row">
                                <div class="col-md-10">
                                <label>(*): Update by profile reset the old parameters of ATMs belonging to the modified profile </label>
                                <br> <label>(*): The schedule is updated for any type of service </label>
                                </div>
                                <div class="col-md-2">
                                    <button class="btn btn-danger" onclick="javascript:validerConfigPassiveProfil();">validate</button>
                                </div>
                            </div>
						</div>
					</div>
				</div>
			</div>

            <div class="col-sm-6" >
                <div class="card shadow-lg p-3 mb-5 bg-white rounded">
                    <div class="card-header bg-secondary" >Passive ATM settings by ATM</div>
                    <div class="card-body">
                        <div id="div_val_passive_gab">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label>Cashpoint ID :</label>
                                    <input class="form-control" placeholder="000000000" id="passive_gab">
                                </div>
                                <div class="col-md-6">
                                    <label>Service:</label>
                                    <select name="service_gab" id="service_gab" class="form-control">
                                        <?php get_select_service_transaction();?>
                                    </select>
                                </div>
                            </div>
																					
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label>beginning time:</label>
                                    <input class="form-control" placeholder="00" id="start_passive_gab">
                                </div>
                                <div class="col-md-6">
                                    <label>End time:</label>
                                    <input class="form-control" placeholder="00" id="end_passive_gab">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label>Hourly IN value (minutes):</label>
                                    <input class="form-control" placeholder="00" id="passive_value_gab">
                                </div>
                                <div class="col-md-6">
                                    <label>Hourly OUT value (minutes):</label>
                                    <input class="form-control" placeholder="00" id="passive_value_gab_out">
                                </div>
                            </div>
														
                            <div class="form-group row" >
                                <div class="col-md-10">
                                    <label>(*): The schedule is updated for any type of service </label>


                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-danger" onclick="javascript:validerConfigPassiveGab();">validate</button>
                                </div>
														
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</div> 
							
<?php
	
}
/**************************************************************************************************************/
/**************************************************************************************************************/
/**************************************************************************************************************/
/**************************************************************************************************************/
/**************************************************************************************************************/

function getFormParametrageMontantCassettes()
{
	?>
	<div id="div_parametrage_montant">
        <div class="row">
            <div class="col-sm-6" >
                <div class="card shadow-lg p-3 mb-5 bg-white rounded">
                    <div class="card-header bg-secondary">Critical amount setting by Profile</div>
                    <div class="card-body">
                        <div id="div_val_montant_profile">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label>Profile:</label>
                                    <select  name="profile_montant"  id="profile_montant" class="form-control">
                                        <?php get_select_profile();?>
                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label>Amount (MGA):</label>
                                    <input class="form-control" placeholder="0" id="montant_value_profil">
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-10">
                                    <label>(*): Update by profile reset the old parameters of ATMs belonging to the modified profile</label>
                                </div>
																	
																	
                                <div class="col-md-2">
                                    <button class="btn btn-danger" onclick="javascript:validerConfigMontantProfil();">Validate</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
														
            </div>
								
            <div class="col-sm-6" >
                <div class="card shadow-lg p-3 mb-5 bg-white rounded">
                    <div class="card-header bg-secondary">Parameter setting Critical amount by ATM</div>
                    <div class="card-body">
                        <div id="div_val_montant_gab">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label>Cashpoint ID:</label>
                                    <input class="form-control" placeholder="000000000" id="montant_gab">
                                </div>
                                <div class="col-md-6">
                                    <label>Value (in minutes):</label>
                                    <input class="form-control" placeholder="0" id="montant_value_gab">
                                </div>
                            </div>
                            <div class="form-group row" >
                                <div class="col-md-10" style="margin-top: 10px">
                                    <label>(*): Applied for each ATM distribution module</label>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-danger" onclick="javascript:validerConfigMontantGab();">Validate</button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
											
            </div>
        </div>
	</div> 
							
<?php	
	
}


/**************************************************************************************************************/
function getFormParametrageSupervisorMode()
{
	?>
	<div id="div_parametrage_passif">
        <div class="row">
            <div class="col-sm-6" >
                <div class="card shadow-lg p-3 mb-5 bg-white rounded">
                    <div class="card-header bg-secondary">ATM settings in supervisor mode by Profile</div>
                    <div class="card-body">
                        <div id="div_val_superviseur_profile">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label>Profile:</label>
                                    <select   name="profile_superviseur"  id="profile_superviseur" class="form-control">';
                                        <?php get_select_profile();?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label>Value (in minutes):</label>
                                    <input class="form-control" placeholder="0" id="superviseur_value_profil">
                                </div>
                            </div>
																
                            <div class="form-group row" >
                                <div class="col-md-10">
                                    <label>(*): Update by profile reset the old parameters of ATMs belonging to the modified profile</label>
                                </div>
                                <div class="col-md-2">
                                    <button class="btn btn-danger" onclick="javascript:validerConfigModeSuperviseurProfil();">Validate</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
								
            <div class="col-sm-6" >
                <div class="card shadow-lg p-3 mb-5 bg-white rounded">
                    <div class="card-header bg-secondary" >ATM settings in supervisor mode by ATM</div>
                    <div style="margin-left: 10px" class="card-body">
                        <div id="div_val_superviseur_gab">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label>Cashpoint ID:</label>
                                    <input class="form-control" placeholder="000000000" id="superviseur_gab">
                                </div>
                                <div class="col-md-6">
                                    <label>Value (in minutes):</label>
                                    <input class="form-control" placeholder="0" id="superviseur_value_gab">
                                </div>
                            </div>

                            <div class="row" style="margin-top: 15px">
                                <div class="col-md-10"></div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-danger" onclick="javascript:validerConfigModeSuperviseurGab();">Validate</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</div> 
							
<?php
	
}
/**************************************************************************************************************/

function getFormParametragetimeOutCommand_Compagn()
{
	?>
	<div id="div_parametrage_timeout">
        <div class="row">
            <div class="col-sm-6" >
                <div class="card shadow-lg p-3 mb-5 bg-white rounded">
                    <div class="card-header bg-secondary">Setting the command timeout period</div>
                    <div class="card-body">
                        <div id="div_val_timeout_command">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label>Ordered :</label>
                                    <select   name="id_command"  id="id_command" class="form-control">
                                        <?php get_select_command();?>
                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label>Value (in minutes):</label>
                                    <input class="form-control" placeholder="0" id="parm_timeout_cmd">
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-10">
                                    <label>(*): The default applied value is 40 minutes</label>
                                </div>
                                <div class="col-md-2">
                                    <button class="btn btn-danger" onclick="javascript:validerConfigTimeoutCommand();">Validate</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
								
            <div class="col-sm-6" >
                <div class="card shadow-lg p-3 mb-5 bg-white rounded">
                    <div class="card-header bg-secondary">Setting the timeout period for advertising campaigns</div>
                    <div class="card-body">
                        <div id="div_val_timeout_compagn">
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <label>Value (in minutes):</label>
                                    <input class="form-control" placeholder="0" id="parm_timeout_compagn">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-10">
                                    <label>(*): The default applied value is 40 minutes</label>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-danger" onclick="javascript:validerConfigTimeoutCompagn();">Validate</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
							
<?php
	
}



/**************************************************************************************************************/
function getpanelparame()
{
    include "languages/" . $_SESSION['lang'] . ".php";

    ?>
    <div class="row" id="div__info_parametrage_EventJRN">
        <div class="col-sm-12 col-lg-12">
            <div class="card shadow-lg p-3 mb-5 bg-white rounded">
               <div class="card">
                   <div class="card-header bg-secondary"><?php echo $lang['info_param_ev_jour']?> </div>
                   <div class="card-body">
                       <table class="table table-responsive-sm table-hover table-outline mb-0">
                           <thead class="thead-light">
                               <th><?php echo $lang['type_even']?> </th>
                               <th><?php echo $lang['even_lie']?></th>
                           </thead>
                             <?php getallcongjrn(); ?>
                       </table>
                   </div>
               </div>
               <div class="card">
                   <div class="card-header bg-secondary" >Passive ATM Parameter Info </div>
                   <div  class="card-body">
                       <table class="table table-responsive-sm table-hover table-outline mb-0">
                           <thead class="thead-light">
                               <th class="text-center">Profile </th>
                               <th class="text-center">Transaction</th>
                               <th class="text-center">Day / Night Passive Value</th>
                               <th class="text-center">Start Date - End Date</th>
                           </thead>
                           <?php get_all_gap_passive(); ?>
                       </table>
                   </div>
               </div>

               <div class=card">
                   <div class="card-header bg-secondary">Supervisor Mode Parameter Info </div>
                   <div class="card-body">
                       <table class="table table-responsive-sm table-hover table-outline mb-0">
                           <thead class="thead-light">
                               <th class="text-center">Profile </th>
                               <th class="text-center">Supervisor Mode Value</th>
                           </thead>
                           <?php get_all_mode_superviseur();?>
                       </table>
                   </div>
               </div>
               <div class="card">
                   <div class="card-header bg-secondary">Info Setting the timeout period for the images to be deployed </div>
                   <div class="card-body">
                       <?php get_tableau_config_timeout_compagn();?>
                   </div>
               </div>
               <div class="card">
                   <div class="card-header bg-secondary" >Info Paramétrage du délai timeout des commandes </div>
                   <div  class="card-body">
                       <?php get_tableau_config_timeout_command();?>
                   </div>
               </div>
           </div>
       </div>
   </div>
<?php
}
/**************************************************************************************************************/
/**************************************************************************************************************/
/**************************************************************************************************************/
function get_tableau_config_timeout_command()
{
	$conn=ma_db_connexion();
    echo '<tbody id="div_info_timeout_cmd">
    <div>';
	
    $SQL= "SELECT  list_cmd_for_atm.description_cmd, config_timeout_cmd.value_config
	FROM config_timeout_cmd, list_cmd_for_atm
	WHERE config_timeout_cmd.id_command = list_cmd_for_atm.id_command";
   
   $result=mysqli_query($conn,$SQL);
	if (!$result)
			{
				error_log("Erreur sql 535:  ".$SQL."   ".mysqli_error($conn));
				die('ERREUR QUERY 535 !');
			}
   
   
    if ($result)
    {
		echo '<table class="table table-responsive-sm table-hover table-outline mb-0">
                                 <thead class="thead-light">
                                    <th class="text-center">Commande </th>
                                    <th class="text-center">Value (minutes) </th>    
                                 </thead>';
		
		
        if(mysqli_num_rows($result)>0)
        {
          
            while ($row = mysqli_fetch_assoc($result))
            {
               
                echo '<tr>
                    <td style="padding: 3px" align="left"> ' . $row["description_cmd"] . '</td>
                    <td style="padding: 3px" align="center"> ' . $row["value_config"] . '</td>';
					
				echo '</tr>';
            }
        } else{
			
			
		}
		
        mysqli_free_result($result);
		
		echo ' </table>';
    }
mysqli_close($conn);
    echo '
             </td>
           
            </div></tbody>';
}

/**************************************************************************************************************/
function get_tableau_config_timeout_compagn()
{
	$conn=ma_db_connexion();
    echo '<tbody id="div_info_timeout_compagn">
    <div>';
	
    $SQL= "SELECT  config_timeout_deployment.value_config
	FROM config_timeout_deployment
	WHERE config_timeout_deployment.type_deployment=1";
	
	 $result=mysqli_query($conn,$SQL);
	if (!$result)
			{
				error_log("Erreur sql 536:  ".$SQL."   ".mysqli_error($conn));
				die('ERREUR QUERY 536 !');
			}
   
    if ($result)
    {
		echo '<table class="table table-responsive-sm table-hover table-outline mb-0">
                                 <thead class="thead-light">
                                    <th class="text-center">Value (minutes) </th>
                                       
                                 </thead>';
		
		
        if(mysqli_num_rows($result)>0)
        {
          
            while ($row = mysqli_fetch_assoc($result))
            {
               
                echo '<tr>
                    <td style="padding: 3px" align="center"> ' . $row["value_config"] . '</td>';
					
				echo '</tr>';
            }
        } else{
			
			
		}
		
        mysqli_free_result($result);
		
		echo ' </table>';
    }
mysqli_close($conn);
    echo '
             </td>
           
            </div></tbody>';
}


?>