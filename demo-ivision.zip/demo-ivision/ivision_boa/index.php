<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

include "lib/auth/config.php";

?>
<!DOCTYPE html>
<html lang="<?php echo $lang['lang'] ?>">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="IPRC">

    <title><?php echo $lang['title'] ?></title>

    <?php include 'headerAcceuil.php'; ?>
</head>
<body>

<?php


if(empty($_POST['mdp'])){$_POST['mdp']="";}
if(empty($_POST['user'])){$_POST['user']="";}

//session_start();

include("lib/userlib.php");


$user="";

if((getlenght($_POST['mdp'])>=3) && (getlenght($_POST['mdp'])<=60) && (getlenght($_POST['user'])>=3) && (getlenght($_POST['user'])<=108) )
{
    if(empty($_POST['user'])){$user="";}else{$user=antixss($_POST['user']);}
    if(empty($_POST['mdp'])){$mdp="";}else{$mdp=antixss($_POST['mdp']);}
}
$id_utilisateur=get_id_user($user);

if (((isset($_SESSION['user']))&&(verif_user($_SESSION['user'],$_SESSION['mdp'])==true)) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true) ))
{
    //echo "autorisation_projet : ".$_SESSION['autorisation_projet'];
    //var_dump($_SESSION['autorisation_projet']);
    header('Location: start.php');
}
else
{

    if (($user <> "")&&(verif_existe_user($user)===true))://si user est existe


        if (($user <> "")&&(verif_etat_blocage($id_utilisateur)==true)): //si le compte est  bloquée

            if (($user <> "")&&(verif_duree_blocage($id_utilisateur)==true)):// si duree blocage Sup a 10 min

                if (($user <> "")&&(verif_user($user,$mdp)==true))://  verfier user et mode passe
                    ?>
                    <?php
                    $_SESSION['user']=$user;
                    $_SESSION['mdp']=$_POST['mdp'];
                    $_SESSION['id_utilisateur']=get_id_user($_POST['user']);
                    /*****************************************/
                    if(empty($_SESSION['user'])){$_SESSION['user']="";}
                    if(empty($_SESSION['mdp'])){$_SESSION['mdp']="";}
                    $_SESSION['habilitation_backoffice']=charger_habilitation($_SESSION['user']);
                    // $_SESSION['habilitation_backoffice']=charger_habilitation_menu($_SESSION['user']);
                    $_SESSION['habilitation_sous_menu']=charger_habilitation_sous_menu($_SESSION['user']);
                    $_SESSION['habilitation_action']=charger_habilitation_action($_SESSION['user']);
                    $_SESSION['adresse_ip']=chager_ip_adresse($_SESSION['user']);
                    $_SESSION['autorisation_projet']=chager_id_option_projet($_SESSION['user']);
                    $_SESSION['autorisation_backoffice']=chager_id_option_backoffice($_SESSION['user']);
                    /*****************************************/
                    // foreach($_SESSION['habilitation_sous_menu'] as $cle2 => $valeur2){echo $valeur2 ,'<br>';}
                    update_tent_date_initial_value($id_utilisateur);
                    ajouter_historique_connexion(get_id_user(htmlspecialchars($user)), htmlspecialchars($user),get_ip(),date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))),'PROJET BMCE CASHING','Connexion Réussi');
                    update_last_connexion(htmlspecialchars($user));

                    header('Location: start.php');
                    ?>
                <?php else:
                    update_tent_date_up($id_utilisateur);
                    include("lib/auth/get_index.php");
                endif ?>

            <?php else:
                update_tent_date_up($id_utilisateur);
                include("lib/auth/get_index.php");
            endif ?>
        <?php else:
            if (($user <> "")&&(verif_user($user,$mdp)==true)):
                ?>
                <?php
                $_SESSION['user']=$user;
                $_SESSION['mdp']=$_POST['mdp'];
                $_SESSION['id_utilisateur']=get_id_user($_POST['user']);
                /*****************************************/
                if(empty($_SESSION['user'])){$_SESSION['user']="";}
                if(empty($_SESSION['mdp'])){$_SESSION['mdp']="";}
                $_SESSION['habilitation_backoffice']=charger_habilitation($_SESSION['user']);
                // $_SESSION['habilitation_backoffice']=charger_habilitation_menu($_SESSION['user']);
                $_SESSION['habilitation_sous_menu']=charger_habilitation_sous_menu($_SESSION['user']);
                $_SESSION['habilitation_action']=charger_habilitation_action($_SESSION['user']);
                $_SESSION['adresse_ip']=chager_ip_adresse($_SESSION['user']);
                $_SESSION['autorisation_projet']=chager_id_option_projet($_SESSION['user']);
                $_SESSION['autorisation_backoffice']=chager_id_option_backoffice($_SESSION['user']);
                /*****************************************/
                // foreach($_SESSION['habilitation_sous_menu'] as $cle2 => $valeur2){echo $valeur2 ,'<br>';}
                update_tent_date_initial_value($id_utilisateur);
                ajouter_historique_connexion(get_id_user(htmlspecialchars($user)), htmlspecialchars($user),get_ip(),date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y"))),'PROJET BMCE CASHING','Connexion Réussi');
                update_last_connexion(htmlspecialchars($user));
                header('Location: start.php');
                ?>
            <?php else:
                if (getnbr_tentative($id_utilisateur)<2):// si nombre tentative inf a 3

                    update_tent_date_up($id_utilisateur);?>
                <?php else: // si nombre tentative sup ou egal a 3
                    update_block_tent_date_($id_utilisateur);
                endif ?>
                <?php
                include("lib/auth/get_index.php");
            endif ?>
        <?php endif ?>

    <?php else:
        include("lib/auth/get_index.php");

    endif ?>
    <?php
}
?>

</body>
</html>
