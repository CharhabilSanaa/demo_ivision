<?php
include "lib/auth/config.php";

?>
<!DOCTYPE html>
<html lang="<?php echo $lang['lang'];?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php include 'header_star.php'; ?>
<style type="text/css">
    div.dataTables_wrapper  div.dataTables_filter {
        width: 100%;
        float: none;
        text-align: right;
</style>
</head>
<?php

if (verif_user($_SESSION['user'],$_SESSION['mdp'])==true): ?>
    <?php if ((verif_user($_SESSION['user'],$_SESSION['mdp'])==true) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true))): ?>

        <?php
        $profil =0;
        if(empty($_POST['dated'])){$dated=date('Y-m-d');}else{$dated=$_POST['dated'];}
        if(empty($_POST['datef'])){$datef=date('Y-m-d');}else{$datef=$_POST['datef'];}
        ?>

        <body class="c-app">

        <?php
        include 'sidebar.php';

        ?>
        <div class="c-wrapper c-fixed-components">
            <?php  include 'navbar_star.php'; ?>
            <div class="c-body">
                <main class="c-main">
                    <div class="container-fluid">
                        <div class="fade-in">
                            <input type="hidden" id="hdnSession" data-value="24"/>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="start.php">I-Vision</a></li>
                                    <li class="breadcrumb-item"><a href="start.php"><?php echo $lang['administrate'];?></a></li>
                                    <li class="breadcrumb-item" aria-current="page"><?php echo $lang['disp_gab'];?></li>
                                </ol>
                            </nav>

                            <?php
                            if ((verif_habilitation($_SESSION['habilitation_backoffice'],24)==true)):
                            ?>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <form id="form_moyen_dispo_gab" method="post" enctype="multipart/form-data">
                                                <div class="row d-flex justify-content-between">

                                                    <div class="col-md-4 search-box">
                                                        <input type="date" lang="en" id="dated" name="dated" value="<?php if($dated<>''){echo $dated; } ?>" class="form-control required" placeholder="Date début" required>
                                                    </div>

                                                    <div class="col-md-4 search-box">
                                                        <input type="date" lang="en" id="datef" name="datef" value="<?php if($datef<>''){echo $datef; } ?>"  class="form-control required" placeholder="Date début" required>
                                                    </div>

                                                    <div class="col-md-2 search-box">

                                                    </div>
                                                    <div class="col-md-2 search-box">
                                                        <button class="btn btn-block btn-outline-primary my-2 my-sm-0" type="submit"><?php echo $lang['search'];  ?>
                                                            <svg class="c-icon float-right">
                                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-cloud-upload"></use>
                                                            </svg>
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row" >
                                <div class="col-lg-12">
                                    <div class="card">

                                        <div class="card-header"><i class="fa fa-align-justify"></i> <?php echo $lang['disp_gab'];?>  :</div>
                                        <div class="card-body">
                                            <table id="tbl_d_m_gab" class="table table-responsive-sm table-hover table-outline mb-0">
                                                <thead class="thead-light">
                                                <tr>
                                                    <th class="text-center">ID</th>
                                                    <th class="text-center"><?php echo $lang['atm'];?></th>
                                                    <th class="text-center"><?php echo $lang['atm_name'];?></th>
                                                    <th class="text-center"><?php echo $lang['th_table_5'];?></th>
                                                    <th class="text-center"><?php echo $lang['th_table_6'];?></th>
                                                    <th class="text-center"><?php echo $lang['th_table_7'];?></th>
                                                </tr>
                                                </thead>
                                                <tbody id="tb_compagnes_pub">

                                                <?php
                                                get_moyen_dispo_gab($dated,$datef);
                                                //get_Compagnes_pub();
                                                ?>
                                                </tbody>
                                            </table>



                                        </div>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <?php
                                else:
                                    echo '<div class="alert alert-danger text-center" role="alert">PAGE UNAUTHORIZED !!</div>';
                                endif
                                ?>
                                <!-- /.col-lg-4 (nested) -->

                                <!-- /.col-lg-8 (nested) -->
                            </div>

                        </div>
                    </div>
                </main>
            </div>

        </div>

        <?php

        //header NAV Bar
        include 'footer.php';

        ?>



        </body>

    <?php
    else:
        header("location: start.php");
    endif ?>
<?php
else:
    header("location: index.php");
endif ?>
</html>
