<?php
include "lib/auth/config.php";

?>
<!DOCTYPE html>
<html lang="<?php echo $lang['lang'];?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php include 'header_star.php'; ?>

</head>
<script>
    function showAlert(){
        if($("#myAlert").find("div#myAlert2").length==0){
            $("#myAlert").append("<div class='alert alert-success alert-dismissable' id='myAlert2'> <button type='button' class='close' data-dismiss='alert'  aria-hidden='true'>&times;</button> Success! message sent successfully.</div>");
        }
        $("#myAlert").css("display", "");
        setTimeout(function() {
            $("#myAlert2").alert('close');
        }, 6000);
    }
</script>
<?php
error_reporting(0);
if (verif_user($_SESSION['user'],$_SESSION['mdp'])==true): ?>
    <?php if ((verif_user($_SESSION['user'],$_SESSION['mdp'])==true) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true))): ?>

        <?php
        if(empty($_POST['num_terminal'])){$_POST['num_terminal']="";}


        ?>

        <body class="c-app">

        <?php
        include 'sidebar.php';
        ?>
        <div class="c-wrapper c-fixed-components">
            <?php  include 'navbar_star.php'; ?>
            <div class="c-body">
                <main class="c-main">
                    <div class="container-fluid">
                        <div class="fade-in">
                            <input type="hidden" id="hdnSession" data-value="22"/>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="start.php">I-Vision</a></li>
                                    <li class="breadcrumb-item" ><a href="start.php"><?php echo $lang['bank'];?></a></li>
                                    <li class="breadcrumb-item" aria-current="page"><?php echo $lang['det_decl'];?></li>
                                </ol>
                            </nav>

                            <?php
                            if((verif_habilitation($_SESSION['habilitation_backoffice'],22)==true) && (!empty($_POST['num_terminal'])) )
                            {
                                $connexion=ma_db_connexion(); //mysqli_real_escape_string($connexion,
                                $term = $_POST['num_terminal'];
                                list($lebelle_intervention, $id_intervention) = explode('-',$_POST['inputcauseaction']);
                                $sql = "SELECT id_gab,id_incident FROM new_incident_gab_ouvert WHERE id_gab='".mysqli_real_escape_string($connexion,$term)."'
                                AND id_action_fonctionelle = '".mysqli_real_escape_string($connexion,$id_intervention)."'   ";
                                //var_dump($sql);
                                $control=mysqli_query($connexion,$sql);
                                if (!$control)
                                {
                                    error_log("Erreur sql 400:  ".$sql."   ".mysqli_error($connexion));
                                    die('ERREUR QUERY 400 !');
                                }
                                if ($control)
                                {
                                    /***********************************************************/
                                    if(mysqli_num_rows($control) == 0)
                                    {

                                        list($p1, $p2) = explode(' ', date_transaction($_POST['inputarret']));
                                        list($yr, $mn, $dy) = explode('-', $p1);
                                        $date_acteul=date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y")));
                                        $niveau_intervention=get_id_niveau_intervention_incident($id_intervention);
                                        $date_rappel=get_date_rappel2_declaration($_POST['id_rappel'],date_transaction($date_acteul),$niveau_intervention,$_POST['id_affecter']);
                                        $date_declaration=get_date_indident_declaration($_POST['id_rappel'],date_transaction($_POST['inputarret']),$niveau_intervention);

                                        /***Variables d'entrées*/
                                        $id_terminal= $_POST['num_terminal'];
                                        $date_arret= $date_declaration;
                                        //$date_rappel
                                        $id_niveau= get_id_niveau_intervention(trim($niveau_intervention));
                                        $id_action_interv= $id_intervention;
                                        $remarque=$_POST['remarque_incident'];
                                        $id_note= "";
                                        $persone_avise = $_POST['persone_avise'];
                                        $id_affecter= $_POST['id_affecter'];
                                        $id_etat= $_POST['id_etat'];

                                        $id_gab=get_IdAtm_Terminal($id_terminal);
                                        $purpose_input= $_POST['purpose_input'];
                                        $stat_scrn_incid=get_screen_incident($id_gab,$purpose_input);

                                        $id_arret= $_POST['id_arret'];
                                        if($id_arret=="")
                                        {
                                            $id_arret=0;
                                        }

                                        /*if(!empty($_POST['purpose_input'])) {
                                            echo '  ' . $_POST['purpose_input'];
                                        }*/

                                        //echo ' cheked_cmd :  ' . $_POST['purpose_input'];

                                        /**********************/


                                        //if (control_date_arret_same_values_last_Inci($id_terminal,$date_arret)=="" AND controlIncidentsImbriques($id_terminal,$date_arret)=="")
                                        {

                                            /****************************LA DECLARATION***************************************************************************************/
                                            $type_arret=get_array_type_arret($id_action_interv);
                                            $idcategorie=get_array_idcategorie($id_action_interv);
                                            $date_actuel=date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y")));
                                            //$date_actuel=date("Y-m-d  H:i:s");

                                            $duree = date_different($date_arret, $date_actuel);

                                            if (get_niveau_intervention_fonctionnelle($id_action_interv)==0){ $inter_fonc=0;}
                                            else{$inter_fonc=$id_action_interv;}

                                            if (get_niveau_intervention_technique($id_action_interv)==0){$inter_tech=0;}
                                            else{$inter_tech=$id_action_interv;}

                                            /**Pour le controle de la date*/
                                            $tabDate = date_parse($date_arret);
                                            if (($duree['minutes_total']>=0) && ( strtotime($date_arret) <= strtotime($date_actuel)) && ($tabDate['error_count'] == 0) && ($tabDate['warning_count'] == 0)  )
                                            {
                                                $id_niveau_interv=get_id_niveau_intervention_incident($id_action_interv);
                                                $id_etat_export_technique=get_return_affiche_dans_rapport_technique($id_action_interv);
                                                $indisponibilite=$id_action_interv;
                                                $date_remis = '0000-00-00 00:00:00';
                                                $etat_incident='0';
                                                if ($id_affecter==3){$appelagence=0;}else{$appelagence=1;}

                                                //****///Recuperer last Transaction mysqli_real_escape_string($connexion,

                                                $sql11="SELECT * FROM First_Arret WHERE terminal_atm_number='".mysqli_real_escape_string($connexion,$id_terminal)."'";

                                                $recupFirstArret=mysqli_query($connexion,$sql11);
                                                if (!$recupFirstArret)
                                                {
                                                    error_log("Erreur sql 410:  ".$sql11."   ".mysqli_error($connexion));
                                                    die('ERREUR QUERY 410 !');
                                                }

                                                if($recupFirstArret)
                                                {
                                                    if( mysqli_num_rows($recupFirstArret) > 0)
                                                    {
                                                        while ($DOO= mysqli_fetch_assoc($recupFirstArret))
                                                        {
                                                            $TT = $DOO["terminal_atm_number"];
                                                            $grouping = $DOO["terminal_atm_grouping"];
                                                            $outlet = $DOO["outlet_number"];
                                                            $atm = htmlspecialchars(mysqli_real_escape_string($DOO["atm_acronym"]));
                                                            $link = $DOO["link_com_addr"];
                                                            $profil = $DOO["terminal_profile"];
                                                            $LT = $DOO["last_transaction_date"];
                                                            $montantC1 = $DOO["cassette1_available_amount"];
                                                            $montantC2 = $DOO["cassette2_available_amount"];
                                                            $montantC3 = $DOO["cassette3_available_amount"];
                                                            $montantC4 = $DOO["cassette4_available_amount"];
                                                            $etatC1 = $DOO["cassette1_status"];
                                                            $etatC2 = $DOO["cassette2_status"];
                                                            $etatC3 = $DOO["cassette3_status"];
                                                            $etatC4 = $DOO["cassette4_status"];

                                                            $typeC1 = $DOO["cassette1_notes_type"];
                                                            $typeC2 = $DOO["cassette2_notes_type"];
                                                            $typeC3 = $DOO["cassette3_notes_type"];
                                                            $typeC4 = $DOO["cassette4_notes_type"];
                                                            $etatCasRejet = $DOO["cassette_reject_status"];
                                                            $etatSep = $DOO["dispenser"];
                                                            $etatLecteur = $DOO["card_reader_status"];
                                                            $etatJournal = $DOO["log_printer_status"];
                                                            $etatPinpad = $DOO["pinpad_status"];
                                                            $etatEpp = $DOO["encryption_device_status"];
                                                            $etatPC = $DOO["safe_box_status"];
                                                            $ticket = $DOO["ticket_printer_status"];
                                                            $lastEvent = $DOO["last_event"];
                                                            $lastEventDate = $DOO["last_event_date"];
                                                            $lastInserv = $DOO["last_in_service"];

                                                            $uplastTransFirstArret = $DOO["up_last_Trans"];
                                                            if ($uplastTransFirstArret=="0000-00-00 00:00:00"){$uplastTransFirstArret=$LT;}
                                                            $changeMontant=  $DOO["if_chgmt_montant"];

                                                            $m_c1=  $DOO["m_c1_chgmt"];
                                                            $m_c2=  $DOO["m_c2_chgmt"];
                                                            $m_c3=  $DOO["m_c3_chgmt"];
                                                            $m_c4=  $DOO["m_c4_chgmt"];

                                                            $s_c1=  $DOO["s_c1_chgmt"];
                                                            $s_c2=  $DOO["s_c2_chgmt"];
                                                            $s_c3=  $DOO["s_c3_chgmt"];
                                                            $s_c4=  $DOO["s_c4_chgmt"];

                                                            $etatTraitementArret=  $DOO["ifTraiter"];
                                                            $datePriseEnChargeTraiter=  $DOO["date_traiter"];


                                                            if($etatTraitementArret==1)
                                                            {
                                                                /*****/
                                                                $ArretTraiterDeclarer=mysqli_query("UPDATE historique_arret_traiter 
												SET  if_declarer=1 WHERE  date_arret_traiter='".mysqli_real_escape_string($connexion,$datePriseEnChargeTraiter)."' AND terminal='$TT'  ");
                                                                /*****/

                                                                if(strtotime($date_arret) >= strtotime($datePriseEnChargeTraiter) )
                                                                {
                                                                    $datePriseEnCharge= $date_actuel;

                                                                }
                                                                else if(strtotime($date_arret) < strtotime($datePriseEnChargeTraiter)){
                                                                    $datePriseEnCharge= $datePriseEnChargeTraiter;
                                                                }

                                                            }
                                                            else
                                                            {
                                                                $datePriseEnCharge= $date_actuel;
                                                            }

                                                        }
                                                    }
                                                    else
                                                    {

                                                        $sqlEtatParc="SELECT * FROM Etat_Parc_Gab WHERE terminal_atm_number='".mysqli_real_escape_string($connexion,$id_terminal)."'";
                                                        $recupEtatParc=mysqli_query($connexion,$sqlEtatParc);
                                                        if (!$recupEtatParc)
                                                        {
                                                            error_log("Erreur sql 401:  ".$sqlEtatParc."   ".mysqli_error($connexion));
                                                            die('ERREUR QUERY 401 !');
                                                        }

                                                        if ($recupEtatParc)
                                                        {
                                                            while ($DOO= mysqli_fetch_assoc($recupEtatParc))
                                                            {

                                                                $TT = $DOO["terminal_atm_number"];
                                                                $grouping = $DOO["terminal_atm_grouping"];
                                                                $outlet = $DOO["outlet_number"];
                                                                $atm = htmlspecialchars(mysqli_real_escape_string($DOO["atm_acronym"]));
                                                                $link = $DOO["link_com_addr"];
                                                                $profil = $DOO["terminal_profile"];
                                                                $LT = $DOO["last_transaction_date"];
                                                                $montantC1 = $DOO["cassette1_available_amount"];
                                                                $montantC2 = $DOO["cassette2_available_amount"];
                                                                $montantC3 = $DOO["cassette3_available_amount"];
                                                                $montantC4 = $DOO["cassette4_available_amount"];
                                                                $etatC1 = $DOO["cassette1_status"];
                                                                $etatC2 = $DOO["cassette2_status"];
                                                                $etatC3 = $DOO["cassette3_status"];
                                                                $etatC4 = $DOO["cassette4_status"];

                                                                $typeC1 = $DOO["cassette1_notes_type"];
                                                                $typeC2 = $DOO["cassette2_notes_type"];
                                                                $typeC3 = $DOO["cassette3_notes_type"];
                                                                $typeC4 = $DOO["cassette4_notes_type"];
                                                                $etatCasRejet = $DOO["cassette_reject_status"];
                                                                $etatSep = $DOO["dispenser"];
                                                                $etatLecteur = $DOO["card_reader_status"];
                                                                $etatJournal = $DOO["log_printer_status"];
                                                                $etatPinpad = $DOO["pinpad_status"];
                                                                $etatEpp = $DOO["encryption_device_status"];
                                                                $etatPC = $DOO["safe_box_status"];
                                                                $ticket = $DOO["ticket_printer_status"];
                                                                $lastEvent = $DOO["last_event"];
                                                                $lastEventDate = $DOO["last_event_date"];
                                                                $lastInserv = $DOO["last_in_service"];

                                                                $uplastTransFirstArret=$LT;
                                                                $changeMontant=  $DOO["if_chgmt_montant"];

                                                                $m_c1=  $DOO["m_c1_chgmt"];
                                                                $m_c2=  $DOO["m_c2_chgmt"];
                                                                $m_c3=  $DOO["m_c3_chgmt"];
                                                                $m_c4=  $DOO["m_c4_chgmt"];

                                                                $s_c1=  $DOO["s_c1_chgmt"];
                                                                $s_c2=  $DOO["s_c2_chgmt"];
                                                                $s_c3=  $DOO["s_c3_chgmt"];
                                                                $s_c4=  $DOO["s_c4_chgmt"];



                                                                $datePriseEnCharge= $date_actuel;
                                                                mysqli_free_result($recupEtatParc);
                                                            }
                                                        }
                                                    }
                                                    mysqli_free_result($recupFirstArret);
                                                }

                                                /************************************/
                                                // $total_montant_traitement= traitementCassetteForWarninngMinCassette($etatC1,$montantC1) + traitementCassetteForWarninngMinCassette($etatC2,$montantC2) + traitementCassetteForWarninngMinCassette($etatC3,$montantC3) + traitementCassetteForWarninngMinCassette($etatC4,$montantC4);
                                                // $total_montant= $montantC1 + $montantC2 + $montantC3 + $montantC4;
                                                $total_montant_traitement=30001;
                                                $total_montant=30001;
                                                /************************************/

                                                $datePriseEnCharge=date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y")));
                                                if ($id_action_interv==6 OR $id_action_interv==281 )
                                                {
                                                    if ($total_montant_traitement <=30000 OR $total_montant <=30000 )
                                                    {
                                                        /*****************/

                                                        /////////////////Ajouter incident  gab.
                                                        if ($stat_scrn_incid===0 || $purpose_input<>0)
                                                        {
                                                            if($purpose_input=="")
                                                            {
                                                                $purpose_input=0;
                                                            }
                                                            update_state_incident($purpose_input);
                                                        }
                                                        else
                                                        {
                                                            $purpose_input=0;
                                                            echo '<p class="alert alert-danger">'.$lang["inc_save_witout_sec"].'</p>';
                                                        }
                                                        $sql="INSERT INTO `new_incident_gab`(`id_incident`, `id_gab`, `date_arrete`,`date_prise_en_charge_contractuelle` , `date_prise_en_charge`, `date_remise`, `date_derniere_rappel`, `date_derniere_interv`,
                                                         `etat_incident`, `remarque_frss`, `remarque_press`,`rapport_technique_excel`,`id_indisponibilite`, `id_gab_sensible`, `cd_filiale`, `cd_banque` ,`cd_agence` , 
                                                         `cd_region`, `cd_prestataire`, `cd_fournisseur`, `cd_arret_fonctionnelle`,`cd_arret_technique`, `id_categories_fonctionnelle`,`id_categories_technique`,
                                                         `id_action_fonctionelle`, `id_niveau_fonctionelle`, `id_action_technique`, `id_niveau_technique`, `id_activation`, `id_strategiques`,`appelagence`,`last_Trans`,
                                                         montant_c1, montant_c2, montant_c3, montant_c4, etat_c1, etat_c2, etat_c3, etat_c4, etat_cas_rejet, etat_sep,	etat_lecteur, etat_journal, etat_pinpad, etat_epp, 	
                                                         etat_pc, last_event, last_inserv, last_event_date, up_last_Trans, if_chgmt_montant, m_c1_chgmt, m_c2_chgmt, m_c3_chgmt, m_c4_chgmt, s_c1_chgmt, s_c2_chgmt, s_c3_chgmt,s_c4_chgmt, `id_facturable`, `code_screenshot` )
                                                          VALUES ('','".mysqli_real_escape_string($connexion,trim($id_terminal))."','".mysqli_real_escape_string($connexion,trim($date_arret))."',
                                                          '".mysqli_real_escape_string($connexion,get_date_prise_charge_contractuel(trim($date_arret)))."','".mysqli_real_escape_string($connexion,trim($date_actuel))."',
                                                          '".mysqli_real_escape_string($connexion,trim($date_remis))."','".mysqli_real_escape_string($connexion,trim($date_rappel))."',
                                                          '".mysqli_real_escape_string($connexion,trim($date_arret))."','".mysqli_real_escape_string($connexion,trim($etat_incident))."',
                                                          '".mysqli_real_escape_string($connexion,addslashes($remarque))."','".mysqli_real_escape_string($connexion,addslashes($remarque))."',
                                                          '".mysqli_real_escape_string($connexion,$id_etat_export_technique)."','".mysqli_real_escape_string($connexion,get_etat_disponibilite_intervention($id_action_interv))."', 
                                                          '".mysqli_real_escape_string($connexion,get_gab_sensible(trim($id_terminal)))."',
                                                          '".mysqli_real_escape_string($connexion,get_code_filiale(trim($id_terminal)))."', '".mysqli_real_escape_string($connexion,get_id_banque(trim($id_terminal)))."',  
                                                          '".mysqli_real_escape_string($connexion,get_id_agence(trim($id_terminal)))."', 
                                                          '".mysqli_real_escape_string($connexion,get_id_region(trim($id_terminal)))."', '".mysqli_real_escape_string($connexion,get_code_prestataire(trim($id_terminal)))."',
                                                          '".mysqli_real_escape_string($connexion,get_code_fournisseur(trim($id_terminal)))."','".mysqli_real_escape_string($connexion,$type_arret[0])."',
                                                          '".mysqli_real_escape_string($connexion,$type_arret[1])."','".mysqli_real_escape_string($connexion,$idcategorie[0])."',
                                                          '".mysqli_real_escape_string($connexion,$idcategorie[1])."', '".mysqli_real_escape_string($connexion,$inter_fonc)."',
                                                          '".mysqli_real_escape_string($connexion,get_niveau_intervention_fonctionnelle($id_action_interv))."',
                                                          '".mysqli_real_escape_string($connexion,$inter_tech)."','".mysqli_real_escape_string($connexion,get_niveau_intervention_technique($id_action_interv))."',
                                                          '".mysqli_real_escape_string($connexion,get_etat_activation(trim($id_terminal)))."', '".mysqli_real_escape_string($connexion,get_etat_strategique(trim($id_terminal)))."',
                                                          '".mysqli_real_escape_string($connexion,$appelagence)."','".mysqli_real_escape_string($connexion,$LT)."','$montantC1',
                                                          '$montantC2','$montantC3','$montantC4','$etatC1','$etatC2','$etatC3','$etatC4','$etatCasRejet','$etatSep','$etatLecteur','$etatJournal','$etatPinpad','$etatEpp','$etatPC',
                                                          '$lastEvent','$lastInserv', '$lastEventDate','$uplastTransFirstArret', '$changeMontant','$m_c1', '$m_c2', '$m_c3', '$m_c4', '$s_c1', '$s_c2', '$s_c3', 
                                                          '$s_c4', '".mysqli_real_escape_string($connexion,getEtatFacturation($inter_fonc))."','".mysqli_real_escape_string($connexion,$purpose_input)."')";


                                                        $result=mysqli_query($connexion,$sql);
                                                        if (!$result)
                                                        {
                                                            error_log("Erreur sql 402:  ".$sql."   ".mysqli_error($connexion));
                                                            die('ERREUR QUERY 402 !');
                                                        }

                                                        /////////////////Séléctionner Id alerte
                                                        $last_id = mysqli_insert_id($connexion);

                                                        /**************///Insertion dans la table intermediare pour Incidents ouverts//////
                                                        $sql3="INSERT INTO new_incident_gab_ouvert (SELECT * FROM new_incident_gab WHERE  id_incident='".mysqli_real_escape_string($connexion,$last_id)."')";

                                                        $insertion=mysqli_query($connexion,$sql3);
                                                        if (!$insertion)
                                                        {
                                                            error_log("Erreur sql 403:  ".$sql3."   ".mysqli_error($connexion));
                                                            die('ERREUR QUERY 403 !');
                                                        }

                                                        /**************////////////////Ajouter Action intervention incident .
                                                        $sql4="INSERT INTO `new_intevention_incident`(`id_action_interv`, `id_incident`,`id_gab`, `date_action`,`date_prise_en_charge`,`date_prise_en_charge2`,`id_affectation`, `type_contact`, `etat_contact`, `personne_avisee`, `id_action_intervention`, `id_categories`,
                                                         `id_niveau_intervention`, `date_rappel`, `nbr_tentative`, `nbr_escalade`, `id_utilisateur`, `etat_cloture`, `remarque`, `note`, `degre_intervention`, `degre_appel`, `last_Trans`) 
                                                         VALUES (NULL,'".mysqli_real_escape_string($connexion,$last_id)."','".mysqli_real_escape_string($connexion,trim($id_terminal))."',
                                                         '".mysqli_real_escape_string($connexion,$date_actuel)."','".mysqli_real_escape_string($connexion,$date_actuel)."',
                                                         '".mysqli_real_escape_string($connexion,$date_actuel)."','".mysqli_real_escape_string($connexion,$id_affecter)."','Declaration',
                                                         '".mysqli_real_escape_string($connexion,$id_etat)."','".mysqli_real_escape_string($connexion,addslashes($persone_avise))."',
                                                         '".mysqli_real_escape_string($connexion,$id_action_interv)."','".mysqli_real_escape_string($connexion,get_categories_arret($id_action_interv))."', 
                                                         '".mysqli_real_escape_string($connexion,$id_niveau_interv)."',
                                                         '".mysqli_real_escape_string($connexion,$date_rappel)."','1', '1','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',
                                                         '".mysqli_real_escape_string($connexion,$etat_incident)."','','".mysqli_real_escape_string($connexion,addslashes($id_note))."','1','1','".mysqli_real_escape_string($connexion,$LT)."')";

                                                        $insertion2=mysqli_query($connexion,$sql4);
                                                        if (!$insertion2)
                                                        {
                                                            error_log("Erreur sql 404:  ".$sql4."   ".mysqli_error($connexion));
                                                            die('ERREUR QUERY 404 !');
                                                        }

                                                        $last_id_interv=mysqli_insert_id($connexion);
                                                        /**************////////////////Ajouter Action intervention incident table tempo.
                                                        $sql5="INSERT INTO `new_intevention_incident_tmp`(`id_action_interv`, `id_incident`,`id_gab`, `date_action`,`date_prise_en_charge`,`date_prise_en_charge2`,`id_affectation`, `type_contact`, `etat_contact`, `personne_avisee`, `id_action_intervention`, `id_categories`,
                                                         `id_niveau_intervention`, `date_rappel`, `nbr_tentative`, `nbr_escalade`, `id_utilisateur`, `etat_cloture`, `remarque`, `note`, `degre_intervention`, `degre_appel`, `last_Trans`) 
                                                         VALUES ('".mysqli_real_escape_string($connexion,$last_id_interv)."','".mysqli_real_escape_string($connexion,$last_id)."','".mysqli_real_escape_string($connexion,trim($id_terminal))."',
                                                         '".mysqli_real_escape_string($connexion,$date_actuel)."','".mysqli_real_escape_string($connexion,$date_actuel)."',
                                                         '".mysqli_real_escape_string($connexion,$date_actuel)."','".mysqli_real_escape_string($connexion,$id_affecter)."','Declaration',
                                                         '".mysqli_real_escape_string($connexion,$id_etat)."','".mysqli_real_escape_string($connexion,addslashes($persone_avise))."','".mysqli_real_escape_string($connexion,$id_action_interv)."',
                                                         '".mysqli_real_escape_string($connexion,get_categories_arret($id_action_interv))."', '".mysqli_real_escape_string($connexion,$id_niveau_interv)."',
                                                         '".mysqli_real_escape_string($connexion,$date_rappel)."','1', '1','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',
                                                         '".mysqli_real_escape_string($connexion,$etat_incident)."','','".mysqli_real_escape_string($connexion,addslashes($id_note))."','1','1','".mysqli_real_escape_string($connexion,$LT)."')";

                                                        $insertion4=mysqli_query($connexion,$sql5);
                                                        if (!$insertion4)
                                                        {
                                                            error_log("Erreur sql 405:  ".$sql5."   ".mysqli_error($connexion));
                                                            die('ERREUR QUERY 405 !');
                                                        }

                                                        /******************************************FIN DECLARATION***************************************************************************/

                                                        /******************************************Confirmation DECLARATION***************************************************************************/
                                                        $_POST['last_id']=$last_id;
                                                        get_detail_gab_declarer($_POST['num_terminal'],$_POST['last_id'],$lang);
                                                        /*****************/
                                                    }
                                                    else
                                                    {
                                                        echo "<div class='alert alert-danger' align='center' style='font-size:15px;font-weight:bold;'> ".$lang['inc_no_save_ver_mtn']." </strong></div>";
                                                    }

                                                }
                                                else
                                                {

                                                    if ($total_montant <=30000)
                                                    {
                                                        echo "<div class='alert alert-danger' align='center' style='font-size:15px;font-weight:bold;'> ".$lang['inc_no_save_inf_mtn']." </strong></div>";
                                                    }
                                                    else
                                                    {

                                                        if ($stat_scrn_incid===0 || $purpose_input<>0)
                                                        {
                                                            if($purpose_input=="")
                                                            {
                                                                $purpose_input=0;
                                                            }

                                                            update_state_incident($purpose_input);
                                                        }
                                                        else
                                                        {
                                                            $purpose_input=0;
                                                            echo '<p class="alert alert-danger">'.$lang["inc_save_witout_sec"].'</p>';
                                                        }
                                                        /*****************/
                                                        /////////////////Ajouter incident  gab.
                                                        $sql6="INSERT INTO `new_incident_gab`(`id_incident`, `id_gab`, `date_arrete`,`date_prise_en_charge_contractuelle` , `date_prise_en_charge`, `date_remise`, `date_derniere_rappel`, `date_derniere_interv`,
                                                         `etat_incident`, `remarque_frss`, `remarque_press`,`rapport_technique_excel`,`id_indisponibilite`, `id_gab_sensible`, `cd_filiale`, `cd_banque` ,`cd_agence` , 
                                                         `cd_region`, `cd_prestataire`, `cd_fournisseur`, `cd_arret_fonctionnelle`,`cd_arret_technique`, `id_categories_fonctionnelle`,`id_categories_technique`,
                                                         `id_action_fonctionelle`, `id_niveau_fonctionelle`, `id_action_technique`, `id_niveau_technique`, `id_activation`, `id_strategiques`,`appelagence`,`last_Trans`, montant_c1, montant_c2, montant_c3, montant_c4, etat_c1, etat_c2, etat_c3, etat_c4, etat_cas_rejet, etat_sep,	etat_lecteur, etat_journal, etat_pinpad, etat_epp, 	etat_pc, last_event, last_inserv, last_event_date, up_last_Trans, if_chgmt_montant, m_c1_chgmt, m_c2_chgmt, m_c3_chgmt, m_c4_chgmt, s_c1_chgmt, s_c2_chgmt, s_c3_chgmt,s_c4_chgmt, `id_facturable` , `code_screenshot` )
                                                          VALUES ('','".mysqli_real_escape_string($connexion,trim($id_terminal))."','".mysqli_real_escape_string($connexion,trim($date_arret))."',
                                                          '".mysqli_real_escape_string($connexion,get_date_prise_charge_contractuel(trim($date_arret)))."','".mysqli_real_escape_string($connexion,trim($datePriseEnCharge))."',
                                                          '".mysqli_real_escape_string($connexion,trim($date_remis))."',
                                                          '".mysqli_real_escape_string($connexion,trim($date_rappel))."','".mysqli_real_escape_string($connexion,trim($date_arret))."','".mysqli_real_escape_string($connexion,trim($etat_incident))."',
                                                          '".mysqli_real_escape_string($connexion,addslashes($remarque))."','".mysqli_real_escape_string($connexion,addslashes($remarque))."','".mysqli_real_escape_string($connexion,$id_etat_export_technique)."',
                                                          '".mysqli_real_escape_string($connexion,get_etat_disponibilite_intervention($id_action_interv))."', 
                                                          '".mysqli_real_escape_string($connexion,get_gab_sensible(trim($id_terminal)))."',
                                                          '".mysqli_real_escape_string($connexion,get_code_filiale(trim($id_terminal)))."', 
                                                          '".mysqli_real_escape_string($connexion,get_id_banque(trim($id_terminal)))."',  
                                                          '".mysqli_real_escape_string($connexion,get_id_agence(trim($id_terminal)))."', 
                                                          '".mysqli_real_escape_string($connexion,get_id_region(trim($id_terminal)))."', 
                                                          '".mysqli_real_escape_string($connexion,get_code_prestataire(trim($id_terminal)))."',
                                                          '".mysqli_real_escape_string($connexion,get_code_fournisseur(trim($id_terminal)))."',
                                                          '".mysqli_real_escape_string($connexion,$type_arret[0])."','".mysqli_real_escape_string($connexion,$type_arret[1])."',
                                                          '".mysqli_real_escape_string($connexion,$idcategorie[0])."',
                                                          '".mysqli_real_escape_string($connexion,$idcategorie[1])."',
                                                          '".mysqli_real_escape_string($connexion,$inter_fonc)."',
                                                          '".mysqli_real_escape_string($connexion,get_niveau_intervention_fonctionnelle($id_action_interv))."',
                                                          '".mysqli_real_escape_string($connexion,$inter_tech)."',
                                                          '".mysqli_real_escape_string($connexion,get_niveau_intervention_technique($id_action_interv))."',
                                                          '".mysqli_real_escape_string($connexion,get_etat_activation(trim($id_terminal)))."', 
                                                          '".mysqli_real_escape_string($connexion,get_etat_strategique(trim($id_terminal)))."',
                                                          '".mysqli_real_escape_string($connexion,$appelagence)."',
                                                          '".mysqli_real_escape_string($connexion,$LT)."','$montantC1','$montantC2','$montantC3','$montantC4','$etatC1','$etatC2','$etatC3','$etatC4','$etatCasRejet','$etatSep','$etatLecteur','$etatJournal','$etatPinpad','$etatEpp','$etatPC','$lastEvent','$lastInserv', '$lastEventDate','$uplastTransFirstArret', '$changeMontant','$m_c1', '$m_c2', '$m_c3', '$m_c4', '$s_c1', '$s_c2', '$s_c3', '$s_c4', '".getEtatFacturation($inter_fonc)."','".mysqli_real_escape_string($connexion,$purpose_input)."')";
                                                        $resultDeclar1=mysqli_query($connexion,$sql6);
                                                        if (!$resultDeclar1)
                                                        {
                                                            error_log("Erreur sql 406:  ".$sql6."   ".mysqli_error($connexion));
                                                            die('ERREUR QUERY 406 !');
                                                        }
                                                        /////////////////Séléctionner Id alerte
                                                        $last_id = MaxIdIncident("id_incident","new_incident_gab");
                                                        /**************///Insertion dans la table intermediare pour Incidents ouverts//////
                                                        $sql7="INSERT INTO new_incident_gab_ouvert (SELECT * FROM new_incident_gab WHERE  id_incident='".$last_id."')";
                                                        $insertion7=mysqli_query($connexion,$sql7);
                                                        if (!$insertion7)
                                                        {
                                                            error_log("Erreur sql 407:  ".$sql7."   ".mysqli_error($connexion));
                                                            die('ERREUR QUERY 407 !'.$sql7);
                                                        }
                                                        /**************////////////////Ajouter Action intervention incident .
                                                        $sql8="INSERT INTO `new_intevention_incident`(`id_action_interv`, `id_incident`,`id_gab`, `date_action`,`date_prise_en_charge`,`date_prise_en_charge2`,`id_affectation`, `type_contact`, `etat_contact`, `personne_avisee`, `id_action_intervention`, `id_categories`,
                                                         `id_niveau_intervention`, `date_rappel`, `nbr_tentative`, `nbr_escalade`, `id_utilisateur`, `etat_cloture`, `remarque`, `note`, `degre_intervention`, `degre_appel`, `last_Trans`) 
                                                         VALUES (NULL,'".mysqli_real_escape_string($connexion,$last_id)."','".mysqli_real_escape_string($connexion,trim($id_terminal))."',
                                                         '".mysqli_real_escape_string($connexion,$date_actuel)."','".mysqli_real_escape_string($connexion,$date_actuel)."',
                                                         '".mysqli_real_escape_string($connexion,$date_actuel)."',
                                                         '".mysqli_real_escape_string($connexion,$id_affecter)."','Declaration','".mysqli_real_escape_string($connexion,$id_etat)."',
                                                         '".mysqli_real_escape_string($connexion,addslashes($persone_avise))."','".mysqli_real_escape_string($connexion,$id_action_interv)."',
                                                         '".mysqli_real_escape_string($connexion,get_categories_arret($id_action_interv))."', 
                                                         '".mysqli_real_escape_string($connexion,$id_niveau_interv)."',
                                                         '".mysqli_real_escape_string($connexion,$date_rappel)."','1', '1','".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."',
                                                         '".mysqli_real_escape_string($connexion,$etat_incident)."','','".mysqli_real_escape_string($connexion,addslashes($id_note))."','1','1',
                                                         '".mysqli_real_escape_string($connexion,$LT)."')";

                                                        $insertion8=mysqli_query($connexion,$sql8);
                                                        if (!$insertion8)
                                                        {
                                                            error_log("Erreur sql 408:  ".$sql8."   ".mysqli_error($connexion));
                                                            die('ERREUR QUERY 408 !');
                                                        }

                                                        $last_id_interv=MaxIdIncident("id_action_interv","new_intevention_incident");



                                                        /**************////////////////Ajouter Action intervention incident table tempo.
                                                        $sql3="INSERT INTO `new_intevention_incident_tmp`(`id_action_interv`, `id_incident`,`id_gab`, `date_action`,`date_prise_en_charge`,`date_prise_en_charge2`,`id_affectation`, `type_contact`, `etat_contact`, `personne_avisee`, `id_action_intervention`, `id_categories`,
                                                         `id_niveau_intervention`, `date_rappel`, `nbr_tentative`, `nbr_escalade`, `id_utilisateur`, `etat_cloture`, `remarque`, `note`, `degre_intervention`, `degre_appel`, `last_Trans`) 
                                                         VALUES ('".mysqli_real_escape_string($connexion,$last_id_interv)."','".mysqli_real_escape_string($connexion,$last_id)."',
                                                         '".mysqli_real_escape_string($connexion,trim($id_terminal))."',
                                                         '".mysqli_real_escape_string($connexion,$date_actuel)."','".mysqli_real_escape_string($connexion,$date_actuel)."',
                                                         '".mysqli_real_escape_string($connexion,$date_actuel)."','".mysqli_real_escape_string($connexion,$id_affecter)."','Declaration',
                                                         '".mysqli_real_escape_string($connexion,$id_etat)."','".mysqli_real_escape_string($connexion,addslashes($persone_avise))."',
                                                         '".mysqli_real_escape_string($connexion,$id_action_interv)."','".mysqli_real_escape_string($connexion,get_categories_arret($id_action_interv))."', 
                                                         '".mysqli_real_escape_string($connexion,$id_niveau_interv)."',
                                                         '".mysqli_real_escape_string($connexion,$date_rappel)."','1', '1',
                                                         '".mysqli_real_escape_string($connexion,$_SESSION['id_utilisateur'])."','".mysqli_real_escape_string($connexion,$etat_incident)."','',
                                                         '".mysqli_real_escape_string($connexion,addslashes($id_note))."','1','1','".mysqli_real_escape_string($connexion,$LT)."')";
                                                        // $sqltempo=mysqli_query(ma_db_connexion(),$sql3) or die('Erreur sql  Action intervention incident tempo!<br>'.$sql3.'<br>'.mysqli_error());

                                                        mysqli_free_result($insertion);
                                                        // mysqli_free_result($sqltempo);
                                                        mysqli_free_result($resultDeclar2);
                                                        mysqli_free_result($resultDeclar1);


                                                        /******************************************FIN DECLARATION***************************************************************************/

                                                        /********************************FLAG LIST ATM STOPPED ********************************************************/
                                                        if($id_arret<>0)
                                                        {
                                                            $sqlUP=" UPDATE atm_list_stopped_test_test SET if_declared=1,id_incident=".$last_id." WHERE id_insert= ".mysqli_real_escape_string($connexion,$id_arret)."  ";

                                                            $resultUP=mysqli_query($connexion,$sqlUP);
                                                            if (!$resultUP)
                                                            {
                                                                error_log("Erreur sql 488:  ".$sqlUP."   ".mysqli_error($connexion));
                                                                die('ERREUR QUERY 488 !');
                                                            }
                                                        }
                                                        /******************************************Confirmation DECLARATION***************************************************************************/
                                                        $_POST['last_id']=$last_id;
                                                        // echo "<br>ID DETAIL INCIDENT ".$_POST['last_id']."<br>";
                                                        get_detail_gab_declarer($_POST['num_terminal'],$_POST['last_id'],$lang);
                                                        /**********************************************************************************************************************************************/




                                                    }
                                                }
                                            }
                                            else if( ($tabDate['error_count'] <> 0) OR ($tabDate['warning_count'] <> 0) )
                                            {
                                                echo "<div class='alert alert-danger' align='center' style='font-size:15px;font-weight:bold;'> ".$lang['inc_no_save_for_date']." </strong></div>";
                                            }
                                            else if( strtotime($date_arret) > strtotime($date_actuel))
                                            {
                                                echo $lang['date_acc']. " ".$date_actuel."<br>";
                                                echo $lang['stop_date']. " ".$date_arret."<br>";

                                                echo "<div class='alert alert-danger' align='center' style='font-size:15px;font-weight:bold;'> ".$lang['inc_no_save_ver_date']."</strong></div>";
                                            }


                                            else
                                            {
                                                echo "<div class='alert alert-danger' align='center' style='font-size:15px;font-weight:bold;'> ".$lang['inc_no_save_ver_data']."</strong></div>";
                                            }
                                        }
                                    }
                                    else
                                    {
                                        echo '<div class="alert alert-danger" align="center" style="font-size:15px;font-weight:bold;"> '.$lang['inc_no_save_gab_read'].'</strong></div>';
                                        while ($incid= mysqli_fetch_assoc($control))
                                        {
                                            $id_inci = $incid["id_incident"];
                                        }
                                    }


                                    mysqli_free_result($control);
                                }
                            }


                            ?>
                        </div>
                    </div>
                </main>
            </div>

        </div>
        <?php

        //header NAV Bar
        include 'footer.php';

        ?>



        </body>

    <?php
    else:
        header("location: start.php");
    endif ?>
<?php
else:
    header("location: index.php");
endif ?>
</html>
