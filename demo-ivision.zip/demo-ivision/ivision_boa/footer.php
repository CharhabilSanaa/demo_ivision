<?php
if (!empty($_SESSION['user']) && !empty($_SESSION['mdp']))
{
?>

<!-- jQuery -->

    <script src="vendors/jquery/jquery.min.js"></script>




    <script src="vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
    <!--[if IE]><!-->
    <script src="vendors/@coreui/icons/js/svgxuse.min.js"></script>
    <!--<![endif]-->
    <!-- Plugins and scripts required by this view-->
    <script src="vendors/@coreui/chartjs/js/coreui-chartjs.bundle.js"></script>
    <script src="vendors/@coreui/utils/js/coreui-utils.js"></script>
    <!--<script src="js/main.js"></script>-->

    <script src="vendors/bootstrap/js/bootstrap-select.js"></script>
    <script src="vendors/fullcalendar/scripts/script.js"></script>
    <script src="js/ajax.js"></script>
    <script src="js/ajaxAchraf.js"></script>
    <script src="js/ajaxKamar.js"></script>
    <script src="js/searchAutoAjax.js"></script>
    <script src="vendors/bootstrap/dataTables/js/jquery.dataTables.min.js" type="text/javascript" charset="utf8" ></script>
    <script src="vendors/bootstrap/dataTables/js/dataTables.buttons.min.js" type="text/javascript" charset="utf8" ></script>
    <script src="vendors/bootstrap/dataTables/js/buttons.colVis.min.js" type="text/javascript" charset="utf8" ></script>
    <script src="vendors/bootstrap/dataTables/js/dataTables.bootstrap4.min.js" type="text/javascript" charset="utf8" ></script>

<?php

}
else
{
    header('Location: index.php');
}

?>	
	