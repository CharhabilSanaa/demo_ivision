<?php

//a donner comme paramertes un table soit key values soit deux tableaux
function return_code_html_map(){

    $map_html="<script src='./node_modules/echarts/dist/echarts.min.js'></script>
    <script src='./node_modules/jquery/dist/jquery.min.js'></script>
    <style>
        body {
        background-color: #fff;
        color: #000;
    }
    
    a:link, a:visited {
        color: #4682b4;
    }
    
    a:hover {
        color: #4169e1;
    }
    
    #main	{
        width: 800px;
        height: 600px;
        margin: auto;
  width: 50%;
  /*border: 1px solid lightgray;*/
  padding: 10px;
    }
    </style>
    <head>
        <meta http-equiv='Content-Type' content='text/html; charset=UTF-8' /></head>
    <div id='main'>
    </div>
    
    <script>
    
    var myChart = echarts.init(document.getElementById('main'));
    
    // Specify configurations and data graphs 
    myChart.showLoading();
    
    $.get('./node_modules/maroc.geojson', function (MAJson) {
    myChart.hideLoading();
    
    echarts.registerMap('Morocco', MAJson, {});
    option = {
    
    title : {
        text: 'Répartition des incidents par région',
        left: 'right'
    },
    
    tooltip : {
        trigger: 'item',
        showDelay: 0,
        transitionDuration: 0.2,
        formatter : function (params) {
            var value = (params.value + '').split('.');
            value = value[0].replace(/(\d{1,3})(?=(?:\d{3})+(?!\d))/g, '$1,');
            return params.name + ' : ' + value;
        }
    },
    visualMap: {
        left: 'right',
        min: 500000,
        max: 38000000,
        color: ['orangered','yellow','lightskyblue'],
        text:['High','Low'],          
        calculable : true
    },
    toolbox: {
        show : true,
        //orient : 'vertical',
        left: 'left',
        top: 'top',
        feature : {
            mark : {show: true},
            dataView : {show: true, readOnly: true},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
    series : [
        {
            name: 'Maroc Map',
            type: 'map',
            roam: true,
            map: 'Morocco',
            itemStyle:{
                emphasis:{label:{show:true}}
            },
            textFixed : {
                Alaska : [20, -20]
            },
            data:[
                {name : 'Laayoune-Saguia Hamra', value : 4822023},
                {name : 'Rabat-Sale-Kenitra', value : 731449},
                {name : 'Beni Mellal-Khenifra', value : 6553255},
                {name : 'Dakhla-Oued Eddahab', value : 2949131},
                {name : 'Tanger-Tetouan-Hoceima', value : 38041430},
                {name : 'Marrakech-Safi', value : 5187582},
                {name : 'Daraa-Tafilelt', value : 3590347},
                {name : 'Guelmim-Oued Noun', value : 917092},
                {name : 'Fes-Meknes', value : 632323},
                {name : 'Oriental', value : 19317568},
                {name : 'Casablanca-Settat', value : 9919945},
                {name : 'Souss Massa', value : 1392313},
              
            ]
        }
    ]
    };
    
    myChart.setOption(option);
    });
    </script>";

return $map_html;


}





?>