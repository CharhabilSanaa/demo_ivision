<?php
include "lib/auth/config.php";

?>
<!DOCTYPE html>
<html lang="<?php echo $lang['lang'];?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php include 'header_star.php'; ?>

</head>
<?php

if (verif_user($_SESSION['user'],$_SESSION['mdp'])==true): ?>
    <?php if ((verif_user($_SESSION['user'],$_SESSION['mdp'])==true) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true))): ?>

        <?php
        $profil =0;
        ?>

        <body class="c-app">

        <?php
        include 'sidebar.php';

        ?>
        <div class="c-wrapper c-fixed-components">
            <?php  include 'navbar_star.php'; ?>
            <div class="c-body">
                <main class="c-main">
                    <div class="container-fluid">
                        <div class="fade-in">
                            <input type="hidden" id="hdnSession" data-value="21"/>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="start.php">I-Vision</a></li>
                                    <li class="breadcrumb-item"><a href="start.php"><?php echo $lang['administrate'];?></a></li>
                                    <li class="breadcrumb-item" aria-current="page"><?php echo $lang['suiv_vers'];?></li>
                                </ol>
                            </nav>



                            <div class="row" id="form_upload_image_prof_2">
                                <div class="col-lg-12">
                                    <div class="card">

                                        <div class="card-header"><i class="fa fa-align-justify"></i> <?php echo $lang['suiv_vers_cli'];?> :</div>
                                        <div class="card-body">
                                            <form id="form_upload_image_prof" enctype="multipart/form-data" >
                                                <div class="row" style="padding-left:10px">

                                                    <?php
                                                    if ((verif_habilitation($_SESSION['habilitation_backoffice'],37)==true)):
                                                        get_list_atm_suivi_client();
                                                    else:
                                                        echo '<p class="alert alert-danger"> PAGE UNAUTHORIZED !!</p>';
                                                    endif
                                                    ?>

                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.col-lg-4 (nested) -->

                                <!-- /.col-lg-8 (nested) -->
                            </div>

                        </div>
                    </div>
                </main>
            </div>

        </div>

        <?php

        //header NAV Bar
        include 'footer.php';

        ?>



        </body>

    <?php
    else:
        header("location: start.php");
    endif ?>
<?php
else:
    header("location: index.php");
endif ?>
</html>
