<?php
include "lib/auth/config.php";

?>
<!DOCTYPE html>
<html lang="<?php echo $lang['lang'];?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php include 'header_star.php'; ?>
    <style type="text/css">
        div.dataTables_wrapper  div.dataTables_filter {
            width: 100%;
            float: none;
            text-align: right;
    </style>
</head>
<?php

if (verif_user($_SESSION['user'],$_SESSION['mdp'])==true): ?>
    <?php if ((verif_user($_SESSION['user'],$_SESSION['mdp'])==true) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true))): ?>

        <?php
        if(empty($_GET['idATM'])){$idATM="";}
        if(empty($_GET['date_vacation'])){$_GET['date_vacation']="";}

       // $date_vacation = (new DateTime($_GET['date_vacation']))->format('c');
        $date_vacation = date('Y-m-d\TH:i', strtotime($_GET['date_vacation']));



        if(empty($_POST['date_debut'])){$_POST['date_debut']='';}else{$_GET['date_debut']=$_POST['date_debut'];}
        if(empty($_POST['date_fin'])){$_POST['date_fin']='';}else{$_GET['date_fin']=$_POST['date_fin'];}

        if(!empty($_GET['date_debut'])){$_POST['date_debut']=$_GET['date_debut'];}
        if(!empty($_GET['date_fin'])){$_POST['date_fin']=$_GET['date_fin'];}


        if(empty($_POST['historique_vacation'])){$_POST['historique_vacation']='';}
        $val=get_name_terminal_gag($_GET['idATM']);
        ?>

        <body class="c-app">

        <?php
        include 'sidebar.php';

        ?>
        <div class="c-wrapper c-fixed-components">
            <?php  include 'navbar_star.php'; ?>
            <div class="c-body">
                <main class="c-main">
                    <div class="container-fluid">
                        <div class="fade-in">
                            <input type="hidden" id="hdnSession" data-value="1"/>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="start.php">I-Vision</a></li>
                                    <li class="breadcrumb-item" aria-current="page"><?php echo $lang['dev_stat_hist'];?></li>
                                </ol>
                            </nav>

                            <?php
                            if ((verif_habilitation($_SESSION['habilitation_backoffice'],1)==true)):
                            ?>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <form action="" method="post">
                                                <div class="row d-flex justify-content-between">

                                                    <div class="col-md-4 search-box">
                                                        <input type="datetime-local" lang="en" id="date_debut" name="date_debut" value="<?php if ($_POST['date_debut']==""){ echo $date_vacation;}else{echo $_POST['date_debut'];} ?>" class="form-control required" placeholder="Date début" required>
                                                    </div>

                                                    <div class="col-md-4 search-box">
                                                        <input type="datetime-local" lang="en" id="date_fin" name="date_fin" value="<?php if ($_POST['date_fin']==""){ echo $date_vacation;}else{echo $_POST['date_fin'];} ?>"  class="form-control required" placeholder="Date début" required>
                                                    </div>

                                                    <div class="col-md-2 search-box">

                                                    </div>
                                                    <div class="col-md-2 search-box">
                                                        <button class="btn btn-block btn-outline-primary my-2 my-sm-0" type="submit"><?php echo $lang['search'];  ?>
                                                            <svg class="c-icon float-right">
                                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-cloud-upload"></use>
                                                            </svg>
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row" >
                                <div class="col-lg-12">
                                    <div class="card">

                                        <div class="card-header"><i class="fa fa-align-justify"></i> <?php echo $lang['dev_stat_hist'];?> : <?php echo $_GET['idATM']?> - <?php echo $val[0]?> - <?php echo $val[1]?> </div>
                                        <div id="div_etat_parc" class="card-body">
                                            <?php
                                            if((strlen(antixss($_GET['idATM']))>=0) && (strlen(antixss($_GET['idATM']))<=10) )
                                            {

                                                if((strtotime($_POST['date_fin']) >= strtotime($_POST['date_debut'])))
                                                {
                                                    if((!empty($_GET['date_vacation']))&&(empty($_POST['date_fin'])))
                                                    {
                                                        $_POST['date_debut']=$_GET['date_vacation'];$_POST['date_fin']=$_GET['date_vacation'];
                                                    }
                                                    else
                                                    {
                                                        $_POST['date_debut']=$_POST['date_debut'];$_POST['date_fin']=$_POST['date_fin'];
                                                    }
                                                    include("pagination.php");
                                                    $idatm=htmlspecialchars(mysqli_real_escape_string(ma_db_connexion(),$_GET['idATM']));
                                                    if(!empty($idatm)){getHistoriqueEtatParcATM($idatm,1,0,$_POST['date_debut'],$_POST['date_fin']);}
                                                }
                                            }
                                            ?>



                                        </div>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <?php
                                else:
                                    echo '<div class="alert alert-danger text-center" role="alert">PAGE UNAUTHORIZED !!</div>';
                                endif
                                ?>
                                <!-- /.col-lg-4 (nested) -->

                                <!-- /.col-lg-8 (nested) -->
                            </div>

                        </div>
                    </div>
                </main>
            </div>

        </div>

        <?php

        //header NAV Bar
        include 'footer.php';

        ?>



        </body>

    <?php
    else:
        header("location: start.php");
    endif ?>
<?php
else:
    header("location: index.php");
endif ?>
</html>
