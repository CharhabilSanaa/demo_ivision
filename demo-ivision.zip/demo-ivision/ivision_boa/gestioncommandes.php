<?php
include "lib/auth/config.php";

?>
<!DOCTYPE html>
<html lang="<?php echo $lang['lang'];?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php include 'header_star.php'; ?>

</head>
<?php

if (verif_user($_SESSION['user'],$_SESSION['mdp'])==true): ?>
    <?php if ((verif_user($_SESSION['user'],$_SESSION['mdp'])==true) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true))): ?>

        <?php
        $profil =0;
        ?>

        <body class="c-app">

        <?php
        include 'sidebar.php';

        ?>
        <div class="c-wrapper c-fixed-components">
            <?php  include 'navbar_star.php'; ?>
            <div class="c-body">
                <main class="c-main">
                    <div class="container-fluid">
                        <div class="fade-in">
                            <input type="hidden" id="hdnSession" data-value="21"/>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="start.php">I-Vision</a></li>
                                    <li class="breadcrumb-item"><a href="start.php"><?php echo $lang['administrate'];?></a></li>
                                    <li class="breadcrumb-item" aria-current="page"><?php echo $lang['gest_cmd'];?></li>
                                </ol>
                            </nav>

                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <form id="form_upload_image_prof" enctype="multipart/form-data">
                                                <div class="row d-flex justify-content-between">
                                                    <div class="col-md-4 search-box ">
                                                        <label for="type_commande" class="control-label"><?php echo $lang['type_cmd'];?> : </label>
                                                        <select id="type_commande[]" class="form-control"  onchange="javascript:show()"  required>
                                                        <?php get_select_commande();?>
                                                        </select>
                                                    </div>

                                                    <div class="col-md-4 search-box ">
                                                        <label for="profil[]" class="control-label"><?php echo $lang['atm_profil'];?> : </label>
                                                        <?php
                                                        echo '<select id="profil[]" class="form-control"  onchange="javascript:get_bianire_profil_for_commande(\''.$profil.'\')" required> ';
                                                            get_select_profile();?>
                                                            <option value="2">All</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3 search-box " >
                                                        <div id="pathconfig" style="display: none;">
                                                            <label for="type_commande" class="control-label"><?php echo $lang['config_value'];?> : </label>
                                                            <input  type="text" id="pathconfig22" name="pathconfig" class="form-control"  required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-1 search-box">
                                                        <label for="type_commande" class="control-label"> &nbsp;</label>
                                                        <button class="btn btn-block btn-outline-primary my-2 my-sm-0" type="button" onclick="javascript:getSendCommand()"><?php echo $lang['send'];  ?>
                                                            <svg class="c-icon float-right">
                                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-cloud-upload"></use>
                                                            </svg>
                                                        </button>
                                                    </div>
                                                    <div></div>
                                                    <div></div>
                                                    <div></div>

                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row" id="form_upload_image_prof_2">
                                <div class="col-lg-12">
                                    <div class="card">

                                        <div class="card-header"><i class="fa fa-align-justify"></i> <?php echo $lang['gest_cmd'];?></div>
                                        <div class="card-body">
                                            <?php

                                            if ((verif_habilitation($_SESSION['habilitation_backoffice'],21)==true)):
                                                include("pagination.php");
                                                get_bianire_profil_for_commande($profil);
                                            else:
                                                echo '<div class="alert alert-danger text-center" role="alert">PAGE UNAUTHORIZED !!</div>';
                                            endif
                                            ?>

                                        </div>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.col-lg-4 (nested) -->

                                <!-- /.col-lg-8 (nested) -->
                            </div>

                        </div>
                    </div>
                </main>
            </div>

        </div>

        <?php

        //header NAV Bar
        include 'footer.php';

        ?>



        </body>

    <?php
    else:
        header("location: start.php");
    endif ?>
<?php
else:
    header("location: index.php");
endif ?>
</html>
