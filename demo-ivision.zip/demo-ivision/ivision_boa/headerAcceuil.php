

<!-- Main styles for this application-->
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="img/Logo noir 110.ico" />
<link rel="stylesheet" href="vendors/@coreui/dist/css/coreui.min.css">

<!-- Global site tag (gtag.js) - Google Analytics-->

<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    // Shared ID
    gtag('config', 'UA-118965717-3');
    // Bootstrap ID
    gtag('config', 'UA-118965717-5');
</script>
<!--<script type="text/javascript">
    var userLang = navigator.language || navigator.userLanguage;
    alert ("The language is: " + userLang);
</script>-->


