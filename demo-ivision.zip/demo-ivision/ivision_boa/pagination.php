<?php

// include("lib/connexion.php");

class Pagination
{
  var $querry;
  var $totallignes;
  var $pagecourant;
  var $totalpage;
  var $lignesparpage;
  var $nompage;
  var $style_texte;

  function __construct($query, $maxligne, $compt = '*', $page = 'page')
  {
    global $_GET, $_POST;

    $this->querry = $query;
    $this->nompage = $page;

    if (isset($_GET[$page])) {
      $page = $_GET[$page];
    } elseif (isset($_POST[$page])) {
      $page = $_POST[$page];
    } else {
      $page = '';
    }

    if (empty($page) || !is_numeric($page)) $page = 1;
    $this->pagecourant = $page;

    $this->lignesparpage = $maxligne;
    // $queryLwr = ($this->querry);
    $queryLwr = strtolower($this->querry);

    $union_pos = strpos($queryLwr, 'union', 0);

    if($union_pos)
      $posTo = $union_pos;
    else
      $posTo = strlen($this->querry);

    $posFrom = strpos($queryLwr, ' from', 0);
    $posGroupBy = strpos($queryLwr, ' group by', $posFrom);
    if (($posGroupBy < $posTo) && ($posGroupBy != false)) $posTo = $posGroupBy;

    $posHaving = strpos($queryLwr, ' having', $posFrom);
    if (($posHaving < $posTo) && ($posHaving != false)) $posTo = $posHaving;

    $posOrderBy = strpos($queryLwr, ' order by', $posFrom);
    if (($posOrderBy < $posTo) && ($posOrderBy != false)) $posTo = $posOrderBy;

    if (strpos($queryLwr, 'distinct') || strpos($queryLwr, 'group by')) {
      $strCount = 'distinct ' . $compt;
    } else {
      $strCount = $compt;
    }


    $connexion=ma_db_connexion();
    $query11="select count(" . $strCount . ") as total " . substr($queryLwr, $posFrom, ($posTo - $posFrom)) ;
    $qry = mysqli_query($connexion,$query11);

    if (!$qry)
    {
      error_log("Erreur sql 7777:  ".$query11."   ".mysqli_error($connexion));
      die('ERREUR QUERY 7777 !'.$query11);
    }
    //$qry = mysqli_query($connexion,"select count(" . $strCount . ") as total " . substr($queryLwr, $posFrom, ($posTo - $posFrom)));
    $obj = mysqli_fetch_object($qry);
    $count = $obj->total;

    if($posLimit =  strpos($queryLwr, ' limit'))
    {
      $this->_query = substr($this->querry, 0, $posLimit);
      $this->totallignes = substr($query, $posLimit + 7);
    }
    else
    {
      $this->totallignes = $count;
    }

    if($this->totallignes > $count)
      $this->totallignes = $count;

    if (($posOrderBy < $posTo) && ($posOrderBy != false)) $posTo = $posOrderBy;

    if($union_pos)
    {
      $posTo = strlen($this->querry);
      $posFrom = strpos($queryLwr, ' from', $union_pos);
      $posGroupBy = strpos($queryLwr, ' group by', $posFrom);
      if (($posGroupBy < $posTo) && ($posGroupBy != false)) $posTo = $posGroupBy;

      $posHaving = strpos($queryLwr, ' having', $posFrom);
      if (($posHaving < $posTo) && ($posHaving != false)) $posTo = $posHaving;

      $posOrderBy = strpos($queryLwr, ' order by', $posFrom);
      if (($posOrderBy < $posTo) && ($posOrderBy != false)) $posTo = $posOrderBy;

      if (strpos($queryLwr, 'distinct') || strpos($queryLwr, 'group by')) {
        $strCount = 'distinct ' . $compt;
      } else {
        $strCount = $compt;
      }

      $sqlqry="select count(" . $strCount . ") as total2 " . substr($queryLwr, $posFrom, ($posTo - $posFrom));
      $qry = mysqli_query(ma_db_connexion(),$sqlqry);

      $count2 = mysqli_num_rows($qry);

      $this->totallignes += $count2->total2;
    }

    $this->totalpage = ceil($this->totallignes / $this->lignesparpage);

    if ($this->pagecourant > $this->totalpage) {
      $this->pagecourant = $this->totalpage;
    }

    $offset = ($this->lignesparpage * ($this->pagecourant - 1));

    if($offset < 0) $offset = 0;

    $this->querry .= " limit " . $offset . ", " . $this->lignesparpage;
  }
  function liens($maxPageLinks, $parameters = '') {
    global $PHP_SELF, $request_type;

    $strLinks = '';

    if($this->totallignes <= 0)
      return '&nbsp;';

    $class = 'class="' . $this->style_texte . '"';
    if (trim($parameters) == '' || (substr($parameters, -1) != '&')) $parameters .= '';
    if ($this->pagecourant > 1)
      $strLinks .= '<li class="page-item"><a class="page-link" href="' . basename($PHP_SELF) . '?' . $parameters . $this->nompage . '=' . ($this->pagecourant - 1) . '">&laquo; Previous</a></li>';
    else
      $strLinks .= '<li class="page-item disabled"><a class="page-link"tabindex="-1">&laquo; Previous</a></li>';
    $curWindowNum = intval($this->pagecourant / $maxPageLinks);
    if ($this->pagecourant % $maxPageLinks) $curWindowNum++;
    $maxWindowNum = intval($this->totalpage / $maxPageLinks);
    if ($this->totalpage % $maxPageLinks) $maxWindowNum++;
    if ($curWindowNum > 1)
      $strLinks .= ' <li class="page-item"><a class="page-link" href="' . (basename($PHP_SELF) . '?' . $parameters . $this->nompage . '=' . (($curWindowNum - 1) * $maxPageLinks)) .  '">...</a></li>';
    for ($jumpToPage = 1 + (($curWindowNum - 1) * $maxPageLinks); ($jumpToPage <= ($curWindowNum * $maxPageLinks)) && ($jumpToPage <= $this->totalpage); $jumpToPage++) {
      if ($jumpToPage == $this->pagecourant) {
        $strLinks .= '<li class="page-item disabled"><a class="page-link"tabindex="-1">' . $jumpToPage . '</a></li>';
      } else {
        $strLinks .= '<li class="page-item"><a class="page-link" href="' . (basename($PHP_SELF) . '?' . $parameters . $this->nompage . '=' . $jumpToPage .'">'.  $jumpToPage) . '</a></li>';
      }
    }
    if ($curWindowNum < $maxWindowNum)
      $strLinks .= '<li class="page-item"><a class="page-link"href="' . (basename($PHP_SELF) . '?' . $parameters . $this->nompage . '=' . (($curWindowNum) * $maxPageLinks + 1)) . '">...</a></li>';
    if (($this->pagecourant < $this->totalpage) && ($this->totalpage != 1))
      $strLinks .= '<li class="page-item"><a class="page-link" href="' . (basename($PHP_SELF) . '?' . $parameters . $this->nompage . '=' . ($this->pagecourant + 1)) . '">Next &raquo;</a></li>';
    else
      $strLinks .= '<li class="page-item disabled"><a class="page-link"tabindex="-1">Next &raquo;</a></li>';

    return $strLinks;
  }

  function constructPaginate($maxPageLinks, $parameters = '', $idAtm,$terminalID,$Dated, $Datef,$Idev,$Idev2,$Idev3) {
    global $PHP_SELF, $request_type;

    $strLinks = '';

    if($this->totallignes <= 0)
      return '&nbsp;';

    $class = 'class="' . $this->style_texte . '"';
    if (trim($parameters) == '' || (substr($parameters, -1) != '&')) $parameters .= '';
    if ($this->pagecourant > 1)
      $strLinks .= '<li class="page-item page-link apage" data-id_atm="'.$idAtm.'" data-terminalID="'.$terminalID.'" data-dated="'.$Dated.'" data-datef="'.$Datef.'" data-idev="'.$Idev.'" data-idev2="'.$Idev2.'" data-idev3="'.$Idev3.'" data-page="'   . ($this->pagecourant - 1)  .'">&laquo;&nbsp;Previous</li>';
    else
      $strLinks .= '<li class="page-item page-link disabled">&laquo;Previous</li>&nbsp;';
    $curWindowNum = intval($this->pagecourant / $maxPageLinks);
    if ($this->pagecourant % $maxPageLinks) $curWindowNum++;
    $maxWindowNum = intval($this->totalpage / $maxPageLinks);
    if ($this->totalpage % $maxPageLinks) $maxWindowNum++;
    if ($curWindowNum > 1)
      $strLinks .= ' &nbsp;&nbsp;<li class="page-item page-link apage" data-id_atm="'.$idAtm.'" data-terminalID="'.$terminalID.'" data-dated="'.$Dated.'" data-datef="'.$Datef.'" data-idev="'.$Idev.'" data-idev2="'.$Idev2.'" data-idev3="'.$Idev3.'" data-page="'. (($curWindowNum - 1) * $maxPageLinks) .  '">...</li>&nbsp;&nbsp;';
    for ($jumpToPage = 1 + (($curWindowNum - 1) * $maxPageLinks); ($jumpToPage <= ($curWindowNum * $maxPageLinks)) && ($jumpToPage <= $this->totalpage); $jumpToPage++) {
      if ($jumpToPage == $this->pagecourant) {
        $strLinks .= '&nbsp;<li class="page-item page-link disabled">' . $jumpToPage . '</li>&nbsp;';
      } else {
        $strLinks .= '&nbsp;' . '<li  class="page-item page-link apage" data-id_atm="'.$idAtm.'" data-terminalID="'.$terminalID.'" data-dated="'.$Dated.'" data-datef="'.$Datef.'" data-idev="'.$Idev.'" data-idev2="'.$Idev2.'" data-idev3="'.$Idev3.'" data-page="' . $jumpToPage .'">'.  $jumpToPage . '</li>&nbsp;';
      }
    }
    if ($curWindowNum < $maxWindowNum)
      $strLinks .= '&nbsp;&nbsp;<li class="page-item page-link apage" data-id_atm="'.$idAtm.'" data-terminalID="'.$terminalID.'" data-dated="'.$Dated.'" data-datef="'.$Datef.'" data-idev="'.$Idev.'" data-idev2="'.$Idev2.'" data-idev3="'.$Idev3.'" data-page="' . (($curWindowNum) * $maxPageLinks + 1) . '">...</li>&nbsp;&nbsp;' ;
    if (($this->pagecourant < $this->totalpage) && ($this->totalpage != 1))
      $strLinks .= '<li class="page-item page-link apage" data-id_atm="'.$idAtm.'" data-terminalID="'.$terminalID.'" data-dated="'.$Dated.'" data-datef="'.$Datef.'" data-idev="'.$Idev.'" data-idev2="'.$Idev2.'" data-idev3="'.$Idev3.'"  data-page="' . ($this->pagecourant + 1)  .'">Next&nbsp;&raquo;</li>';
    else
      $strLinks .= '&nbsp;<li class="page-item page-link disabled">Next&raquo;</li>';

    return $strLinks;
  }

  function Paginate_modal($maxPageLinks, $parameters = '',$id_compaign,$id_image,$name_compaign)
  {
    global $PHP_SELF, $request_type;

    $strLinks = '';

    if($this->totallignes <= 0)
      return '&nbsp;';

    $class = 'class="' . $this->style_texte . '"';
    if (trim($parameters) == '' || (substr($parameters, -1) != '&')) $parameters .= '';
    if ($this->pagecourant > 1)
      $strLinks .= '<li class="page-item page-link precedent modalpage" data-id_compaign="'.$id_compaign.'" data-id_image="'.$id_image.'" data-name_compaign="'.$name_compaign.'"   data-page="'   . ($this->pagecourant - 1)  .'">&laquo;&nbsp;Previous</li>';
    else
      $strLinks .= '<li class="page-item page-link disabled">&laquo;Previous</li>&nbsp;';
    $curWindowNum = intval($this->pagecourant / $maxPageLinks);
    if ($this->pagecourant % $maxPageLinks) $curWindowNum++;
    $maxWindowNum = intval($this->totalpage / $maxPageLinks);
    if ($this->totalpage % $maxPageLinks) $maxWindowNum++;
    if ($curWindowNum > 1)
      $strLinks .= ' &nbsp;&nbsp;<li class="page-item page-link modalpage" data-id_compaign="'.$id_compaign.'" data-id_image="'.$id_image.'" data-name_compaign="'.$name_compaign.'"  data-page="'. (($curWindowNum - 1) * $maxPageLinks) .  '">...</li>&nbsp;&nbsp;';
    for ($jumpToPage = 1 + (($curWindowNum - 1) * $maxPageLinks); ($jumpToPage <= ($curWindowNum * $maxPageLinks)) && ($jumpToPage <= $this->totalpage); $jumpToPage++) {
      if ($jumpToPage == $this->pagecourant) {
        $strLinks .= '&nbsp;<li class="page-item page-link disabled">' . $jumpToPage . '</li>&nbsp;';
      } else {
        $strLinks .= '&nbsp;' . '<li  class=" page-item page-link  modalpage" data-id_compaign="'.$id_compaign.'" data-id_image="'.$id_image.'" data-name_compaign="'.$name_compaign.'"  data-page="' . $jumpToPage .'">'.  $jumpToPage . '</li>&nbsp;';
      }
    }
    if ($curWindowNum < $maxWindowNum)
      $strLinks .= '&nbsp;&nbsp;<li class="page-item page-link modalpage" data-id_compaign="'.$id_compaign.'" data-id_image="'.$id_image.'" data-name_compaign="'.$name_compaign.'"  data-page="' . (($curWindowNum) * $maxPageLinks + 1) . '">...</li>&nbsp;&nbsp;' ;
    if (($this->pagecourant < $this->totalpage) && ($this->totalpage != 1))
      $strLinks .= '<li class="page-item page-link precedent modalpage" data-id_compaign="'.$id_compaign.'" data-id_image="'.$id_image.'" data-name_compaign="'.$name_compaign.'"  data-page="' . ($this->pagecourant + 1)  .'">Next&nbsp;&raquo;</li>';
    else
      $strLinks .= '&nbsp;<li class="page-item page-link disabled">Next&raquo;</li>';

    return $strLinks;
  }
  function Paginate_modal_screen($maxPageLinks, $parameters = '',$ATM,$value_cmd)
  {
    global $PHP_SELF, $request_type;

    $strLinks = '';

    if($this->totallignes <= 0)
      return '&nbsp;';

    $class = 'class="' . $this->style_texte . '"';
    if (trim($parameters) == '' || (substr($parameters, -1) != '&')) $parameters .= '';
    if ($this->pagecourant > 1)
      $strLinks .= '<li class="page-item"><a class="page-link modalpage_screen" data-ATM="'.$ATM.'" data-value_cmd="'.$value_cmd.'"    data-page="'   . ($this->pagecourant - 1)  .'">&laquo;&nbsp;Previous</a></li>';
    else
      $strLinks .= '<li class="page-item disabled"><a class="page-link"tabindex="-1">&laquo; Previous</a></li>';
    $curWindowNum = intval($this->pagecourant / $maxPageLinks);
    if ($this->pagecourant % $maxPageLinks) $curWindowNum++;
    $maxWindowNum = intval($this->totalpage / $maxPageLinks);
    if ($this->totalpage % $maxPageLinks) $maxWindowNum++;
    if ($curWindowNum > 1)
      $strLinks .= ' &nbsp;&nbsp;<li class="page-item"><a class="page-link modalpage_screen" data-ATM="'.$ATM.'" data-value_cmd="'.$value_cmd.'"   data-page="'. (($curWindowNum - 1) * $maxPageLinks) .  '">...</a></li>&nbsp;&nbsp;';
    for ($jumpToPage = 1 + (($curWindowNum - 1) * $maxPageLinks); ($jumpToPage <= ($curWindowNum * $maxPageLinks)) && ($jumpToPage <= $this->totalpage); $jumpToPage++) {
      if ($jumpToPage == $this->pagecourant) {
        $strLinks .= '<li class="page-item disabled"><a class="page-link"tabindex="-1">' . $jumpToPage . '</a></li>';
      } else {
        $strLinks .= '&nbsp;' . '<li class="page-item"><a  class="page-link modalpage_screen" data-ATM="'.$ATM.'" data-value_cmd="'.$value_cmd.'"   data-page="' . $jumpToPage .'">'.  $jumpToPage . '</a></li>&nbsp;';
      }
    }
    if ($curWindowNum < $maxWindowNum)
      $strLinks .= '&nbsp;&nbsp;<li class="page-item"><a class="page-link modalpage_screen" data-ATM="'.$ATM.'" data-value_cmd="'.$value_cmd.'"  data-page="' . (($curWindowNum) * $maxPageLinks + 1) . '">...</a></li>&nbsp;&nbsp;' ;
    if (($this->pagecourant < $this->totalpage) && ($this->totalpage != 1))
      $strLinks .= '<li class="page-item"><a class="page-link modalpage_screen" data-ATM="'.$ATM.'" data-value_cmd="'.$value_cmd.'" data-page="' . ($this->pagecourant + 1)  .'">Next&nbsp;&raquo;</a></li>';
    else
      $strLinks .= '<li class="page-item disabled"><a class="page-link"tabindex="-1">Next &raquo;</a></li>';

    return $strLinks;
  }

  function getCount($textOutput)
  {
    $toNum = ($this->lignesparpage * $this->pagecourant);
    if ($toNum > $this->totallignes) $toNum = $this->totallignes;

    $fromNum = ($this->lignesparpage * ($this->pagecourant - 1));

    if ($toNum == 0) {
      $fromNum = 0;
    } else {
      $fromNum++;
    }

    return sprintf($textOutput, $fromNum, $toNum, $this->totallignes);
  }

  function req()
  {
    return $this->querry;
  }
}
?>
