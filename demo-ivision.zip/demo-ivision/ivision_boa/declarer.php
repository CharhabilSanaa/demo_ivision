<?php
include "lib/auth/config.php";

?>
<!DOCTYPE html>
<html lang="<?php echo $lang['lang'];?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php include 'header_star.php'; ?>

</head>
<?php

if (verif_user($_SESSION['user'],$_SESSION['mdp'])==true): ?>
    <?php if ((verif_user($_SESSION['user'],$_SESSION['mdp'])==true) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true))): ?>

        <?php
        if(empty($_GET['terminal'])){$_GET['terminal']="";}
        if(empty($_GET['id_motif'])){$_GET['id_motif']="";}
        if(empty($_GET['dateArret'])){$_GET['dateArret']="";}
        if(empty($_GET['id_arret'])){$_GET['id_arret']="";}

        ?>

        <body class="c-app">

        <?php
        include 'sidebar.php';

        $date_month= date("Y-m");
        $date_today= date("Y-m-d", strtotime("-1 day"));
        $date= date("Y-m-d", strtotime("-15 day"));
        setlocale(LC_TIME, 'fr_FR.utf8', 'fra');
        ?>
        <div class="c-wrapper c-fixed-components">
            <?php  include 'navbar_star.php'; ?>
            <div class="c-body">
                <main class="c-main">
                    <div class="container-fluid">
                        <div class="fade-in">
                            <input type="hidden" id="hdnSession" data-value="1"/>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="start.php">I-Vision</a></li>
                                    <li class="breadcrumb-item" ><a href="start.php"><?php echo $lang['bank'];?></a></li>
                                    <li class="breadcrumb-item" aria-current="page"><?php echo $lang['declar'];?></li>
                                </ol>
                            </nav>

                            <?php
                            if((verif_habilitation($_SESSION['habilitation_backoffice'],22)==true)&&(strlen(antixss($_GET['terminal']))>=0) && (strlen(antixss($_GET['terminal']))<=10) && (strlen(antixss($_GET['id_motif']))>=0) && (strlen(antixss($_GET['id_motif']))<=20) && (strlen(antixss($_GET['dateArret']))>=0) && (strlen(antixss($_GET['dateArret']))<=20) ):
                                get_declaration($_GET["terminal"],$_GET["id_motif"],$_GET["dateArret"],$_GET["id_arret"],$lang);

                            else:
                                echo '<div class="alert alert-danger text-center" role="alert">PAGE UNAUTHORIZED !!</div>';
                            endif
                            ?>
                        </div>
                    </div>
                </main>
            </div>

        </div>
        <?php

        //header NAV Bar
        include 'footer.php';

        ?>



        </body>

    <?php
    else:
        header("location: start.php");
    endif ?>
<?php
else:
    header("location: index.php");
endif ?>
</html>
