<?php
//session_start();

if (!empty($_SESSION['user']) && !empty($_SESSION['mdp']))
{
    ?>
    <title><?php echo $lang['title'] ?></title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="vendors/@coreui/icons/css/all.min.css">
    <link rel="icon" href="img/Logo noir 110.ico" />
    <link href="css/style.css" rel="stylesheet">
    <!-- Global site tag (gtag.js) - Google Analytics-->

    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        // Shared ID
        gtag('config', 'UA-118965717-3');
        // Bootstrap ID
        gtag('config', 'UA-118965717-5');
    </script>

    <link href="vendors/@coreui/chartjs/css/coreui-chartjs.css" rel="stylesheet">
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="vendors/bootstrap/css/bootstrap-select.css" rel="stylesheet">



    <style>
        .toggle.ios, .toggle-on.ios, .toggle-off.ios { border-radius: 20rem; }
        .toggle.ios .toggle-handle { border-radius: 20rem; }
    </style>

    <div class="error-jwt">

    </div>

    <?php include 'lib/lib.php'; ?>
    <?php include 'frmModal.php'; ?>
    <?php

}
else
{
    header('Location: index.php');
}

?>
