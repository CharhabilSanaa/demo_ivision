<?php
include "lib/auth/config.php";
?>
<!DOCTYPE html>
<html lang="<?php echo $lang['lang'] ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php include 'header_star.php'; ?>

</head>
<?php

if (verif_user($_SESSION['user'],$_SESSION['mdp'])==true):


   /* include("bootstrap.php");
    include("functions.inc.php");
    include("get_function_img.php");*/


    ?>
    <?php if ((verif_user($_SESSION['user'],$_SESSION['mdp'])==true) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true))): ?>

    <?php
    if(empty($_POST['recherche'])){$_POST['recherche']="";}
    if(empty($_POST['code_gab'])){$_POST['code_gab']="";}
    if(empty($_POST['id_filiales'])){$_POST['id_filiales']="";}
    if(empty($_POST['type_gab'])){$_POST['type_gab']="";}
    if(empty($_POST['type_gestionnaire'])){$_POST['type_gestionnaire']="";}
    if(empty($_POST['date_debut'])){$_POST['date_debut']="";}
    if(empty($_POST['date_fin'])){$_POST['date_fin']="";}
    if(empty($_GET['page'])){$_GET['page']="";}
    if(empty($_POST['categorie'])){$_POST['categorie']="";}
    ?>

    <body class="c-app">

    <?php
    include 'sidebar.php';

    $date_month= date("Y-m");
    $date_today= date("Y-m-d", strtotime("-1 day"));
    $date= date("Y-m-d", strtotime("-15 day"));
    setlocale(LC_TIME, 'fr_FR.utf8', 'fra');
    ?>
    <div class="c-wrapper c-fixed-components">
        <?php  include 'navbar_star.php'; ?>
        <div class="c-body">
            <main class="c-main">
                <div class="container-fluid">
                    <div class="fade-in">
                        <input type="hidden" id="hdnSession" data-value="2"/>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="start.php">I-Vision</a></li>
                                <li class="breadcrumb-item"><a href="start.php">Bank</a></li>
                                <li class="breadcrumb-item" aria-current="page"><?php echo $lang['titre_page_reppot2'];?></li>
                            </ol>
                        </nav>



                        <div class="row">
                            <div id="accordion"><div id="collapseOne" class="collapse" data-parent="#accordion"></div></div>
                            <div class="col-lg-12">
                                <div class="card">

                                    <div class="card-header"> <?php //echo $lang['entete_msg']?>
                                        <?php //echo "<br>";?>
                                        <?php //echo $lang['corps_msg_1']?>


                                        <div id="accordion">
                                            <div class="card">
                                                <div class="card-header">
                                                    <a class="card-link" data-toggle="collapse" href="#collapseOne">
                                                        <img src="img/clique_ici.jpg" />
                                                    </a>
                                                </div>
                                                <div id="collapseOne" class="collapse" data-parent="#accordion">
                                                    <div class="card-body">

                                                        <form class="form-horizontal" action="" method="post">
                                                            <div class="card">

                                                                <div class="card-body">


                                                                    <div class="form-group row">
                                                                        <label class="col-md-2 col-form-label" for="hf-password"><?php echo $lang['th_table_1'];?></label>
                                                                        <div class="col-md-4">
                                                                            <select class="form-control" id="id_filiales" name="id_filiales" >
                                                                                <?php
                                                                                if(($_POST['id_filiales']<>'%')&&($_POST['id_filiales']<>'')){get_list_filiale($_POST['id_filiales']);}
                                                                                echo '<option value="%">Toutes les régions</option>';
                                                                                get_list_filiale('%');


                                                                                ?>
                                                                            </select>
                                                                        </div>

                                                                    </div>

                                                                    <div class="form-group row">
                                                                        <label class="col-md-2 col-form-label" for="hf-password"><?php echo $lang['th_table_38'];?></label>
                                                                        <div class="col-md-4">
                                                                            <select class="form-control" id="type_gab" name="type_gab" >
                                                                                <?php
                                                                                if(($_POST['type_gab']<>'%')&&($_POST['type_gab']<>'')){get_list_type_gab($_POST['type_gab']);}
                                                                                echo '<option value="%">Toutes les types GAB</option>';
                                                                                get_list_type_gab('%');

                                                                                ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group row">
                                                                        <label class="col-md-2 col-form-label" for="hf-password"><?php echo $lang['th_table_39'];?></label>
                                                                        <div class="col-md-4">
                                                                            <select class="form-control" id="type_gestionnaire" name="type_gestionnaire" >
                                                                                <?php
                                                                                if(($_POST['type_gestionnaire']<>'%')&&($_POST['type_gestionnaire']<>'')){get_list_gestionnaire($_POST['type_gestionnaire']);}
                                                                                echo '<option value="%">Toutes les gestionnaires</option>';
                                                                                get_list_gestionnaire('%');

                                                                                ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group row">
                                                                        <label class="col-md-2 col-form-label" for="hf-password"><?php echo $lang['th_table_21'];?></label>
                                                                        <div class="col-md-4">
                                                                            <select class="custom-select" id="categorie" name="categorie" >
                                                                                <?php
                                                                                if(($_POST['categorie']<>'%')&&($_POST['categorie']<>'')){get_list_categorie($_POST['categorie']);}
                                                                                echo '<option value="%">Toutes les  catégories</option>';
                                                                                get_list_categorie('%');

                                                                                ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group row">
                                                                        <label class="col-md-2 col-form-label" for="date_debut"><?php echo $lang['th_table_40'];?></label>
                                                                        <div class="col-md-4">
                                                                            <input class="form-control" id="date_debut" type="date" name="date_debut" placeholder="date" <?php if(($_POST['date_debut']<>'%')&&($_POST['date_debut']<>'')){ echo "value=".$_POST['date_debut'];} ?>>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group row">
                                                                        <label class="col-md-2 col-form-label" for="date_fin"><?php echo $lang['th_table_41'];?></label>
                                                                        <div class="col-md-4">
                                                                            <input class="form-control" id="date_fin" type="date" name="date_fin" placeholder="date" <?php if(($_POST['date_fin']<>'%')&&($_POST['date_fin']<>'')){ echo "value=".$_POST['date_fin'];} ?>>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group row">
                                                                        <label class="col-md-2 col-form-label" for="date_fin"> </label>
                                                                        <div class="col-md-4">
                                                                            <div class="input-group search">
                                                                                <button class="btn btn-block btn-outline-primary my-2 my-sm-0" type="submit"><?php echo $lang['search'];?></button>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </form>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>




                                    </div>
                                    <div class="card-body">
                                        <?php


                                        if ((verif_habilitation($_SESSION['habilitation_backoffice'],2)==true)):

                                            if(strlen($_POST['code_gab'])<=60)
                                            {
                                                if((getlenght($_POST['date_debut'])>=0) && (getlenght($_POST['date_debut'])<=20) && (getlenght($_POST['date_fin'])>=0) && (getlenght($_POST['date_fin'])<=20)  && (getlenght($_POST['code_gab'])>=0) && (getlenght($_POST['code_gab'])<=20)	&&(getlenght($_POST['type_gab'])>=0) && (getlenght($_POST['type_gab'])<=20)	&&(getlenght($_POST['type_gestionnaire'])>=0) && (getlenght($_POST['type_gestionnaire'])<=20)	&&  (getlenght($_POST['id_filiales'])>=0) && (getlenght($_POST['id_filiales'])<=40))
                                                {
                                                    if($_POST['date_debut']==""){$date_debut=date("Y-m-d", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d")-5,date("Y")));}else{$date_debut=$_POST['date_debut'];}
                                                    if($_POST['date_fin']==""){$date_fin=date("Y-m-d", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y")));}else{$date_fin=$_POST['date_fin'];}


                                                }
                                            }




                                            $nb_jour_mois=nbr_jour_duree($date_debut, $date_fin);
                                            $list_gab_retrait_argent=get_liste_gab_inclus_taux("id_activation");
                                            $list_gab_depot_argent=get_liste_gab_inclus_taux("id_activ_depot_argent");
                                            $list_gab_depot_cheque=get_liste_gab_inclus_taux("id_activ_depot_cheque");

                                            $motif_retrait_argent=get_liste_motif_inclus_taux("retrait_argent");
                                            $motif_depot_argent=get_liste_motif_inclus_taux("depot_argent");
                                            $motif_depot_cheque=get_liste_motif_inclus_taux("depot_cheque");

                                            $nb_gab_retrait_argent=get_return_nb_gab('','id_activation');
                                            $nb_gab_depot_argent=get_return_nb_gab('','id_activ_depot_argent');
                                            $nb_gab_depot_cheque=get_return_nb_gab('','id_activ_depot_cheque');






                                            // echo "<br>";
                                            // $date_debut=date("Y-m-d", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d")-5,date("Y")));
                                            // echo "<br>";
                                            // $date_fin=date("Y-m-d", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y")));
                                            // echo "<br>";
                                            // echo "<br> morsli : ";


                                            echo "<br>";

                                            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                            function get_corps_mail($date_debut,$date_fin,$id_filiales,$type_gab,$type_gestionnaire,$categorie,
                                                                    $motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque,
                                                                    $list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque,
                                                                    $nb_gab_retrait_argent,$nb_gab_depot_argent,$nb_gab_depot_cheque,$nb_jour_mois,$lang)
                                            {


                                                echo $lang['entete_msg'];
                                                echo "<br>";
                                                echo $lang['corps_msg_1'];
                                                if (strtotime($date_debut)==strtotime($date_fin)){echo date("d-m-Y",strtotime($date_debut));}else{ echo date("d/m/Y",strtotime($date_debut))." ".$lang['corps_msg_2']." ".date("d/m/Y",strtotime($date_fin)); ;}
                                                echo "<br>";
                                                echo $lang['corps_msg_3'];
                                                echo "<br>";
                                                echo $lang['corps_msg_4'];
                                                echo "<br>";








                                                $duree_globlal=$nb_gab_retrait_argent*$nb_jour_mois*1440;

                                                $duree=getTauxIndispoMotif2($date_debut,$date_fin,$motif_retrait_argent,$list_gab_retrait_argent,$categorie,$id_filiales,$type_gab,$type_gestionnaire);
                                                $taux_indispo_dispo=getverifTaux1($duree,$duree_globlal);
                                                $dispo=round(100-$taux_indispo_dispo,2,PHP_ROUND_HALF_DOWN);
                                                $duree_indispo=$duree_globlal-$duree;



                                                echo '<br>
	<table class="table table-responsive-sm table-hover table-outline mb-0">
		<thead class="thead-light">
			<tr>
					<th>'.$lang['th_table_11'].'</th>
					<th>'.$lang['th_table_12'].'</th>
					<th>'.$lang['th_table_13'].'</th>

			</tr>
			</thead>
			<tbody>';
                                                // $NbrIncident=getNbrIncident($date_debut,$date_fin,$motif_inclus,$list_gab,$categorie,$nb_gab,$nb_jour,$motif_exclus,$region);
                                                $NbrIncident=get_nbr_incident_categorie($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,'',$id_filiales,$type_gab,$type_gestionnaire);

                                                echo '<tr>';

                                                echo '<td style="text-align: center;">'.date("d/m/Y", strtotime($date_debut)).' au '.date("d/m/Y", strtotime($date_fin)).'</td>';
                                                echo '<td style="text-align: center;">'.$dispo.'%</td>';
                                                echo '<td style="text-align: center;">'.$NbrIncident.'</td>';
                                                echo '</tr>';
                                                echo '
			</tbody>			
		</table>';







                                                echo '<br><p style="color:#002060;font-family:  Calibri, serif;font-size:16px;font-weight: bold;">'.$lang['titre_11'].'</p>';
                                                echo '<table style="width: 100%">';
                                                echo '<tbody><tr>
										  <td>';affichageDureeInformationIntervenantCategorieMotif($date_debut,$date_fin,$motif_retrait_argent,$list_gab_retrait_argent,$categorie,$nb_gab_retrait_argent,$nb_jour_mois,$id_filiales,$type_gab,$type_gestionnaire,"Service retrait d'argent",$lang);echo '</td>';
                                                echo '<td>';affichageDureeInformationIntervenantCategorieMotif($date_debut,$date_fin,$motif_depot_argent,$list_gab_depot_argent,$categorie,$nb_gab_depot_argent,$nb_jour_mois,$id_filiales,$type_gab,$type_gestionnaire,"Service dépôt d'argent",$lang);echo '</td>';
                                                echo '<td>';affichageDureeInformationIntervenantCategorieMotif($date_debut,$date_fin,$motif_depot_cheque,$list_gab_depot_cheque,$categorie,$nb_gab_depot_cheque,$nb_jour_mois,$id_filiales,$type_gab,$type_gestionnaire,"Service dépôt de chèque",$lang);echo '</td></tr>';
                                                echo'<tr>';

                                                $name_image='img_taux_dispo_categorie_retrait_argent_'.date("d-m-Y", strtotime($date_debut))."_".date("d-m-Y", strtotime($date_fin));
                                                $titre='Indisponibilité par catégorie %';
                                                $array_tx_dispo = getDureeCategorie($date_debut,$date_fin,$motif_retrait_argent,$list_gab_retrait_argent,$categorie,$nb_gab_retrait_argent,$nb_jour_mois,$id_filiales);
                                                // foreach ($array_tx_dispo AS $_url){ echo "<br> Taux :  ".$_url;}
                                                $array_categorie = getLibelleCategorieDuree($date_debut,$date_fin,$motif_retrait_argent,$list_gab_retrait_argent,$categorie,$nb_gab_retrait_argent,$nb_jour_mois);
                                                // foreach ($array_categorie AS $_url){ echo "<br> Categorie :  ".$_url;}

                                                if($array_tx_dispo[0]<>0)
                                                {
                                                    echo'<td style="text-align: center;">';
                                                    genere_img_taux_dispo_nbr_incident_categorie($date_debut,$date_fin,$array_tx_dispo,$array_categorie,$titre,$name_image);
                                                    echo "<img src='/backoffice/demo-monitoring/rapport/img/".$name_image.".png'/><br>";

                                                    echo '</td>';
                                                }
                                                else
                                                {
                                                    echo'<td style="text-align: center;">Img not found';
                                                    echo '</td>';
                                                }



                                                $name_image='img_taux_dispo_categorie_depot_argent_'.date("d-m-Y", strtotime($date_debut))."_".date("d-m-Y", strtotime($date_fin));
                                                $titre='Indisponibilité par catégorie %';
                                                $array_tx_dispo = getDureeCategorie($date_debut,$date_fin,$motif_depot_argent,$list_gab_depot_argent,$categorie,$nb_gab_depot_argent,$nb_jour_mois,$id_filiales);
                                                // foreach ($array_tx_dispo AS $_url){ echo "<br> Taux :  ".$_url;}
                                                $array_categorie = getLibelleCategorieDuree($date_debut,$date_fin,$motif_depot_argent,$list_gab_depot_argent,$categorie,$nb_gab_depot_argent,$nb_jour_mois);
                                                // foreach ($array_categorie AS $_url){ echo "<br> Categorie :  ".$_url;}

                                                if($array_tx_dispo[0]<>0)
                                                {
                                                    echo'<td style="text-align: center;">';
                                                    genere_img_taux_dispo_nbr_incident_categorie($date_debut,$date_fin,$array_tx_dispo,$array_categorie,$titre,$name_image);
                                                    echo "<img src='/backoffice/demo-monitoring/rapport/img/".$name_image.".png'/><br>";

                                                    echo '</td>';
                                                }
                                                else
                                                {
                                                    echo'<td style="text-align: center;">Img not found';
                                                    echo '</td>';
                                                }


                                                $name_image='img_taux_dispo_categorie_depot_cheque_'.date("d-m-Y", strtotime($date_debut))."_".date("d-m-Y", strtotime($date_fin));
                                                $titre='Indisponibilité par catégorie %';
                                                $array_tx_dispo = getDureeCategorie($date_debut,$date_fin,$motif_depot_cheque,$list_gab_depot_cheque,$categorie,$nb_gab_depot_cheque,$nb_jour_mois,$id_filiales);
                                                // foreach ($array_tx_dispo AS $_url){ echo "<br> Taux :  ".$_url;}
                                                $array_categorie = getLibelleCategorieDuree($date_debut,$date_fin,$motif_depot_cheque,$list_gab_depot_cheque,$categorie,$nb_gab_depot_cheque,$nb_jour_mois);
                                                // foreach ($array_categorie AS $_url){ echo "<br> Categorie :  ".$_url;}

                                                if($array_tx_dispo[0]<>0)
                                                {
                                                    echo'<td style="text-align: center;">';
                                                    genere_img_taux_dispo_nbr_incident_categorie($date_debut,$date_fin,$array_tx_dispo,$array_categorie,$titre,$name_image);
                                                    echo "<img src='/backoffice/demo-monitoring/rapport/img/".$name_image.".png'/><br>";
                                                    echo '</td>';
                                                }
                                                else
                                                {
                                                    echo'<td style="text-align: center;">Img not found';
                                                    echo '</td>';
                                                }


                                                echo '</tr></tbody>';

                                                echo'</table>';






                                                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////






                                                echo '<br><p style="color:#002060;font-family:  Calibri, serif;font-size:16px;font-weight: bold;">'.$lang['titre_12'].'</p>';
                                                echo '<table style="width: 100%">';
                                                echo '<tbody><tr>						
																
									  <td>';affichageDureeInformationIntervenantVille($date_debut,$date_fin,$motif_retrait_argent,$list_gab_retrait_argent,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$nb_gab_retrait_argent,$nb_jour_mois,"Service retrait d'argent","",$lang);echo '</td>';
                                                echo '<td>';affichageDureeInformationIntervenantVille($date_debut,$date_fin,$motif_depot_argent,$list_gab_depot_argent,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$nb_gab_depot_argent,$nb_jour_mois,"Service dépôt d'argent","id_activ_depot_argent",$lang);echo '</td>';
                                                echo '<td>';affichageDureeInformationIntervenantVille($date_debut,$date_fin,$motif_depot_cheque,$list_gab_depot_cheque,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$nb_gab_depot_cheque,$nb_jour_mois,"Service dépôt de chèque","id_activ_depot_cheque",$lang);echo '</td>
								</tr></tbody>';
                                                echo'</table>';



                                                echo'<table cellspacing="0" cellpadding="0">';

                                                echo '<tr>';
                                                echo '<td colspan=2><br><p style="color:#002060;font-family:  Calibri, serif;font-size:16px;font-weight: bold;">'.$lang['titre_13'].'</p>	</td>';
                                                echo '</tr>';
                                                echo '<tr>';
                                                echo '<td>';
                                                get_table_nbr_alerte_incidents_responsable($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,'',$id_filiales,$type_gab,$type_gestionnaire,$lang) ;
                                                echo '</td>';
                                                echo '<td>';
                                                genere_img_incident_par_responsable($date_debut,$date_fin,$categorie,$list_gab_retrait_argent,'',$id_filiales,$type_gab,$type_gestionnaire);
                                                echo '<img  src="/backoffice/demo-monitoring/rapport/img/img_incident_ouvert_par_responsable_'.date("d-m-Y",strtotime($date_debut)).'_'.date("d-m-Y",strtotime($date_fin)).'.png"/><br>';
                                                echo '</td>';
                                                echo '</tr>';


                                                echo '<tr>';
                                                echo '<td colspan="2"><br><p style="color:#002060;font-family:  Calibri, serif;font-size:16px;font-weight: bold;">'.$lang['titre_14'].'</p></td>';
                                                echo '</tr>';
                                                echo '<tr>';
                                                echo '<td>';
                                                get_table_nbr_alerte_incidents_service_categorie($date_debut,$date_fin,$list_gab_retrait_argent,'',$categorie,$id_filiales,$type_gab,$type_gestionnaire,$lang) ;
                                                echo '</td>';
                                                echo '<td>';
                                                genere_img_incident_par_categorie_service($date_debut,$date_fin,$list_gab_retrait_argent,'',$categorie,$id_filiales,$type_gab,$type_gestionnaire);
                                                echo '<img  src="/backoffice/demo-monitoring/rapport/img/img_incident_ouvert_par_categorie_'.date("d-m-Y",strtotime($date_debut)).'_'.date("d-m-Y",strtotime($date_fin)).'.png"/><br>';

                                                echo '</td>';
                                                echo '</tr>';

                                                echo '<tr>';
                                                echo '<td colspan=2><br><p style="color:#002060;font-family:  Calibri, serif;font-size:16px;font-weight: bold;">'.$lang['titre_15'].'</p>	</td>';
                                                echo '</tr>';

                                                echo '<tr>';
                                                echo '<td>';
                                                get_table_nbr_alerte_incidents_categorie($date_debut,$date_fin,$list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque,$motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$lang);
                                                echo '</td>';
                                                echo '<td>';
                                                image_incident_ouvert_par_categorie_service($date_debut,$date_fin,'',$list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque,$motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$lang);
                                                echo '<img  src="/backoffice/demo-monitoring/rapport/img/img_incident_ouvert_par_categorie_service_'.date("d-m-Y",strtotime($date_debut)).'_'.date("d-m-Y",strtotime($date_fin)).'.png"/><br>';

                                                // echo '<br>  <p style="color:#404040;font-family:  Calibri, serif;font-size:14px;">
                                                // * La catégorie Autres comprend le motif suivant : Gab déconnecté.
                                                // </p>';
                                                echo '</td>';
                                                echo '</tr>';

                                                echo'</table>';


                                                echo '<br><p style="color:#002060;font-family:  Calibri, serif;font-size:16px;font-weight: bold;">'.$lang['titre_16'].'</p>';
                                                echo '<table style="width: 100%">';
                                                echo '<tbody><tr>';
                                                echo '<td>';affichageInformationDeppasementSLA4($date_debut,$date_fin,$nb_gab_retrait_argent,$nb_jour_mois,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab_retrait_argent,$motif_retrait_argent,'retrait d‘argent',$lang);echo '</td></tr>';
                                                echo '<tr><td>';affichageInformationDeppasementSLA4($date_debut,$date_fin,$nb_gab_depot_argent,$nb_jour_mois,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab_depot_argent,$motif_depot_argent,'dépôt d‘argent',$lang);echo '</td></tr>';
                                                echo '<tr><td>';affichageInformationDeppasementSLA4($date_debut,$date_fin,$nb_gab_depot_cheque,$nb_jour_mois,$categorie,$id_filiales,$type_gab,$type_gestionnaire,$list_gab_depot_cheque,$motif_depot_cheque,'dépôt de chèque',$lang);echo '</td>';
                                                // echo '<td>';echo  '<img  src="cid:img_incident_intervention_sla" >';echo '</td>';
                                                echo'</tr></tbody>';
                                                echo'</table>';



                                            }




                                            get_corps_mail($date_debut,$date_fin,$_POST['id_filiales'],$_POST['type_gab'],$_POST['type_gestionnaire'],
                                                $_POST['categorie'],$motif_retrait_argent,$motif_depot_argent,$motif_depot_cheque
                                                ,$list_gab_retrait_argent,$list_gab_depot_argent,$list_gab_depot_cheque
                                                ,$nb_gab_retrait_argent,$nb_gab_depot_argent,$nb_gab_depot_cheque,$nb_jour_mois,$lang);

                                        else:
                                            echo '<div class="alert alert-danger text-center" role="alert">PAGE UNAUTHORIZED !!</div>';
                                        endif
                                        ?>

                                    </div>
                                </div>
                                <!-- /.table-responsive -->
                            </div>
                            <!-- /.col-lg-4 (nested) -->

                            <!-- /.col-lg-8 (nested) -->
                        </div>

                    </div>
                </div>
            </main>
        </div>

    </div>

    <?php

    //header NAV Bar
    include 'footer.php';

    ?>



    </body>

<?php
else:
    header("location: start.php");
endif ?>
<?php
else:
    header("location: index.php");
endif ?>
</html>
