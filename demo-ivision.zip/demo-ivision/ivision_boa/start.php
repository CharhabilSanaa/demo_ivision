<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

    include "lib/auth/config.php";

?>

<!DOCTYPE html>
<html lang="<?php echo $lang['lang'] ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php
        include 'header_star.php';
    ?>

</head>
<?php

if (((isset($_SESSION['user']))&&(verif_user($_SESSION['user'],$_SESSION['mdp'])==true)) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true) )):?>

    <body class="c-app">

    <?php
        include 'sidebar.php';

        $date_month= date("Y-m");
        $date_today= date("Y-m-d", strtotime("-1 day"));
        $date= date("Y-m-d", strtotime("-15 day"));

    ?>
    <div class="c-wrapper c-fixed-components">
    <?php  include 'navbar_star.php'; ?>
        <div class="c-body">
            <main class="c-main">
                <div class="container-fluid">
                    <div class="fade-in">
                        <input type="hidden" id="hdnSession" data-value="1"/>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="start.php">I-Vision</a></li>
                                <li class="breadcrumb-item" aria-current="page"><?php echo $lang['bank']?></li>
                            </ol>
                        </nav>

                        <div class="row">
                            <div class="col-sm-12 col-lg-12">
                                <div class="card shadow-lg p-3 mb-2 bg-white rounded">
                                    <div class="card text-white bg-secondary  mb-2" style="text-align: center;">
                                        <div class="text-value-xl  c-icon-3xl text-white my-1 text-white"><h style="color: #4f5d73;"><?php echo $lang['indicat']?><?php echo (strftime("%A %d %B %Y"));
                                        ?> </h></div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="row">

                            <div class="col-sm-3 col-md-4 ">
                                <div class="card col-12">
                                    <div class="card-header " align="center" style="font-size: 20px;font-family: Calibri"><?php echo $lang['taux_dis_RA']?></div>
                                    <div class="card-body">
                                        <div class="c-chart-wrapper">
                                            <canvas id="myChart" ></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3 col-md-4 ">
                                <div class="card col-12">
                                    <div class="card-header" align="center" style="font-size: 20px;font-family: Calibri"><?php echo $lang['taux_dis_DA']?></div>
                                    <div class="card-body">
                                        <div class="c-chart-wrapper">
                                            <canvas id="myChart7" ></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3 col-md-4 ">
                                <div class="card col-12">
                                    <div class="card-header" align="center" style="font-size: 20px;font-family: Calibri"><?php echo $lang['taux_dis_DC']?></div>
                                    <div class="card-body">
                                        <div class="c-chart-wrapper">
                                            <canvas id="myChart8" ></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-3 col-md-4 ">
                                <div class="card col-12">
                                    <div class="card-header" align="center" style="font-size: 20px;font-family: Calibri"><?php echo $lang['gab_dispo']?></div>
                                    <div class="card-body">
                                        <div class="c-chart-wrapper">
                                            <canvas id="myChart2" ></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3 col-md-4 ">
                                <div class="card col-12">
                                    <div class="card-header" align="center" style="font-size: 20px;font-family: Calibri"><?php echo $lang['nbr_incid_ouv']?></div>
                                    <div class="card-body">
                                        <div class="c-chart-wrapper">
                                            <canvas id="myChart3" ></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3 col-md-4 ">
                                <div class="card col-12">
                                    <div class="card-header" align="center" style="font-size: 20px;font-family: Calibri"><?php echo $lang['nbr_inci_serv']?></div>
                                    <div class="card-body">
                                        <div class="c-chart-wrapper">
                                            <canvas id="myChart9" ></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col-sm-12 col-lg-12">
                                <div class="card shadow-lg p-3 mb-2 bg-white rounded">
                                    <div class="card text-white bg-secondary  mb-2" style="text-align: center;">
                                        <div class="text-value-xl  c-icon-3xl text-white my-1 text-white"><h style="color: #4f5d73;"><?php echo $lang['indicat_mois']?> <?php echo (ucwords(strftime("%B"))); ?> </h></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-3 col-md-4 ">
                                <div class="card col-12">
                                    <div class="card-header" align="center" style="font-size: 20px;font-family: Calibri"><?php echo $lang['taux_dis_RA']?></div>
                                    <div class="card-body">
                                        <div class="c-chart-wrapper">
                                            <canvas id="myChart4" ></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3 col-md-4 ">
                                <div class="card col-12">
                                    <div class="card-header" align="center" style="font-size: 20px;font-family: Calibri"><?php echo $lang['taux_dis_DA']?></div>
                                    <div class="card-body">
                                        <div class="c-chart-wrapper">
                                            <canvas id="myChart5" ></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3 col-md-4" >
                                <div class="card col-12">
                                    <div class="card-header" align="center" style="font-size: 20px;font-family: Calibri"><?php echo $lang['taux_dis_DC']?></div>
                                    <div class="card-body">
                                        <div class="c-chart-wrapper">
                                            <canvas id="myChart6"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </main>
        </div>

        </div>

    <?php

    //header NAV Bar
    include 'footer.php';

    ?>
    <script>



        // Get the chart's base64 image string
        var my_lang = '<?php echo $lang["lang"]; ?>';

        $(document).ready(function () {

            Chart.pluginService.register({
                beforeDraw: function (chart) {
                    if (chart.config.options.elements.center) {
                        //Get ctx from string
                        var ctx = chart.chart.ctx;

                        //Get options from the center object in options
                        var centerConfig = chart.config.options.elements.center;
                        var fontStyle = centerConfig.fontStyle || 'Arial';
                        var txt = centerConfig.text;
                        var color = centerConfig.color || '#000';
                        var sidePadding = centerConfig.sidePadding || 20;
                        var sidePaddingCalculated = (sidePadding/100) * (chart.innerRadius * 2)
                        //Start with a base font of 30px
                        ctx.font = "30px " + fontStyle;

                        //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
                        var stringWidth = ctx.measureText(txt).width;
                        var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;

                        // Find out how much the font can grow in width.
                        var widthRatio = elementWidth / stringWidth;
                        var newFontSize = Math.floor(30 * widthRatio);
                        var elementHeight = (chart.innerRadius * 2);

                        // Pick a new font size so it will not be larger than the height of label.
                        var fontSizeToUse = Math.min(newFontSize, elementHeight);

                        //Set font settings to draw it correctly.
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'middle';
                        var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
                        var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
                        ctx.font = fontSizeToUse+"px " + fontStyle;
                        ctx.fillStyle = color;

                        //Draw text in center
                        ctx.fillText(txt, centerX, centerY);
                    }
                }
            });
            showGraph1();
            showGraph2();
            showGraph3();
            showGraph4();
            showGraph5();
            showGraph6();
            showGraph7();
            showGraph8();
            showGraph9();

        });

        function showGraph1() {
            {
                $.post("lib/datachart/taux_dispo_J.php",
                    function (data)
                    {
                        //console.log(data);

                        var taux_dispo_reel = [];
                        var taux_indispo_reel = [];
                        var descrip = [];

                        var my_lang = '<?php echo $lang["lang"]; ?>';

                        for (var i in data) {
                            taux_dispo_reel.push(data[i].taux);

                            descrip.push(data[i].descrip);
                            taux_indispo_reel.push(100-data[i].taux);

                        }



                        var chartdata = {

                            labels: ['<?php echo $lang["taux_dis_RA"]; ?>','<?php echo $lang["taux_ind_dis_RA"]; ?>'],
                            datasets: [
                                {
                                    backgroundColor: [
                                        'rgb(165,165,165)',
                                        'rgb(219,225,235)',

                                    ],
                                    borderColor: [
                                        'rgb(165,165,165)',
                                        'rgb(219,225,235)',

                                    ],

                                    borderWidth: 1,
                                    showInLegend: "true",
                                    indexLabelFontSize: 16,
                                    data: [taux_dispo_reel,taux_indispo_reel]
                                }
                            ],
                        };

                        var myChart = $("#myChart");
                        var chart_variable = new Chart(myChart, {
                            type: 'doughnut',
                            data: chartdata,
                            options: {
                                cutoutPercentage: 80,
                                responsive: false,
                                elements: {
                                    center: {
                                        text: Number(taux_dispo_reel[0]).toFixed(2)+ " %",
                                        color: '#595959', // Default is #000000
                                        fontStyle: 'Calibri Light', // Default is Arial
                                        sidePadding: 50 // Defualt is 20 (as a percentage)
                                    }
                                },
                                legend: {
                                    display: false
                                },
                                tooltips: {
                                    enabled: true,
                                    mode: 'label',
                                    callbacks: {
                                        title: function(tooltipItems, data) {
                                            var idx = tooltipItems[0].index;
                                            return  data.labels[idx]; //do something with title
                                        },
                                        label: function(tooltipItem, data) {
                                            // get the data label and data value to display
                                            var value =  Number(data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index]).toFixed(2).toLocaleString()+' %';
                                            // return the text to display on the tooltip
                                            return value;
                                        }
                                    }
                                },
                                title: {
                                    display: true,
                                    text: ' ',
                                    fontSize: 20,
                                    fontFamily: 'Calibri'
                                },
                                animation: {
                                    animateScale: true,
                                    animateRotate: true
                                }
                            }
                        });
                    });
            }
        }
        function showGraph2() {
            {
                $.post("lib/datachart/taux_gab_dispo.php",
                    function (data)
                    {
                        //console.log(data);

                        var taux_dispo_reel = [];
                        var descrip = [];



                        for (var i in data) {
                            taux_dispo_reel.push(data[i].taux);
                            descrip.push(data[i].descrip);


                        }

                        var chartdata = {
                            labels: ['<?php echo $lang["gab_dispo"]; ?>','<?php echo $lang["gab_ind_dispo"]; ?>'],
                            datasets: [
                                {
                                    backgroundColor: [
                                        'rgb(118,41,47)',
                                        'rgb(219,225,235)',

                                    ],
                                    borderColor: [
                                        'rgb(118,41,47)',
                                        'rgb(219,225,235)',

                                    ],

                                    borderWidth: 1,
                                    showInLegend: "true",
                                    legendText: taux_dispo_reel+ " %",
                                    indexLabelFontSize: 16,
                                    indexLabel: taux_dispo_reel+ " %",
                                    data: [taux_dispo_reel,(100-taux_dispo_reel)]
                                }
                            ],
                        };

                        var myChart = $("#myChart2");

                        var doughnutGraph = new Chart(myChart, {
                            type: 'doughnut',
                            data: chartdata,
                            options: {
                                cutoutPercentage: 80,
                                responsive: false,
                                elements: {
                                    center: {
                                        text: Number(taux_dispo_reel[0]).toFixed(2)+ " %",
                                        color: '#595959', // Default is #000000
                                        fontStyle: 'Calibri Light', // Default is Arial
                                        sidePadding: 50 // Defualt is 20 (as a percentage)
                                    }
                                },
                                legend: {
                                    display: false
                                },
                                tooltips: {
                                    enabled: true,
                                    mode: 'label',
                                    callbacks: {
                                        title: function(tooltipItems, data) {
                                            var idx = tooltipItems[0].index;
                                            return  data.labels[idx]; //do something with title
                                        },
                                        label: function(tooltipItem, data) {
                                            // get the data label and data value to display
                                            var value =  Number(data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index]).toFixed(2).toLocaleString()+' %';
                                            // return the text to display on the tooltip
                                            return value;
                                        }
                                    }
                                },
                                title: {
                                    display: true,
                                    text: ' ',
                                    fontSize: 20,
                                    fontFamily: 'Calibri'
                                },
                                animation: {
                                    animateScale: true,
                                    animateRotate: true
                                }
                            }
                        });
                    });
            }
        }
        function showGraph3() {
            {
                $.post("lib/datachart/taux_nbr_gab_hs.php",
                    {
                        lang: '<?php echo $lang["lang"]; ?>'
                    },
                    function (data)
                    {
                        //console.log(data);

                        var taux_dispo_reel = [];
                        var libelle = [];
                        var total = [];
                        var total_GAB = [];



                        for (var i in data)
                        {
                            if(i != data.length-2 && i != data.length-1)
                            {
                                taux_dispo_reel.push(data[i].nbr_incidents);
                                libelle.push(data[i].libelle);
                            }
                            else if (i == data.length-2)
                            {
                                total.push(data[i]);
                            }
                            else
                            {
                                total_GAB.push(data[i]);
                            }
                        }

                        var chartdata = {

                            labels: libelle,
                            datasets: [
                                {
                                    backgroundColor: [
                                        '#772a2e',
                                        '#d31d1a',
                                        '#e75543',
                                        '#f9bfae',
                                        'rgba(164,83,83,0.94)',
                                        'rgba(247,157,81,0.38)',
                                        'rgba(223,135,77,0.79)',



                                    ],
                                    borderColor: [
                                        '#772a2e',
                                        '#d31d1a',
                                        '#e75543',
                                        '#f9bfae',
                                        'rgba(164,83,83,0.94)',
                                        'rgba(247,157,81,0.38)',
                                        'rgba(223,135,77,0.79)',

                                    ],

                                    borderWidth: 1,
                                    showInLegend: "true",
                                    legendText: taux_dispo_reel,
                                    indexLabelFontSize: 16,
                                    indexLabel: taux_dispo_reel,
                                    data: taux_dispo_reel
                                }
                            ],
                        };

                        var myChart = $("#myChart3");

                        var doughnutGraph = new Chart(myChart, {
                            type: 'doughnut',
                            data: chartdata,
                            options: {
                                cutoutPercentage: 80,
                                responsive: false,
                                elements: {
                                    center: {
                                        text: total ,
                                        color: '#595959', // Default is #000000
                                        fontStyle: 'Calibri Light', // Default is Arial
                                        sidePadding: 80 // Defualt is 20 (as a percentage)
                                    }
                                },
                                legend: {
                                    display: true,
                                    position: 'left',
                                    labels: {
                                        fontSize: 8
                                    },
                                    onClick: (e) => e.stopPropagation()
                                },
                                tooltips: {
                                    display: true
                                }
                                ,
                                title: {
                                    display: true,
                                    text: ' ',
                                    fontSize: 20,
                                    fontFamily: 'Calibri'
                                },
                                animation: {
                                    animateScale: true,
                                    animateRotate: true
                                }
                            }
                        });
                    });
            }
        }
        function showGraph4() {
            {
                $.post("lib/datachart/taux_dispo_M.php",
                    function (data)
                    {
                        //console.log(data);

                        var taux_dispo_reel = [];
                        var descrip = [];



                        for (var i in data) {
                            taux_dispo_reel.push(data[i].taux);
                            descrip.push(data[i].descrip);


                        }

                        var chartdata = {
                            labels: ['<?php echo $lang["taux_dis_RA"]; ?>','<?php echo $lang["taux_ind_dis_RA"]; ?>'],
                            datasets: [
                                {
                                    backgroundColor: [
                                        'rgb(165,165,165)',
                                        'rgb(219,225,235)',

                                    ],
                                    borderColor: [
                                        'rgb(165,165,165)',
                                        'rgb(219,225,235)',

                                    ],

                                    borderWidth: 1,
                                    showInLegend: "true",
                                    legendText: taux_dispo_reel+ " %",
                                    indexLabelFontSize: 12,
                                    indexLabel: taux_dispo_reel+ " %",
                                    data: [taux_dispo_reel,(100-taux_dispo_reel)]
                                }
                            ],
                        };

                        var myChart = $("#myChart4");

                        var doughnutGraph = new Chart(myChart, {
                            type: 'doughnut',
                            data: chartdata,
                            options: {
                                cutoutPercentage: 80,
                                responsive: false,
                                elements: {
                                    center: {
                                        text: Number(taux_dispo_reel[0]).toFixed(2)+ " %",
                                        color: '#595959', // Default is #000000
                                        fontStyle: 'Calibri Light', // Default is Arial
                                        sidePadding: 40 // Defualt is 20 (as a percentage)
                                    }
                                },
                                legend: {
                                    display: false
                                },
                                tooltips: {
                                    enabled: true,
                                    mode: 'label',
                                    callbacks: {
                                        title: function(tooltipItems, data) {
                                            var idx = tooltipItems[0].index;
                                            return  data.labels[idx]; //do something with title
                                        },
                                        label: function(tooltipItem, data) {
                                            // get the data label and data value to display
                                            var value =  Number(data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index]).toFixed(2).toLocaleString()+' %';
                                            // return the text to display on the tooltip
                                            return value;
                                        }
                                    }
                                },
                                title: {
                                    display: true,
                                    text: ' ',
                                    fontSize: 20,
                                    fontFamily: 'Calibri'
                                },
                                animation: {
                                    animateScale: true,
                                    animateRotate: true
                                }
                            }
                        });
                    });
            }
        }
        function showGraph5() {
            {
                $.post("lib/datachart/taux_dispo_da.php",
                    function (data)
                    {
                        //console.log(data);

                        var taux_dispo_reel = [];
                        var descrip = [];



                        for (var i in data) {
                            taux_dispo_reel.push(data[i].taux);
                            descrip.push(data[i].descrip);


                        }

                        var chartdata = {
                            labels: ['<?php echo $lang["taux_dis_DA"]; ?>','<?php echo $lang["taux_ind_dis_DA"]; ?>'],
                            datasets: [
                                {
                                    backgroundColor: [
                                        'rgba(221, 59, 46,1)',
                                        'rgb(219,225,235)',

                                    ],
                                    borderColor: [
                                        'rgba(221, 59, 46,1)',
                                        'rgb(219,225,235)',

                                    ],

                                    borderWidth: 1,
                                    showInLegend: "true",
                                    legendText: taux_dispo_reel+ " %",
                                    indexLabelFontSize: 16,
                                    indexLabel: taux_dispo_reel+ " %",
                                    data: [taux_dispo_reel,(100-taux_dispo_reel)]
                                }
                            ],
                        };

                        var myChart = $("#myChart5");

                        var doughnutGraph = new Chart(myChart, {
                            type: 'doughnut',
                            data: chartdata,
                            options: {
                                cutoutPercentage: 80,
                                responsive: false,
                                elements: {
                                    center: {
                                        text: Number(taux_dispo_reel[0]).toFixed(2)+ " %",
                                        color: '#595959', // Default is #000000
                                        fontStyle: 'Calibri Light', // Default is Arial
                                        sidePadding: 50 // Defualt is 20 (as a percentage)
                                    }
                                },
                                legend: {
                                    display: false
                                },
                                tooltips: {
                                    enabled: true,
                                    mode: 'label',
                                    callbacks: {
                                        title: function(tooltipItems, data) {
                                            var idx = tooltipItems[0].index;
                                            return  data.labels[idx]; //do something with title
                                        },
                                        label: function(tooltipItem, data) {
                                            // get the data label and data value to display
                                            var value =  Number(data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index]).toFixed(2).toLocaleString()+' %';
                                            // return the text to display on the tooltip
                                            return value;
                                        }
                                    }
                                },
                                title: {
                                    display: true,
                                    text: ' ',
                                    fontSize: 20,
                                    fontFamily: 'Calibri'
                                },
                                animation: {
                                    animateScale: true,
                                    animateRotate: true
                                }
                            }
                        });
                    });
            }
        }
        function showGraph6() {
            {
                $.post("lib/datachart/taux_dispo_dc.php",
                    function (data)
                    {
                        //console.log(data);

                        var taux_dispo_reel = [];
                        var descrip = [];



                        for (var i in data) {
                            taux_dispo_reel.push(data[i].taux);
                            descrip.push(data[i].descrip);


                        }

                        var chartdata = {
                            labels: ['<?php echo $lang["taux_dis_DC"]; ?>','<?php echo $lang["taux_ind_dis_DC"]; ?>'],
                            datasets: [
                                {
                                    backgroundColor: [
                                        'rgb(89,89,89)',
                                        'rgb(219,225,235)',

                                    ],
                                    borderColor: [
                                        'rgb(89,89,89)',
                                        'rgb(219,225,235)',

                                    ],

                                    borderWidth: 1,
                                    showInLegend: "true",
                                    legendText: taux_dispo_reel+ " %",
                                    indexLabelFontSize: 16,
                                    indexLabel: taux_dispo_reel+ " %",
                                    data: [taux_dispo_reel,(100-taux_dispo_reel)]
                                }
                            ],
                        };

                        var myChart = $("#myChart6");

                        var doughnutGraph = new Chart(myChart, {
                            type: 'doughnut',
                            data: chartdata,
                            options: {

                                cutoutPercentage: 80,
                                responsive: false,
                                elements: {
                                    center: {
                                        text: Number(taux_dispo_reel[0]).toFixed(2)+ " %",
                                        color: '#595959', // Default is #000000
                                        fontStyle: 'Calibri Light', // Default is Arial
                                        sidePadding: 50 // Defualt is 20 (as a percentage)
                                    }
                                },
                                legend: {
                                    display: false
                                },
                                tooltips: {
                                    enabled: true,
                                    mode: 'label',
                                    callbacks: {
                                        title: function(tooltipItems, data) {
                                            var idx = tooltipItems[0].index;
                                            return  data.labels[idx]; //do something with title
                                        },
                                        label: function(tooltipItem, data) {
                                            // get the data label and data value to display
                                            var value =  Number(data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index]).toFixed(2).toLocaleString()+' %';
                                            // return the text to display on the tooltip
                                            return value;
                                        }
                                    }
                                },
                                title: {
                                    display: true,
                                    text: ' ',
                                    fontSize: 20,
                                    fontFamily: 'Calibri'
                                },
                                animation: {
                                    animateScale: true,
                                    animateRotate: true
                                }
                            }
                        });
                    });
            }
        }
        function showGraph7() {
            {
                $.post("lib/datachart/taux_dispo_da_J.php",
                    function (data)
                    {
                        //console.log(data);

                        var taux_dispo_reel = [];
                        var descrip = [];



                        for (var i in data) {
                            taux_dispo_reel.push(data[i].taux);
                            descrip.push(data[i].descrip);


                        }

                        var chartdata = {
                            labels: ['<?php echo $lang["taux_dis_DA"]; ?>','<?php echo $lang["taux_ind_dis_DA"]; ?>'],
                            datasets: [
                                {
                                    backgroundColor: [
                                        'rgba(221, 59, 46,1)',
                                        'rgb(219,225,235)',

                                    ],
                                    borderColor: [
                                        'rgba(221, 59, 46,1)',
                                        'rgb(219,225,235)',

                                    ],

                                    borderWidth: 1,
                                    showInLegend: "true",
                                    legendText: taux_dispo_reel+ " %",
                                    indexLabelFontSize: 16,
                                    indexLabel: taux_dispo_reel+ " %",
                                    data: [taux_dispo_reel,(100-taux_dispo_reel)]
                                }
                            ],
                        };

                        var myChart = $("#myChart7");

                        var doughnutGraph = new Chart(myChart, {
                            type: 'doughnut',
                            data: chartdata,
                            options: {
                                cutoutPercentage: 80,
                                responsive: false,
                                elements: {
                                    center: {
                                        text: Number(taux_dispo_reel[0]).toFixed(2)+ " %",
                                        color: '#595959', // Default is #000000
                                        fontStyle: 'Calibri Light', // Default is Arial
                                        sidePadding: 50 // Defualt is 20 (as a percentage)
                                    }
                                },
                                legend: {
                                    display: false
                                },
                                tooltips: {
                                    enabled: true,
                                    mode: 'label',
                                    callbacks: {
                                        title: function(tooltipItems, data) {
                                            var idx = tooltipItems[0].index;
                                            return  data.labels[idx]; //do something with title
                                        },
                                        label: function(tooltipItem, data) {
                                            // get the data label and data value to display
                                            var value =  Number(data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index]).toFixed(2).toLocaleString()+' %';
                                            // return the text to display on the tooltip
                                            return value;
                                        }
                                    }
                                },
                                title: {
                                    display: true,
                                    text: ' ',
                                    fontSize: 20,
                                    fontFamily: 'Calibri'
                                },
                                animation: {
                                    animateScale: true,
                                    animateRotate: true
                                }
                            }
                        });
                    });
            }
        }
        function showGraph8() {
            {
                $.post("lib/datachart/taux_dispo_dc_J.php",
                    function (data)
                    {
                        //console.log(data);

                        var taux_dispo_reel = [];
                        var descrip = [];



                        for (var i in data) {
                            taux_dispo_reel.push(data[i].taux);
                            descrip.push(data[i].descrip);


                        }

                        var chartdata = {
                            labels: ['<?php echo $lang["taux_dis_DC"]; ?>','<?php echo $lang["taux_ind_dis_DC"]; ?>'],
                            datasets: [
                                {
                                    backgroundColor: [
                                        'rgb(89,89,89)',
                                        'rgb(219,225,235)',

                                    ],
                                    borderColor: [
                                        'rgb(89,89,89)',
                                        'rgb(219,225,235)',

                                    ],

                                    borderWidth: 1,
                                    showInLegend: "true",
                                    legendText: taux_dispo_reel+ " %",
                                    indexLabelFontSize: 16,
                                    indexLabel: taux_dispo_reel+ " %",
                                    data: [taux_dispo_reel,(100-taux_dispo_reel)]
                                }
                            ],
                        };

                        var myChart = $("#myChart8");

                        var doughnutGraph = new Chart(myChart, {
                            type: 'doughnut',
                            data: chartdata,
                            options: {
                                cutoutPercentage: 80,
                                responsive: false,
                                elements: {
                                    center: {
                                        text: Number(taux_dispo_reel[0]).toFixed(2)+ " %",
                                        color: '#595959', // Default is #000000
                                        fontStyle: 'Calibri Light', // Default is Arial
                                        sidePadding: 50 // Defualt is 20 (as a percentage)
                                    }
                                },
                                legend: {
                                    display: false
                                },
                                tooltips: {
                                    enabled: true,
                                    mode: 'label',
                                    callbacks: {
                                        title: function(tooltipItems, data) {
                                            var idx = tooltipItems[0].index;
                                            return  data.labels[idx]; //do something with title
                                        },
                                        label: function(tooltipItem, data) {
                                            // get the data label and data value to display
                                            var value =  Number(data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index]).toFixed(2).toLocaleString()+' %';
                                            // return the text to display on the tooltip
                                            return value;
                                        }
                                    }
                                },
                                title: {
                                    display: true,
                                    text: ' ',
                                    fontSize: 20,
                                    fontFamily: 'Calibri'
                                },
                                animation: {
                                    animateScale: true,
                                    animateRotate: true
                                }
                            }
                        });
                    });
            }
        }
        function showGraph9() {
            {
                $.post("lib/datachart/nbr_incid_service.php",
                    {
                        lang: my_lang
                    },
                    function (data)
                    {
                        //console.log(data);
                        var taux_dispo_reel = [];
                        var libelle = [];

                        for (var i in data)
                        {
                            taux_dispo_reel.push(data[i].nbr_incidents);
                            libelle.push(data[i].libelle);
                        }

                        var chartdata = {

                            labels: libelle,
                            datasets: [
                                {
                                    backgroundColor: [
                                        '#772a2e',
                                        '#d31d1a',
                                        '#e75543',
                                        '#f9bfae',
                                    ],
                                    borderColor: [
                                        '#772a2e',
                                        '#d31d1a',
                                        '#e75543',
                                        '#f9bfae',
                                    ],
                                    barThickness: 15,
                                    borderWidth: 0,
                                    data: taux_dispo_reel
                                }
                            ],
                        };


                        var myChart = $("#myChart9");

                        var doughnutGraph = new Chart(myChart, {
                            type: 'bar',
                            data: chartdata,
                            options: {
                                showAllTooltips: true,
                                cutoutPercentage: 80,
                                responsive: false,

                                legend: {
                                    display: false}
                                ,
                                tooltips: {
                                    display: true
                                },

                                //events: false,
                                title: {
                                    display: true,
                                    text: ' ',
                                    fontSize: 20,
                                    fontFamily: 'Calibri'
                                },
                                animation: {
                                    animateScale: true,
                                    animateRotate: true,
                                    onComplete: function () {
                                        var chartInstance = this.chart,
                                            ctx = chartInstance.ctx;
                                        ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
                                        ctx.textAlign = 'center';
                                        ctx.textBaseline = 'bottom';

                                        this.data.datasets.forEach(function (dataset, i) {
                                            var meta = chartInstance.controller.getDatasetMeta(i);
                                            meta.data.forEach(function (bar, index) {

                                                var data = dataset.data[index];
                                                ctx.fillText(data, bar._model.x, bar._model.y - 5);
                                            });
                                        });
                                    }
                                },
                                scales: {
                                    xAxes: [{
                                        gridLines: {
                                            display: true,
                                            drawTicks: false
                                        },
                                        ticks: {
                                            callback: function(value, index, values) {
                                                if(value==="Retrait d'argent" || value==="Cash withdrawal")
                                                {
                                                    return 'RA';
                                                }
                                                if(value==="Depot d'argent" || value==="Cash deposit")
                                                {
                                                    return 'DA';
                                                }
                                                if(value==="Depot de cheque" || value==="Check deposit")
                                                {
                                                    return 'DC';
                                                }
                                                if(value==="Autre transactions" || value==="Other transactions")
                                                {
                                                    return 'AT';
                                                }

                                            }
                                        }

                                    }],
                                    yAxes: [{

                                        ticks: {
                                            display:false,
                                            beginAtZero: true
                                        },
                                        gridLines: {
                                            display: false,
                                            drawTicks: false
                                        }
                                    }]
                                }
                            }
                        });
                    });
            }
        }

    </script>

    </body>

<?php
else:
    header("location: index.php");
endif

?>
</html>
