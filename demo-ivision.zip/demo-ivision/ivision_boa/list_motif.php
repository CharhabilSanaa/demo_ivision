<?php
session_start();
include("lib/lib.php");
if (verif_user($_SESSION['user'],$_SESSION['mdp'])==true):
    if(empty($_POST['keyword'])){$_POST['keyword']="";}
    if(empty($_POST['iterminal2'])){$_POST['iterminal2']="";}

    if((strlen(antixss($_POST['keyword']))>=0) && (strlen(antixss($_POST['keyword']))<=20) )
    {
        if(strlen(antixss($_POST['keyword']))>=3)
        {
            $connexion = ma_db_connexion();
            $keyword = '%'.$_POST['keyword'].'%';
            $sql = "SELECT `id_intevention`,`libelle_intevention` FROM `new_action_intervention` 
		WHERE UPPER(`id_intevention`) LIKE '%".strtoupper($keyword)."%'
		OR  UPPER(`libelle_intevention`) LIKE '%".strtoupper($keyword)."%'
		OR  UPPER(`libelle_intevention`) LIKE '".strtoupper($keyword)."%'
		OR  UPPER(`libelle_intevention`) LIKE '%".strtoupper($keyword)."'
		ORDER BY libelle_intevention ASC
		LIMIT 30";



            $result=mysqli_query($connexion,$sql);
            if (!$result)
            {
                error_log("Erreur sql 020:  ".$sql."   ".mysqli_error($connexion));
                die('ERREUR QUERY 020 !');
            }

            if ($result)
            {
                while ($row = mysqli_fetch_assoc($result))
                {
                    echo '<li ><a onClick="javascript:get_motif_arret(\''.addslashes($row["libelle_intevention"]).'\',\''.$row["id_intevention"].'\',\''.$_POST['iterminal2'].'\');hide_motif_arret()">'.$row["libelle_intevention"].'-'.$row["id_intevention"].' </a>	</li>';
                }
                mysqli_free_result($result);
            }
        }
    }

    ?>
<?php
else:
    header('Location: index.php');
endif;
?>