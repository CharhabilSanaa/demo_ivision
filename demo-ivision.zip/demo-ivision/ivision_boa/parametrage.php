<?php
include "lib/auth/config.php";

?>
<!DOCTYPE html>
<html lang="<?php echo $lang['lang'];?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php include 'header_star.php'; ?>

</head>
<?php

if (verif_user($_SESSION['user'],$_SESSION['mdp'])==true): ?>
    <?php if ((verif_user($_SESSION['user'],$_SESSION['mdp'])==true) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true))): ?>

        <?php
        if(empty($_POST['terminal'])){$_POST['terminal']="";}
        if(empty($_POST['date_debut'])){$_POST['date_debut']="";}
        if(empty($_POST['date_fin'])){$_POST['date_fin']="";}
        if(empty($_POST['historique_vacation'])){$_POST['historique_vacation']="";}
        ?>

        <body class="c-app">

        <?php
        include 'sidebar.php';
        ?>
        <div class="c-wrapper c-fixed-components">
            <?php  include 'navbar_star.php'; ?>
            <div class="c-body">
                <main class="c-main">
                    <div class="container-fluid">
                        <div class="fade-in">
                            <input type="hidden" id="hdnSession" data-value="13"/>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="start.php">I-Vision</a></li>
                                    <li class="breadcrumb-item"><a href="suiviGAB.php"><?php echo $lang['admin'];?></a></li>
                                    <li class="breadcrumb-item" aria-current="page">Incident settings</li>
                                </ol>
                            </nav>

                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">

                                        <div class="card-header"><i class="fa fa-align-justify"></i> <?php echo $lang['park_gab'];?></div>
                                        <div class="card-body">

                                            <?php
                                            if ((verif_habilitation($_SESSION['habilitation_backoffice'],9)==true)):

                                                include("pagination.php");
                                                getpanelparame();
                                                getFormParametragePassive();
                                                getFormParametrageMontantCassettes();
                                                getFormParametrageSupervisorMode();
                                                getFormParametragetimeOutCommand_Compagn();
                                                getFormParametrageEventJRN();

                                            else:
                                                echo '<p class="alert alert-danger"> PAGE UNAUTHORIZED !!</p>';
                                            endif
                                            ?>

                                        </div>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.col-lg-4 (nested) -->

                                <!-- /.col-lg-8 (nested) -->
                            </div>

                        </div>
                    </div>
                </main>
            </div>

        </div>

        <?php

        //header NAV Bar
        include 'footer.php';

        ?>



        </body>

    <?php
    else:
        header("location: start.php");
    endif ?>
<?php
else:
    header("location: index.php");
endif ?>
</html>
