<?php
include "lib/auth/config.php";

?>
<!DOCTYPE html>
<html lang="<?php echo $lang['lang'];?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php include 'header_star.php'; ?>

</head>
<?php

if (verif_user($_SESSION['user'],$_SESSION['mdp'])==true): ?>
    <?php if ((verif_user($_SESSION['user'],$_SESSION['mdp'])==true) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true))): ?>

        <?php
        if(empty($_GET['ternimal'])){$_GET['ternimal']="";}
        if(empty($_GET['id'])){$_GET['id']="";}
        ?>

        <body class="c-app">

        <?php
        include 'sidebar.php';
        ?>
        <div class="c-wrapper c-fixed-components">
            <?php  include 'navbar_star.php'; ?>
            <div class="c-body">
                <main class="c-main">
                    <div class="container-fluid">
                        <div class="fade-in">
                            <input type="hidden" id="hdnSession" data-value="2"/>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="start.php">I-Vision</a></li>
                                    <li class="breadcrumb-item"><a href="start.php"><?php echo $lang['bank'];?></a></li>
                                    <li class="breadcrumb-item" ><a href="suiviIncident.php"><?php echo $lang['hist_inci'];?></a></li>
                                    <li class="breadcrumb-item" aria-current="page"><?php echo $lang['det_incid'];?></li>
                                </ol>
                            </nav>
                            <div id="liste_disponibilite_gab" class="row">
                                <?php
                                if((strlen(antixss($_GET['id']))>=0) && (strlen(antixss($_GET['id']))<=15) && (strlen(antixss($_GET['ternimal']))>=0) && (strlen(antixss($_GET['ternimal']))<=15))
                                {
                                    get_detail_gab($_GET['ternimal'],$_GET['id']);
                                }
                                ?>
                            </div>

                        </div>
                    </div>
                </main>
            </div>

        </div>

        <?php

        //header NAV Bar
        include 'footer.php';

        ?>



        </body>

    <?php
    else:
        header("location: start.php");
    endif ?>
<?php
else:
    header("location: index.php");
endif ?>
</html>
