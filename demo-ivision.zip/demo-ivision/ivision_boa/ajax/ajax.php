﻿<?php
 session_start(); 
if (!empty($_SESSION['user']) && !empty($_SESSION['mdp'])) 
{
include("../lib/lib.php");
error_reporting(1);
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="update_theme_interface")
{
	session_start();	
	update_theme_interface($_POST['libelle'],$_POST['parame']);
}
/////////////////////////////////////////////////////////////
if($_POST['function']=="declarer_incident_gab")
{
    session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        confirmerDeclarerAlerte($_POST['$id_ATM'],$_POST['name_ATM'],$_POST['Vacation'],$_POST['Erreur'],$_POST['statusXFS'],$_POST['categoryXFS'],$_POST['codeError'],$_POST['dateVacation']);
        getDetailPeripheralStatus($_POST['idGVacation'],$_POST['idVacation'],$_POST['tableVacation'],$_POST['xfsErreur'],$_POST['xfsStatus'],$_POST['nameVacation'],$_POST['histDateVacation'],$_POST['histNameFile'],1,$_POST['category'],$_POST['code_error'],$_POST['logical_name'],$_POST['paramAffichage']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }


	
}
/////////////////////////////////////////////////////////////
if($_POST['function']=="traiter_arret")
{
    session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
	//echo "idMotifTraiter: " .$_POST['$idMotifTraiter']."<br>";
	//echo "idMotifTraiter111: " .$_POST['idMotifTraiter111']."<br>";

    if(checkAuthJWT($token,$listHabill))
    {
		// $_POST['$terminal333']
		// $_POST['$ifTraiter333']
		// $_POST['$idMotifTraiter']
		// $_POST['$id_arret']
		//valider_etat_traitement_arret($_POST['terminal333'],$_POST['ifTraiter333'],$_POST['idMotifTraiter'], $_POST['valAction']);
		//echo "Traité (".getMotifTraiterById($_POST['idMotifTraiter']).")";
		$result=update_state_check($_POST['id_arret'],$_POST['terminal333'],$_POST['idMotifTraiter111']);
		
		if($result)
		{
			if($_POST['idMotifTraiter111']==2)
			{
				delete_checked_in_service_arret($_POST['id_arret']);
			}
			check_arret($_POST['terminal333'],"",1,$_POST['idMotifTraiter111'],$_POST['id_arret'],"");	
			
		}
		
		

	}
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action non autorisée</strong></div>';
        session_destroy();
        // http_response_code(401);
    }


	
}


/////////////////////////////////////////////////////////////
if($_POST['function']=="getDetailHistotiquePeripheralStatus")
{
	session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getDetailHistotiquePeripheralStatus($_POST['paramettre'],$_POST['idprivilege'],$_POST['id_atm'],$_POST['id_vacation'],$_POST['tableVacation'],$_POST['xfsErreur'],$_POST['xfsStatus'],$_POST['nameVacation'],$_POST['histDateVacation'],$_POST['histNameFile'],1,$_POST['category'],$_POST['code_error'],$_POST['logical_name'],$_POST['paramAffichage'],$_POST['id_service'],$_POST['id_logical_name']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_nom_gab")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_nom_gab($_POST['id'],$_POST['nom_gab']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="getAjouterRegion")
{
    $listHabill=array(15);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getAjouterRegion();
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="getAjouterProfil")
{
    $listHabill=array(15);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getAjouterProfil();
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="suppimerRegion")
{
	// session_start();
    $listHabill=array(15);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        suppimerRegion($_POST['id_sup']);
        suiviRegion();
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="suppimerProfil")
{
	// session_start();
    $listHabill=array(15);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        suppimerProfil($_POST['id_profil']);
        suiviRegion();
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="ajouterRegion")
{
    $listHabill=array(15);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        ajouterRegion($_POST['region']);
        suiviRegion();
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="ajouterProfil")
{
    $listHabill=array(15);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        ajouterProfil($_POST['profil']);
        suiviRegion();
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}	
/////////////////////////////////////////////////////////////
if($_POST['function']=="getDetailPeripheralStatusSpinner")
{
							 echo '
									<div class="modal-dialog modal-lg">
										<div class="modal-content" style="background-color:#e9ecef;color:#2b3449;">																										  
												<!-- Modal Header -->
												<div class="modal-header">
													<h4 class="modal-title">Details peripheral <strong style="font-size:18px;font-weight:bold;color:#e7722c;" ></strong></h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
																										
												<!-- Modal body -->
												<div class="modal-body">
												
														<img src="img/spinnerIPRC.gif" />
												</div>
																										
												<!-- Modal footer -->
												<div class="modal-footer">
														<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
																										
										</div>
							</div>';	
}
/////////////////////////////////////////////////////////////
if($_POST['function']=="getDetailPeripheralStatus")
{
	session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getDetailPeripheralStatus($_POST['paramettre'],$_POST['idprivilege'],$_POST['id_atm'],$_POST['idVacation'],$_POST['tableVacation'],$_POST['xfsErreur'],$_POST['xfsStatus'],$_POST['nameVacation'],$_POST['histDateVacation'],$_POST['histNameFile'],1,$_POST['category'],$_POST['code_error'],$_POST['logical_name'],$_POST['paramAffichage']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
    // echo "<img src='img/spinnerIPRC.gif '  position='absolute;'/>";

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="getDetailVacationPeripheralStatus")
{
	session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getDetailPeripheralStatus($_POST['paramettre'],$_POST['idprivilege'],$_POST['id_atm'],$_POST['idVacation'],$_POST['tableVacation'],$_POST['xfsErreur'],$_POST['xfsStatus'],$_POST['nameVacation'],$_POST['histDateVacation'],$_POST['histNameFile'],1,$_POST['category'],$_POST['code_error'],$_POST['logical_name'],$_POST['paramAffichage']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="updateXFSErrors")
{
	session_start();

    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        updateXFSErrors($_POST['paramettre'],$_POST['idprivilege'],$_POST['logical_name'],$_POST['id_atm'],$_POST['id_service'],$_POST['id_error'],$_POST['etatVal']);
        // echo $_POST['nameVacation'];
        getDetailPeripheralStatus($_POST['paramettre'],$_POST['idprivilege'],$_POST['id_atm'],$_POST['idVacation'],$_POST['tableVacation'],$_POST['xfsErreur'],$_POST['xfsStatus'],$_POST['nameVacation'],$_POST['histDateVacation'],$_POST['histNameFile'],1,$_POST['category'],$_POST['code_error'],$_POST['logical_name'],$_POST['paramAffichage']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="getDeclarerPeripheralStatus")
{
	session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getDetailPeripheralStatus($_POST['paramettre'],$_POST['idprivilege'],$_POST['id_atm'],$_POST['idVacation'],$_POST['tableVacation'],$_POST['xfsErreur'],$_POST['xfsStatus'],$_POST['nameVacation'],$_POST['histDateVacation'],$_POST['histNameFile'],2,$_POST['category'],$_POST['code_error'],$_POST['logical_name'],$_POST['paramAffichage']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_remarque2")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_remarque_incident($_POST['id'],$_POST['remarque']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="modifier_remarque2")
{
    session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        modifier_remarque2($_POST['remarque'],$_POST['id_incident']);
        get_remarque_incident($_POST['id_incident'],$_POST['remarque']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        //session_destroy();
        // http_response_code(401);
    }

}

/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_remarque_incident")
{
session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_remarque_incident($_POST['id'],$_POST['remarque']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        //session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////
if($_POST['function']=="modifiernumSerie")
{ 
session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        modifiernumSerie($_POST['numSerie'],$_POST['id']);
        getNumSerie($_POST['id'],$_POST['numSerie']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="suppimerTerminal")
{   session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        if(empty($_POST['recherche'])){$_POST['recherche']="";}
        if(empty($_GET['page'])){$_GET['page']="";}
        include("../pagination.php");
        suppimerTerminal($_POST['id_atm']);
        suiviListeGAB($_POST['recherche'],$_GET['page']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="suppimerAgence")
{   session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        if(empty($_POST['recherche'])){$_POST['recherche']="";}
        if(empty($_GET['page'])){$_GET['page']="";}
        include("../pagination.php");
        suppimerAgence($_POST['code_agence']);
        suiviListeAgence($_POST['recherche'],$_GET['page']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_numSerie")
{
session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getNumSerie($_POST['id'],$_POST['numSerie']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="getupdateNumSerie")
{
    session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {

        getupdateNumSerie($_POST['id'],$_POST['Numserie']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_num_affectation2")
{
session_start();

    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_num_affectation($_POST['id'],$_POST['num_affectation']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////
if($_POST['function']=="modifier_num_tiket_bcp")
{ 
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        modifier_num_tiket_bcp($_POST['num_tiket_abi'],$_POST['id_incident']);
        get_num_affectation($_POST['id_incident'],$_POST['num_tiket_abi']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_num_affectation")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_num_affectation($_POST['id'],$_POST['num_affectation']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////
if($_POST['function']=="modifier_nom_gab2")
{ 
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        modifier_nom_gab2($_POST['nom_gab'],$_POST['id']);
        get_nom_gab($_POST['id'],$_POST['nom_gab']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_adresse_ip2")
{
    session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_adresse_ip2($_POST['id'],$_POST['adresse_ip']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}
/////////////////////////////////////
if($_POST['function']=="modifier_adresse_ip2")
{ 
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        modifier_adresse_ip2($_POST['adresse_ip'],$_POST['id']);
        get_adresse_ip2($_POST['id'],$_POST['adresse_ip']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_adresse_ip")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_adresse_ip($_POST['id'],$_POST['adresse_ip']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_nom_gab2")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_nom_gab($_POST['id'],$_POST['nom_gab']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}
////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_etat_auto_clo")
{
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        if ($_POST['auto_clo']==0)	{$auto_clo=1;}else{$auto_clo=0;}
        update_auto_clo($_POST['id'],$auto_clo,$_POST['id_gab']);
        get_statut_auto_clo($_POST['id'],$auto_clo,$_POST['id_gab']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="getConfigServiceATM")
{
	session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getConfigServiceATM($_POST['paramettre'],$_POST['idprivilege'],$_POST['id_atm'],$_POST['date_debut'],$_POST['date_fin'],$_POST['historique_vacation']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}

if($_POST['function']=="cloturer_incident_fonctionnelle2")
{
session_start();
include("../pagination.php");
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        cloturer_incident_fonctionnelle($_POST['id_incident'],$_POST['date_cloture'],$_POST['option']);
        liste_rappel($_POST['recherche_user']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="getVacationATM")
{
	session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        // echo $_POST['date_debut']." =================== ".$_POST['date_fin']." =================== ".$_POST['historique_vacation'];
        getVacationATM($_POST['paramettre'],$_POST['idprivilege'],$_POST['id_atm'],$_POST['date_debut'],$_POST['date_fin'],$_POST['vacation_date']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="verif_declaration_gab")
{
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_verif_declaration_incident_gab(trim($_POST['id_gab']));
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}
/////////////////////////////////////////////////////////////

if($_POST['function']=="vider_verif_declaration_gab")
{
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        vider_verif_declaration_gab();
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}
/////////////////////////////////////////////////////////////
if($_POST['function']=="actueliser_date_arret")
{
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        actueliser_date_arret();
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}
/////////////////////////////////////////////////////////////
if($_POST['function']=="afficher_loupe")
{
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        if (get_verif_gab(trim($_POST['id_gab']))>="1")
        {
            getDetailGabDetailIncident($_POST['id_gab']);
        }
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////

if($_POST['function']=="actueliser_date_rappel")
{
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        actueliser_date_rappel();
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}
/////////////////////////////////////////////////////////////
if($_POST['function']=="afficher_btn_ajouter")
{
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        if (get_verif_gab(trim($_POST['id_gab']))>="1")
        {
            afficher_btn_ajouter();
        }
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="afficher_information_historique_gab")
{
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_list_information_historique_gab(trim($_POST['id_gab']));

    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}

/////////////////////////////////////////////////////////////
if($_POST['function']=="afficher_ping")
{

    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        if (get_verif_gab(trim($_POST['id_gab']))>="1")
        {
            afficher_ping($_POST['id_gab']);
        }

    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="getdeatil_per")
{

    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        if (get_verif_gab(trim($_POST['id_gab']))>="1")
        {
            getdeatil_per($_POST['id_gab']);
        }

    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_motif_arret")
{
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_motif_arret($_POST['motif'],$_POST['idmotif'],$_POST['terminal']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_generer_mail")
{

    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        list($libelle_niveau, $code_intrevetion) = explode('-', $_POST['motif']);
        $date_arret=$_POST['inputarret'];

       /* echo'<label for="inputsuivant3" class="col-sm-3"></label>
					<div class="col-sm-9"> 
						<a tabindex="-1"  onClick="javascript:get_mail_prestataire_declarer(\''.trim($_POST['terminal']).'\',\''.trim($code_intrevetion).'\',\''.trim($date_arret).'\',\''.$code_intrevetion.'\')"  class="btn btn-info"  data-target="#mail_prestataire_declarer"  data-toggle="modal" >   Générer mail  </a>	
					</div>';*/
       //if((get_verif_mail_gab_abi2($code_intrevetion,$_POST['terminal'])=="1"))
       if($code_intrevetion)
       {
           if ($_SESSION['lang']=='fr')
           {
               echo '<button type="button" tabindex="-1" onClick="javascript:get_mail_prestataire_declarer(\''.trim($_POST['terminal']).'\',\''.trim($code_intrevetion).'\',\''.trim($date_arret).'\',\''.trim($_POST['id_affecter']).'\')"  class="btn btn-block btn-info active" data-target="#mail_prestataire_declarer"  data-toggle="modal">  Générer email</button>';
           }
           else
           {
               echo '<button type="button" tabindex="-1" onClick="javascript:get_mail_prestataire_declarer(\''.trim($_POST['terminal']).'\',\''.trim($code_intrevetion).'\',\''.trim($date_arret).'\',\''.trim($_POST['id_affecter']).'\')"  class="btn btn-block btn-info active" data-target="#mail_prestataire_declarer"  data-toggle="modal">  Generate email</button>';
           }
       }
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}/////////////////////////////////////////////////////////////

if($_POST['function']=="get_mail_prestataire_declarer")
{
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
		get_mail_prestataire_declarer($_POST['terminal'],$_POST['motif'],$_POST['hour'],$_POST['intervention']);

    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////
if($_POST['function']=="ajouter_rappel_detail")
{
	session_start();

    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        include("../pagination.php");

        $connexion=ma_db_connexion();

        $dateactuel=date('Y-m-d  H:i:s', mktime(date("H")+regle_heure_backoffice(), date('i'), date('s'),date('m'),date('d'),date('Y')));
        $niveau_intervention=get_return_array_degre_inertvention(((empty($_POST['id_action_interv_3'])) ? $_POST['id_action_interv_4'] : $_POST['id_action_interv_3']));


        $date_rappel=get_date_rappel2_declaration(((empty($_POST['date_rappel_3'])) ? $_POST['date_rappel_4'] : $_POST['date_rappel_3']),date_transaction($dateactuel),$niveau_intervention,$_POST['id_affecter_3']);
        $date_declaration=$dateactuel;
        if ($_POST['option']=="1")//relance FRM DETAIL
        {
            $_POST['type_contact_3']="Relance";
            $id_incident= $_POST['id_incident_3'];
            $SQL ="SELECT id_incident FROM new_incident_gab_ouvert WHERE id_incident LIKE '".mysqli_real_escape_string($connexion,$id_incident)."'";
            mysqli_query($connexion,"SET CHARACTER SET 'utf8'");
            $ifOpen=mysqli_query($connexion,$SQL);
            if (!$ifOpen)
            {
                error_log("Erreur SQL 000111:  ".$SQL."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 000111 !');
            }
            if ($ifOpen)
            {
                if (mysqli_num_rows($ifOpen)==0)
                {
                    $SQL1 ="SELECT id_gab FROM new_incident_gab WHERE id_incident LIKE '".mysqli_real_escape_string($connexion,$id_incident)."'";
                    $recupGab=mysqli_query($connexion,$SQL1);
                    if (!$recupGab)
                    {
                        error_log("Erreur SQL 000112:  ".$SQL1."  " .mysqli_error($connexion));
                        die(' ERREUR QUERY 000112 !');
                    }
                    if ($recupGab)
                    {
                        while ($row= mysqli_fetch_assoc($recupGab))
                        {
                            $gab = $row["id_gab"];
                        }
                        mysqli_free_result($recupGab);
                    }
                    $SQL2="SELECT id_incident FROM new_incident_gab_ouvert WHERE id_gab LIKE '".mysqli_real_escape_string($connexion,$gab)."' ";
                    $control=mysqli_query($connexion,$SQL2);
                    if (!$control)
                    {
                        error_log("Erreur SQL 000113:  ".$SQL2."  " .mysqli_error($connexion));
                        die(' ERREUR QUERY 000113 !');
                    }
                    if ($control)
                    {
                        if (mysqli_num_rows($control)>0)
                        {
                            while ($row2= mysqli_fetch_assoc($control))
                            {
                                $incOpen = $row2["id_incident"];
                            }
                            get_detail_gab_erreur_modif($_POST['id_terminal_3'],$_POST['id_incident_3'],$incOpen);
                            echo'<div>
                            <strong style="color:#b70101" >Attention!: Un incident est déjà ouvert pour ce Gab sous le numéro de dossier  '.$incOpen.'</strong> 
                        </div>';
                        }
                        else
                        {
                            ajouter_rappel_gab($_POST['type_contact_3'],$_POST['id_incident_3'], $date_rappel,$_POST['id_action_interv_3'],$_POST['id_remarque_3'],$_POST['id_note_3'],$niveau_intervention,$date_declaration,$_POST['persone_avise'],$_POST['id_affecter_3'],$_POST['id_appel_3'],$_POST['id_etat_3']);
                            get_detail_gab($_POST['id_terminal_3'],$_POST['id_incident_3']);

                        }
                        mysqli_free_result($control);
                    }

                }
                else
                {
                    ajouter_rappel_gab($_POST['type_contact_3'],$_POST['id_incident_3'], $date_rappel,$_POST['id_action_interv_3'],$_POST['id_remarque_3'],$_POST['id_note_3'],$niveau_intervention,$date_declaration,$_POST['persone_avise'],$_POST['id_affecter_3'],$_POST['id_appel_3'],$_POST['id_etat_3']);
                    get_detail_gab($_POST['id_terminal_3'],$_POST['id_incident_3']);
                }
                mysqli_free_result($ifOpen);
            }
        }
        elseif ($_POST['option']=="20")
        {
            $_POST['type_contact_3']="Relance";
            ajouter_rappel_gab($_POST['type_contact_3'],$_POST['id_incident_3'], $date_rappel,$_POST['id_action_interv_3'],$_POST['id_remarque_3'],$_POST['id_note_3'],$niveau_intervention,$date_declaration,$_POST['persone_avise']);
            liste_gab_admin_suivi($_POST['recherche_user']);

        }
        elseif ($_POST['option']=="21")
        {
            $_POST['type_contact_3']="Relance";
            ajouter_rappel_gab($_POST['type_contact_4'],$_POST['id_incident_4'], $date_rappel,$_POST['id_action_interv_4'],$_POST['id_remarque_4'],$_POST['id_note_4'],$niveau_intervention,$date_declaration,$_POST['persone_avise']);
            liste_gab_admin_suivi($_POST['recherche_user']);

        }
        elseif ($_POST['option']=="2")
        {
            ajouter_rappel_gab($_POST['type_contact_4'],$_POST['id_incident_4'], $date_rappel,$_POST['id_action_interv_4'],$_POST['id_remarque_4'],$_POST['id_note_4'],$niveau_intervention,$date_declaration,$_POST['persone_avise']);
            get_detail_gab($_POST['id_terminal_4'],$_POST['id_incident_4']);
        }

        elseif ($_POST['option']=="3")
        {
            $etat=$_POST['etat_incident_5'];
            $id_incident= $_POST['id_incident_5'];
            $Open="SELECT id_incident FROM new_incident_gab_ouvert WHERE id_incident LIKE '".mysqli_real_escape_string($connexion,$id_incident)."'";
            $ifOpen=mysqli_query($connexion,$Open);
            if (!$ifOpen)
            {
                error_log("Erreur SQL 000114:  ".$Open."  " .mysqli_error($connexion));
                die(' ERREUR QUERY 000114 !');
            }
            if ($ifOpen)
            {
                if (mysqli_num_rows($ifOpen)==0)
                {
                    if ($etat==0)
                    {
                        if ($etat==0)
                        {
                            $date_remise='0000-00-00 00:00:00';
                            $SQL_ouv="UPDATE `new_incident_gab` SET `date_remise`='".$date_remise."', `etat_incident`='".$etat."' WHERE  `id_incident`=  '".$id_incident."'";
                            //var_dump($SQL_ouv);
                            $resultSQL_ouv=mysqli_query($connexion,$SQL_ouv);
                            if (!$resultSQL_ouv)
                            {
                                error_log("Erreur SQL 000115_1:  ".$SQL_ouv."  " .mysqli_error($connexion));
                                die(' ERREUR QUERY 000115_1 !');
                            }
                            $SQL_ouv1="UPDATE `new_intevention_incident` SET `etat_cloture` = '0' WHERE  `id_incident` =  '".$id_incident."'";
                            //var_dump($SQL_ouv1);
                            $resultSQL_ouv1=mysqli_query($connexion,$SQL_ouv1);
                            if (!$resultSQL_ouv1)
                            {
                                error_log("Erreur SQL 000115_2:  ".$SQL_ouv1."  " .mysqli_error($connexion));
                                die(' ERREUR QUERY 000115_2 !');
                            }
                             mysqli_free_result($resultSQL_ouv1);
                        }
                        $rGab="SELECT id_gab FROM new_incident_gab WHERE id_incident = '".mysqli_real_escape_string($connexion,$id_incident)."' ";
                        $recupGab=mysqli_query($connexion,$rGab);
                        if (!$recupGab)
                        {
                            error_log("Erreur SQL 000115:  ".$rGab."  " .mysqli_error($connexion));
                            die(' ERREUR QUERY 000115 !');
                        }
                        if ($recupGab)
                        {
                            if (mysqli_num_rows($recupGab)==0)
                            {
                                while ($row= mysqli_fetch_assoc($recupGab))
                                {
                                    $gab = $row["id_gab"];
                                }
                            }
                            mysqli_free_result($recupGab);
                        }
                        $contr="SELECT id_incident FROM new_incident_gab_ouvert WHERE id_gab LIKE '".mysqli_real_escape_string($connexion,$gab)."' ";
                        $control=mysqli_query($connexion,$contr);
                        if (!$control)
                        {
                            error_log("Erreur SQL 000116:  ".$contr."  " .mysqli_error($connexion));
                            die(' ERREUR QUERY 000116 !');
                        }

                        if ($control)
                        {
                            $etaControlReouverture=controlReouvertureDossierIncident($_POST['id_terminal_5'],$id_incident);
                            $controlDurReouvDossier=control_duree_reouverture_dossier($id_incident);
                           /* if ( $etaControlReouverture==0 OR $controlDurReouvDossier==1)
                            {
                                if (mysqli_num_rows($control)>0)
                                {
                                    while ($row2= mysqli_fetch_assoc($control))
                                    {
                                        $incOpen = $row2["id_incident"];
                                    }
                                    get_detail_gab_erreur_modif($_POST['id_terminal_5'],$_POST['id_incident_5'],$incOpen);
                                }
                                else if($etaControlReouverture==0)
                                {
                                    echo '  <div class="alert alert-danger">
                                        <strong style="color:#b70101" >Attention! Vous ne pouvez pas ouvrir ce dossier: Un incident a était déjà enregistré après celui-là</strong>
                                    </div>';
                                 //   get_detail_gab_erreur_control_reouverture_dossier($_POST['id_terminal_5'],$_POST['id_incident_5']);
                                }
                                else if ($controlDurReouvDossier==1)
                                {
                                    get_detail_gab_erreur_control_duree_reouverture_dossier($_POST['id_terminal_5'],$_POST['id_incident_5']);
                                }

                                get_detail_gab($_POST['id_terminal_5'],$_POST['id_incident_5']);

                            }
                            else
                            {
                                modifier_incident_gab($_POST['id_incident_5'],$_POST['id_intervention_5'],date_transaction($_POST['date_arret_5']),$_POST['date_remis_5'],$_POST['date_rappel_5'],$_POST['etat_incident_5']);
                                get_detail_gab($_POST['id_terminal_5'],$_POST['id_incident_5']);
                            }*/

                            modifier_incident_gab($_POST['id_incident_5'],$_POST['id_intervention_5'],date_transaction($_POST['date_arret_5']),$_POST['date_remis_5'],$_POST['date_rappel_5'],$_POST['etat_incident_5']);
                            get_detail_gab($_POST['id_terminal_5'],$_POST['id_incident_5']);


                            mysqli_free_result($control);
                        }
                    }
                    else
                    {
                        modifier_incident_gab($_POST['id_incident_5'],$_POST['id_intervention_5'],date_transaction($_POST['date_arret_5']),$_POST['date_remis_5'],$_POST['date_rappel_5'],$_POST['etat_incident_5']);
                        get_detail_gab($_POST['id_terminal_5'],$_POST['id_incident_5']);
                    }
                }
                else
                {
                    modifier_incident_gab($_POST['id_incident_5'],$_POST['id_intervention_5'],date_transaction($_POST['date_arret_5']),$_POST['date_remis_5'],$_POST['date_rappel_5'],$_POST['etat_incident_5']);
                    get_detail_gab($_POST['id_terminal_5'],$_POST['id_incident_5']);
                }
                mysqli_free_result($ifOpen);
            }
        }
        elseif ($_POST['option']=="4")
        {
            cloturer_rappel_gab($_POST['id_incident_6'],$_POST['motif_cloturer_6'],$_POST['id_action_interv_6'],$_POST['date_cloturer_6']);
            get_detail_gab($_POST['id_terminal_6'],$_POST['id_incident_6']);

        }
        elseif ($_POST['option']=="5")
        {
            supprimer_action_intervention_gab($_POST['id_incident'],$_POST['id_intervention']);
            get_detail_gab($_POST['terminal'],$_POST['id_incident']);

        }
        elseif ($_POST['option']=="6")
        {
            modifier_intervention_incident($_POST['id_incident_8'],$_POST['id_intervention_8'],$_POST['date_intervention_8'],$_POST['date_rappel_8'],$_POST['nbr_tentative_8'],$_POST['id_action_interv_8'],$_POST['etat_incident_8'],$_POST['id_remarque_8'],$_POST['id_note_8'],$_POST['date_remise_8']);
            get_detail_gab($_POST['id_terminal_8'],$_POST['id_incident_8']);
        }
        elseif ($_POST['option']=="9")
        {

            cloturer_rappel_gab_fonctionnelle($_POST['id_incident_f'],$_POST['motif_cloturer_f'],$_POST['id_action_interv_f'],$_POST['date_cloturer_f']);
            get_detail_gab($_POST['id_terminal_f'],$_POST['id_incident_f']);
        }
        mysqli_close($connexion);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();

    }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////
if($_POST['function']=="ajouter_nouvelle_appel2")
{
    //todo:a voir
    session_start();

    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        $connexion=ma_db_connexion();
        $id_incident= $_POST['id_incident'];
        $Open="SELECT id_incident FROM new_incident_gab_ouvert WHERE id_incident LIKE '".mysqli_real_escape_string($connexion,$id_incident)."'";
        $ifOpen=mysqli_query($connexion,$Open);
        if (!$ifOpen)
        {
            error_log("Erreur SQL 000117:  ".$Open."  " .mysqli_error($connexion));
            die(' ERREUR QUERY 000117 !');
        }
        if($ifOpen)
        {
            if (mysqli_num_rows($ifOpen)==0)
            {
                $recup="SELECT id_gab FROM new_incident_gab WHERE id_incident LIKE '".mysqli_real_escape_string($connexion,$id_incident)."' ";
                $recupGab=mysqli_query($connexion,$recup);
                if (!$recupGab)
                {
                    error_log("Erreur SQL 000118:  ".$recup."  " .mysqli_error($connexion));
                    die(' ERREUR QUERY 000118 !');
                }
                if ($recupGab)
                {
                    while ($row= mysqli_fetch_assoc($recupGab))
                    {
                        $gab = $row["id_gab"];
                    }
                    mysqli_free_result($recupGab);
                }
                $cont="SELECT id_incident FROM new_incident_gab_ouvert WHERE id_gab LIKE '".mysqli_real_escape_string($connexion,$gab)."'";
                $control=mysqli_query($connexion,$cont);
                if (!$control)
                {
                    error_log("Erreur SQL 000119:  ".$cont."  " .mysqli_error($connexion));
                    die(' ERREUR QUERY 000119 !');
                }
                if($control)
                {
                    if (mysqli_num_rows($control)>0)
                    {
                        while ($row2= mysqli_fetch_assoc($control))
                        {
                            $incOpen = $row2["id_incident"];
                        }
                        get_nouveau_appel_gab_erreur($_POST['id_incident'],$incOpen);
                    }
                    else
                    {
                        ajouter_nouveau_appel($_POST['id_incident'],$_POST['id_motif_arret'],$_POST['txtnumaffectation'],$_POST['id_affectation'],$_POST['date_prise'],$_POST['id_rappel'],$_POST['degre_declaration'],$_POST['id_etat']);
                        get_nouveau_appel_gab($_POST['id_incident']);
                    }
                    mysqli_free_result($control);
                }

            }
            else
            {
                ajouter_nouveau_appel($_POST['id_incident'],$_POST['id_motif_arret'],$_POST['txtnumaffectation'],$_POST['id_affectation'],$_POST['date_prise'],$_POST['id_rappel'],$_POST['degre_declaration'],$_POST['id_etat']);
                get_nouveau_appel_gab($_POST['id_incident']);
            }
            mysqli_free_result($ifOpen);
        }

        mysqli_close($connexion);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();

    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_degre_appel2")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_nbr_degre_appel($_POST['id'],$_POST['degre_appel']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_date_arrete2")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_date_arrete($_POST['id'],$_POST['date_arrete']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}
/////////////////////////////////////
if($_POST['function']=="modifier_date_arrete2")
{ 
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        modifier_date_arrete2($_POST['date_arrete'],$_POST['id']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

get_date_arrete($_POST['id'],$_POST['date_arrete']);
}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_date_arrete")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_date_arrete($_POST['id'],$_POST['date_arrete']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////
if($_POST['function']=="get_nouveau_appel_gab")
{
session_start();
    $listHabill=array(20);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_nouveau_appel_gab($_POST['id_incident']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_nbr_escalade2")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_nbr_escalade($_POST['id'],$_POST['nbr_escalade']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_etat_contact2")
{
    session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_libelle_etat_contact1($_POST['id'],$_POST['etat_contact']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_id_affectation2")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_libelle_id_affectation($_POST['id'],$_POST['id_affectation']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="update_personne_avisee")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        update_personne_avisee($_POST['id'],$_POST['personne_avisee']);
        get_libelle_personne_avisee($_POST['id'],$_POST['personne_avisee']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_personne_avisee2")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_libelle_personne_avisee($_POST['id'],$_POST['nbr_escalade']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_personne_avisee")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_personne_avisee($_POST['id'],$_POST['personne_avisee']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_date_derniere_rappel2")
{
session_start();

    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_date_derniere_rappel($_POST['id'],$_POST['date_rappel']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////
if($_POST['function']=="modifier_dernier_rappel")
{ 
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        modifier_dernier_rappel($_POST['dernier_dtrappel'],$_POST['id_incident']);
        get_date_derniere_rappel($_POST['id_incident'],$_POST['dernier_dtrappel']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }


}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_date_derniere_rappel")
{
    session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_date_derniere_rappel($_POST['id'],$_POST['date_rappel']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_date_prise_en_charge2")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_date_prise_charge2($_POST['id'],$_POST['date_prise_en_charge2']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        //session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_rappel2")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_date_rappel2($_POST['id'],$_POST['date_rappel2']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_action_intervention2")
{
session_start();

    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_libelle_action_intervention1($_POST['id'],$_POST['idaction_intervention']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="update_nbr_degre_appel")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        update_nbr_degre_appel($_POST['id'],$_POST['degre_appel']);
        get_nbr_degre_appel($_POST['id'],$_POST['degre_appel']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_nbr_degre_appel")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_nbr_degre_appel($_POST['id'],$_POST['degre_appel']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="update_nbr_escalade")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        update_nbr_escalade($_POST['id'],$_POST['nbr_escalade']);
        get_nbr_escalade($_POST['id'],$_POST['nbr_escalade']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_nbr_escalade")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_nbr_escalade($_POST['id'],$_POST['nbr_escalade']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="update_id_etat_contact")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        update_id_etat_contact($_POST['id'],$_POST['etat_contact']);
        get_libelle_etat_contact1($_POST['id'],$_POST['etat_contact']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_id__etat_contact")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_id__etat_contact($_POST['id'],$_POST['etat_contact']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="update_id_affectation")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        update_id_affectation($_POST['id'],$_POST['id_affectation']);
        get_libelle_id_affectation($_POST['id'],$_POST['id_affectation']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_id_affectation")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_id_affectation($_POST['id'],$_POST['id_affectation']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="modifier_date_rappel2")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        modifier_date_rappel2($_POST['date_rappel2'],$_POST['id_action']);
        get_date_rappel2($_POST['id_action'],$_POST['date_rappel2']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_rappel2")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_rappel2($_POST['id'],$_POST['date_rappel2']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="modifier_date_prise_charge_iprc2")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        modifier_date_prise_charge_iprc2($_POST['date_prise_charge_iprc2'],$_POST['id_action']);
        get_date_prise_charge2($_POST['id_action'],$_POST['date_prise_charge_iprc2']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if($_POST['function']=="get_annuler_update_date_prise_charge_iprc2")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_date_prise_charge($_POST['id'],$_POST['date_prise_en_charge']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_date_prise_charge")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_date_prise_charge($_POST['id'],$_POST['date_prise_en_charge']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_date_prise_charge2")
{
session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_date_prise_charge2($_POST['id'],$_POST['date_prise_en_charge2']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
       // session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="update_id_action_intervention")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        update_id_action_intervention($_POST['id'],$_POST['idaction_intervention']);
        get_libelle_action_intervention1($_POST['id'],$_POST['idaction_intervention']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_update_action_intervention")
{
session_start();
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_update_action_intervention($_POST['id'],$_POST['idaction_intervention']);

    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
if($_POST['function']=="get_ajouter_rappel_detail")
{
    $listHabill=array(20);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {

        if ($_POST['option']=="0")
        {
            get_ajouter_rappel_detail_prestataire($_POST['terminal'],$_POST['id_incident'],$_POST['id_intervention'],$_POST['id_degre']);
        }
        elseif ($_POST['option']=="2")
        {
            get_modifier_incident_detail($_POST['terminal'],$_POST['id_incident'],$_POST['id_intervention'],$_POST['id_degre']);
        }
        elseif ($_POST['option']=="3")
        {
            get_cloturer_incident_detail($_POST['terminal'],$_POST['id_incident'],$_POST['id_intervention'],$_POST['id_degre']);
        }

    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="afficher_information_gab")
{

    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        if (get_verif_gab(trim($_POST['id_gab']))>="1")
        {
            get_list_information_gab2(trim($_POST['id_gab']));
        }
        else
        {
            get_gab_introuvable();
        }
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
if($_POST['function']=="afficher_affectation_gab")
{
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        afficher_affectation_gab(trim($_POST['id_gab']));
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }



}
if($_POST['function']=="afficher_nom_gab")
{
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        afficher_nom_gab(trim($_POST['id_gab']));
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }


}

/////////////////////////////////////////////////////////////
if($_POST['function']=="getConfigLogicalNameService")
{
	session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getConfigLogicalNameService($_POST['paramettre'],$_POST['idprivilege'],$_POST['id_atm'],$_POST['date_debut'],$_POST['date_fin'],$_POST['historique_vacation']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="getConfigStatusLogicalName")
{
	session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getConfigStatusLogicalName($_POST['paramettre'],$_POST['idprivilege'],$_POST['id_atm'],$_POST['date_debut'],$_POST['date_fin'],$_POST['historique_vacation']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="getConfigStatusXFSName")
{
	session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getConfigStatusXFSName($_POST['paramettre'],$_POST['idprivilege'],$_POST['id_atm'],$_POST['date_debut'],$_POST['date_fin'],$_POST['historique_vacation']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}

/////////////////////////////////////////////////////////////
if($_POST['function']=="getRedemarrerATM")
{
	session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {

        getRedemarrerATM($_POST['paramettre'],$_POST['idprivilege'],$_POST['id_atm'],$_POST['date_debut'],$_POST['date_fin'],$_POST['historique_vacation']);

    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}
/////////////////////////////////////////////////////////////

if($_POST['function']=="getPingATM")
{
	session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getPingATM($_POST['paramettre'],$_POST['idprivilege'],$_POST['id_atm'],$_POST['terminal'],$_POST['ip_adress']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}
/////////////////////////////////////////////////////////////

if($_POST['function']=="get_update_id_facturation")
{
	session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        if ($_POST['id_facturation']==0)
        {
            $id_facturation=1;
        }
        else
        {
            $id_facturation=0;
        }

        modifier_update_id_facturation2($id_facturation,$_POST['id']);
        get_num_facturation($_POST['id'],$id_facturation);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
}


/////////////////////////////////////////////////////////////
    if($_POST['function']=="getScreenshotATM")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            getScreenshotATM($_POST['id_atm']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
if($_POST['function']=="detailler_email_consigne")
{
    session_start();
    $listHabill=array(9);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];

    if(checkAuthJWT($token,$listHabill))
    {
        detailler_email_consigne($_POST['id_mail']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////

if($_POST['function']=="suppimer_mail_consigne")
{
    session_start();
    $listHabill=array(9);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];

    if(checkAuthJWT($token,$listHabill))
    {
        suppimer_mail_consigne($_POST['id_mail'],$_POST['id_intrevention']);
        get_id_mail_intervention2($_POST['id_mail']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////

if($_POST['function']=="ajouter_intrevention_consigne")
{
    session_start();
    $listHabill=array(9);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];

    if(checkAuthJWT($token,$listHabill))
    {
        ajouter_intrevention_consigne($_POST['id_intrevention'],$_POST['id_mail']);
        get_id_mail_intervention2($_POST['id_mail']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="ShowScreenshotATM")
{
    session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        ShowScreenshotATM($_POST['id_atm'],$_POST['value_cmd']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////

if($_POST['function']=="declarerNouveauGAB")
{
	session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        declarerNouveauGAB($_POST['paramettre'],$_POST['idprivilege'],$_POST['id_atm'],$_POST['date_debut'],$_POST['date_fin'],$_POST['historique_vacation']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="getModifierAgence")
{
	session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getModifierAgence($_POST['code_agence']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="getModifierGAB")
{
	session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getModifierGAB($_POST['id_atm']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="getModifierATMConfirmed")
{
    session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getModifierATMConfirmed($_POST['id_atm']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
    if($_POST['function']=="getDownloadFileGAB")
    {
        session_start();
        $listHabill=array(45);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            getDownloadFileGAB($_POST['id_atm'],$_POST['terminalID'],$_POST['idprivilege']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
/////////////////////////////////////////////////////////////
if($_POST['function']=="suppimer_gab_suivi")
{
session_start();
include("../pagination.php");
    $listHabill=array(2);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        suppimer_gab_suivi($_POST['id_incident']);
        liste_gab_admin_suivi($_POST['recherche_user']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="modifierAgence")
{
		if(empty($_POST['recherche'])){$_POST['recherche']="";}
include("../pagination.php");
	session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        modifierAgence($_POST['code_agence'],$_POST['name_agence'],$_POST['name_region'],$_POST['name_ville']);
        suiviListeAgence($_POST['recherche'],$_GET['page']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="modifierGAB")
{
    include("../pagination.php");
    session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        modifierGAB($_POST['id_atm'],$_POST['name_ATM'],$_POST['constucteur'],$_POST['cd_agance'],$_POST['ville'],$_POST['region'],$_POST['cd_terminal']);
        suiviListeGAB($_POST['recherche'],$_GET['page']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="modifierATMConfirmed")
{
    //include("../pagination.php");
	session_start();

    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        //var_dump($_POST['id_atm']);
        modifierATMConfirmed($_POST['id_atm'],$_POST['cd_ATM'],$_POST['cd_ATM_old'],$_POST['name_ATM'],$_POST['profil'],$_POST['constucteur'],$_POST['nbr_jr_file'],$_POST['state'],$_POST['send_statut'],$_POST['parse_journal'],$_POST['exec_command'],$_POST['depl_image'],$_POST['depl_binaire'],$_POST['sleep_command'],$_POST['state_depot_argent'],$_POST['state_depot_cheque'],$_POST['time_sleeping'],$_POST['cd_agence'],$_POST['state_uplaod_cmd']);
        get_etat_parc_atm($_POST['id_atm'],1,1,$_POST['date_debut'],$_POST['date_fin'],$_POST['historique_vacation'],'');
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="confirmeDeclarerNouveauGAB")
{

	session_start();

    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
		activerToutesStatusXFSErrors($_POST['id_atm']);
        confirmeDeclarerNouveauGAB(trim($_POST['id_atm']),trim($_POST['cd_ATM']),trim($_POST['name_ATM']),trim($_POST['name_agence']),trim($_POST['send_statut']),trim($_POST['parse_journal']),trim($_POST['exec_command']),trim($_POST['depl_image']),trim($_POST['depl_binaire']),trim($_POST['upload_command']),trim($_POST['constucteur']),trim($_POST['profil']),trim($_POST['cd_agance']),trim($_POST['ville']),trim($_POST['code_region']),trim($_POST['region']),trim($_POST['pays']),trim($_POST['ip_adresse_gab']));
        get_etat_parc_atm($_POST['id_atm'],1,1,$_POST['date_debut'],$_POST['date_fin'],$_POST['historique_vacation'],'');
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }
	// if ((verif_habilitation($_SESSION['autorisation_projet'],37)==true)&&(verif_habilitation($_SESSION['autorisation_projet'],34)==false)) {$affichage=2;}else{$affichage=1;}

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="activerToutesStatusXFSErrors")
{
	
	session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        activerToutesStatusXFSErrors($_POST['id_atm']);
        // echo $_POST['date_debut']." =================== ".$_POST['date_fin']." =================== ".$_POST['historique_vacation'];
        //get_etat_parc_atm($_POST['id_atm'],1,1,$_POST['date_debut'],$_POST['date_fin'],$_POST['historique_vacation'],'');
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="redemarrerATM")
{	
	session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        if(empty($_POST['idatm'])){$_POST['idatm']="";}
        redemarrerATM($_POST['id_atm']);
        //get_etat_parc_atm($_POST['idatm'],$_POST['paramettre'],$_POST['idprivilege']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}

/////////////////////////////////////////////////////////////
if($_POST['function']=="activerRedemarrerATM")
{
    session_start();

    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill) && $_POST['code_redemarage']=='1234')
    {
        redemarrerATM($_POST['id_atm']);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
        $encoded = json_encode($responseArray);
        header('Content-Type: application/json');
        echo $encoded;
        //session_destroy();
        // http_response_code(401);
    }


	// echo "ok";
	// echo $_POST['date_debut']." =================== ".$_POST['date_fin']." =================== ".$_POST['historique_vacation'];	
    // get_etat_parc_atm($_POST['idatm'],$_POST['paramettre'],$_POST['idprivilege'],$_POST['date_debut'],$_POST['date_fin'],$_POST['historique_vacation']);	
}
/////////////////////////////////////////////////////////////
    if($_POST['function']=="activerScreenshotATM")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill) && $_POST['code_redemarage']=='0000')
        {
            //echo  $_POST['code_redemarage'];
            ScreenshotATM($_POST['id_atm']);
        }
        else
        {
            $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
            $encoded = json_encode($responseArray);
            header('Content-Type: application/json');
            echo $encoded;
            //session_destroy();
            // http_response_code(401);
        }

    }

/////////////////////////////////////////////////////////////
    if($_POST['function']=="change_state")
    {
        session_start();
        $listHabill=array(44);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            change_state($_POST['id_atm']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
/////////////////////////////////////////////////////////////
if($_POST['function']=="confirmServiceATM")
{
	session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        ajouter_service_atm(substr($_POST['serviceCheckbox'], 0, -1),$_POST['idatm']);
        // echo $_POST['date_debut']." =================== ".$_POST['date_fin']." =================== ".$_POST['historique_vacation'];
        //get_etat_parc_atm($_POST['idatm'],$_POST['paramettre'],$_POST['idprivilege'],$_POST['date_debut'],$_POST['date_fin'],$_POST['historique_vacation']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }


}
/////////////////////////////////////////////////////////////
if($_POST['function']=="confirmLogicalNamesServiceATM")
{
	session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        confirmLogicalNamesServiceATM(substr($_POST['valLogicalname'], 0, -1),$_POST['idatm'],$_POST['idservice']);
        // echo $_POST['date_debut']." =================== ".$_POST['date_fin']." =================== ".$_POST['historique_vacation'];
        //get_etat_parc_atm($_POST['idatm'],$_POST['paramettre'],$_POST['idprivilege'],$_POST['date_debut'],$_POST['date_fin'],$_POST['historique_vacation']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="confirmSLogicalNamesServiceATM")
{
	session_start();
    $listHabill=array(44);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        confirmSLogicalNamesServiceATM(substr($_POST['valSLogicalname'], 0, -1),$_POST['idatm'],$_POST['idservice'],$_POST['id_logical_name'],$_POST['nameTable']);
        // echo $_POST['date_debut']." =================== ".$_POST['date_fin']." =================== ".$_POST['historique_vacation'];
        //get_etat_parc_atm($_POST['terminal'],$_POST['paramettre'],$_POST['idprivilege'],$_POST['date_debut'],$_POST['date_fin'],$_POST['historique_vacation']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="modifier_langue")
{	
	modifier_langue($_POST['id_langue'],$_POST['etat']);
	getLangue();	
}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="getAjouterRelance")
{	
	getAjouterRelance($_POST['id_alerte']);	
}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="getModifierAlerte")
{	
	getModifierAlerte($_POST['id_alerte']);	
}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="getModifierAction")
{	
	getModifierAction($_POST['id_alerte'],$_POST['id_action']);	
}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="getClotureRelance")
{	
	getClotureRelance($_POST['id_alerte']);	
}

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="getModifierPorteur")
{	
	// echo "Porteur --- ".$_POST['id_alerte']." --- ".$_POST['id_porteur'];	
	getModifierPorteur($_POST['id_alerte'],$_POST['id_porteur']);	
}

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="getUpdatePorteur")
{	
	// echo "Porteur --- ".$_POST['id_alerte']." --- ".$_POST['id_porteur'];	
	getUpdatePorteur($_POST['id_porteur']);	
}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="getNote")
{	
	getNote($_POST['id_action']);	
}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="cloturer_action_alerte")
{	
    session_start();
	$_POST['action']="";
	$date_acteul=date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y")));	
	cloturerAction($_POST['idAlerte'],$_POST['action'],$_POST['idTypeAppel'],'',$date_acteul,$_POST['dateCloture'],$_POST['note']);	
	detailAlerte($_POST['idAlerte']);
}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="update_porteur")
{	
				
    session_start();
	modifier_porteur($_POST['id_porteur'],trim($_POST['porteur']),trim($_POST['cin']),trim($_POST['numCompte']),trim($_POST['numCarte']),trim($_POST['gsm']),trim($_POST['etatGSM']));	
	detailPorteur($_POST['id_porteur']);
}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="modifier_porteur")
{	
				
    session_start();
	modifier_porteur($_POST['id_porteur'],trim($_POST['porteur']),trim($_POST['cin']),trim($_POST['numCompte']),trim($_POST['numCarte']),trim($_POST['gsm']),trim($_POST['etatGSM']));	
	detailAlerte($_POST['idAlerte']);
}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="ajouter_action_alerte")
{	
    session_start();
	$_POST['action']="";

	$date_acteul=date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y")));	
	$dateRappel=getDateRappel($_POST['dureeRappel'],$date_acteul,1);
	inserAction($_POST['idAlerte'],$_POST['action'],$_POST['idTypeAppel'],$_POST['idTypeRappel'],$_POST['idNiveauIntervention'],'',$date_acteul,$dateRappel);	
	detailAlerte($_POST['idAlerte']);
}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="modifier_actions")
{
    session_start();
	modifier_actions($_POST['id_alerteAC'],$_POST['id_actionAC'],$_POST['datePriseChargeAC'],$_POST['dateRappelAC'],$_POST['typeAppelAC'],$_POST['notAC'],$_POST['niveauInterventionAC'],$_POST['NBAppelAC'],$_POST['NBTentativeAC']);	
	detailAlerte($_POST['id_alerteAC']);
}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="modifier_alerte")
{	
    session_start();
	modifier_alerte($_POST['idAlerteA'],$_POST['dateArretA'],$_POST['datePriseChargeA'],$_POST['dateClotureA'],$_POST['porteurA'],$_POST['typeProduitA'],$_POST['typeBlocageA'],$_POST['EtatAlerteA'],$_POST['remarqueA']);	
	detailAlerte($_POST['idAlerteA']);
}
/////////////////////////////////////////////////////////////////////
if($_POST['function']=="declarerAlerte")
{

$_POST['action']="";
session_start();
getDeclarer2($_POST['porteur'],$_POST['numCarte'],$_POST['numCompte'],$_POST['cin'],$_POST['tel'],$_POST['etatTel'],$_POST['dureeRappel'],$_POST['typeProduit'],$_POST['typeAppel'],$_POST['typeBlocage'],$_POST['remarque']);
}
if($_POST['function']=="retourDeclarerAlerte")
{

$_POST['action']="";
session_start();
getDeclarer1($_POST['porteur'],$_POST['numCarte'],$_POST['numCompte'],$_POST['cin'],$_POST['tel'],$_POST['etatTel'],$_POST['dureeRappel'],$_POST['typeProduit'],$_POST['typeAppel'],$_POST['typeBlocage'],$_POST['remarque']);
}

if($_POST['function']=="confirmerDeclarerAlerte")
{

$_POST['action']="";
session_start();
$date_acteul=date("Y-m-d  H:i:s", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d"),date("Y")));	
if ($_POST['etatTel']==1)
{$dateRappel=$_POST['dureeRappel'];}
else
{$dateRappel=getDateRappel($_POST['dureeRappel'],$date_acteul,1);}
confirmerDeclarerAlerte($_POST['porteur'],$_POST['numCarte'],$_POST['numCompte'],$_POST['cin'],$_POST['typeProduit'],$_POST['action'],$_POST['typeAppel'],$_POST['typeBlocage'],$_POST['tel'],$_POST['etatTel'],$dateRappel,$date_acteul,$_POST['remarque']);
// getDeclarer2($_POST['porteur'],$_POST['numCarte'],$_POST['numCompte'],$_POST['cin'],$_POST['tel'],$_POST['etatTel'],$_POST['dureeRappel'],$_POST['typeProduit'],$_POST['typeAppel'],$_POST['typeBlocage'],$_POST['remarque']);
}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="suppimerAlerte")
{
	session_start();
	$_POST['recherche']="";
	include("../pagination.php");
	suppimerAlerte($_POST['id_alerte']);
	suiviAlertes($_POST['recherche']);
}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="suppimerAction")
{
	session_start();
	include("../pagination.php");
	suppimerAction($_POST['id_action'],$_POST['id_alerte']);
	detailAlerte($_POST['id_alerte']);
}

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="insert_form_upload_execution")
{
    session_start();
    $listHabill=array(45);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        insert_form_upload_execution($_POST['id_atm'],$_POST['path_upload']);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
        $encoded = json_encode($responseArray);
        header('Content-Type: application/json');
        echo $encoded;
        session_destroy();
        // http_response_code(401);

    }

}
//////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
    if($_POST['function']=="ShowFileUploadATM")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
           // var_dump($_POST['code_upload_content']);die();

            ShowFileUploadATM($_POST['id_atm'],$_POST['code_upload_content'],$_POST['state_upload']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
    /////////////////////////////////////////////////////////////
    if($_POST['function']=="DownFileUploadATM")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
           // var_dump($_POST['code_upload_content']);die();

            DownFileUploadATM($_POST['id_atm'],$_POST['code_upload_content'],$_POST['state_upload']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
    /////////////////////////////////////////////////////////////
    if($_POST['function']=="get_remarque_incident_pres")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {

            get_remarque_incident_pres($_POST['id_incident']);

        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="suppimerPorteur")
{
	session_start();
	$_POST['recherche']="";
	include("../pagination.php");
	suppimerPorteur($_POST['porteur']);
	suiviPorteur($_POST['recherche']);
}

}
else
{	
header('Location: index.php');
}	


?>