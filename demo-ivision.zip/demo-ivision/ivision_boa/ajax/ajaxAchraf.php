<?php
 session_start(); 
if (!empty($_SESSION['user']) && !empty($_SESSION['mdp'])) 
{
include("../lib/lib.php");
error_reporting(1);
/////////////////////////Partie Function////////////////////////////////////
if($_POST['function']==="uploadcompagne")
{
    session_start();
    $listHabill=array(24);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        uploadcompagne($_POST['nom_dépl'],$_POST['datedep'],$_POST['description_dépl'],$_POST['chemin_dépl'],$_POST['idatms'], $_FILES['uploadimage']);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
        $encoded = json_encode($responseArray);
        header('Content-Type: application/json');
        echo $encoded;
        session_destroy();
        // http_response_code(401);
    }
}
/////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']==="uploadschedule")
    {
        session_start();
        $listHabill=array(24);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            uploadschedule($_POST['nom_dépl'],$_POST['time_dep'],$_POST['frenq_date'],$_POST['description_dépl'],$_POST['idatms']);
        }
        else
        {
            $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
            $encoded = json_encode($responseArray);
            header('Content-Type: application/json');
            echo $encoded;
            session_destroy();
            // http_response_code(401);
        }
    }
/////////////////////////Partie Function////////////////////////////////////
if($_POST['function']==="uploadpic")
{
    session_start();

    $listHabill=array(25);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        uploadpic($_POST['hdin'],$_POST['pathimage'], $_FILES['uploadimage']);
    }
    else
    {

        $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
        $encoded = json_encode($responseArray);
        header('Content-Type: application/json');
        echo $encoded;
        session_destroy();
        // http_response_code(401);

    }

}
/////////////////////////Partie Function////////////////////////////////////
if($_POST['function']==="uploadpicprofil")
{
    session_start();
    $listHabill=array(26);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        uploadpicprofil($_POST['idatms'],$_POST['pathimage'], $_FILES['uploadimage']);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
        $encoded = json_encode($responseArray);
        header('Content-Type: application/json');
        echo $encoded;
        session_destroy();
        // http_response_code(401);

    }
}
/////////////////////////Partie Function////////////////////////////////////
if($_POST['function']=="updatecompagne")
{
    session_start();
    $listHabill=array(26);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        updatecompagne($_POST['id_compaign'],$_POST['nom_compagne'],$_POST['datedep'],$_POST['Chemin_images'],$_POST['idatms'],$_POST['checkbox_compagne']);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
        $encoded = json_encode($responseArray);
        header('Content-Type: application/json');
        echo $encoded;
        session_destroy();
        // http_response_code(401);

    }

}
/////////////////////////Partie Function////////////////////////////////////
if($_POST['function']=="updatescheduled")
{
    session_start();
    $listHabill=array(26);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        updatescheduled($_POST['id_compaign'],$_POST['nom_compagne'],$_POST['datedep'],$_POST['frequenxe'],$_POST['idatms'],$_POST['checkbox_compagne']);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
        $encoded = json_encode($responseArray);
        header('Content-Type: application/json');
        echo $encoded;
        session_destroy();
        // http_response_code(401);

    }

}
/////////////////////////Partie Function/////////////////////////////////////// /////////////////////////Partie Function////////////////////////////////////
if($_POST['function']=="RelaunchComp")
{
    session_start();

    $listHabill=array(26);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        RelaunchComp($_POST['id_compaign'],$_POST['id_atms']);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
        $encoded = json_encode($responseArray);
        header('Content-Type: application/json');
        echo $encoded;
        session_destroy();
        // http_response_code(401);
    }
}
/////////////////////////Partie Function////////////////////////////////////

if($_POST['function']=="uploadbinaireprofil")
{
    session_start();
    $listHabill=array(35);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {

       uploadbinaireprofil($_POST['idatms'],$_POST['pathbinaire'], $_FILES['uploadbinaire']);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
        $encoded = json_encode($responseArray);
        header('Content-Type: application/json');
        echo $encoded;
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////Partie Function////////////////////////////////////

if($_POST['function']=="getSendCommand")
{
    session_start();
    $listHabill=array(38);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getSendCommand($_POST['gabSelected'],$_POST['valeurCommande'],$_POST['pathconfigFinal']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////Partie Function////////////////////////////////////
if($_POST['function']=="getSendModeExecution")
{
    session_start();
    $listHabill=array(39);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getSendModeExecution($_POST['gabSelected'],$_POST['valeurCommande'],$_POST['valeurVersion']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }


}


    /////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="get_hist_deplo")
    {
        session_start();
        $listHabill=array(41);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];

        if(checkAuthJWT($token,$listHabill))
        {
            get_hist_deplo();
        }
        else
        {

            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
    /////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="get_Compagnes_pub")
    {
        session_start();
        $listHabill=array(24);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_Compagnes_pub();
        }
        else
        {

            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
    ////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="get_Schedule_pub")
    {
        session_start();
        $listHabill=array(24);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_schedule_ej_pub();
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
    /////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="get_hist_deplo_binaire")
    {
        session_start();
        $listHabill=array(42);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_hist_deplo_binaire();
        }
        else
        {

            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
    /////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="get_hist_redemarrage")
    {
        session_start();
        $listHabill=array(42);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_hist_redemarrage();
        }
        else
        {

            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
/////////////////////////Partie Function////////////////////////////////////

 /////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="get_hist_monitor_server")
    {
        session_start();
        $listHabill=array(43);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_hist_monitor_server();
        }
        else
        {

            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }


/// /////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="get_atm_new_comp")
    {
        session_start();
        $listHabill=array(24);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_atm_new_comp($_POST['profil']);
        }
        else
        {

            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }

/// /////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="get_atm_profil")
    {
        session_start();
        $listHabill=array(26);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_atm_profil($_POST['profil']);
        }
        else
        {

            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

     }
    /// /////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="get_bianire_profil_for_commande")
    {
        session_start();
        $listHabill=array(38);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_bianire_profil_for_commande($_POST['profil']);
        }
        else
        {

            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

     }
 /////////////////////////Partie Function/////////////////////////////////////// /////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="get_atm_comp")
    {
        session_start();
        $listHabill=array(24);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_atm_comp($_POST['profil'],$_POST['idatms'],$_POST['id_compaign']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

     }

 /////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="comm_atm_profil")
    {
        session_start();
        $listHabill=array(27);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            comm_atm_profil($_POST['profil']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
/////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="get_bianire_profil")
    {
        session_start();
        $listHabill=array(35);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_bianire_profil($_POST['profil']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
/////////////////////////Partie Function////////////////////////////////////
/// /////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="get_bianire_profil_echoues")
    {
        session_start();
        $listHabill=array(36);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_bianire_profil_echoues($_POST['profil']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
/////////////////////////Partie Function////////////////////////////////////
    if($_POST['function']=="get_bianire_profil_for_mode_execution")
    {
        session_start();
        $listHabill=array(36);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_bianire_profil_for_mode_execution($_POST['profil']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
///////////////////////////////////////////////////////////////

    if($_POST['function']=="getjournalATM")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {

            getjournalATM($_POST['id_atm'],$_POST['terminalID']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
///////////////////////////////////////////////////////////////
/// ///////////////////////////////////////////////////////////////

    if($_POST['function']=="TraitMassive")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {

            //var_dump("idatms : ".$_POST['idatms']);
            TraitMassive($_POST['idincid']);

        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
///////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////////////////////

    if($_POST['function']=="getdeconATM")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {

            getdeconATM($_POST['id_atm']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
///////////////////////////////////////////////////////////////

if($_POST['function']=="get_supprimer_incident")
{
    session_start();

    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        get_supprimer_incident($_POST['id_atm']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
///////////////////////////////////////////////////////////////
if($_POST['function']=="getcommandeATM")
{
    session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getcommandeATM($_POST['id_atm'],$_POST['terminalID'],$_POST['idprivilege']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////

    if($_POST['function']=="get_scren_incident")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
           // var_dump($_POST['id_atm']);
            //var_dump($_POST['terminalID']);
            get_scren_incident($_POST['id_atm'],$_POST['terminalID']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
/////////////////////////////////////////////////////////////
if($_POST['function']=="getallcommandATM")
{
    session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {

        getallcommandATM($_POST['id_atm'],$_POST['idprivilege']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
if($_POST['function']=="get_all_scren_incident")
{
    session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {

        get_all_scren_incident($_POST['id_atm']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
/////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////

    if($_POST['function']=="getTraitMassive")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            getTraitMassive();
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }
    }
//////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////

    if($_POST['function']=="getjournalATMdate")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            getjournalATMdate($_POST['id_atm'],$_POST['terminalID'],$_POST['dated'],$_POST['datef'],$_POST['idev'],$_POST['idev2'],$_POST['idev3'],(int) $_GET['page']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }
    }
//////////////////////////////////////////////////////////////////////

if($_POST['function']=="Show_All_Image_Comp")
{
    session_start();
    $listHabill=array(24);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        Show_All_Image_Comp($_POST['id_compaign'],$_POST['id_image'],$_POST['name_compaign'],(int) $_GET['page']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
//////////////////////////////////////////////////////////////////////

if($_POST['function']=="ShowScreenshotATM")
{
    session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {

        ShowScreenshotATM($_POST['ATM'],$_POST['value_cmd'],(int) $_GET['page']);
    }
    else
    {
        echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
        session_destroy();
        // http_response_code(401);
    }

}
//////////////////////////////////////////////////////////////////////

    if($_POST['function']=="getDetail_Compagnes_success")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            getDetail_Compagnes_success($_POST['id_compaign'],$_POST['name_compaign']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
    //////////////////////////////////////////////////////////////////////

    if($_POST['function']=="getDetail_Compagnes_not_yet")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            getDetail_Compagnes_not_yet($_POST['id_compaign'],$_POST['name_compaign']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
    //////////////////////////////////////////////////////////////////////

    if($_POST['function']=="getDetail_Compagnes_non_déployée")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            getDetail_Compagnes_non_déployée($_POST['id_compaign'],$_POST['name_compaign']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }    //////////////////////////////////////////////////////////////////////

    if($_POST['function']=="getDetail_Compagnes_Time_out")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            getDetail_Compagnes_Time_out($_POST['id_compaign'],$_POST['name_compaign']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
    if($_POST['function']=="Show_MyModal_Image")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            Show_MyModal_Image($_POST['id_compaign'],$_POST['id_image']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
//////////////////////////////////////////////////////////////////////

    if($_POST['function']=="getconfigevrnt")
    {
        session_start();
        $listHabill=array(9);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            $return=getconfigevrnt($_POST['aldiv']);
            $return=true;
            if($return==true)
            {
                echo'<div class="col-sm-12" ><br>
                    <div class="alert alert-success" align="center"> <strong>Mise à jour enregistrée </strong></div>
                </div>';
            }
            else
            {
                echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Aucune Mise à jour enregistrée </strong></div>
		  </div>';

            }
        }
        else
        {
            echo '<div class="col-sm-12" ><br>
            <div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div> 
            </div>';
            session_destroy();
            // http_response_code(401);
        }


    }
//////////////////////////////////////////////////////////////////////
    if($_POST['function']=="deletconfigevent")
    {
        session_start();

        $listHabill=array(9);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            deletconfigevent($_POST['d_name_event']);
            getallcongjrn();
        }
        else
        {
            echo '<div class="col-sm-12" ><br>
            <div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div> 
            </div>';
            session_destroy();
            // http_response_code(401);
        }


    }

//////////////////////////////////////////////////////////////////////
     if($_POST['function']=="getallcongjrn")
        {
            session_start();
            getallcongjrn();
        }

////////////////////////////////////////////////////////////////////////
if($_POST['function']=="ajouterintervention")
{
    session_start();
    $listHabill=array(33);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        ajouterintervention($_POST['intervention'],$_POST['categ'],$_POST['note']);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
        $encoded = json_encode($responseArray);
        header('Content-Type: application/json');
        echo $encoded;
        session_destroy();
        // http_response_code(401);
    }
}
//////////////////////////////////////////////////////////////////////
    if($_POST['function']=="update_mail_auto")
    {
        session_start();
        $listHabill=array(33);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            update_mail_auto($_POST['auto_mail'],$_POST['id_intevention']);
        }
        else
        {
            echo '<div class="col-sm-12" ><br>
            <div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div> 
            </div>';
            session_destroy();
            // http_response_code(401);
        }

    }
//////////////////////////////////////////////////////////////////////
    if($_POST['function']=="update_retrait_argent")
    {
        session_start();
        $listHabill=array(33);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            update_retrait_argent($_POST['retrait_argent'],$_POST['id_intevention']);
        }
        else
        {
            echo '<div class="col-sm-12" ><br>
            <div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div> 
            </div>';
            session_destroy();
            // http_response_code(401);
        }

    }
//////////////////////////////////////////////////////////////////////
    if($_POST['function']=="update_depot_argent")
    {
        session_start();
        $listHabill=array(33);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            update_depot_argent($_POST['depot_argent'],$_POST['id_intevention']);
        }
        else
        {
            echo '<div class="col-sm-12" ><br>
            <div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div> 
            </div>';
            session_destroy();
            // http_response_code(401);
        }

    }
//////////////////////////////////////////////////////////////////////
    if($_POST['function']=="update_depot_cheque")
    {
        session_start();
        $listHabill=array(33);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            update_depot_cheque($_POST['depot_cheque'],$_POST['id_intevention']);
        }
        else
        {
            echo '<div class="col-sm-12" ><br>
            <div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div> 
            </div>';
            session_destroy();
            // http_response_code(401);
        }

    }

//////////////////////////////////////////////////////////////////////
    if($_POST['function']=="update_autre_transactions")
    {
        session_start();
        $listHabill=array(33);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            update_autre_transactions($_POST['autre_transactions'],$_POST['id_intevention']);
        }
        else
        {
            echo '<div class="col-sm-12" ><br>
            <div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div> 
            </div>';
            session_destroy();
            // http_response_code(401);
        }

    }
//////////////////////////////////////////////////////////////////////
    if($_POST['function']=="update_categorie_intervention")
    {
        session_start();
        $listHabill=array(33);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            update_categorie_intervention($_POST['sel'],$_POST['id_intevention']);
        }
        else
        {
            echo '<div class="col-sm-12" ><br>
            <div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div> 
            </div>';
            session_destroy();
            // http_response_code(401);
        }


    }
//////////////////////////////////////////////////////////////////////
    if($_POST['function']=="delete_intervention")
    {
        session_start();
        $listHabill=array(33);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            delete_intervention($_POST['id_intevention']);
        }
        else
        {
            echo '<div class="col-sm-12" ><br>
            <div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div> 
            </div>';
            session_destroy();
            // http_response_code(401);
        }

    }
//////////////////////////////////////////////////////////////////////////
    if($_POST['function']=="get_modal_AjouterPost")
    {
        session_start();
        $listHabill=array(34);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_modal_AjouterPost();
        }
        else
        {
            echo '<div class="col-sm-12" ><br>
            <div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div> 
            </div>';
            session_destroy();
            // http_response_code(401);
        }

    }
//////////////////////////////////////////////////////////////////////////
     if($_POST['function']=="ajouterPost")
    {
        session_start();
        $listHabill=array(34);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            ajouterPost($_POST['region']);
            suivi_work_post();
        }
        else
        {
            echo '<div class="col-sm-12" ><br>
            <div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div> 
            </div>';
            session_destroy();
            // http_response_code(401);
        }

    }
//////////////////////////////////////////////////////////////////////////
     if($_POST['function']=="suppimer_work_post")
    {
        session_start();
        $listHabill=array(34);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            suppimer_work_post($_POST['id_post']);
            suivi_work_post();
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
//////////////////////////////////////////////////////////////////////////
    if($_POST['function']=="get_modal_modifier_work_post")
    {
        session_start();
        $listHabill=array(34);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            get_modal_modifier_work_post($_POST['id_post']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
//////////////////////////////////////////////////////////////////////////
    if($_POST['function']=="modifierPost")
    {
        session_start();
        $listHabill=array(34);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            modifierPost($_POST['id_post'],$_POST['name_poste'],$_POST['id_filiale']);
            suivi_work_post();
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
//////////////////////////////////////////////////////////////////////////
    if($_POST['function']=="getDashboardATM")
    {
        session_start();
        $listHabill=array(1,10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            getDashboardATM($_POST['id_atm']);
        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }

    }
//////////////////////////////////////////////////////////////////////////
if($_POST['function']==="getall_upload_content")
{
    session_start();
    $listHabill=array(24);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        getall_upload_content($_POST['id_atm'],$_POST['idprivilege']);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
        $encoded = json_encode($responseArray);
        header('Content-Type: application/json');
        echo $encoded;
        session_destroy();
        // http_response_code(401);
    }
}
//////////////////////////////////////////////////////////////////////////
if($_POST['function']==="DownloadFileATM")
{
    session_start();
    $listHabill=array(24);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        DownloadFileATM($_POST['id_atm'],$_POST['id_content'],$_POST['searchIDs']);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
        $encoded = json_encode($responseArray);
        header('Content-Type: application/json');
        echo $encoded;
        session_destroy();
        // http_response_code(401);
    }
}
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

    if($_POST['function']=="getAffectIncid_gab_ouv")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
            getAffectIncid_gab_ouv($_POST['terminal'],$_POST['id_insert'],$_POST['id_atm']);

        }
        else
        {
            echo '<div class="alert alert-danger" align="center"><strong>Action is not allowed</strong></div>';
            session_destroy();
            // http_response_code(401);
        }
    }
//////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
    if($_POST['function']=="Affect_Incid")
    {
        session_start();
        $listHabill=array(10);
        $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
        if(checkAuthJWT($token,$listHabill))
        {
 
			//var_dump($_POST['id_insert']);
            Affect_Incid($_POST['id_insert'],$_POST['idMotifTraiter']);
        }
        else
        {
            $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
            $encoded = json_encode($responseArray);
            header('Content-Type: application/json');
            echo $encoded;
            session_destroy();
            // http_response_code(401);
        }
    }
}
else
{	
header('Location: index.php');
}	

?>