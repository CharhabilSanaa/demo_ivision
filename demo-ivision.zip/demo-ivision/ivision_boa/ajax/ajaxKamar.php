<?php
 session_start(); 
if (!empty($_SESSION['user']) && !empty($_SESSION['mdp'])) 
{
include("../lib/lib.php");
error_reporting(1);
/////////////////////////Partie Function////////////////////////////////////


if($_POST['function']=="pingGab")   
{
    session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    $ipGAB=$_POST['ipGab'];
    $TerminalGAB=$_POST['terminal'];


    // $host = '192.168.0.126';
    $host = $ipGAB;

    $if_success=0;
    $if_executed=0;
    $value_cmd="";

    $port = 443;
    $waitTimeoutInSeconds = 1;

    //var_dump($token);
    if(checkAuthJWT($token,$listHabill))
    {
        $fp = fsockopen($host,$port,$errCode,$errStr,$waitTimeoutInSeconds);
        if ($fp)
        {
            $gabPing= 'OK';
            $if_success=1;
            $if_executed=1;
            $value_cmd="PING OK";
        }
        else
        {
            // It didn't work
            echo "<label style='color: #b70101' class='control-label'>$errStr($errCode)</label>";
            $gabPing= 'NOK';
            $if_success=0;
            $if_executed=2;
            $value_cmd="PING NOT OK  - $errStr($errCode)";
        }
        fclose($fp);

        historique_ping($TerminalGAB,$if_success,$if_executed,$value_cmd);
        echo"
        <div class='row'>
        <div class='col-sm-8'>
        <label  class='control-label'>Ping IP GAB ".$host." </label>
        </div>
        <div class='col-sm-4'>
        <label  class='control-label'>".$gabPing." </label>
        </div>
        </div>";
    }
    else
    {
        echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Action is not allowed </strong></div>
		  </div>';
        session_destroy();
        // http_response_code(401);
    }

}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="suprimerGabHorsService")   
{
    session_start();
    $listHabill=array(10);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        suprimerGabHorsServ($_POST['idAtm'],$_POST['user']);
    }
    else
    {
        $responseArray = array('type' => 'danger', 'message' => 'Action is not allowed');
        $encoded = json_encode($responseArray);
        header('Content-Type: application/json');
        echo $encoded;
        //session_destroy();
        // http_response_code(401);
    }


}
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="validerConfigPassiveProfil")
{
include("../pagination.php");
	session_start();
	$id_profile=$_POST['id_profile'];	
	$service=$_POST['service'];	
	$valuePassive=$_POST['valuePassive'];	
	
	$startDayPassive=$_POST['startDayPassive'];	
	$endDayPassive=$_POST['endDayPassive'];	
	$valuePassiveOut=$_POST['valuePassiveOut'];	

    $listHabill=array(9);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        $return=validerParamProfile($id_profile,$service,$valuePassive,$startDayPassive,$endDayPassive,$valuePassiveOut);


        if($return==true)
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-success" align="center"> <strong>Mise à jour bien enregistrée </strong></div>
		  </div>';

        }
        else
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Aucune mise à jour effectuée</strong></div>
		  </div>';

        }
    }
    else
    {
        echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Action is not allowed </strong></div>
		  </div>';
        session_destroy();
        // http_response_code(401);
    }
	

	
		
}

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="validerConfigTimeoutCommand")
{
include("../pagination.php");
	session_start();
	$id_command=$_POST['id_command'];	
	$parm_timeout_cmd=$_POST['parm_timeout_cmd'];	

	
		// echo "startDayPassive ".$startDayPassive;
		// echo "endDayPassive ".$endDayPassive;
		// echo "valuePassiveOut ".$valuePassiveOut;

    $listHabill=array(9);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        $return=validerTimeoutCommand($id_command,$parm_timeout_cmd);
        $return=true;

        if($return==true)
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-success" align="center"> <strong>Mise à jour bien enregistrée </strong></div>
		  </div>';

        }
        else
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Aucune mise à jour effectuée</strong></div>
		  </div>';
        }
    }
    else
    {
        echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Action is not allowed </strong></div>
		  </div>';
        session_destroy();
        // http_response_code(401);
    }

	
		
}

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="validerConfigTimeoutCompagn")
{
include("../pagination.php");
	session_start();
	
	$parm_timeout_compagn=$_POST['parm_timeout_compagn'];	

	
		// echo "startDayPassive ".$startDayPassive;
		// echo "endDayPassive ".$endDayPassive;
		// echo "valuePassiveOut ".$valuePassiveOut;

    $listHabill=array(9);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        $return=validerTimeoutCompagn($parm_timeout_compagn);
        $return=true;

        if($return==true)
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-success" align="center"> <strong>Mise à jour bien enregistrée </strong></div>
		  </div>';

        }
        else
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Aucune mise à jour effectuée</strong></div>
		  </div>';
        }
    }
    else
    {
        echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Action is not allowed </strong></div>
		  </div>';
        session_destroy();
        // http_response_code(401);
    }

}


//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
if($_POST['function']=="validerConfigIncident")
{
include("../pagination.php");
	session_start();


    $valsCheckedStatus=$_POST['valsCheckedStatus'];
    $atm_all=$_POST['atm_all'];
    $logicalName=$_POST['logicalName'];
    $idService=$_POST['idService'];
    $nomService=$_POST['nomService'];
    $listHabill=array(31);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        $return=updateConfig_fwDevice($idService,$nomService,$valsCheckedStatus,$atm_all,$logicalName);
        if($return==true)
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-success" align="center"> <strong>Mise à jour bien enregistrée </strong></div>
		  </div>';

        }
        else
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Aucune mise à jour effectuée</strong></div>
		  </div>';

        }
    }
    else
    {
        echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Action is not allowed </strong></div>
		  </div>';
        session_destroy();
        // http_response_code(401);
    }

	
		
}

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="validerConfigLogicalName")
{
include("../pagination.php");
	session_start();
	
	$atm_all=$_POST['atm_all'];	
	$logicalName=$_POST['logicalName'];	
	$idService=$_POST['idService'];	
	$nomService=$_POST['nomService'];	
	// echo "valsCheckedStatus ".$valsCheckedStatus."<br>";
	// echo "atm_all ".$atm_all."<br>";
	// echo "logicalName ".$logicalName."<br>";
	// echo "idService ".$idService."<br>";
	// echo "nomService ".$nomService."<br>";

    $listHabill=array(32);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        $return=updateConfig_logical_name($idService,$nomService,$atm_all,$logicalName);
        //$return=true;
        if($return==true)
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-success" align="center"> <strong>Mise à jour bien enregistrée </strong></div>
		  </div>';
        }
        else
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Aucune mise à jour effectuée</strong></div>
		  </div>';
        }
    }
    else
    {
        echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Action is not allowed </strong></div>
		  </div>';
        session_destroy();
        // http_response_code(401);
    }

	
		
}


//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="validerConfigPassiveGab")
{
    include("../pagination.php");

	session_start();
	$gab=$_POST['gab'];	
	$service=$_POST['service'];	
	
	$valuePassive=$_POST['valuePassive'];	
	$valuePassiveOut=$_POST['valuePassiveOut'];	
	
	$startPassiveGab=$_POST['startPassiveGab'];	
	$endPassiveGab=$_POST['endPassiveGab'];
    $listHabill=array(9);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        $return=validerParamGAB($gab,$service,$valuePassive,$startPassiveGab,$endPassiveGab,$valuePassiveOut);
        if($return==true)
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-success" align="center"> <strong>Mise à jour bien enregistrée </strong></div>
		  </div>';

        }
        else
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Aucune mise à jour effectuée</strong></div>
		  </div>';

        }
    }
    else
    {
        echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Action is not allowed </strong></div>
		  </div>';
        session_destroy();
        // http_response_code(401);
    }

	

		// echo "id_profile ".$id_profile;
		// echo "service ".$service;
		// echo "valuePassive ".$valuePassive;
		
}

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="validerConfigMontantGab")
{
    include("../pagination.php");
	session_start();
	$gab=$_POST['gab'];	
	$valueMontant=$_POST['valueMontant'];
    $listHabill=array(9);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        $return=validerParamMontantGAB($gab,$valueMontant);

        if($return==true)
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-success" align="center"> <strong>Mise à jour bien enregistrée </strong></div>
		  </div>';

        }
        else
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Aucune mise à jour effectuée</strong></div>
		  </div>';

        }
    }
    else
    {
        echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Action is not allowed </strong></div>
		  </div>';
        session_destroy();
        // http_response_code(401);
    }

		// echo "id_profile ".$id_profile;
		// echo "service ".$service;
		// echo "valuePassive ".$valuePassive;
		
}

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="validerConfigMontantProfil")
{
include("../pagination.php");

	session_start();
	$profil=$_POST['profilMontant'];	
	$valueMontant=$_POST['valueMontant'];
   //echo "<br>profil: ".$profil;	
    $listHabill=array(9);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        $return=validerParamMontantProfile($profil,$valueMontant);
        if($return==true)
        {
            echo'<div class="col-sm-12" ><br>
            <div class="alert alert-success" align="center"> <strong>Mise à jour bien enregistrée </strong></div>
            </div>';
        }
        else
        {
            echo'<div class="col-sm-12" ><br>
            <div class="alert alert-danger" align="center"> <strong>Aucune mise à jour effectuée</strong></div>
            </div>';
        }
    }
    else
    {
        echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Action is not allowed </strong></div>
		  </div>';
        session_destroy();
        // http_response_code(401);
    }

}

//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="validerConfigModeSuperviseurProfil")
{
include("../pagination.php");

	session_start();
	$profil=$_POST['profilSuperviseur'];	
	$valueSupervieur=$_POST['valueSuperviseur'];

    $listHabill=array(9);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        $return=validerParamSuperviseurModeProfile($profil,$valueSupervieur);

        if($return==true)
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-success" align="center"> <strong>Mise à jour bien enregistrée </strong></div>
		  </div>';

        }
        else
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Aucune mise à jour effectuée</strong></div>
		  </div>';

        }
    }
    else
    {
        echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Action is not allowed </strong></div>
		  </div>';
        session_destroy();
        // http_response_code(401);
    }
   //echo "<br>profil: ".$profil;	

		// echo "id_profile ".$id_profile;
		// echo "service ".$service;
		// echo "valuePassive ".$valuePassive;
		
		
		
}

//////////////////////////////////////////////////////////////////////
if($_POST['function']=="validerConfigModeSuperviseurGab")
{
include("../pagination.php");

	session_start();
	$gab=$_POST['gab'];	
	$valueSuperviseurGab=$_POST['valueSuperviseurGab'];

    $listHabill=array(9);
    $token = $_SERVER['HTTP_X_ACCESS_TOKEN'];
    if(checkAuthJWT($token,$listHabill))
    {
        $return=validerParamSuperviseurModeGAB($gab,$valueSuperviseurGab);
        if($return==true)
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-success" align="center"> <strong>Mise à jour bien enregistrée </strong></div>
		  </div>';

        }
        else
        {
            echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Aucune mise à jour effectuée</strong></div>
		  </div>';

        }
    }
    else
    {
        echo'<div class="col-sm-12" ><br>
			<div class="alert alert-danger" align="center"> <strong>Action is not allowed </strong></div>
		  </div>';
        session_destroy();
        // http_response_code(401);
    }

		// echo "id_profile ".$id_profile;
		// echo "service ".$service;
		// echo "valuePassive ".$valuePassive;
		
}
//////////////////////////////////////////////////////////////////////





}
else
{	
header('Location: index.php');
}	

?>