<?php
include "lib/auth/config.php";

?>
<!DOCTYPE html>
<html lang="<?php echo $lang['lang'];?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php include 'header_star.php'; ?>

</head>
<?php

if (verif_user($_SESSION['user'],$_SESSION['mdp'])==true): ?>
    <?php if ((verif_user($_SESSION['user'],$_SESSION['mdp'])==true) && ((verif_habilitation($_SESSION['autorisation_projet'],24)==true))): ?>

        <?php
        $profil =0;
        ?>

        <body class="c-app">

        <?php
        include 'sidebar.php';

        ?>
        <div class="c-wrapper c-fixed-components">
            <?php  include 'navbar_star.php'; ?>
            <div class="c-body">
                <main class="c-main">
                    <div class="container-fluid">
                        <div class="fade-in">
                            <input type="hidden" id="hdnSession" data-value="41"/>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="start.php">I-Vision</a></li>
                                    <li class="breadcrumb-item"><a href="start.php"><?php echo $lang['administrate'];?></a></li>
                                    <li class="breadcrumb-item" aria-current="page"><?php echo $lang['hist_dep_imd'];?></li>
                                </ol>
                            </nav>

                            <?php
                            if ((verif_habilitation($_SESSION['habilitation_backoffice'],41)==true)):
                            ?>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <form id="form_historique_deploiement" method="post" enctype="multipart/form-data">
                                                <div class="row d-flex justify-content-between">

                                                    <div class="col-md-4 search-box">
                                                        <input type="datetime-local" lang="en" id="dated" name="dated" class="form-control required" placeholder="Date début" required="">
                                                    </div>

                                                    <div class="col-md-4 search-box">
                                                        <input type="datetime-local" lang="en" id="datef" name="datef" class="form-control required" placeholder="Date début" required="">
                                                    </div>

                                                    <div class="col-md-2 search-box">
                                                        <input type="text" id="idatm" name="idatm"  class="form-control" <?php if(!empty($_POST["idatm"])){echo "value=".$_POST["idatm"].""; } ?> placeholder="ID" />

                                                    </div>
                                                    <div class="col-md-2 search-box">
                                                        <button class="btn btn-block btn-outline-primary my-2 my-sm-0" type="submit"><?php echo $lang['search'];  ?>
                                                            <svg class="c-icon float-right">
                                                                <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-cloud-upload"></use>
                                                            </svg>
                                                        </button>
                                                    </div>


                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row" >
                                <div class="col-lg-12">
                                    <div class="card">

                                        <div class="card-header"><i class="fa fa-align-justify"></i> <?php echo $lang['hist_dep_imd'];?>  :</div>
                                        <div class="card-body">
                                            <?php

                                                echo '
                                                <table id="his_p_i" class="table table-responsive-sm table-hover table-outline mb-0">
                                                    <thead class="thead-light">               
                                                        <th class="text-center">ID</th>
                                                        <th class="text-center">'. $lang['pict_name'].'</th>
                                                        <th class="text-center">'. $lang['path_img'].'</th>
                                                        <th class="text-center">'. $lang['dat_der_dep'].'</th>
                                                        <th class="text-center">'. $lang['date_dep'].'</th>
                                                        <th class="text-center">'. $lang['result'].'</th>
                                                    </thead>
                                                     <tbody id="tb_get_hist">';
                                                        get_hist_deplo();
                                                echo '</tbody>
                                                </table>
                                           

                                        </div>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>';
                                 else:
                                                echo '<div class="alert alert-danger text-center" role="alert">PAGE UNAUTHORIZED !!</div>';
                                            endif
                                            ?>
                                <!-- /.col-lg-4 (nested) -->

                                <!-- /.col-lg-8 (nested) -->
                            </div>

                        </div>
                    </div>
                </main>
            </div>

        </div>

        <?php

        //header NAV Bar
        include 'footer.php';

        ?>



        </body>

    <?php
    else:
        header("location: start.php");
    endif ?>
<?php
else:
    header("location: index.php");
endif ?>
</html>
